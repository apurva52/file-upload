import { Type } from '@angular/core';
import { Routes } from '@angular/router';
import { SettingsComponent } from '../settings/settings.component'; 
import { VersionControlComponent } from '../settings/version-control/version-control.component'; 
import { CasewareComponent } from '../settings/caseware/caseware.component';
import { RetentionComponent } from '../settings/retention/retention.component';
import { TagComponent } from '../settings/tag/tag.component';
import { AddtagComponent } from '../settings/tag/addtag/addtag.component';
import { AddRetentionComponent } from '../settings/retention/addretention/addretention.component';
import { FirmdocumentComponent } from '../settings/firmdocument/firmdocument.component';
import { GeneralComponent } from '../settings/general/general.component'
import { UserpreferencesComponent } from '../settings/userpreferences/userpreferences.component';
import { UserpreferenceDataTableComponent } from '../settings/userpreferences/userpreference-data-table/userpreference-data-table.component';
import { ViewComponent } from '../pdf/view.component';
import { OpenDocumentViewComponent } from '../onedrive/open-document-view/open-document-view.component';
import { DocumentsComponent } from '../documents/documents.component'
import { ClientDocumentsComponent } from '../module/client/client-documents/client-documents.component';
import { FirmDocumentsComponent } from '../module/firm/firm-documents/firm-documents.component';
import { ImportsComponent } from '../module/imports/imports/imports.component';
import { RecyclebinComponent } from '../module/recyclebin/recyclebin/recyclebin.component';
import { SpaceUsageChartComponent } from '../module/space-usage/space-usage-chart/space-usage-chart.component';
import { FoldertemplatesComponent } from '../settings/foldertemplates/foldertemplates.component';
import { ContactsTabComponent } from '../settings/foldertemplates/contacts-tab/contacts-tab.component';
import { JobsTabComponent } from '../settings/foldertemplates/jobs-tab/jobs-tab.component';
import { AddTemplatePopupComponent } from '../settings/foldertemplates/add-template-popup/add-template-popup.component';
import { FolderstructureComponent } from '../settings/foldertemplates/folderstructure/folderstructure.component';
import { SettingsDragDropComponent } from '../settings/foldertemplates/settings-drag-drop/settings-drag-drop.component';
import { AddRenamePopupComponent } from '../settings/foldertemplates/add-rename-popup/add-rename-popup.component';
import { SpaceUsageComponent } from '../module/space-usage/space-usage/space-usage.component';
import { ConversationsComponent } from '../module/conversations/conversations/conversations.component';
import { SpaceUsageModule } from '../module/space-usage/space-usage.module';




export const APP_COMPONENTS: Type<any>[] = [
    SettingsComponent,
    VersionControlComponent,
    CasewareComponent,
    RetentionComponent,
    AddRetentionComponent,
    TagComponent,
    AddtagComponent,
    FirmdocumentComponent,
    GeneralComponent,
    UserpreferencesComponent,
    UserpreferenceDataTableComponent,
    FoldertemplatesComponent,
    ContactsTabComponent,
    JobsTabComponent,
    AddTemplatePopupComponent,
    FolderstructureComponent,
    SettingsDragDropComponent,
    AddRenamePopupComponent
];

export const APP_ROUTES : Routes = [  
    { path: 'dms/settings/main', redirectTo: 'dms/settings', data: { release: 'beta' }},     
    { path: 'dms/settings', component: SettingsComponent, data: { release: 'beta' }},
    { path: 'dms/settings/versioncontrolsetting', redirectTo: 'dms/settings/version-control', data: { release: 'beta' } },
    { path: 'dms/settings/version-control', component: VersionControlComponent, data: { release: 'beta' } },
    { path: 'dms/settings/casewaresetting', redirectTo: 'dms/settings/caseware', data: { release: 'beta' } },
    { path: 'dms/settings/caseware', component: CasewareComponent, data: { release: 'beta' } },
    { path: 'dms/settings/retentionsetting', redirectTo: 'dms/settings/retention', data: { release: 'beta' } },
    { path: 'dms/settings/retention', component: RetentionComponent, data: { release: 'beta' } },
    { path: 'dms/settings/edittagssetting', redirectTo: 'dms/settings/tag', data: { release: 'beta' } },
    { path: 'dms/settings/tag', component: TagComponent , data: { release: 'beta' }},
    { path: 'dms/settings/firmdocumentssetting', redirectTo: 'dms/settings/firmdocument' , data: { release: 'beta' }},
    { path: 'dms/settings/firmdocument', component: FirmdocumentComponent, data: { release: 'beta' } },
    { path: 'dms/settings/generalsetting', component: GeneralComponent, data: { release: 'beta' } },
    { path: 'dms/settings/userpreferences', component: UserpreferencesComponent, data: { release: 'beta' } },
    { path: 'dms/settings/userpreferences/userpreference-data-table', component: UserpreferenceDataTableComponent, data: { release: 'beta' } },
    { path: 'dms/pdfview', component: ViewComponent, data: { release: 'beta' } },
    { path: 'dms/openofficeview', component: OpenDocumentViewComponent, data: { release: 'beta' } },
    { path: 'dms/home/main', component: DocumentsComponent, data: { release: 'beta' } },
   { path: 'dms/home/clientdocuments', component: ClientDocumentsComponent, data: { release: 'beta' }},
    { path: 'dms/home/firmdocument', component:FirmDocumentsComponent,data: { release: 'beta' }},
    { path: 'dms/home/imports', component:ImportsComponent,data: { release: 'beta' } },
    { path: 'dms/home/recyclebin', component: RecyclebinComponent,data: { release: 'beta' }},
    { path: 'dms/home/spaceusage', component:SpaceUsageComponent,data: { release: 'beta' }},
    { path: 'dms/home/spaceusagechart', component:SpaceUsageChartComponent,data: { release: 'beta' }},
    { path: 'dms/settings/foldertemplatessetting', redirectTo: 'dms/settings/foldertemplates', data: { release: 'beta' } },
    { path: 'dms/settings/foldertemplates', component: FoldertemplatesComponent, data: { release: 'beta' } },
    { path: 'dms/settings/folderstructure', redirectTo: 'dms/settings/foldertemplates/folderstructure', data: { release: 'beta' } },
    { path: 'dms/settings/foldertemplates/folderstructure', component: FolderstructureComponent, data: { release: 'beta' } },
    { path: 'dms/conversations', component:ConversationsComponent,data: { release: 'beta' }},

];
