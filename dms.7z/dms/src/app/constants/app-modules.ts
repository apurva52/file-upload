import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { LocalizationModule,
         IFirmCommonModule,
         IFirmDataTableModule,
         LoaderModule,
         IFirmDropdownButtonModule
        } from '@ifirm';

export const APP_MODULES = [
    CommonModule,
    LocalizationModule,
    IFirmCommonModule,
    ReactiveFormsModule,
    IFirmDataTableModule,
    FormsModule,
    LoaderModule,
    IFirmDropdownButtonModule
];