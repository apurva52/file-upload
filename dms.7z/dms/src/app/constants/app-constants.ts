export class AppConstants {
    public static maxVersionAllow: number = 999;
    public static minVersionAllow: number = 1;
    public static maxFileSize: number = 23333000;
    public static maxDmsTagLimit: number = 220;
    public static maxFileNameLength = 100;
    public static caseWareExtension: string = "ac_";
    public static disAllowedFileExtension = ".png,.gif,.jpg,.jpeg,.bmp,.jpe,.tif,.tiff,.pdf";
    public static disAllowedCompressedFileExtensions: ["zip", "rar", "tar", "iso", "cab", "shar", "7z", "arj"];
}


export enum retentionType {
    Default = 0,
    JobType = 1,
    Tag = 2,
    FirmFolder = 3
}

export enum firmFolder {
    InternalDocuments = 1,
    HRDocuments = 2,
    UserDocuemnts = 3
}

export enum eventType {
    Default = 0,
    FileUpload = 1,
    FolderCreate = 2,
    FileOpen = 3,
    Download = 4,
    Rename = 5,
    Delete = 6,
    Override = 7,
    PermanentDeleteVersion = 8,
    CopyVersion = 9,
    RevertVersion = 10,
    DownloadVersion = 11,
    MoveToRecycleBin = 12,
    Restore = 13,
    Copy = 14,
    Move = 15
}

export enum antivirusScanStatus {
    NotStarted = 0,
    Queued = 1,
    Success = 2,
    Fail = 3,
    Error = 4,
    InvalidExtension = 5
}

export enum DocumentKind {
    File = 1,
    Folder = 2
}

export enum NoteStatus {
    Unassigned = 1,
    Open = 2,
    Resolved = 3
}
export enum entityType {
    None = 0,
    Firm = 1,
    User = 2,
    Contact = 3,
    Job = 4,
    Migration = 5,
    Hr = 6
}

export enum documentType {
    Admin = 1
}

export enum fileSource {
    Desktop = 1,
    Portal = 2,
    Email = 3,
    Intranet = 4,
    DocOp = 5,
    OfficeAddin = 6,
    CopyDocument = 7,
    Import = 8,
    Tax = 9,
    OneDrive = 10,
    LinkUrl = 11
}

export enum fileKind {
    None = 0,
    File = 1,
    Folder = 2,
    Contact = 3
}

export enum OpenDocument {
    Both = 0,
    Deskstop = 1,
    Online = 2
}

export enum ApiValidationCode
{
    None = 0,
    Forbidden = 403,
    FileForceUnlocked = 1001,
    FileNotFound = 1002,
    FileLockExist = 1003,
    FileLockRename = 1004,
    FileLockDelete = 1005,
    FileLockUpload = 1006,
    OneDriveSettingInvalid = 1063,
    SameNameLinkUrlFileExists = 1066,
    FileNotScanned= 1050,
    FileInvalidExtension= 1013,
    FileQuarantined= 1038,
    AllFilesEitherQuarantinedOrInvalid = 1051,
    AllLinkFileInvalidExtension = 1067
}

export enum LockType {
    Local = 1,
    Shared = 2,
    PdfEdit = 3
}

export enum templateType {
    SystemTemplate = 1,
    CustomTemplate = 2,
    TaxTemplate = 3
}

export enum userFolderFilter{
    ShowMyUserFolder= 1,
    ShowAllUserFolders= 2,
    ShowActiveUserFolders= 3,
    ShowInactiveUserFolders= 4
}

export enum Search {
    TagSearch = 0,
    NoteSearch = 1,
    NoteDropdownVal = -999
}

export enum DMSFirmDocument{
    InternalDocuments = 1,
    HRDocuments = 6,
    User = 2
}

export enum FileExtensions{
    disAllowedFileExtensions = "exe, msi, bat, sh, js, vbs, ws, wsf, vb, sc, scr, pif, cmd, ps1, resx, ps1xml, ps2, ps2xml, psc1, psc2, bin, com, cpl, gadget, inf1, ins, inx, isu, job, jse, lnk, msc, msp, mst, paf, reg, sct, shb, shs, u3p, vbe, vbscript, wsh, url, dmsurllink, php, bin, chm, com, jar, jsp, mrc, msi, py, url, cs",
    disAllowedCompressedFileExtensions = "zip, rar, tar, iso, cab, shar, 7z, arj",
    allowedPdfEditingFileExtension = "png, gif, jpg, jpeg, bmp, jpe, tif, tiff, pdf", 
    officeFileExtensions = "DOCX, XLSX, PPTX, PPT, DOC, XLS",
    caseWareExtension = "ac_"
}

export enum pdfOpenWithApplication {
    Browser = "browser",
    LocalApplication = "localapplication"
}
export enum entityUrl {
    'dmsdocs'= '/#/crm/2/clientview/edit'
}