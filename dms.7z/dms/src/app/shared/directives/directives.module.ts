import { NgModule } from '@angular/core';
import { ScrollLoadMoreDirective } from './scroll-loadmore.directive';

@NgModule({
  imports: [],
  declarations: [ScrollLoadMoreDirective],
  exports: [ScrollLoadMoreDirective]
})
export class DirectivesModule { }