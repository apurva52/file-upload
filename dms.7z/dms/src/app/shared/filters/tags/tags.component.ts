import { Component, EventEmitter, HostListener, Input, OnChanges, OnInit, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LocalizationModule, ResourceService } from '@ifirm';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DmsFiltersService } from '../../../filter-components/dms-filters.service';
import { FilterAcceptanceCriteria, TagsResponse } from '../model/user.model';

@Component({
  selector: 'app-tags',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, LocalizationModule],
  templateUrl: './tags.component.html',
  styleUrls: ['./tags.component.scss']
})
export class TagsComponent implements OnInit, OnChanges {

  @Input() filterTags;
  @Input() callClearFilter;
  @Output() passTagsList = new EventEmitter();
  droppedDownOpened: boolean = false;
  selectedItem: string[] = [];
  TagList: TagsResponse[] = [];
  @Input() callApplyFilter;
  validateFilterEvent: FilterAcceptanceCriteria; 

  constructor(private dmsFilterService: DmsFiltersService, private resourceService: ResourceService) { }
  ngOnInit(): void {
    this.validateFilterEvent = this.dmsFilterService.tempDefaultFilter;
  }
  ngOnChanges(): void {
    this.TagList = this.filterTags;
    if (this.callClearFilter){
      this.clearAllSelectedData();
    }
    if (this.callApplyFilter){
      this.updateValidateFilterEventObj();
    }
  }
  itemSelectionChanged(item){
   this.updateTagsObj(item);
  }
  itemClicked(item){
    item.IsSelected = !item.IsSelected;
    this.updateTagsObj(item);
    return item
  }
  updateTagsObj(item){
    const index =  this.selectedItem.findIndex(element => element === item.TagId);
    if (!item.IsSelected){
      if (index >= 0){
        this.selectedItem.splice(index,1);
      }
    }else {
      if (index < 0){
        this.selectedItem.push(item.TagId);
      }
    }
    this.selectedItem = this.selectedItem.sort();
    this.passTagsList.emit(this.selectedItem)
  }
  openDropdownMenu($event: Event){
    // if (!this.droppedDownOpened){
    //   this.droppedDownOpened = true;
    // }
    this.droppedDownOpened = !this.droppedDownOpened;
    $event.stopPropagation();
  }
  clearAllSelectedData(){
    this.selectedItem = [];
    this.callClearFilter = false;
    this.TagList?.map(element => element.IsSelected = false);
    this.validateFilterEvent = this.dmsFilterService.tempDefaultFilter;
  }
  updateValidateFilterEventObj(){
    this.validateFilterEvent = this.dmsFilterService.tempDefaultFilter;
    this.callApplyFilter = false;
  }
  validateTags(){
    if (this.selectedItem?.length > 0 && 
      JSON.stringify(this.validateFilterEvent.TagList) !== JSON.stringify(this.selectedItem)){
        return true;
      }
  }

  updateSelectedCount(){
    const result = this.resourceService.getText('dms.filters.ntagsselected',[this.selectedItem?.length]);
    if (result){
      return result;
    }else {
      return '0 selected'
    }
  }

  @HostListener('document:click', ['$event']) closeDropdownMenu($event){
    this.droppedDownOpened = false;
  }
}
