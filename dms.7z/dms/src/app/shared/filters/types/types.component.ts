import { Component, CUSTOM_ELEMENTS_SCHEMA, EventEmitter, Input, OnChanges, OnInit, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormArray, FormBuilder, FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LocalizationModule } from '@ifirm';
import { of } from 'rxjs';

@Component({
  selector: 'app-types',
  standalone: true,
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  imports: [CommonModule,  ReactiveFormsModule, FormsModule, LocalizationModule],
  templateUrl: './types.component.html',
  styleUrls: ['./types.component.scss']
})
export class TypesComponent implements OnInit, OnChanges {

  @Input() fileExcollection;
  @Input() callClearFilter;
  @Output() passFileExtension = new EventEmitter();
  filtersType: FormGroup;
  dataType: any = [];
  constructor(private fb: FormBuilder) { }

  ngOnChanges(event): void {
    if (this.callClearFilter){
      this.clearAllSelectedData();
    }else {
      if (event?.callClearFilter){
        if (event?.callClearFilter?.currentValue && !event?.callClearFilter?.previousValue){
            (this.filtersType?.controls?.type as FormArray).clear();
            of(this.fetchData()).subscribe(dataSet => {
              this.dataType = dataSet;
              this.createCheckbox();
            });
          }
      }else {
        (this.filtersType?.controls?.type as FormArray).clear();
        of(this.fetchData()).subscribe(dataSet => {
          this.dataType = dataSet;
          this.createCheckbox();
        });
      }
    }
  }

  ngOnInit(): void {
    this.filtersType = this.fb.group({
      type: new FormArray([]),
    });
  }
  fetchData(){
    if (this.fileExcollection?.length === 0 && this.filtersType){
      (this.filtersType.controls?.type as FormArray).clear();
    }else if (this.fileExcollection === null && this.filtersType){
      (this.filtersType.controls?.type as FormArray).clear();
    }
    return this.fileExcollection;
  }
  createCheckbox(){
    this.dataType?.map((obj, ind)=>{
      const control = new FormControl();
      (this.filtersType.controls.type as FormArray).push(control)
    });
  }
  getControls() {
    return (this.filtersType.get('type') as FormArray).controls;
  }
  updateSelectedType(){
    const selectedOrderIds = this.filtersType.value.type
      .map((v, i) => v ? this.dataType[i].Id : null)
      .filter(v => v !== null);
      this.passFileExtension.emit(selectedOrderIds)
  }
  clearAllSelectedData(){
    this.filtersType?.reset();
    this.callClearFilter = false;
  }
}
