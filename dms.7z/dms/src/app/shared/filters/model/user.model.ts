import { PropertyName } from "@ifirm";

export class UserInfoResponse{
    constructor(){
        this.UserId = ''
        this.UserFullName = ''
    }
    @PropertyName('userId') UserId: string;
    @PropertyName('userFullName') UserFullName: string;
}
export class payLoadCommonModel {
    constructor() { }

    @PropertyName('EntityType') EntityType: null | number;
    @PropertyName('EntityId') EntityId: null | number;
    @PropertyName('FolderId') FolderId: null | number;
    @PropertyName('Hierarchy') Hierarchy: null;
    @PropertyName('SearchText') SearchText: string;
    @PropertyName('SearchNote') SearchNote: string;
    @PropertyName('Page') Page: number;
    @PropertyName('SortColumn') SortColumn: string;
    @PropertyName('SortOrder') SortOrder: string;
    @PropertyName('IsFiltering') IsFiltering: boolean;
    @PropertyName('IsDeleted') IsDeleted: boolean;
    @PropertyName('IsOnlyUserFolderFiltering') IsOnlyUserFolderFiltering: boolean;
    @PropertyName('DisplayArea') DisplayArea: number;
    @PropertyName('HasMoreEntityRecords') HasMoreEntityRecords: boolean;
    @PropertyName('HasMoreRecords') HasMoreRecords: boolean;
    @PropertyName('ContentSearchOffset') ContentSearchOffset: any;
    @PropertyName('IsFileSearch') IsFileSearch: boolean;
    @PropertyName('SearchMore') SearchMore: boolean;
    @PropertyName('IsContentSearch') IsContentSearch?: boolean;
    @PropertyName('IsPurgeDate') IsPurgeDate?: boolean;
    @PropertyName('Filters') Filters: FilterAcceptanceCriteria;
    @PropertyName('SearchTags') SearchTags: SearchTagCriteria;
    @PropertyName('FolderName') FolderName? :string;
}

export class FilterAcceptanceCriteria {
    constructor() { }
    @PropertyName('DateFrom') DateFrom: string;
    @PropertyName('DateTo') DateTo: string;
    @PropertyName('IsJobClosed') IsJobClosed: string;
    @PropertyName('FileTypes') FileTypes: string[];
    @PropertyName('UserId') UserId: string;
    @PropertyName('TagList') TagList: string[];
    @PropertyName('JobTypeTagList') JobTypeTagList: any;
    @PropertyName('ContactsTagList') ContactsTagList: any;
    @PropertyName("FirmSystemTag") FirmSystemTag: string;
    @PropertyName('ContactGroupId') ContactGroupId: string;
    @PropertyName('IsArchivedContacts') IsArchivedContacts: boolean;
    @PropertyName('ShowArchivedContactsCheckBox') ShowArchivedContactsCheckBox: boolean;
    @PropertyName('ShowInActiveUserCheckBox') ShowInActiveUserCheckBox: boolean;
    @PropertyName('IsInActiveUser') IsInActiveUser: boolean;
    @PropertyName('ContactList') ContactList: string[];
    @PropertyName('MyRecentFiles') MyRecentFiles: boolean;
    @PropertyName('UserFolders') UserFolders: number;
    @PropertyName('NoteStatus') NoteStatus: string;
    @PropertyName('NoteAssignTo') NoteAssignTo: string;
    @PropertyName('NoteCreatedBy') NoteCreatedBy: string;
    @PropertyName('NoteDueDate') NoteDueDate: string;
    @PropertyName('IsFilterPortalTag') IsFilterPortalTag: boolean;
}

export class SearchTagCriteria {
    constructor() { }
    @PropertyName('Tags') Tags: any;
    @PropertyName('JobTypeTags') JobTypeTags: any;
    @PropertyName('ContactsTypeTags') ContactsTypeTags: any;
    @PropertyName('PermentContactsTagType') PermentContactsTagType: number;
    @PropertyName('PermentTagType') PermentTagType: number;
    @PropertyName('IsSearchPortalTag') IsSearchPortalTag: boolean;
}

export class UserListPayload{
    @PropertyName('IncludeSystemUser') IncludeSystemUser: boolean;
    @PropertyName('IsInactiveUser') IsInactiveUser: boolean;
    @PropertyName('PageNumber') PageNumber: number | string;
    @PropertyName('PageSize') PageSize: number | string;
    @PropertyName('SearchText') SearchText: string;
}

export class ContactGroupPayload{
    @PropertyName('PageNumber') PageNumber: number | string;
    @PropertyName('PageSize') PageSize: number | string;
    @PropertyName('SearchText') SearchText: string;
}
export class ContactListPayload{
    @PropertyName('ContactGroupId') ContactGroupId: string;
    @PropertyName('IsArchivedContact') IsArchivedContact: boolean;
    @PropertyName('PageNumber') PageNumber: number | string;
    @PropertyName('PageSize') PageSize: number | string;
    @PropertyName('SearchText') SearchText: string;
}
export class UserListResponse{
    @PropertyName('Base64Photo') Base64Photo: string;
    @PropertyName('CanAddContact') CanAddContact: boolean;
    @PropertyName('CanEditContact') CanEditContact: number | string;
    @PropertyName('CanUploadDocument') CanUploadDocument: number | string;
    @PropertyName('FirstName') FirstName: string;
    @PropertyName('FullName') FullName: string;
    @PropertyName('LastName') LastName: boolean;
    @PropertyName('ProfilePhoto') ProfilePhoto: number | string;
    @PropertyName('UserId') UserId: number | string;
    @PropertyName('UserName') UserName: string;
}

export class ContactGroupResponse{
    @PropertyName('ContactGroupId') ContactGroupId: string;
    @PropertyName('ContactGroupName') ContactGroupName: string;
    @PropertyName('GroupType') GroupType: number | string;
}
export class ContactListResponse{
    @PropertyName('ContactId') ContactId: string | number;
    @PropertyName('ContactCode') ContactCode: string;
    @PropertyName('ContactName') ContactName: string;
    @PropertyName('IsSelected') IsSelected: boolean;
}
export class myRecentActivityAction{
    @PropertyName('event') event: boolean;
    data: payLoadCommonModel;
}

export class FileTypeResponse{
    @PropertyName('Id') Id: string | number;
    @PropertyName('GroupName') GroupName: string;
    @PropertyName('Extension') Extension: string;
    @PropertyName('FileExtensionId') FileExtensionId: string | number;
    @PropertyName('ResourceKey') ResourceKey: string;
}
export class TagsListResponse{
    TagList: TagsResponse[];
}
export class TagsResponse{
    @PropertyName('TagId') TagId: string | number;
    @PropertyName('TagIdForMapping') TagIdForMapping: string;
    @PropertyName('TagNameForDisplay') TagNameForDisplay: string;
    @PropertyName('TagNameLanguage1') TagNameLanguage1: string ;
    @PropertyName('ShowTag') ShowTag: boolean;
    @PropertyName('SortOrder') SortOrder: number;
    @PropertyName('IsSystemTag') IsSystemTag: boolean;
    @PropertyName('CreatedBy') CreatedBy: number;
    @PropertyName('CreatedDateTime') CreatedDateTime: string ;
    @PropertyName('UpdatedBy') UpdatedBy: number;
    @PropertyName('UpdatedDateTime') UpdatedDateTime: string;
    @PropertyName('IsDisabled') IsDisabled: boolean;
    @PropertyName('IsSelected') IsSelected: boolean;
}
export class BindContactGroup{
    @PropertyName('pageNumber') pageNumber: number;
    @PropertyName('items') items: ContactGroupResponse[];
    @PropertyName('searchText') searchText: string;
}
export class BindContactList{
    @PropertyName('pageNumber') pageNumber: number;
    @PropertyName('items') items: ContactListResponse[];
    @PropertyName('searchText') searchText: string;
}
export class BindUserList{
    @PropertyName('pageNumber') pageNumber: number;
    @PropertyName('items') items: UserListResponse[];
    @PropertyName('searchText') searchText: string;
}
export class BindCreatedByUserList{
    @PropertyName('pageNumber') pageNumber: number;
    @PropertyName('items') items: UserListResponse[];
    @PropertyName('searchText') searchText: string;
}
export class BindAssignToUserList{
    @PropertyName('pageNumber') pageNumber: number;
    @PropertyName('items') items: UserListResponse[];
    @PropertyName('searchText') searchText: string;
}
export class GridDropdownPayload{
    @PropertyName('columnId') columnId: string;
    @PropertyName('column1') column1: string;
    @PropertyName('column2') column2: string;
    @PropertyName('searchWaterMark') searchWaterMark: string;
    @PropertyName('column1DisplayName') column1DisplayName: any;
    @PropertyName('column2DisplayName') column2DisplayName: any;
    @PropertyName('noDataFoundDisplayName') noDataFoundDisplayName: any;
    @PropertyName('pageSize') pageSize: number;
    @PropertyName('isMultiSelect') isMultiSelect: boolean;
    @PropertyName('column1Width') column1Width: number;
    @PropertyName('column2Width') column2Width: number;
    @PropertyName('ownId') ownId: string;
    @PropertyName('isBlueCss') isBlueCss: boolean;
    @PropertyName('searchCallbackFunction') searchCallbackFunction: any;
    @PropertyName('loadMoreDisplayName') loadMoreDisplayName: string;
    @PropertyName('onlyDisplayColumn1') onlyDisplayColumn1: boolean;
    @PropertyName('itemChangedCallback') itemChangedCallback: any;
    @PropertyName('initialLoadCallbackFunction') initialLoadCallbackFunction: any;
}