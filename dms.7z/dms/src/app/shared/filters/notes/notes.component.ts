import { ChangeDetectorRef, Component, CUSTOM_ELEMENTS_SCHEMA, EventEmitter, Input, OnChanges, OnInit, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { IFirmDatePickerModule, LocalizationModule, ResourceService } from '@ifirm';
import { NoteStatus } from '../../../constants/app-constants';
import { DmsFiltersService } from '../../../filter-components/dms-filters.service';
import { IfirmGridDropdownModule } from 'projects/ifirm-common-components/src/lib/ifirm-dropdown-checkbox/ifirm-grid-dropdown.module';
import { BindAssignToUserList, BindCreatedByUserList, FilterAcceptanceCriteria, GridDropdownPayload } from '../model/user.model';

@Component({
  selector: 'app-notes',
  standalone: true,
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  imports: [CommonModule, IFirmDatePickerModule, ReactiveFormsModule, FormsModule, LocalizationModule, IfirmGridDropdownModule],
  templateUrl: './notes.component.html',
  styleUrls: ['./notes.component.scss']
})
export class NotesComponent implements OnInit, OnChanges {

  @Output() passNotesResponse = new EventEmitter();
  @Input()createdByUser;
  @Input()assignToUserList;
  @Input() callClearFilter;
  refreshContactList: boolean = false;
  @Output() passContactSearchData = new EventEmitter();
  notesStatus: any = [];
  bindCreatedByUserData: BindAssignToUserList;
  bindAssignToUserData: BindCreatedByUserList;
  selectedAssignToUserId: string[] = [];
  selectedCreatedByUserId: string[] = [];
  createdByHeaderObj: GridDropdownPayload;
  assignToHeaderObj: GridDropdownPayload; 
  notesForm: FormGroup;
  selectedStatus = null;
  refreshData: boolean = false;
  @Input() callApplyFilter;
  validateFilterEvent: FilterAcceptanceCriteria; 
  assignToText: string = '';
  createdByText: string = '';

  constructor(private fb: FormBuilder, private resourceManager: ResourceService, private dmsFilterService: DmsFiltersService, private cdr: ChangeDetectorRef) { }

  searchCreatedbyCallbackFunction = (searchText, pageNumber, pageSize, ownId) =>{
    var getContactListContract = {
        ContactGroupId: '',
        IsArchivedContact: true,
        PageSize: pageSize,
        PageNumber: pageNumber,
        SearchText: searchText
    }
    if (this.createdByText !== '' && searchText ==='' || this.createdByText === '' && searchText !==''
    || this.createdByText !== '' && searchText !==''){
      this.createdByText = searchText;
      this.shareSearchData(getContactListContract, 'contactCreatedByApi', ownId)
    }
  }
  createdByCallBack = (createdByList) =>{
    this.selectedCreatedByUserId = createdByList
    const selectedAssignTo = this.selectedCreatedByUserId?.length > 0 ? this.selectedCreatedByUserId[0] : '';
    this.notesForm.controls['createdBy'].setValue(selectedAssignTo);
    this.passNotesData();
  };
  searchAssigntoCallbackFunction = (searchText, pageNumber, pageSize, ownId) =>{
    var getContactListContract = {
        ContactGroupId: '',
        IsArchivedContact: true,
        PageSize: pageSize,
        PageNumber: pageNumber,
        SearchText: searchText
    }
    if (this.assignToText !== '' && searchText ==='' || this.assignToText === '' && searchText !==''
    || this.assignToText !== '' && searchText !==''){
      this.assignToText = searchText;
      this.shareSearchData(getContactListContract, 'contactAssignToApi', ownId)
    }
  }
  assigntoCallBack = (assigntoList) =>{
    this.selectedAssignToUserId  = assigntoList;
    const selectedAssignTo = this.selectedAssignToUserId?.length > 0 ? this.selectedAssignToUserId[0] : '';
    this.notesForm.controls['assignTo'].setValue(selectedAssignTo);
    this.passNotesData();
  };
  
  ngOnChanges(): void {
    this.bindCreatedByUserData = {
      pageNumber: 200,
      items: this.createdByUser,
      searchText: this.createdByText
    }
    this.bindAssignToUserData = {
      pageNumber: 200,
      items: this.assignToUserList,
      searchText: this.assignToText
    }
    this.objInitialize();
    if (this.callClearFilter){
      this.clearAllSelectedData();
    }
    if (this.callApplyFilter){
      this.updateValidateFilterEventObj();
    }
  }
  initialLoadCallbackFunction = (searchText, pageNumber, pageSize, ownId) =>{
    var getContactListContract = {
      ContactGroupId: '',
      IsArchivedContact: true,
      PageSize: pageSize,
      PageNumber: pageNumber,
      SearchText: searchText
  }
    this.createdByText = searchText;
    this.shareSearchData(getContactListContract,'contactCreatedByApi', ownId);

  }
  initialAssignToLoadCallbackFunction = (searchText, pageNumber, pageSize, ownId) =>{
    var getContactListContract = {
      ContactGroupId: '',
      IsArchivedContact: true,
      PageSize: pageSize,
      PageNumber: pageNumber,
      SearchText: searchText
  }
    this.assignToText = searchText;
    this.shareSearchData(getContactListContract,'contactAssignToApi', ownId);
  }
  ngOnInit(): void {
    this.validateFilterEvent = this.dmsFilterService.tempDefaultFilter;
    this.notesForm = this.fb.group({
      noteStatus: new FormControl(null, [Validators.required]),
      dueDate: new FormControl(null, [Validators.required]),
      assignTo: new FormControl(null, [Validators.required]),
      createdBy: new FormControl(null, [Validators.required])
    });
    this.createNotesStatus();
  }
  objInitialize(){
    this.createdByHeaderObj = {
      "columnId": "UserId",
      "column1": "UserName",
      "column2": "FullName",
      "searchWaterMark": this.resourceManager.get('dms.searchtag.search') + "...",
      "column1DisplayName": this.resourceManager.get('ifirm.common.user'),
      "column2DisplayName": this.resourceManager.get('ifirm.common.name'),
      "noDataFoundDisplayName": this.resourceManager.get('dms.searchtag.nodatafound'),
      "pageSize": 200,
      "isMultiSelect": false,
      "column1Width": 300,
      "column2Width": 300,
      "ownId": "dmsFilterCreatedBy",
      "isBlueCss": true,
      "searchCallbackFunction": this.searchCreatedbyCallbackFunction,
      "loadMoreDisplayName":'load More',
      "onlyDisplayColumn1": false,
      "itemChangedCallback": this.createdByCallBack,
      "initialLoadCallbackFunction": this.initialLoadCallbackFunction,
  }
    this.assignToHeaderObj = {
      "columnId": "UserId",
      "column1": "UserName",
      "column2": "FullName",
      "searchWaterMark": this.resourceManager.get('dms.searchtag.search') + "...",
      "column1DisplayName": this.resourceManager.get('ifirm.common.user'),
      "column2DisplayName": this.resourceManager.get('ifirm.common.name'),
      "noDataFoundDisplayName": this.resourceManager.get('dms.searchtag.nodatafound'),
      "pageSize": 200,
      "isMultiSelect": false,
      "column1Width": 300,
      "column2Width": 300,
      "ownId": "dmsFilterAssignTo",
      "isBlueCss": true,
      "searchCallbackFunction": this.searchAssigntoCallbackFunction,
      "loadMoreDisplayName":'load More',
      "onlyDisplayColumn1": false,
      "itemChangedCallback": this.assigntoCallBack,
      "initialLoadCallbackFunction": this.initialAssignToLoadCallbackFunction,
  }
  }
  
  updateFormValue(){
    this.passNotesData();
  }
  createNotesStatus(){
    this.notesStatus = 
    [{ Id: NoteStatus.Unassigned, value: this.resourceManager.get('dms.notestatusselect') },
    { Id: NoteStatus.Open, value: this.resourceManager.get('dms.notestatusopen') },
    { Id: NoteStatus.Resolved, value: this.resourceManager.get('dms.notestatusresolved') }]
  }
  updateStatus(event){
    this.notesForm.controls['noteStatus'].setValue(event);
    this.passNotesData();
  }
  passNotesData(){
    this.passNotesResponse.emit(this.notesForm.value)
  }
  clearAllSelectedData(){
    this.notesForm?.reset();
    this.validateFilterEvent = this.dmsFilterService.tempDefaultFilter;
    this.refreshData = true;
    this.refreshContactList = true;
    this.cdr.detectChanges();
    this.callClearFilter = false;
    this.selectedStatus = null;
    this.selectedAssignToUserId = [];
    this.selectedCreatedByUserId = [];
    this.resetPeriodEnded('#dueDateId');
  }
  updateRefreshKey(event){
    this.refreshData = false;
  }
  updatedEvent(event){
    this.refreshContactList = false;
  }
  resetPeriodEnded(datePickerParentDivId : string) {
    if(document.querySelector(datePickerParentDivId) && document.querySelector(datePickerParentDivId).querySelectorAll('button')[0])
    {
    document.querySelectorAll(datePickerParentDivId).forEach(x=> x.querySelectorAll('button')[0].click());
    }
  }
  updateValidateFilterEventObj(){
    this.validateFilterEvent = this.dmsFilterService.tempDefaultFilter;
    this.callApplyFilter = false;
  }
  validateNotesStatus(){
    if (this.validateFilterEvent.NoteStatus !== this.selectedStatus && this.selectedStatus !== null){
      return true;
    }
  }
  validateAssignToUserId(){
    if (this.selectedAssignToUserId?.length > 0 && this.validateFilterEvent.NoteAssignTo !== this.selectedAssignToUserId[0]){
      return true;
    }
  }
  validateCreatedByUserId(){
    if (this.selectedCreatedByUserId?.length > 0 && this.validateFilterEvent.NoteCreatedBy !== this.selectedCreatedByUserId[0]){
      return true;
    }
  }
  validateDueDate(){
    if (this.notesForm.controls['dueDate'].value  != null && this.notesForm.controls['dueDate'].value  != this.validateFilterEvent.NoteDueDate){
      return true;
    }
  }
  shareSearchData(sendEvent, type, ownId){
    const payload = {
      data: sendEvent,
      type,
      ownId
    }
    this.passContactSearchData.emit(payload);
  }
}



