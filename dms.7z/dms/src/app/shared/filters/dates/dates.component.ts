import {  ChangeDetectorRef, Component, CUSTOM_ELEMENTS_SCHEMA, ElementRef, EventEmitter, Input, OnChanges, OnDestroy, OnInit, Output } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { DateService } from 'projects/ifirm-common-components/src/lib/date-picker/date-picker/date-service';
import { IFirmDatePickerModule } from 'projects/ifirm-common-components/src/lib/date-picker/date-picker.module';
import { FormBuilder, FormControl, FormGroup, FormsModule, NG_VALUE_ACCESSOR, ReactiveFormsModule, Validators } from '@angular/forms';
import { GridColumnModel, LocalizationModule, ResourceService } from '@ifirm';
import { DmsFiltersService } from '../../../filter-components/dms-filters.service';
import { Subscription } from 'rxjs';
import { IfirmGridDropdownModule } from 'projects/ifirm-common-components/src/lib/ifirm-dropdown-checkbox/ifirm-grid-dropdown.module';
import { BindUserList, FilterAcceptanceCriteria, GridDropdownPayload, UserListResponse } from '../model/user.model';


@Component({
  selector: 'app-dates',
  templateUrl: './dates.component.html',
  styleUrls: ['./dates.component.scss'],
  standalone: true,
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  providers: [DateService, DatePipe,
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: DatesComponent,
      multi: true,
    },],
  imports: [CommonModule,  IFirmDatePickerModule, ReactiveFormsModule, FormsModule, LocalizationModule, IfirmGridDropdownModule],

})
export class DatesComponent implements OnInit, OnChanges, OnDestroy {

  @Output() passLastSectionData = new EventEmitter();
  @Output() passSearchByData = new EventEmitter();
  @Input()userList;
  @Input()emailAddressList;
  @Input() callClearFilter;
  @Input() selectedIndex;
  bindUserData: BindUserList;
  refreshContactList: boolean = false;
  getchUserList: UserListResponse[] = [];
  selectedId: string[] = [];
  tableHeaderObj: GridDropdownPayload ;
  dateForm: FormGroup;
  refreshData: boolean = false;
  subscription: Subscription;
  @Input() callApplyFilter;
  validateFilterEvent: FilterAcceptanceCriteria; 
  userByText: string = '';
  selectedStartDate: Date = null
  selectedEndDate: Date = null;
  dataSet = null;
  updateDisable: boolean = false;

  constructor(private fb: FormBuilder, private resourceManager: ResourceService, private dmsFilterService: DmsFiltersService, private cdr: ChangeDetectorRef) { 
    this.subscription = this.dmsFilterService.updateDateSection.subscribe(res => {
      this.updateMyRecentActivity(res);
    })
  }
  ngOnDestroy(): void {
    this.subscription?.unsubscribe();
  }

  searchContactCallbackFunction = (searchText, pageNumber, pageSize, ownId) => {
    var getUserByContract = {
        ContactGroupId: '',
        IsArchivedContact: true,
        PageSize: pageSize,
        PageNumber: pageNumber,
        SearchText: searchText
    }
    if (this.userByText !== '' && searchText ==='' || this.userByText === '' && searchText !==''
      || this.userByText !== '' && searchText !==''){
      this.userByText = searchText;
      this.shareSearchData(getUserByContract,'userByApiCall', ownId);
    }
  }
  initialLoadCallbackFunction = (searchText, pageNumber, pageSize, ownId) =>{
    var getContactListContract = {
      ContactGroupId: '',
      IsArchivedContact: true,
      PageSize: pageSize,
      PageNumber: pageNumber,
      SearchText: searchText
  }
    this.userByText = searchText;
    this.shareSearchData(getContactListContract,'userByApiCall', ownId);
  }
  shareSearchData(sendEvent, type, ownId){
    const payload = {
      data: sendEvent,
      type,
      ownId
    }
    this.passSearchByData.emit(payload);
  }
  contactsChangedCallback = (selectedId) =>{
    this.selectedId = selectedId;
    const selectedUser = this.selectedId?.length > 0 ? this.selectedId[0] : '';
    this.dateForm.controls['selectedUser'].setValue(selectedUser);
    this.updateDropdownValue('ByUser');
  }
  ngOnChanges(): void {
    this.getchUserList = this.userList;
    this.bindUserData = {
      pageNumber: 200,
      items: this.getchUserList,
      searchText: this.userByText
    }
    this.objInitialize();
    if (this.callClearFilter){
      this.clearAllSelectedData();
    }
    if (this.callApplyFilter){
      this.updateValidateFilterEventObj();
    }
  }
  ngOnInit(): void {
    this.validateFilterEvent = this.dmsFilterService.tempDefaultFilter;
    this.dateForm = this.fb.group({
      activeUser: new FormControl(null, [Validators.required]),
      attachment: new FormControl(null),
      startDate: new FormControl(null, [Validators.required]),
      endDate: new FormControl(null, [Validators.required]),
      savedstartDate:new FormControl(null),
      savedendDate: new FormControl(null),
      selectedUser: new FormControl('', [Validators.required]),
      userId : new FormControl(''),
      emailid :new FormControl('')
    });
  }
  objInitialize(){
    this.tableHeaderObj = {
      "columnId": "UserId",
      "column1": "UserName",
      "column2": "FullName",
      "searchWaterMark": this.resourceManager.get('dms.searchtag.search') + "...",
      "column1DisplayName": this.resourceManager.get('ifirm.common.user'),
      "column2DisplayName": this.resourceManager.get('ifirm.common.name'),
      "noDataFoundDisplayName": this.resourceManager.get('dms.searchtag.nodatafound'),
      "pageSize": 200,
      "isMultiSelect": false,
      "column1Width": 300,
      "column2Width": 300,
      "ownId": "dmsFilterBySelections",
      "isBlueCss": true,
      "searchCallbackFunction": this.searchContactCallbackFunction,
      "loadMoreDisplayName":'load More',
      "onlyDisplayColumn1": false,
      "itemChangedCallback": this.contactsChangedCallback,
      "initialLoadCallbackFunction": this.initialLoadCallbackFunction
  }
  }
  updateFormValue(){
    this.updateDropdownValue('Dates');
  }
 
  updateInactiveUsersfield(showInactiveUsers): void{
    this.dateForm.controls['activeUser'].setValue(showInactiveUsers);
    this.dateForm.controls['attachment'].setValue(showInactiveUsers);
    this.dateForm.controls['selectedUser'].setValue('');
    this.refreshContactList = true;
    this.cdr.detectChanges();
    this.updateDropdownValue('activeUser');
  }

  updateDropdownValue(eventfrom){
    const event = {
      data: this.dateForm.value,
      eventfrom
    }
    console.log(event)
    this.passLastSectionData.emit(event)
  }
  clearAllSelectedData(){
    this.dateForm?.reset();
    this.selectedId = [];
    this.updateDisable = false;
    this.dataSet =  null;
    this.selectedStartDate = null;
    this.selectedEndDate = null;
    this.refreshData = true;
    this.cdr.detectChanges();
    this.callClearFilter = false;
    this.resetPeriodEnded('#startDateId');
    this.resetPeriodEnded('#endDateId');
    this.validateFilterEvent = this.dmsFilterService.tempDefaultFilter;
  }
  updateRefreshKey(event){
    this.refreshData = false;
  }
  updatedEvent(event){
    this.refreshContactList = false;
  }
  resetPeriodEnded(datePickerParentDivId : string) {
    if(document.querySelector(datePickerParentDivId) && document.querySelector(datePickerParentDivId).querySelectorAll('button')[0])
    {
    document.querySelectorAll(datePickerParentDivId).forEach(x=> x.querySelectorAll('button')[0].click());
    }
  }

  updateMyRecentActivity(response){
    if (response?.event === true){
    this.selectedStartDate = new Date(response?.data.Filters.DateFrom);
    this.selectedEndDate = new Date(response?.data.Filters.DateTo);
    
    this.dataSet =  {
      id: response?.data.Filters.UserId,
      name: this.dmsFilterService.userFullName
    }
    this.updateDisable = true;
    this.selectedId = [];
    }else {
    this.selectedStartDate = null;
    this.selectedEndDate = null;
    this.selectedId = [];
    this.dateForm.controls['selectedUser'].setValue('');
    this.resetPeriodEnded('#startDateId');
    this.resetPeriodEnded('#endDateId');
    this.dataSet =  null;
    this.updateDisable = false;
    }
  }
  updateValidateFilterEventObj(){
    this.validateFilterEvent = this.dmsFilterService.tempDefaultFilter;
    this.callApplyFilter = false;
  }
  validateActiveUser(){
    if (this.dateForm.controls['activeUser'].value !== this.validateFilterEvent.IsInActiveUser
    && this.dateForm.controls['activeUser'].value !== null){
      return true;
    }
  }
  validateByUser(){
    if (this.selectedId?.length > 0 && this.validateFilterEvent.UserId !== this.selectedId[0]){
      return true;
    }
  }
  validateStartDate(){
    if (this.dateForm.controls['startDate'].value  != null && this.dateForm.controls['startDate'].value  != this.validateFilterEvent.DateFrom){
      return true;
    }
  }
  validateEndDate(){
    if (this.dateForm.controls['endDate'].value  != null && this.dateForm.controls['endDate'].value  != this.validateFilterEvent.DateTo){
      return true;
    }
  }
}



