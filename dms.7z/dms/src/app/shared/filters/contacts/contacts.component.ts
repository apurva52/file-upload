import { ChangeDetectorRef, Component, CUSTOM_ELEMENTS_SCHEMA, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { LocalizationModule, ResourceService } from '@ifirm';
import { DmsFiltersService } from '../../../filter-components/dms-filters.service';
import { IfirmGridDropdownModule } from 'projects/ifirm-common-components/src/lib/ifirm-dropdown-checkbox/ifirm-grid-dropdown.module';
import { BindContactGroup, BindContactList, FilterAcceptanceCriteria, GridDropdownPayload } from '../model/user.model';

@Component({
  selector: 'app-contacts',
  standalone: true,
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  imports: [CommonModule, ReactiveFormsModule, FormsModule, LocalizationModule, IfirmGridDropdownModule],
  templateUrl: './contacts.component.html',
  styleUrls: ['./contacts.component.scss']
})
export class ContactsComponent implements OnInit, OnChanges {

  contactForm: FormGroup;
  tableHeader_contactGroup: GridDropdownPayload;
  tableHeader_contactList: GridDropdownPayload;
  selectedContactGroup: string[] = [];
  selectedContactList: string[] = [];
  contactGroupData: BindContactGroup;
  contactlistData: BindContactList;
  refreshData: boolean = false;
  refreshContactList: boolean = false;
  @Input() contactList;
  @Input() contactGroupList;
  @Input() callClearFilter;
  @Input() callApplyFilter;
  @Output() passContactData = new EventEmitter();
  @Output() passContactSearchData = new EventEmitter();
  validateFilterEvent: FilterAcceptanceCriteria;
  contactGroupText: string = ''
  contactListText: string = ''
  constructor(private fb: FormBuilder, private resourceManager: ResourceService, private dmsFilterService: DmsFiltersService, private cdr: ChangeDetectorRef) { 
  }  

  ngOnChanges(): void {
    this.contactGroupData = {
      pageNumber: 200,
      items: this.contactGroupList,
      searchText: this.contactGroupText
    } 
    this.contactlistData = {
      pageNumber: 200,
      items: this.contactList,
      searchText: this.contactListText
    }
    if (this.callClearFilter){
      this.clearAllSelectedData();
    }
    if (this.callApplyFilter){
      this.updateValidateFilterEventObj();
    }
  }
  searchContactCallbackFunction = (searchText, pageNumber, pageSize, ownId) =>{
    var getContactListContract = {
        PageSize: pageSize,
        PageNumber: pageNumber,
        SearchText: searchText
    }
    if (this.contactGroupText !== '' && searchText ==='' || this.contactGroupText === '' && searchText !==''
    || this.contactGroupText !== '' && searchText !==''){
      this.contactGroupText = searchText;
      this.shareSearchData(getContactListContract,'contactGroupApiCall', ownId);
    }
    
  }
  initialLoadCallbackFunction = (searchText, pageNumber, pageSize, ownId) =>{
    var getContactListContract = {
      PageSize: pageSize,
      PageNumber: pageNumber,
      SearchText: searchText
  }
  this.contactGroupText = searchText;
  this.shareSearchData(getContactListContract,'contactGroupApiCall', ownId);
  }
  initialContactLoadCallbackFunction = (searchText, pageNumber, pageSize, ownId) =>{
    var getContactListContract = {
      PageSize: pageSize,
      PageNumber: pageNumber,
      SearchText: searchText
  }
  this.contactListText = searchText;
  this.shareSearchData(getContactListContract,'contactListApiCall', ownId);
  }
  contactsChangedCallback = (selectedIds) =>{
    this.selectedContactGroup  = [...selectedIds];
    this.refreshContactList = true;
    this.cdr.detectChanges();
    this.contactForm.controls['selectedContactGroup'].setValue(selectedIds);
    this.selectedContactList  = [];
    this.contactForm.controls['selectedContactList'].setValue(null);
    this.shareDataToParentComponent('groupList');
  };
  updatedEvent(event){
    this.refreshContactList = false;
  }
  searchContactListCallbackFunction = (searchText, pageNumber, pageSize, ownId) => {
    var getContactListContract = {
        PageSize: pageSize,
        PageNumber: pageNumber,
        SearchText: searchText
    }
    if (this.contactListText !== '' && searchText ==='' || this.contactListText === '' && searchText !==''
    || this.contactListText !== '' && searchText !==''){
      this.contactListText = searchText;
      this.shareSearchData(getContactListContract,'contactListApiCall',ownId);
    }
  }
  contactsListCallback = (selectedIds) =>{
    this.selectedContactList  = [...selectedIds];
    this.contactForm.controls['selectedContactList'].setValue(selectedIds);
    this.shareDataToParentComponent('contactList');
  };

  ngOnInit(): void {
    this.validateFilterEvent = this.dmsFilterService.tempDefaultFilter;
    this.contactForm = this.fb?.group({
      archivedContacts: new FormControl(null, [Validators.required]),
      myrecentFiles: new FormControl(null, [Validators.required]),
      selectedContactList: new FormControl([], [Validators.required]),
      selectedContactGroup: new FormControl([], [Validators.required])
    });
    this.objInitialize();
    
  }
  objInitialize(){
    this.tableHeader_contactGroup = {
      "columnId": "ContactGroupId",
      "column1": "ContactGroupName",
      "column2": "GroupType",
      "searchWaterMark": this.resourceManager.get('dms.searchtag.search') + "...",
      "column1DisplayName": this.resourceManager.get('ifirm.common.user'),
      "column2DisplayName": this.resourceManager.get('ifirm.common.name'),
      "noDataFoundDisplayName": this.resourceManager.get('dms.searchtag.nodatafound'),
      "pageSize": 200,
      "isMultiSelect": false,
      "column1Width": 300,
      "column2Width": 300,
      "ownId": "dmsFilterContactGroup",
      "isBlueCss": true,
      "searchCallbackFunction": this.searchContactCallbackFunction,
      "loadMoreDisplayName":'load More',
      "onlyDisplayColumn1": false,
      "itemChangedCallback": this.contactsChangedCallback,
      "initialLoadCallbackFunction": this.initialLoadCallbackFunction,
    }
    this.tableHeader_contactList = {
      "columnId": "ContactId",
      "column1": "ContactCode",
      "column2": "ContactName",
      "searchWaterMark": this.resourceManager.get('dms.searchtag.search') + "...",
      "column1DisplayName": this.resourceManager.get('ifirm.common.user'),
      "column2DisplayName": this.resourceManager.get('ifirm.common.name'),
      "noDataFoundDisplayName": this.resourceManager.get('dms.searchtag.nodatafound'),
      "pageSize": 200,
      "isMultiSelect": true,
      "column1Width": 300,
      "column2Width": 300,
      "ownId": "dmsFilterContactList",
      "isBlueCss": true,
      "searchCallbackFunction": this.searchContactListCallbackFunction,
      "loadMoreDisplayName":'load More',
      "onlyDisplayColumn1": false,
      "itemChangedCallback": this.contactsListCallback,
      "initialLoadCallbackFunction": this.initialContactLoadCallbackFunction,
    }    
  }
  updateFormFields(event, filedName){
    this.contactForm.controls[filedName].setValue(event);
    this.shareDataToParentComponent(filedName);
  }
  shareDataToParentComponent(dataFrom){
    const payload = {
      data: this.contactForm.value,
      from: dataFrom
    }
    this.passContactData.emit(payload);
  }
  shareSearchData(sendEvent, type, ownId){
    const payload = {
      data: sendEvent,
      type,
      ownId
    }
    this.passContactSearchData.emit(payload);
  }
  clearAllSelectedData(){
    this.validateFilterEvent = this.dmsFilterService.tempDefaultFilter;
    this.contactForm?.reset();
    this.refreshData = true;
    this.refreshContactList = true;
    this.cdr.detectChanges();
    this.callClearFilter = false;
    this.selectedContactList  = [];
    this.selectedContactGroup  = [];
  }
  updateRefreshKey(event){
    this.refreshData = false;
  }
  updateValidateFilterEventObj(){
    this.validateFilterEvent = this.dmsFilterService.tempDefaultFilter;
    this.callApplyFilter = false;
  }
  validateContactList(){
    if (this.selectedContactList?.length > 0 &&
      JSON.stringify(this.validateFilterEvent.ContactList) !== JSON.stringify(this.selectedContactList)){
        return true;
    }
  }
  validateArchivedContact(){
    if (this.contactForm.controls['archivedContacts'].value !== this.validateFilterEvent.IsArchivedContacts
    && this.contactForm.controls['archivedContacts'].value !== null){
      return true;
    }
  }
  validateContactGroup(){
    if (this.selectedContactGroup?.length > 0 && this.validateFilterEvent.ContactGroupId !== this.selectedContactGroup[0]){
      return true;
    }
  }
  validateMyrecentFile(){
    if (this.contactForm.controls['myrecentFiles'].value !== this.validateFilterEvent.MyRecentFiles
    && this.contactForm.controls['myrecentFiles'].value !== null){
      return true;
    }
  }
}
