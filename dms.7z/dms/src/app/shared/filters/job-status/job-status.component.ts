import { CommonModule } from '@angular/common';
import { Component, CUSTOM_ELEMENTS_SCHEMA, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LocalizationModule } from '@ifirm';

@Component({
  selector: 'app-job-status',
  templateUrl: './job-status.component.html',
  styleUrls: ['./job-status.component.scss'],
  standalone: true,
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  imports: [CommonModule, ReactiveFormsModule, FormsModule, LocalizationModule],
})
export class JobStatusComponent implements OnInit {

  jobStatusValue: string = '0';
  @Input() callClearFilter;
  @Output() passJobStatusData = new EventEmitter();
  
  constructor() { }
  ngOnChanges(): void {
    if (this.callClearFilter){
      this.clearAllSelectedData();
    }
  }

  ngOnInit(): void {
  
  }
  updateJobStatus(event){
    this.passJobStatusData.emit(event);
  }
  clearAllSelectedData(){
    this.jobStatusValue = '0';
    this.callClearFilter = false;
  }
}
