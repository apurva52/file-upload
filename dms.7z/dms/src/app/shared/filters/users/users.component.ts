import { Component, EventEmitter, Input, OnChanges, OnInit, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LocalizationModule, ResourceService } from '@ifirm';
import { userFolderFilter } from '../../../constants/app-constants';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-users',
  standalone: true,
  imports: [CommonModule, LocalizationModule, FormsModule, ReactiveFormsModule],
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.scss']
})
export class UsersComponent implements OnInit, OnChanges {

  userFoldersFilter: any = [];
  selectedUserFolder: number = 1;
  @Input() callClearFilter;
  @Output() passUserFolderData = new EventEmitter();
  constructor(private resourceManager: ResourceService) { }
  ngOnChanges(): void {
    if (this.callClearFilter){
      this.clearAllSelectedData();
    }
  }
  ngOnInit(): void {
    this.userFoldersFilter = [
      { name: this.resourceManager.get("dms.filters.showmyuserfolder"), id: userFolderFilter.ShowMyUserFolder },
      { name: this.resourceManager.get("dms.filters.showalluserfolders"), id: userFolderFilter.ShowAllUserFolders },
      { name: this.resourceManager.get("dms.filters.showactiveuserfolders"), id: userFolderFilter.ShowActiveUserFolders },
      { name: this.resourceManager.get("dms.filters.showinactiveuserfolders"), id: userFolderFilter.ShowInactiveUserFolders }
    ]
  }

  updateUserFolderFilter(event){
    this.passUserFolderData.emit(event);
  }
  clearAllSelectedData(){
    this.selectedUserFolder = 1;
  }
}
