export interface Subfolders{
    id: number;
    name:string;
  
}