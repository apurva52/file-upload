import { Subfolders } from "./subfolder.model";

export interface Folder{
    id: number;
    name: string;
    subfolders: Folder[];
}
