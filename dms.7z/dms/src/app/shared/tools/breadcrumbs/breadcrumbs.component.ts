import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ResourceService } from '@ifirm';
import { DmsService } from './../../../dms.service';

@Component({
  selector: 'app-breadcrumbs',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './breadcrumbs.component.html',
  styleUrls: ['./breadcrumbs.component.scss']
})
export class BreadcrumbsComponent  implements OnInit {

  constructor(private bs: DmsService, private rs:ResourceService ) {

   }
  breadcrumbs:string[]=[];


  ngOnInit(){
    this.bs.breadcrumb$.subscribe(breadcrumbs=>{
      this.breadcrumbs=breadcrumbs;
    })
  }

  navigateToCrumb(crumb){
    console.log(crumb)
    const currentIndex=this.breadcrumbs.indexOf(crumb);
    if(currentIndex>0 && currentIndex<this.breadcrumbs.length-1){
      this.bs.navigateCrumb(currentIndex);
      this.bs.navigateToparent(crumb,currentIndex);
      this.bs.navigateToPage(crumb)
      this.bs.breadCrumbClickedEvent.emit(crumb)
      this.bs.shareBreadCrumb(crumb)
   }
  

   //check for root breadcrumb
   else if(currentIndex==0){
    this.breadcrumbs.splice(1)
    this.bs.navigateToparent(crumb,currentIndex);
    this.bs.breadCrumbClickedEvent.emit(crumb)
    this.bs.shareBreadCrumb(crumb);
   }
 

  }
 
  

}