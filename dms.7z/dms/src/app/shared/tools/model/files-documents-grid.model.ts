import { ContactDataModel } from "./grid.model";

export interface CopyMovePayload {
    EventType: number;
    SelectedItems?: Array<any>
    LocationDetails: locationDetails;
    UserRoles: UserInfo;
}

interface locationDetails {
    EntityType: number;
    EntityId: number;
    FolderId:number;
    FolderName:string;
    Hierarchy?: string;
}
interface UserInfo {
    userId: number;
    allowApmAccess: boolean;
    viewEditCopyMove: boolean;
    addCustomFolder: boolean;
    contactView: boolean;
    internalDocumentsViewEdit: boolean;
    firmDocuments: boolean;
}

export interface PublishPortalPayload {
    ClientId: number;
    ClientPortalDestinationPath: string;
    FolderId: number;
    JobId: number;
    SeletedDocuments: ContactDataModel[],
    SourceFolderHierarchyList: {};
    isValidated: boolean;
}