import { EventEmitter, Injectable, Output } from '@angular/core';
import { ApiService } from '@ifirm';
 
@Injectable({
  providedIn: 'root'
})
export class SearchServiceService {
 
  @Output() public searchEvent: EventEmitter<any> = new EventEmitter();
 
  constructor(private api: ApiService) { }
  
}