import { Component, Input, OnChanges, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';
import { ResourceService,LocalizationModule } from '@ifirm';
import { CommonModule } from '@angular/common';
import { GridServiceService } from '../service/grid-service.service';
import { payLoadModel } from '../model/grid.model';
import { Search } from '../../../constants/app-constants';
import { SearchServiceService } from './search-service.service';
import { payLoadCommonModel } from '../../filters/model/user.model';
import { DmsService } from '../../../dms.service';
import { FirmDocumentsService } from '../../../module/firm/firm-documents/services/firm-documents.service';

@Component({
  selector: 'app-search-bar',
  standalone: true,
  imports: [FormsModule, NgSelectModule, LocalizationModule, CommonModule],
  templateUrl: './search-bar.component.html',
  styleUrls: ['./search-bar.component.scss'],
})
export class SearchBarComponent implements OnInit {
  checkBoxVal: boolean = false;
  allNotesList = [];
  allTagList = [];
  allVal = [];
  tags: any[] = [];
  selectedTagList: any[] = [];
  closeFlag: boolean = false;
  selectedSingleVal: number;
  onShowDropdown: boolean = false;
  dropDownArray: any[] = [];
  dropdownArrayCopy: any[] = [];
  dmsCommonPayload = new payLoadModel();
  previousPayload = new payLoadCommonModel();
  tagVal = Search.TagSearch;
  noteVal = Search.NoteSearch;
  placeholderVal = this.resourceService.getText('dms.searchtag.search') + '...';
  text ='';
  noteDropdown: boolean = false;
  selectedNoteVal = '';
  @ViewChild('mySelect') mySelect: any;
  @Input() selectedIndex:string;

  constructor(
    private resourceService: ResourceService,
    public searchService: SearchServiceService,
    private gridServices: GridServiceService,
    private SearchServiceService: SearchServiceService,
    private dmsService: DmsService, private dmsFirmDocService: FirmDocumentsService
  ) {}

  ngOnInit() {
    this.text =
    this.resourceService.getText('ifirm.common.content') + " " +
    this.resourceService.getText('ifirm.common.search') + " " +
    this.resourceService.getText('apm.generalsettings.jobsettings.enabled');
    this.dropDownArray.push(
      {
        id: this.tagVal,
        name:
          this.resourceService.getText('dms.searchtag.tag') +":"+
          this.resourceService.getText('dms.searchtag.searchtag'),
      },
      {
        id: this.noteVal,
        name:
          this.resourceService.getText('apm.import.activitycode.note') +
          this.resourceService.getText('dms.searchtag.searchnote'),
      }
    );
    this.dropdownArrayCopy = [...this.dropDownArray];

    this.dmsCommonPayload.IsContentSearch = true;
    this.getAllTagList();
    this.gridServices.getCommonPayload().subscribe((response: any) =>{
      if (response){
        const tempData = JSON.stringify(response);
        this.previousPayload = JSON.parse(tempData);
      }
  })

  this.dmsFirmDocService.getPayloadForFilter().subscribe(response=>{
    const tempData = JSON.stringify(response);
   this.dmsCommonPayload = JSON.parse(tempData);
    if (!this.dmsFirmDocService.isFilterSearchArea){
      this.previousPayload = JSON.parse(tempData);
    }
  })
 this.onNavigateToBreadCrumb();
  }

  onNavigateToBreadCrumb(){
    this.dmsService.breadCrumbClickedEvent.subscribe((data)=>{
      document.getElementsByClassName('ng-input')[0].firstChild['value'] = '';
      this.selectedTagList = [];
      this.gridServices.dmsRenameButton = true;
      this.gridServices.resetDownloadMergePDFButton();
    })
  }


  onChangeCheckboxVal(event) {
    this.dmsCommonPayload.IsContentSearch = event.target.checked;
  }

  getAllTagList() {
    this.gridServices.searchTagListSubject.subscribe((res) => {
      this.allTagList = [];
      res?.TagList?.map((val) => {
        this.allTagList.push({ id: val.TagId, name: `${this.resourceService.getText('dms.searchtag.tag')}:${val.TagName}` });
        this.tags = [...this.allTagList];
      });
    });
  }

  onSearch() {
    this.dmsCommonPayload.SearchTags.Tags = [];
    this.selectedTagList.map((res) => {
      if (res.id != Search.NoteDropdownVal) {
        this.dmsCommonPayload.SearchTags.Tags.push(res.id);
      }
    });
    if(!this.dmsCommonPayload.IsContentSearch){
      this.dmsCommonPayload.SearchMore = true;
      this.dmsCommonPayload.IsFileSearch = false;
    }
    else{
    this.dmsCommonPayload.SearchMore = false;
    this.dmsCommonPayload.IsFileSearch = true;
    }
    this.dmsCommonPayload.SearchText = document.getElementsByClassName('ng-input')[0].firstChild['value'];
    this.closeFlag = false;
    this.SearchServiceService.searchEvent.emit(this.dmsCommonPayload);
    this.onShowDropdown = false;
    this.selectedSingleVal = undefined;
    this.dropDownArray = [
      {
        id: this.tagVal,
        name:
          this.resourceService.getText('dms.searchtag.tag') +":"+
          this.resourceService.getText('dms.searchtag.searchtag'),
      },
      {
        id: this.noteVal,
        name:
          this.resourceService.getText('apm.import.activitycode.note') +
          this.resourceService.getText('dms.searchtag.searchnote'),
      },
    ];
document.getElementsByClassName('ng-input')[0].firstChild['style'].color = '#d5d5d5';
    this.mySelect.blur();
  }

  ngchange(event) {
    if (event && event.length > 0) {
      if (this.mySelect) {
        this.mySelect.focus();
      }
      this.onShowDropdown = true;
      this.closeFlag = false;
    }
    this.closeFlag = false;
  }

  drop() {
    this.closeFlag = true;
    if (this.selectedSingleVal[0] === this.tagVal) {
      this.tags = this.allTagList;
      this.onShowDropdown = false;
    } else if (this.selectedSingleVal[0] === this.noteVal) {
      this.noteDropdown = true;
      this.closeFlag = false;
      this.onShowDropdown = false;
    }
  }

  onFocus() {
    document.getElementsByClassName('ng-input')[0].firstChild['style'].color = 'black';
    this.placeholderVal = '';
    if (
      this.selectedSingleVal === undefined ||
      this.selectedSingleVal[0] === this.tagVal
    ) {
      this.onShowDropdown = !this.onShowDropdown;
    } else {
      this.onShowDropdown = false;
    }
  }

  onSearchofInput(event) {
    if (this.selectedSingleVal === undefined) {
     // this.tags.push({ id: this.noteVal, name: `${this.resourceService.getText('apm.import.activitycode.note')}:${event.term}` });
      this.closeFlag = true;
    } else if (this.selectedSingleVal[0] === this.noteVal) {
      this.noteDropdown = true;
      this.closeFlag = false;
      this.onShowDropdown = false;
      this.selectedNoteVal = event.term;
    } else {
      this.onShowDropdown = false;
    }
  }

  clickNote(event) {
    if (this.mySelect) {
      this.mySelect.focus();
    }
    this.selectedTagList = [
      ...this.selectedTagList,
      { id: Search.NoteDropdownVal, name: event.target.label },
    ];
    this.noteDropdown = false;
    this.onShowDropdown = true;
    const indexToRemove = 1; 
    document.getElementsByClassName('ng-input')[0].firstChild['value'] = '';
    this.dropDownArray.splice(indexToRemove, 1);
    if (this.selectedNoteVal != '') {
      this.dmsCommonPayload.SearchNote = this.selectedNoteVal;
    }
  }

  onRemove(event) {
    this.noteDropdown = false;
    this.dropDownArray = this.dropdownArrayCopy;
    this.onShowDropdown = true;
    this.mySelect.blur();
    if (event.value.id === Search.NoteDropdownVal) {
      this.dmsCommonPayload.SearchNote = '';
    }
  }

  keydownInDropdown() {
    return false;
  }

  onClear() {
    this.dmsCommonPayload.SearchTags.Tags = [];
    this.dmsCommonPayload.SearchText = '';
    this.dmsCommonPayload.SearchNote = '';
    this.dropDownArray = [
      {
        id: this.tagVal,
        name:
          this.resourceService.getText('dms.searchtag.tag') +":"+
          this.resourceService.getText('dms.searchtag.searchtag'),
      },
      {
        id: this.noteVal,
        name:
          this.resourceService.getText('apm.import.activitycode.note') +
          this.resourceService.getText('dms.searchtag.searchnote'),
      },
    ];
    this.onShowDropdown = true;
    this.noteDropdown = false;
    const payload = {
      payload: this.previousPayload,
      isOnlyContactSelected: false,
      isEmptyEvent: true
    }
   
    if(this.selectedIndex === 'firmDocument'){
      this.SearchServiceService.searchEvent.emit(this.dmsCommonPayload.IsFileSearch === true ? this.dmsCommonPayload : this.previousPayload);
    }else{
      this.dmsService.clearSearchFilter.next(payload);
    }
  }

  ngAfterViewInit() {
    this.addClickOutsideListener();
  }
  addClickOutsideListener() {
    document.addEventListener('click', this.handleDocumentClick.bind(this));
  }
  handleDocumentClick(event: MouseEvent) {
   //console.log("Target",event.target);
    // console.log(event.target['value'],event.target['className'],event.target['ariaAutoComplete'],event.target['className'] ,'event.target');
    if (
      event.target['value'] === '0: 0' ||
      event.target['value'] === '0: 1' ||
      event.target['value'] === '1: 1' ||
      event.target['className'] === 'ng-option ng-option-marked' ||
      event.target['ariaAutoComplete'] === 'list' ||
      event.target['className'] === 'ng-option-label' ||
      event.target['className'] === 'ng-value-icon left' ||
      event.target['className'] === 'fa fa-search searchicon'
    ) {
      return;
    } else {
      this.placeholderVal = this.resourceService.getText('dms.searchtag.search') + '...';
      this.onShowDropdown = false;
      this.closeFlag = false;
      this.noteDropdown = false;
      this.mySelect.blur();
    }
  }
}
