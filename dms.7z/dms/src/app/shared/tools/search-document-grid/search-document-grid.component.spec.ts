import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchDocumentGridComponent } from './search-document-grid.component';

describe('SearchDocumentGridComponent', () => {
  let component: SearchDocumentGridComponent;
  let fixture: ComponentFixture<SearchDocumentGridComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ SearchDocumentGridComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SearchDocumentGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
