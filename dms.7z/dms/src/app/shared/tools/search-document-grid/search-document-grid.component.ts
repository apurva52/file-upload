import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-search-document-grid',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './search-document-grid.component.html',
  styleUrls: ['./search-document-grid.component.scss']
})
export class SearchDocumentGridComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
