import { EventEmitter, Injectable, Output } from '@angular/core';
import { BehaviorSubject , forkJoin, Observable, Subject } from 'rxjs';
import { ContactDataModel, payLoadModel} from './../../tools/model/grid.model';
import { AppConstants, DMSFirmDocument, DocumentKind, entityType } from '../../../constants/app-constants';
import { ApiService, ToasterService, ResourceService, ModalPopupService, ModalPopupConfig, ConfirmationBoxType, ConfirmationBoxComponent } from '@ifirm';
import { DmsDialogApiService } from '../../../dialogs/dms-dialog-api.service';
import { TagList, ApiStatus, PropertiesPayload } from 'projects/dms/src/app/dialogs/file-property/models/file-property.model';
import { FirmDocumentsService } from '../../../module/firm/firm-documents/services/firm-documents.service';
import { FilePropertyService } from '../../../dialogs/file-property/services/file-property.service';
import { fileKind, antivirusScanStatus, FileExtensions, pdfOpenWithApplication, LockType,ApiValidationCode } from 'projects/dms/src/app/constants/app-constants';
import { DmsService } from '../../../dms.service';
import { userInfoResponse } from '../../../module/firm/firm-documents/models/firm-document.model';
import { EmailPreviewComponent } from '../../../dialogs/email-preview/email-preview.component';
import { OpenDocumentComponent } from '../../../dialogs/open-document/open-document.component';
import { ConfirmationBoxInputModel } from 'projects/apm/src/app/timesheet/model/timesheet-common.model';

@Injectable({
  providedIn: 'root'
})
export class GridServiceService {
  public folderHierarchyList = new Map();
  payLoad=new payLoadModel();
  @Output() public filterEvent= new Subject();
  public contactsSubject = new BehaviorSubject<ContactDataModel>(null);
  public filterFileTypeSubject = new Subject();
  public filterTagListSubject = new Subject();
  public updateFilterFields = new Subject();
  public updatedCommonPayload = new Subject();
  public updatePayload = new Subject();
  public searchTagListSubject = new BehaviorSubject<any>(null);
  public contactData = new Map();
  public commonPayloadData = new Map();
  public checkedDatalist :any[] = [];
  preventFileNameMouseOver: boolean = false;
  selectedTagList: TagList[] = [];
  initialSelectedTagList: TagList[] = [];
  tags: TagList[] = [];
  userInfoMap: userInfoResponse;
  enhancedPdfSwitch: boolean = false;
  enhancedPdfFileCount:any = 0;
  enhancedPdfMaxSize:any = 0;
  isAllowInternaldocuments:boolean = true;
  isAllowDocumentsEdit:boolean = true;
  showOpenPdf: boolean = false;
  showMergePdf: boolean = false;
  failMessage:string;
  dmsRenameButton: boolean = true;
  dmsCopyMoveButton: boolean = true;
  public loaderSubject = new BehaviorSubject<boolean>(false);
  dmsDownloadButton: boolean = true;
  dmsDeleteButton: boolean = true;
  dmsOpenPdfButton: boolean = true;
  dmsMergePdfButton: boolean = true;
  isEnableConditionalButton:boolean = false;
  currentcrumb: any[];

  constructor(private api:ApiService, private toasterService: ToasterService, private resourceService: ResourceService,
    private dmsDialogApiService: DmsDialogApiService, private firmDocService: FirmDocumentsService, 
    private filepropertyservice: FilePropertyService, private dmsServices: DmsService, private popupService: ModalPopupService) {
    this.folderHierarchyList = new Map<string,number>();
    this.contactData = new Map<string,any>();
    this.commonPayloadData = new Map<string,any>();
   }

  public getContactList(contactPayload, isScroll=false): Observable<any> {
    const url = '/dms/api/documentsearch/searchdocuments';
    const contactlist = this.api.post<any>(url, null, contactPayload);
    if(!isScroll){
    //search tag list
    const search = this.tagSearchList(contactPayload);
    search.subscribe(res => this.searchTagListSubject.next(res));

    // filter tag list 
    const filterTagsList = this.filterTagList(contactPayload);
    filterTagsList.subscribe(res => this.filterTagListSubject.next(res));

    // filter files list 
    const filterFilesList = this.filterFilesList(contactPayload);
    filterFilesList.subscribe(res => this.filterFileTypeSubject.next(res));
    }
    return  contactlist;
  }

  public setContactsSubject(val: ContactDataModel){
    this.contactsSubject.next(val);
  }
  public setFilterFields(val){
    this.updateFilterFields.next(val);
  }
  public setCommonPayload(val){
    this.updatedCommonPayload.next(val);
  }
  public getContactsSubject(){
    return this.contactsSubject.asObservable();
  }
  public getFilterFields(){
    return this.updateFilterFields.asObservable();
  }
  public getCommonPayload(){
    return this.updatedCommonPayload.asObservable();
  }
  public tagSearchList(data:any): Observable<any>{
    return this.api.post<any>('dms/api/tag/TagSearchList',null,data);
  }

  public filterTagList(data:any): Observable<any>{
    return this.api.post<any>('dms/api/tag/getfiltertaglist',null,data);
  }

  public filterFilesList(data:any): Observable<any>{
    return this.api.post<any>('/dms/api/documentsearch/getfiletypes/',null,data);
  }

  public getSearchList(contactPayload): Observable<any> {
    const url = '/dms/api/documentsearch/searchdocuments';
    const contactlist = this.api.post<any>(url, null, contactPayload);
    return  contactlist;
  }

  public createFileLinkUrl(fileId): Observable<any> {
    const url = `/dms/api/documentsearch/createFileLinkUrl?fileId=${fileId}`;
    return this.api.get<any>(url);
  }
  
  public validatePublishToPortalRequest(data:any): Observable<any>{
    return this.api.post<any>('/dms/api/clientportal/validatePublishToPortalRequest',null,data);
  }
  
  public  PublishToPortalRequest(data:any): Observable<any>{
    return this.api.post<any>('/dms/api/clientportal/publishtoportal',null,data);
  }

  public removeFromDataList(value:any[]):void{
    const index = this.checkedDatalist.indexOf(value);
    if(index !== -1){
      this.checkedDatalist.splice(index,1);
      this.dmsRenameButton = this.validateRenameButton(this.checkedDatalist);
      this.dmsCopyMoveButton = this.validateCopyMoveButton(this.checkedDatalist);
      this.isDeleteAllowed(this.checkedDatalist);
      this.dmsDownloadButton = this.validateDownloadButton(this.checkedDatalist);
      if(this.checkedDatalist.length > 1){
        this.showMergePdf = true;
        this.showOpenPdf = false;
        this.dmsMergePdfButton = this.validateOpenMergePdfButton(this.checkedDatalist);
      }
      else{
        this.showMergePdf = false;
        this.showOpenPdf = true;
        this.dmsOpenPdfButton = this.validateOpenMergePdfButton(this.checkedDatalist);
      }
    }
  }

  public addToDataList(value:any[]):void{
    this.checkedDatalist.push(value);
    this.dmsRenameButton = this.validateRenameButton(this.checkedDatalist);
    this.dmsCopyMoveButton = this.validateCopyMoveButton(this.checkedDatalist);
    this.isDeleteAllowed(this.checkedDatalist);
    this.dmsDownloadButton = this.validateDownloadButton(this.checkedDatalist);
    if(this.checkedDatalist.length > 1){
      this.showMergePdf = true;
      this.showOpenPdf = false;
      this.dmsMergePdfButton = this.validateOpenMergePdfButton(this.checkedDatalist);
    }
    else{
      this.showMergePdf = false;
      this.showOpenPdf = true;
      this.dmsOpenPdfButton = this.validateOpenMergePdfButton(this.checkedDatalist);
    }
  }

  public getList(){
    return this.checkedDatalist;
  }
 isCaseWareFile (fileData) {
    return fileData.Type && fileData.Type.Extension === FileExtensions.caseWareExtension;
};
  validateRenameButton(records){
    let result = true;
    if (records?.length === 1 && records[0].EntityType === entityType.Firm){
     const userRoles = this.firmDocService.userRoles;
      const selectionHasInternalDocuments = records[0].EntityType == DMSFirmDocument.InternalDocuments
      const selectionHasHrDocuments = records[0].EntityType == DMSFirmDocument.HRDocuments;
      const selectionHasUserDocuments = records[0].EntityType == DMSFirmDocument.User;
      if (userRoles?.firmDocuments){
        if ((selectionHasInternalDocuments && userRoles.internalDocumentsViewEdit) ||
        (selectionHasHrDocuments && userRoles.hrManager) || selectionHasUserDocuments){
          if (records[0].Type === null || records[0].Type?.Extension !== AppConstants.caseWareExtension){
            if (!records[0].IsLocked && records[0].DefaultFolderId === 0 && !records[0].IsSystemFolder && records[0].LinkUrl === null){
                result = false;                
            }
          }
        }
      }
    }else{
      this.applyUserRoles();
     // this.isCaseWareFile(records);
      const singleSelect = records.length === 1;
      const selectionHasDefaultFolders = false;
      if((this.userInfoMap.viewEdit || this.userInfoMap.viewEditCopyMove) && singleSelect && !records[0].IsLocked && !selectionHasDefaultFolders){
      if (records[0].Type === null || records[0].Type?.Extension !== AppConstants.caseWareExtension){
        if (!records[0].IsLocked && records[0].DefaultFolderId === 0 && !records[0].IsSystemFolder && records[0].LinkUrl === null){
            result = false;                
        }
      }
    }
  }
    return result;
  }

  public getAntivirusScanStatusByFileId(fileId): Observable<any>{
    const url = '/dms/api/document/GetAntivirusScanStatusByFileId?fileId='+fileId;
    return this.api.get<any>(url);
  }

  public getEnhancedPDFSettings(): Observable<any>{
    const url = '/dms/api/settings/getEnhancedpdfSettings';
    return this.api.get<any>(url);
  }

  public  getUnlockFile(fileId:number): Observable<any>{
    const url = `/dms/api/document/forceunlockfile?fileId=${fileId}`;
    return this.api.get<any>(url);
  }

  public GetAntivirusScanStatusByFileId(fileId:number): Observable<any>{
    const url = `/dms/api/document/GetAntivirusScanStatusByFileId?fileId=${fileId}`;
    return this.api.get<any>(url);
  }

  public getEditPayLoad(fileId,entityType,entityId,hierarchy,fileName,isReadOnly): Observable<any>{
    const url = '/dms/api/document/getEditPayLoad?fileId='+fileId+'&entityType='+entityType+'&entityId='+entityId+
    '&hierarchy='+hierarchy+'&fileName='+fileName+'&isReadOnly='+isReadOnly;
    return this.api.get<any>(url);
  }

  public  moveToRecyclebinRequest(data:any): Observable<any>{
    return this.api.post<any>('/dms/api/recyclebin/movetorecyclebin',null,{MoveToRecycleFileFolderList:data});
  }

  createRenamePayload(record){
    let fileType = null;
    if (record.Kind === DocumentKind.File) {
      fileType = {
        Id: record.Type.Id,
        GroupName: record.Type.GroupName,
        Extension: record.Type.Extension,
        FileExtensionId: record.Type.FileExtensionId,
        ResourceKey: record.Type.ResourceKey,
      };
    }
    const payloadForRename = {
      EntityId: record.EntityId,
      EntityType: record.EntityType,
      Id: record.Id,
      Guid: record.Guid,
      ParentFolderId: record.ParentId,
      Kind: record.Kind,
      FileType: fileType,
      OldName: record.Name,
      Name: record.Name,
      Hierarchy: record.Hierarchy,
      EmailMetaDataId: record.EmailMetaDataId,
      NewName: '',
    }
    return payloadForRename;
  }
  public getFolderHierarchy(hierarchyId): Observable<any>{
    const url = '/dms/api/document/getfolderhierarchy?hierarchy='+hierarchyId;
    return this.api.get<any>(url);
  }


  fileNameHierarchy(file) {
    if (file.Hierarchy) {      
      if (!file.HierarchyPath) {
        if (!this.preventFileNameMouseOver) {
          this.preventFileNameMouseOver = true;
          this.getFolderHierarchy(file.Hierarchy).subscribe({
            next: (response) => {
              if (response && response.FolderHierarchies) {               
                response.FolderHierarchies.map(function (value) {
                  file.HierarchyPath = !file.HierarchyPath ? value.FolderName : file.HierarchyPath + '\\' + value.FolderName;
                });
                file.HierarchyPath = file.HierarchyPath + '\\' + file.Name;
                this.preventFileNameMouseOver = false;
              }
            },
            error: (e) => {
              this.toasterService.error(this.resourceService.getText('ifirm.common.error'));
            }
          })
        }
      }      
    }
      else {
        file.HierarchyPath = file.Name;
      }
  }

  gridAddTags(file, tab) {
    if (file.Kind == 1) {
      this.getTagList(file, tab);
      let elShowTags = document.getElementById('dmsGridTag-' + file.Kind + file.Id);
      elShowTags?.classList?.remove("hideTags");
      elShowTags?.classList?.add("showTags");
    }
  }

  private getTagList(file, tab): void {
    const taglistobj = { EntityId: file.EntityId, EntityType: file.EntityType, 
      FileId: file.Id, FileKind: file.Kind, FileSource: file.Source } as any;     
    this.dmsDialogApiService.GetTagList(taglistobj).then(res => {      
      if (res.Status.toLowerCase() === ApiStatus.Success) {
        tab == 'firmDoc' ? this.firmDocService.setLoaderSubject(false) : '';
        this.selectedTagList = res.SelectedTagList.map((val) => {
        return {
          id: val,
          name : res.TagList.find((res) => res.TagId == val).TagNameForDisplay
          }
        })
        this.initialSelectedTagList = [...this.selectedTagList]
        this.tags = res.TagList.map((value) => ({
          id: value.TagId,
          name: value.TagNameForDisplay
        }));
      }
      else {
        tab == 'firmDoc' ? this.firmDocService.setLoaderSubject(false) : '';
        this.selectedTagList = []
        this.initialSelectedTagList = []
        this.tags = [];
      }
    }).catch(
      exception => {
        tab == 'firmDoc' ? this.firmDocService.setLoaderSubject(false) : '';
        this.toasterService.error(this.resourceService.getText('dms.common.errormessage'));
      });
    }

    hideGridTags(file, fromIcon){
      if (file.Kind == 1) {          
        let elShowTags = document.getElementById('dmsGridTag-' + file.Kind + file.Id);
        elShowTags?.classList?.add("hideTags");
        elShowTags?.classList?.remove("showTags");
        if (JSON.stringify(this.selectedTagList) !== JSON.stringify(this.initialSelectedTagList) && !fromIcon) {
          this.updateGridTagList(file);
        }
      }
    }

    showGridTags(file){
      if (file.Kind == 1) {             
        let elShowTags = document.getElementById('dmsGridTag-' + file.Kind + file.Id);
        elShowTags?.classList?.add("showTags");
        elShowTags?.classList?.remove("hideTags");
      }
    }

    updateGridTagList(file){     
      const tagPayload = {} as PropertiesPayload;
      tagPayload.EntityType = file.EntityType;
      tagPayload.FileId = file.Id;
      tagPayload.FileSource = file.Source;
      tagPayload.TagList = this.selectedTagList.map((res: TagList) => String(res.id));  
      this.filepropertyservice.updateFileTaglist(tagPayload).subscribe(response => {
        if (response.Status.toLowerCase() === ApiStatus.Success) {
         file.TagCount = response.TotalTagCount;
         return;
        }
      });
  }

  removeGridTag(event): void {
    if (event.value.id <= -1) {
      let index = this.selectedTagList.findIndex(res=> res.id == event.value.id)
      this.selectedTagList.unshift(event.value);
      this.selectedTagList = [...this.selectedTagList];
    }
  }

  gridClipboardLink(file){
    if (file.Kind == fileKind.File) {
      this.createFileLinkUrl(file.Id).subscribe({
        next: (result) => {
          if (result.success) {
              var aux = document.createElement("div");
              aux.innerHTML = result.data;
              document.body.appendChild(aux);
              window.getSelection().selectAllChildren(aux);
              document.execCommand("copy");
              document.body.removeChild(aux);
              this.toasterService.success(this.resourceService.getText('dms.copiedtoclipboard'));
          }
          else {
            this.toasterService.error(this.resourceService.getText('dms.common.error'));
          }
        },
          error: (e) => {
            this.toasterService.error(this.resourceService.getText('dms.common.error'));
      }});
    }
  }

  applyUserRoles() {
    if(this.dmsServices.userInfoMap.get('userInfoValue') != undefined){
      const userInfo = this.dmsServices.userInfoMap.get('userInfoValue');
      console.log('user info---',userInfo);
      this.userInfoMap = userInfo;
      this.userInfoMap.viewAny = userInfo?.DmsViewAny;
      this.userInfoMap.viewEdit = userInfo?.DmsViewEdit;
      this.userInfoMap.viewEditCopyMove = userInfo?.DmsViewEditCopyMove;
      this.userInfoMap.firmDocuments = userInfo?.DmsFirmDocuments;
      this.userInfoMap.internalDocumentsView = userInfo?.DmsInternalDocumentsView;
      this.userInfoMap.internalDocumentsViewEdit = userInfo?.DmsInternalDocumentsViewEdit;
      this.userInfoMap.hrManager = userInfo?.DmsHrManager;
      this.userInfoMap.dmsPdfOpenWithApplication = userInfo?.DmsPdfOpenWithApplication;
      this.userInfoMap.DmsOfficeOnlineSwitch = userInfo?.DmsOfficeOnlineSwitch;
      this.userInfoMap.userId = userInfo?.UserId;
    }
  }

  getEnhancedpdfSettings(tab) {
    this.getEnhancedPDFSettings().subscribe({
      next: (response) => {
            this.enhancedPdfSwitch = response.EnhancedPdfSwitch;
            this.enhancedPdfMaxSize = response.EnhancedPdfMaxSize;
            this.enhancedPdfFileCount = response.EnhancedPdfFileCount;
            this.isAllowInternaldocuments = response.IsAllowInternaldocuments;
            this.isAllowDocumentsEdit = response.IsAllowDocumentsEdit;
            if (this.enhancedPdfSwitch == true) { 
                this.showOpenPdf = true;
            }
          },
          error: (e) => {
            tab == 'firmDoc' ? this.firmDocService.setLoaderSubject(false) : '';
            this.toasterService.error(this.resourceService.getText('ifirm.common.error'));
           }
        });
  }

  getGridFile(file, tab){
    tab == 'firmDoc' ? this.firmDocService.setLoaderSubject(true) : '';
    this.getAntivirusScanStatusByFileId(file.Id).subscribe({
     next: (result) => {
      tab == 'firmDoc' ? this.firmDocService.setLoaderSubject(false) : '';
      if (result.success) {
        if (file.Type != null && (file.Type.Extension.toLowerCase() != "dmsurllink" || file.LinkUrl == null || file.LinkUrl == "undefined") && (result.data === antivirusScanStatus.Queued || result.data === antivirusScanStatus.NotStarted || result.data === antivirusScanStatus.Error)) {              
          const confirmInstance = this.popupService.confirm(this.resourceService.getText('dms.downloadwarning'), this.resourceService.getText('dms.common.filenotscanned'));
          const subscription = confirmInstance.afterClosed.subscribe(a => {
          subscription.unsubscribe();
          if (a && a.result == true) {
             this.openFile(file, 'firmDoc');
          }
          });
        }
        else if (result.data === antivirusScanStatus.Fail || result.data === antivirusScanStatus.InvalidExtension) {
            //showConfirmDeleteDialog(file, result.data);
        }
        else {
            this.openFile(file, 'firmDoc');
        }
      }
      else {
          this.toasterService.error(result.message);
      }
     },
     error: (e) => {
      tab == 'firmDoc' ? this.firmDocService.setLoaderSubject(false) : '';
      this.toasterService.error(this.resourceService.getText('ifirm.common.error'));
     }
    });
  }

  openFile(file, tab){
    if (file.Kind === fileKind.File) {
      if (file.Type.Extension.toLowerCase() === "msg" && file.EmailMetaDataId > 0) {
        const payload: any = this.firmDocService.getPayload$();
        const clientDocPayload: any = this.getCommonPayload();
        let ClientFilesDocPayload:any= clientDocPayload?.source?.value;
        let firmDocPayload = payload?.source.value;
          const data = {
              file: file,
              folderId: tab == 'firmDoc' ? firmDocPayload.folderId : ClientFilesDocPayload?.folderId
          };
          let instance = this.popupService.open<EmailPreviewComponent>(this.resourceService.getText(''), EmailPreviewComponent, {data: data});
          const sub = instance.afterClosed.subscribe(response => {
            if (response) {
              tab == 'firmDoc' ? this.loadFirmGridData() : '';
            }
          });
      }
       else if ((FileExtensions.allowedPdfEditingFileExtension.indexOf(file.Type.Extension.toLowerCase()) !== -1) && this.userInfoMap.dmsPdfOpenWithApplication == pdfOpenWithApplication.LocalApplication) {
          if (file.IsLocked) {
             this.openPdfOfficeOpener(file, true, tab);
          } else {
             this.openFileInDeskStopOrBrowser(file, tab);
          }
      }
      else if ((FileExtensions.allowedPdfEditingFileExtension.indexOf(file.Type.Extension.toLowerCase()) !== -1) && this.enhancedPdfSwitch === true) {
          if (file.IsLocked) {
             this.openPdfOfficeOpener(file, true, tab);
          } else {
            this.openPdfView(file, tab);
          }
      }
      else if (file.Type.Extension.toLowerCase() === "pdf" && this.userInfoMap.dmsPdfOpenWithApplication == pdfOpenWithApplication.Browser && this.enhancedPdfSwitch === false) {
          window.open("/dms/api/Export/GetFileInNewWindow?id=" + file.Id + "&guid=" + file.Guid, '_blank', '');
          tab == 'firmDoc' ? this.loadFirmGridData() : '';
      }
      else if (file.Type.GroupName.toLowerCase() === 'picture') {
          window.open("/dms/api/Export/GetFileInNewWindow?id=" + file.Id + "&guid=" + file.Guid, '_blank', '');
          tab == 'firmDoc' ? this.loadFirmGridData() : '';
      }
      else if ((file.Type.Extension.toLowerCase() === "ac_" && file.Type.GroupName.toLowerCase() === 'caseware' && file.IsReadOnly)) {          
          this.toasterService.info(this.resourceService.getText('dms.openedit.cannotopencwfile'));
      }
      else if (file.Kind === fileKind.File && file.Type.Extension === "") {
          this.toasterService.info(this.resourceService.getText('dms.openedit.extnlessmessage'));
      }
      else if (FileExtensions.disAllowedCompressedFileExtensions.indexOf(file.Type.Extension.toLowerCase()) > -1) {
           this.toasterService.info(this.resourceService.getText('dms.openedit.disallowedcompressedfilemessage'));
      }
      else if (file.Type.Extension.toLowerCase() === "dmsurllink" && file.Type.GroupName.toLowerCase() === 'dmsurllink' && file.LinkUrl != null && file.LinkUrl != "undefined") {
          file.LinkUrl.match(/(http(s)?:\/\/.)(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/) ? window.open(file.LinkUrl, '_blank', '') : window.open('http://' + file.LinkUrl, '_blank', '');
      }
      else if (parseInt(this.userInfoMap.userId, 10) !== parseInt(file.LockedBy, 10) && file.IsLocked && FileExtensions.officeFileExtensions.indexOf(file.Type.Extension.toUpperCase()) !== -1 && file.FileSize < this.enhancedPdfMaxSize) {
         this.openPdfOfficeOpener(file, true, tab);
      }
      else if (file.IsLocked) {
          if (parseInt(this.userInfoMap.userId, 10) === parseInt(file.LockedBy, 10)) {
             this.openFileInDeskStopOrBrowser(file, tab);
          }
          else {
            this.toasterService.error(this.resourceService.getText('dms.openedit.readonlyfilelocked'));
          }
      }
      else {
          const currentUserId = parseInt(this.userInfoMap.userId, 10);
          if (file.Type.Extension.toLowerCase() === FileExtensions.caseWareExtension
              && file.IsLocked && file.LockType === LockType.Local
              && parseInt(file.LockedBy, 10) !== currentUserId) {
                this.toasterService.info(this.resourceService.getText('dms.openedit.filelocked'));
              return;
          }
          this.openFileInDeskStopOrBrowser(file, tab);
      }
    }
  }

  
  openFileInDeskStopOrBrowser(file, tab){   
    const data = {
      FileId: file.Id,
      EntityType: file.EntityType,
      EntityId: file.EntityId,
      Hierarchy: file.Hierarchy,
      FileName: file.Name,
      FileGuid: file.Guid,
      ExtensionType: file.Type ? file.Type.Extension : '',
      IsReadOnly: false,
     // updateLockEvent: updateLockEvent,
     // updateUnlockEvent: updateUnlockEvent
    };

    let instance = this.popupService.open<OpenDocumentComponent>(this.resourceService.getText('dms.opendocumentinbrowser.opendocument'), OpenDocumentComponent, {data: data});
          const sub = instance.afterClosed.subscribe(response => {
            if (response) {
              tab == 'firmDoc' ? this.loadFirmGridData() : '';
            }
          });
  }

  openPdfOfficeOpener(file, isReadOnly, tab) {
   
    // var pdfViewUrl = "/#/dms/pdfview?rh=0&mg=0&ids=" + fileId;
    if (isReadOnly) {
        this.getEditPayLoad(file.Id, file.EntityType, file.EntityId, file.Hierarchy, '', isReadOnly).subscribe({
          next: (data) => {
            if (data.success) {
                let newWindow = window.open(data.data, '_self');
                newWindow.opener = null;
                setTimeout(() => {
                    const limitedInterval = setInterval(() => {
                        if (newWindow != null && newWindow.closed) {
                            clearInterval(limitedInterval);
                            //updateFileList(false, null, true);                        
                            tab == 'firmDoc' ? this.loadFirmGridData() : '';
                        }
                    }, 2000);
                }, 5000);
            } else {
              this.toasterService.error(this.resourceService.getText('ifirm.common.error'));
            }
        },
        error: (e) => { 
          this.toasterService.error(this.resourceService.getText('ifirm.common.error'));
        }
      });
           
    }
    else {
       let newWindow = window.open(file.OpenEditPayload, '_self');
        newWindow.opener = null;
        setTimeout(() => {
            const limitedInterval = setInterval(() => {
                if (newWindow != null && newWindow.closed) {
                    clearInterval(limitedInterval);
                    //updateFileList(false, null, true);  
                    tab == 'firmDoc' ? this.loadFirmGridData() : '';
                }
            }, 2000);
        }, 5000);
    }
  }

  openPdfView(file, tab) {
    if (file.FileSize < this.enhancedPdfMaxSize) {
        if (!file.IsLocked) {
            this.openPdfOfficeOpener(file, false, tab);
            setTimeout(() => {
                //updateFileList(false, null, true);
                tab == 'firmDoc' ? this.loadFirmGridData() : '';
            }, 5000);
        }
        else {
            let currentUserId = parseInt(this.userInfoMap.userId, 10);
            if (parseInt(file.LockedBy, 10) !== currentUserId) {
                this.popupService.info(this.resourceService.getText("ifirm.common.error"), this.resourceService.getText("dms.openedit.filelocked"));
            }
            else {
                let message = this.resourceService.getText("dms.openedit.pdflockmessage");
                console.log(message);
                console.log(message.format(file.Name));
                this.popupService.info(this.resourceService.getText("ifirm.common.error"), message.format(file.Name));
            }
        }
    } else {
        const config: ModalPopupConfig<ConfirmationBoxInputModel> = new ModalPopupConfig<ConfirmationBoxInputModel>();
        let model = new ConfirmationBoxInputModel();
        model.message = this.resourceService.getText('dms.editpdf.maxfilecountorfilesize');
        model.type = ConfirmationBoxType.YesNo;
        config.data = model;
        let instance = this.popupService.open<ConfirmationBoxComponent>(this.resourceService.getText('dms.downloadwarning'), ConfirmationBoxComponent, config);
        //this.loader = true;
        const subscription = instance.afterClosed.subscribe(x => {
          if (x && x.result) {
            window.open("/dms/api/Export/GetFileInNewWindow?id=" + file.Id + "&guid=" + file.Guid, '_blank', '');
            tab == 'firmDoc' ? this.loadFirmGridData() : '';
      }
      });
    }
  }
  fetchSelecctedItem(records){
    let resultSet = [];
    records.forEach(record => {
      resultSet.push(
        {
          EmailMetaDataId: record.EmailMetaDataId,
          EntityId: record.EntityId,
          EntityType: record.EntityType,
          Hierarchy: record.Hierarchy,
          FileGuid: record.Guid,
          Id: record.Id,
          FileKind: record.Kind,
          LinkUrl: record.LinkUrl,
          FileName: record.Name,
          StoragePath: record.StoragePath,
          ParentId: record.ParentId,
          FileType: record.Type
        }
      )
    });
    return resultSet
  }


  downloadSingleFile(selectedData, tab, gridPayload) {
    var fileContract = {
      StoragePath: selectedData.StoragePath,
      FileGuid: selectedData.Guid,
      FileType: selectedData.Type,
      FileId: selectedData.Id,
    };
    this.dmsDialogApiService.validateFileDownload(fileContract).then((response) => {
        if (response.success === false && (response.ValidationCode === ApiValidationCode.FileQuarantined || response.ValidationCode === ApiValidationCode.FileInvalidExtension)){
          var status = (response.ValidationCode === ApiValidationCode.FileQuarantined) ? antivirusScanStatus.Fail : antivirusScanStatus.InvalidExtension;
          this.showConfirmDeleteDialog(selectedData, status, gridPayload, tab);
        }
       else if (response.success === false && response.ValidationCode === ApiValidationCode.FileNotScanned) {
          const config: ModalPopupConfig<ConfirmationBoxInputModel> = new ModalPopupConfig<ConfirmationBoxInputModel>();
          let model = new ConfirmationBoxInputModel();
          model.message = this.resourceService.getText('cp.documents.filenotscanned');
          model.type = ConfirmationBoxType.YesNo;
          config.data = model;
          let instance = this.popupService.open<ConfirmationBoxComponent>(this.resourceService.getText('apm.viewwip.dialog.warning'), ConfirmationBoxComponent, config);
          const subscription = instance.afterClosed.subscribe(x => {
            if (subscription) {
              subscription.unsubscribe();
            }
            if (x && x.result) {
              this.startDownloadingFile(selectedData);
        }
        });
        }
        else if (response.success === false && response.ValidationCode === ApiValidationCode.FileNotFound) {
          this.popupService.info(this.resourceService.get('ifirm.common.error') as string, this.resourceService.get('dms.common.error') as string);
        }
        else if (response.success === true) {
          this.startDownloadingFile(selectedData);
        }
        else{
          this.popupService.info(this.resourceService.get('ifirm.common.error') as string, this.resourceService.get('dms.common.error') as string);
        }
      });
  }

  startDownloadingFile(data) {
    var downloadContract = {
      FolderId: this.folderHierarchyList.get("folderId"),
      Hierarchy: data.Hierarchy,
      FileId: data.Id,
      FileGuid: data.Guid,
      FileName: data.Name,
      FileType: data.Type,
      StoragePath: data.StoragePath,
      EntityType: data.EntityType,
      EntityId: data.EntityId,
    };
    const downloadContractBtoa = encodeURIComponent(btoa(unescape(encodeURIComponent(JSON.stringify(downloadContract)))));
    var target = '_self';
    var form = document.createElement('form');
    form.setAttribute('method', 'POST');
    form.setAttribute('action', '/dms/api/Export/DownloadFile/');
    form.setAttribute('target', target);

    var inputdownloadContractBtoa = document.createElement('input');
    inputdownloadContractBtoa.type = 'hidden';
    inputdownloadContractBtoa.name = 'downloadContractBtoa';
    inputdownloadContractBtoa.value = downloadContractBtoa;
    form.appendChild(inputdownloadContractBtoa);

    document.body.appendChild(form);
    form.target = target;
    form.submit();
    document.body.removeChild(form);
  }

  showConfirmDeleteDialog(selectedFile, status = antivirusScanStatus.Fail, gridPayload, tab){
    if(status === antivirusScanStatus.Fail){
      this.failMessage = this.resourceService.getText('dms.common.filequarantined');
    }
    else{
      this.failMessage = this.resourceService.getText('dms.common.fileinvalidextention');
    }
    const config: ModalPopupConfig<ConfirmationBoxInputModel> = new ModalPopupConfig<ConfirmationBoxInputModel>();
    let model = new ConfirmationBoxInputModel();
    model.message = this.failMessage;
    model.type = ConfirmationBoxType.YesNo;
    config.data = model;
    let instance = this.popupService.open<ConfirmationBoxComponent>(this.resourceService.getText('dms.delete.permanenttitle'), ConfirmationBoxComponent, config);
    const subscription = instance.afterClosed.subscribe(x => {
      if (subscription) {
        subscription.unsubscribe();
      }
      if (x && x.result) {
        var deleteContract = {
          FileGuid: selectedFile.Guid,
          EntityType: selectedFile.EntityType,
          EntityId: selectedFile.EntityId
      };
      this.dmsDialogApiService.DeleteDocumentspermanently(deleteContract).then((res)=>{
        if (res.success === true) {
          this.dmsDownloadButton = true;
          if(tab == 'clientDoc'){
            const payload = {
              payload: gridPayload,
              isOnlyContactSelected: false,
              isEmptyEvent: true
            }
            this.dmsServices.clearSearchFilter.next(payload);
          }
          else{
            this.firmDocService.setLoaderSubject(true);
            this.firmDocService.loadFirmDocuments(gridPayload);
            this.firmDocService.scrollTop();
          }         
      }
      else{
        this.popupService.info(this.resourceService.get('ifirm.common.error') as string, this.resourceService.get('dms.delete.errormessage') as string);
      }
    })
  }
  });
  }

  downloadMultipleFiles(selectedCheckBoxData,tab,gridPayload){   
      var selectedFileIds = [];
      var selectedFolderIds = [];
      var isSearchFilterApplied = false;
      var selecterFolderList = [];
      var contactId = 0;
      var selecterFolderListForEmptyCheck = [];
      if(gridPayload.IsFileSearch || gridPayload.IsFiltering){
      isSearchFilterApplied =  true;
      }
      selectedCheckBoxData.map((res, index) => {
        if (res.Kind === fileKind.File) {
          selectedFileIds.push(res.Id);
        }
        if (res.Kind === fileKind.Folder) {
          if (!isSearchFilterApplied) {
              selectedFolderIds.push(res.Id);
          } else {
              selecterFolderList.push({
                  FolderId: res.Id, Hierarchy: res.Hierarchy
              });
          }
          selecterFolderListForEmptyCheck.push({
              Id: res.Id, Hierarchy: res.Hierarchy
          });
      }
      });

      if (selectedFileIds.length === 0 && (selecterFolderListForEmptyCheck.length > 0)){
        var deleteContract = {
          DeleteFileFolderList: selecterFolderListForEmptyCheck
      };
      this.dmsDialogApiService.checkFolderEmpty(deleteContract).then((res)=>{
        if (res.success === false) {
          this.downloadZip(selectedFolderIds,
              selecterFolderList,
              selectedFileIds,
              isSearchFilterApplied, contactId);
      } else {
        this.popupService.info(this.resourceService.get('ifirm.common.error') as string, this.resourceService.get('dms.download.emptyfoldermsg') as string);
      }
      })
      }
      else {
        this.downloadZip(selectedFolderIds, selecterFolderList, selectedFileIds, isSearchFilterApplied, contactId);
    }
  }

  downloadZip(
    selectedFolderIds,
    selecterFolderList,
    selectedFileIds,
    isSearchFilterApplied,
    contactId
  ) {
    var downloadContract = {
      SelectedFolderIds: selectedFolderIds,
      SelectedFolderList: selecterFolderList,
      SelectedFileIds: selectedFileIds,
      ParentFolderId: this.folderHierarchyList.get("folderId"),
      Hierarchy: null,
      IsSearchFilterApplied: isSearchFilterApplied,
      DisplayArea: 1,
      ContactId: contactId,
    };
    this.dmsDialogApiService.validateBulkFileDownload(downloadContract).then((response) => {
        if (response.success === false && response.ValidationCode === ApiValidationCode.FileNotScanned) {
          const config: ModalPopupConfig<ConfirmationBoxInputModel> = new ModalPopupConfig<ConfirmationBoxInputModel>();
          let model = new ConfirmationBoxInputModel();
          model.message = this.resourceService.getText('cp.documents.filenotscannedfrombulk');
          model.type = ConfirmationBoxType.YesNo;
          config.data = model;
          let instance = this.popupService.open<ConfirmationBoxComponent>(this.resourceService.getText('apm.viewwip.dialog.warning'), ConfirmationBoxComponent, config);
          const subscription = instance.afterClosed.subscribe(x => {
            if (subscription) {
              subscription.unsubscribe();
            }
            if (x && x.result) {
              this.startDownloadZip(downloadContract);
        }
        })
        }
    else if (response.success === false && response.ScanStatusCount > 0 && response.InvalidFilesCount > 0 && response.ScanStatusCount > response.InvalidFilesCount){
          this.startDownloadZip(downloadContract);
         }
       else if ( response.success === true) {
          this.startDownloadZip(downloadContract);
        }
        else if ( response.success === false) {
          this.popupService.info(this.resourceService.get('ifirm.common.error') as string, response.message as string);
        }
      });
  }

  startDownloadZip = function (downloadContract) {
    var downloadContractBtoa = encodeURIComponent(
      btoa(unescape(encodeURIComponent(JSON.stringify(downloadContract))))
    );
    var target = '_self';
    var form = document.createElement('form');
    form.setAttribute('method', 'POST');
    form.setAttribute('action', '/dms/api/Export/DownloadFilesUsingZip/');
    form.setAttribute('target', target);

    var inputdownloadContractBtoa = document.createElement('input');
    inputdownloadContractBtoa.type = 'hidden';
    inputdownloadContractBtoa.name = 'downloadContractBtoa';
    inputdownloadContractBtoa.value = downloadContractBtoa;
    form.appendChild(inputdownloadContractBtoa);

    document.body.appendChild(form);
    form.target = target;
    form.submit();
    document.body.removeChild(form);
};
validateCopyMoveButton(records){
  let result = true;
  let resultSet = [];
    if (records?.length >= 1){
      const userRoles = this.firmDocService.userRoles;
      const selectionHasInternalDocuments = records[0].EntityType == DMSFirmDocument.InternalDocuments
      const selectionHasHrDocuments = records[0].EntityType == DMSFirmDocument.HRDocuments;
      const selectionHasUserDocuments = records[0].EntityType == DMSFirmDocument.User;
      if (userRoles?.firmDocuments){
        if ((selectionHasInternalDocuments && userRoles.internalDocumentsViewEdit) ||
        (selectionHasHrDocuments && userRoles.hrManager) || selectionHasUserDocuments){
          records?.forEach(element => {
            if (!element.IsLocked && element.DefaultFolderId === 0 && !element.IsSystemFolder){
              result = false;
              resultSet.push(result);
            }else {
              resultSet.push(result);
            }
          });
        }
      }
    }
    result = resultSet?.length === 0 ? true: resultSet?.every(ele => ele === false);
    return result;
  }

  validateDeleteButton(element, userRoles){
    if (element.Kind == fileKind.Contact || (element.Kind == fileKind.Folder && (element.Id <= 0 || element.IsSystemFolder || element.DefaultFolderId > 0))) return false; 
    if (userRoles.DmsFirmDocuments && (element.EntityType == entityType.Firm || element.EntityType == entityType.User || element.EntityType == entityType.Hr)) {
        if (element.EntityType == entityType.Firm && userRoles.DmsInternalDocumentsViewEdit) return true;
        if (element.EntityType == entityType.Hr && userRoles.hrManager) return true;
        if (element.EntityType == entityType.User && element.EntityId > 0 && element.EntityId == userRoles.userId) return true;
        if (element.EntityType == entityType.User && element.EntityId > 0 && element.EntityId != userRoles.userId && userRoles.DmsUserFolderAdmin) return true;
      }
  }
  isDeleteAllowed(records) {
    let result = [];
    let userRoles = null;
    if (this.dmsServices.userInfoMap.get('userInfoValue') != undefined) {
      userRoles = this.dmsServices.userInfoMap.get('userInfoValue');
    }
    records?.forEach(element => {
      result.push(this.validateDeleteButton(element, userRoles));
    });
    this.dmsDeleteButton =  result?.length === 0 ? true: !result?.every(Boolean);
  };

 setLoaderSubject(val: boolean) {
  this.loaderSubject.next(val);
  }

  getLoaderSubject() {
  return this.loaderSubject.asObservable();
  }

  validateDownloadButton(records){
    let result: boolean;
    records.forEach(list => {
      if(!result && list.Type?.Extension?.toLowerCase() != "dmsurllink" && records.length !== 0 ){
        result = false;
      }
      else{
        result = true;
      }
    });
    return result === undefined ? true : result;
  }

  openPdf(fileData,tab,gridPayload){
  var isSingleEntityId = true;
  var fileContract = {
    StoragePath: fileData[0].StoragePath,
    FileGuid: fileData[0].Guid,
    FileType: fileData[0].Type,
    FileId: fileData[0].Id
}
this.dmsDialogApiService.validateFileDownload(fileContract).then((response) => {

  if (response.success === false && (response.ValidationCode === ApiValidationCode.FileQuarantined || response.ValidationCode === ApiValidationCode.FileInvalidExtension)) {
    var status = (response.ValidationCode === ApiValidationCode.FileQuarantined) ? antivirusScanStatus.Fail : antivirusScanStatus.InvalidExtension
    this.showConfirmDeleteDialog(fileData[0], status,gridPayload,tab);
}

else if (response.success === false && response.ValidationCode === ApiValidationCode.FileNotScanned) {

  const config: ModalPopupConfig<ConfirmationBoxInputModel> = new ModalPopupConfig<ConfirmationBoxInputModel>();
  let model = new ConfirmationBoxInputModel();
  model.message = this.resourceService.getText('dms.common.filenotscanned');
  model.type = ConfirmationBoxType.YesNo;
  config.data = model;
  let instance = this.popupService.open<ConfirmationBoxComponent>(this.resourceService.getText('dms.downloadwarning'), ConfirmationBoxComponent, config);
  const subscription = instance.afterClosed.subscribe(x => {
    if (subscription) {
      subscription.unsubscribe();
    }
    if (x && x.result) {
      const selectedFileIds = fileData.map((x) => x.Id).join(',');
      this.openPdfEditorWithMultipleFiles(selectedFileIds, isSingleEntityId, fileData[0], fileData.length,gridPayload,tab);
      setTimeout(() => {
        if(tab == 'clientDoc'){
          const payload = {
            payload: gridPayload,
            isOnlyContactSelected: false,
            isEmptyEvent: true
          }
          this.dmsServices.clearSearchFilter.next(payload);
        }
      }, 5000);
}
});
}

else if (response.success === false && response.ValidationCode === ApiValidationCode.FileNotFound) {
  this.popupService.info(this.resourceService.get('dms.validationmessages.' + response.ValidationCode) as string, this.resourceService.get('dms.common.fallbackerrormessage') as string);
}
else if (response.success === true) {
  const selectedFileIds = fileData.map((x) => x.Id).join(',');
  this.openPdfEditorWithMultipleFiles(selectedFileIds, isSingleEntityId, fileData[0], fileData.length,gridPayload,tab)
  setTimeout(() => {
    if(tab == 'clientDoc'){
      const payload = {
        payload: gridPayload,
        isOnlyContactSelected: false,
        isEmptyEvent: true
      }
      this.dmsServices.clearSearchFilter.next(payload);
    }
  }, 5000);
}
else {
  this.popupService.info(this.resourceService.get('ifirm.common.error') as string, this.resourceService.get('dms.common.error') as string);
}

  })
}

openMergePdf(fileData,gridPayload,tab){
  var isSearchFilterApplied = false;
  var parentFolderId = fileData[0].ParentId;
  var fileIdList = fileData.map(function (file) {
    return file.Id;
});
var isSingleEntityId = fileData.every(function (file, i, arr) {
  if (i == 0) {
      return true;
  }
  else {
      return (file.EntityId === arr[i - 1].EntityId);
  }
});
if(gridPayload.IsFileSearch || gridPayload.IsFiltering){
  isSearchFilterApplied =  true;
  }
var downloadContract = {
  SelectedFolderIds: [],
  SelectedFolderList: [],
  SelectedFileIds: fileIdList,
  ParentFolderId: parentFolderId,
  Hierarchy: this.folderHierarchyList.get("Hierarchy"),
  IsSearchFilterApplied: isSearchFilterApplied,
  DisplayArea: this.folderHierarchyList.get("DisplayArea"),
  ContactId: 0
};
this.dmsDialogApiService.validateBulkFileDownload(downloadContract).then((response)=>{
  if (response.success === false && (response.ValidationCode === ApiValidationCode.FileQuarantined || response.ValidationCode === ApiValidationCode.FileInvalidExtension)) {
    var status = (response.ValidationCode === ApiValidationCode.FileQuarantined) ? antivirusScanStatus.Fail : antivirusScanStatus.InvalidExtension
    this.showConfirmDeleteDialog(fileData, status,gridPayload,tab);
}
if (response.success === false && response.InvalidFilesCount > 0 && response.ScanStatusCount > 0) {
  this.popupService.info(this.resourceService.get('ifirm.common.alert') as string, this.resourceService.get('dms.editpdffileseitherquarantinedorinvalid') as string);
}
else if (response.success === false && response.ValidationCode === ApiValidationCode.FileNotScanned) {
  var fileNotScannedMessage = (fileData.length > 1) ? this.resourceService.getText('dms.common.filenotscannedfrombulk') : this.resourceService.getText('dms.common.filenotscanned');
  const config: ModalPopupConfig<ConfirmationBoxInputModel> = new ModalPopupConfig<ConfirmationBoxInputModel>();
  let model = new ConfirmationBoxInputModel();
  model.message = fileNotScannedMessage;
  model.type = ConfirmationBoxType.YesNo;
  config.data = model;
  let instance = this.popupService.open<ConfirmationBoxComponent>(this.resourceService.getText('dms.downloadwarning'), ConfirmationBoxComponent, config);
  const subscription = instance.afterClosed.subscribe(x => {
    if (subscription) {
      subscription.unsubscribe();
    }
    if (x && x.result) {
      const selectedFileIds = fileData.map((x) => x.Id).join(',');
      this.openPdfEditorWithMultipleFiles(selectedFileIds, isSingleEntityId, fileData[0], fileData.length,gridPayload,tab)
      setTimeout(() => {
        if(tab == 'clientDoc'){
          const payload = {
            payload: gridPayload,
            isOnlyContactSelected: false,
            isEmptyEvent: true
          }
          this.dmsServices.clearSearchFilter.next(payload);
        }
      }, 5000);
}
});
}

else if (response.success === false && response.ValidationCode === ApiValidationCode.AllFilesEitherQuarantinedOrInvalid) {
  this.popupService.info(this.resourceService.get('ifirm.common.alert') as string, this.resourceService.get('dms.editpdffileseitherquarantinedorinvalid') as string);
}
else if (response.success === false) {
  this.popupService.info(this.resourceService.get('ifirm.common.error') as string, response.message as string);
}
else if (response.success === true) {
  const selectedFileIds = fileData.map((x) => x.Id).join(',');
  this.openPdfEditorWithMultipleFiles(selectedFileIds, isSingleEntityId, fileData[0], fileData.length,gridPayload,tab)
  setTimeout(() => {
    if(tab == 'clientDoc'){
      const payload = {
        payload: gridPayload,
        isOnlyContactSelected: false,
        isEmptyEvent: true
      }
      this.dmsServices.clearSearchFilter.next(payload);
    }
  }, 5000);
}
})
}

openPdfEditorWithMultipleFiles(fileIds, isSingleEntityId, file, numberOfFiles,gridPayload,tab) {
  if((gridPayload.IsFileSearch || gridPayload.IsFiltering) && numberOfFiles > 1){
    isSingleEntityId =  true;
    }
  var payload = "javascript:var form = document.createElement('form');form.setAttribute('method', 'post');form.setAttribute('action', '/#/dms/pdfview?rh=0&mg=0');form.setAttribute('target', '_blank');var hiddenField = document.createElement('input');hiddenField.setAttribute('name', 'ids');hiddenField.setAttribute('value', '" + fileIds + "');form.appendChild(hiddenField);var hiddenField = document.createElement('input');hiddenField.setAttribute('name', 'entityType');hiddenField.setAttribute('value', '" + file.EntityType + "');form.appendChild(hiddenField);var hiddenField = document.createElement('input');hiddenField.setAttribute('name', 'isSingleEntityId');hiddenField.setAttribute('value', '" + isSingleEntityId + "');form.appendChild(hiddenField);var hiddenField = document.createElement('input');hiddenField.setAttribute('name', 'entityId');hiddenField.setAttribute('value', '" + file.EntityId + "');form.appendChild(hiddenField);var hiddenField = document.createElement('input');hiddenField.setAttribute('name', 'hierarchy');hiddenField.setAttribute('value', '" + file.Hierarchy + "');form.appendChild(hiddenField);form.appendChild(hiddenField);form.appendChild(hiddenField);form.appendChild(hiddenField);document.body.appendChild(form);form.submit()";

  var newWindow = window.open(payload, '_self');
  newWindow.opener = null;
  setTimeout(() => {
      const limitedInterval = setInterval(() => {
          if (newWindow != null && newWindow.closed) {
              clearInterval(limitedInterval);
              if(tab == 'clientDoc'){
                const payload = {
                  payload: gridPayload,
                  isOnlyContactSelected: false,
                  isEmptyEvent: true
                }
                this.dmsServices.clearSearchFilter.next(payload);
              }
             file.IsLocked = true;
             this.showOpenPdf = true;
             this.showMergePdf = false;
             this.dmsOpenPdfButton = true;
             this.dmsMergePdfButton = true;
             if(tab == 'clientDoc'){
              const payload = {
                payload: gridPayload,
                isOnlyContactSelected: false,
                isEmptyEvent: true
              }
              this.dmsServices.clearSearchFilter.next(payload);
            }
            else{
              this.firmDocService.setLoaderSubject(true);
              this.firmDocService.loadFirmDocuments(gridPayload);
              this.firmDocService.scrollTop();
            }  
          }
      }, 2000);
  }, 5000);
}

  openLockClick(file,tab,gridPayload) :void{
    if (this.validateUnlockRole(file,this.userInfoMap)) {
    const config: ModalPopupConfig<ConfirmationBoxInputModel> = new ModalPopupConfig<ConfirmationBoxInputModel>();
    let model = new ConfirmationBoxInputModel();
    model.message = this.resourceService.getText('dms.openedit.unlockfileoropenasreadonly');
    model.type = ConfirmationBoxType.UnlockFile;
    config.data = model;
    let instance = this.popupService.open<ConfirmationBoxComponent>(this.resourceService.getText('dms.openedit.unlockfile'), ConfirmationBoxComponent, config);
    const subscription = instance.afterClosed.subscribe(x => {
      if (subscription) {
        subscription.unsubscribe();
      }
      if (x && x.result) {
     this.getUnlockFile(file.Id).subscribe(result => {
        if (result.success == true && result.data == true) {
          file.IsLocked = false;
      } else {
        this.toasterService.error(this.resourceService.getText('dms.openedit.unlockfileerrormmessage'));
      }
      },
      (error)=> {
        this.toasterService.error(this.resourceService.getText('dms.openedit.unlockfileerrormmessage'));
      })
    }
    else{
      this.openAsReadOnly(file,tab,gridPayload); 
    }
    })
  }
    else{
     this.openAsReadOnly(file,tab,gridPayload);
    }
  }
  private validateUnlockRole(file,userRoles):boolean {
    if (userRoles.DmsViewUnlock && (file.EntityType == entityType.Contact || file.EntityType == entityType.Job)) {
        return true;
    }
    else if (userRoles.DmsFirmDocuments) {
        if (file.EntityType == entityType.Firm && userRoles.DmsInternalDocumentsViewEdit) {
            return true;
        }
        else if (file.EntityType == entityType.Hr && userRoles.DmsHrManager) {
            return true;
        }
        else if (file.EntityType == entityType.User && userRoles.DmsUserFolderAdmin) {
            return true;
        }
        else if (file.EntityType == entityType.User && file.EntityId == userRoles.userId) {
            return true;
        }
        return false;
    }
    return false;
}
openAsReadOnly(file,tab,gridPayload) {
  this.GetAntivirusScanStatusByFileId(file.Id).subscribe((result) => {
    if (result.success) {
      if (result.data === antivirusScanStatus.Queued || result.data === antivirusScanStatus.NotStarted ||
        result.data === antivirusScanStatus.Error) {

          const config: ModalPopupConfig<ConfirmationBoxInputModel> = new ModalPopupConfig<ConfirmationBoxInputModel>();
          let model = new ConfirmationBoxInputModel();
          model.message = this.resourceService.getText('cp.documents.filenotscanned');
          model.type = ConfirmationBoxType.YesNo;
          config.data = model;
          let instance = this.popupService.open<ConfirmationBoxComponent>(this.resourceService.getText('dms.downloadwarning'), ConfirmationBoxComponent, config);
          const subscription = instance.afterClosed.subscribe(x => {
            if (subscription) {
              subscription.unsubscribe();
            }
            if (x && x.result) {
            if ((FileExtensions.allowedPdfEditingFileExtension.indexOf(file.Type.Extension.toLowerCase()) !== -1 ||
            FileExtensions.officeFileExtensions.indexOf(file.Type.Extension.toUpperCase()) !== -1) && file.FileSize < this.enhancedPdfMaxSize) {
                this.openPdfOfficeOpener(file, true,tab);
            }
            else {
                this.toasterService.error(this.resourceService.getText('dms.openedit.readonlyfilelocked'));
            }
          }
          });
  

    }
    else if (result.data === antivirusScanStatus.Fail || result.data === antivirusScanStatus.InvalidExtension) {
           this.showConfirmDeleteDialog(file, result.data,gridPayload,tab);
    }
    else {
      console.log(FileExtensions,file,this.enhancedPdfMaxSize)
        if ((FileExtensions.allowedPdfEditingFileExtension.indexOf(file.Type.Extension.toLowerCase()) !== -1 ||
        FileExtensions.officeFileExtensions.indexOf(file.Type.Extension.toUpperCase()) !== -1) && file.FileSize < this.enhancedPdfMaxSize) {
            this.openPdfOfficeOpener(file, true,tab);
        }
        else {
          this.toasterService.error(this.resourceService.getText('dms.openedit.readonlyfilelocked'));
        }
    }

  } 
  else {
    this.toasterService.error(this.resourceService.getText(result.message));
  }
  },
  (error)=> {
    this.toasterService.error(this.resourceService.getText('dms.common.error'));
  })
}

validateOpenMergePdfButton(records){
  let result: boolean;
  const multiSelect = records.length >= 1;
  const singleSelect = records.length === 1;
  const selectionHasInternalDocuments = false;
  const selectionHasHrDocuments = false;
  const userRoles = this.firmDocService.userRoles;
  if (userRoles){
    var canCreatePdf = userRoles.firmDocuments && multiSelect;
    if (selectionHasInternalDocuments) {
        canCreatePdf = canCreatePdf && (userRoles.internalDocumentsView || userRoles.internalDocumentsViewEdit);
    }
    if (selectionHasHrDocuments) {
        canCreatePdf = canCreatePdf && userRoles.hrManager;
    }
    records.forEach(list => {
      if(!result && (list.Type?.Extension?.toLowerCase() != "dmsurllink") && (records.length !== 0) && (list.Kind !== DocumentKind.Folder) 
      || (FileExtensions.officeFileExtensions.indexOf(list.Type?.Extension?.toUpperCase()) !== -1 &&
      FileExtensions.allowedPdfEditingFileExtension.indexOf(list.Type?.Extension?.toLowerCase()) !== -1)){
        result = false;
      }
      else{
        result = true;
      }
    });
  }
  else{
    this.applyUserRoles();
    const selectionHasFiles = true;
    if((singleSelect && selectionHasFiles && this.userInfoMap.viewAny)){
        result = false;
    }
    records.forEach(list => {
      if(!result && (list.Type?.Extension?.toLowerCase() != "dmsurllink") && (records.length !== 0) && (list.Kind !== DocumentKind.Folder) 
      || (FileExtensions.officeFileExtensions.indexOf(list.Type?.Extension?.toUpperCase()) !== -1 &&
      FileExtensions.allowedPdfEditingFileExtension.indexOf(list.Type?.Extension?.toLowerCase()) !== -1)){
        result = false;
      }
      else{
        result = true;
      }
    });
  }
  return result === undefined ? true : result;
}

resetDownloadMergePDFButton(){
    this.dmsDownloadButton = true;
    this.showOpenPdf = true;
    this.showMergePdf = false;
    this.dmsOpenPdfButton = true;
    this.dmsMergePdfButton = true;
}

getDocumentFullPathName(file) {     
    if (!file.HierarchyPath) {
      if (!this.preventFileNameMouseOver) {
        this.preventFileNameMouseOver = true;
        this.getDocumentFolderPath(file).subscribe({
          next: (response) => {
            if (response) {               
              file.HierarchyPath = response.data + '\ ' + file.Name;
              this.preventFileNameMouseOver = false;
            }
          },
          error: (e) => {
            this.toasterService.error(this.resourceService.getText('ifirm.common.error'));
          }
        })
      }
    }      
  

}

public getDocumentFolderPath(file): Observable<any>{
  let url = '/dms/api/document/getDocumentFullPath?displayArea=1'+'&entityId='+file?.EntityId+'&entityType='+file?.EntityType;
  url = (!!file?.Hierarchy)? url + '&hierarchy='+file?.Hierarchy: url;;
  return this.api.get<any>(url);
}

loadFirmGridData(){
  const payload: any = this.firmDocService.getPayload$();
  this.firmDocService.loadFirmDocuments(payload.source.value);
}

creatBreadcrumbs(folder) {
  this.dmsServices.breadcrumb$.subscribe((value) => {
    this.currentcrumb = value;
  });
  const newBreadCrumbs = [...this.currentcrumb, folder];
  this.dmsServices.updateBreadcrumbs(newBreadCrumbs);
}

addSearchResultBreadcrumb(DocPayload){
  const searchKey = this.resourceService.getText('dms.common.searchresult') ? this.resourceService.getText('dms.common.searchresult') : 'Search Result';
  if (this.currentcrumb){
    const currentBreadcrumb:any = this.currentcrumb[this.currentcrumb.length - 1];
    if (DocPayload.IsFiltering || DocPayload.SearchText !="" || DocPayload.SearchNote !="" ||
    DocPayload.SearchTags.Tags.length>0){
      if (currentBreadcrumb.Name !== searchKey){
        const data = {
          Name: searchKey,
          isColorChange: true
        }
        this.creatBreadcrumbs(data);
      }
    }else {
      if (currentBreadcrumb.Name === searchKey){
        const newBreadCrumbs: any = this.currentcrumb.slice(0, this.currentcrumb.length-1)
        this.dmsServices.updateBreadcrumbs(newBreadCrumbs);
      }
    }
  }
}
}
 
