import { PropertyName } from '@ifirm'

export class DmsRole {
  @PropertyName("DmsSettingsDocuments")
  DmsSettingsDocuments:boolean;

  @PropertyName("DMSDocumentEmailAdmin")
  DMSDocumentEmailAdmin:boolean;
}
