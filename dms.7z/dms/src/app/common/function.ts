export function toBoolean(value: any): boolean {
    let result: boolean;
    switch (typeof value) {
      case 'string':
        result = `${value}`.toLowerCase() === 'true';
        break;
      case 'undefined':
        result = true;
        break;
      case 'number':
        result = `${value}` === '1';
        break;
      case 'object':
        result = value !== null;
        break;
      default:
        result = value;
    }
  
    return result;
  }