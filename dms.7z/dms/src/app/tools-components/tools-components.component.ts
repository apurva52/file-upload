import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tools-components',
  templateUrl: './tools-components.component.html',
  styleUrls: ['./tools-components.component.scss']
})
export class ToolsComponentsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
