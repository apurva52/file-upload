import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ToolsComponentsComponent } from './tools-components.component';

describe('ToolsComponentsComponent', () => {
  let component: ToolsComponentsComponent;
  let fixture: ComponentFixture<ToolsComponentsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ToolsComponentsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ToolsComponentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
