import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OpenDocumentViewComponent } from './open-document-view.component';

describe('OpenDocumentViewComponent', () => {
  let component: OpenDocumentViewComponent;
  let fixture: ComponentFixture<OpenDocumentViewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OpenDocumentViewComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OpenDocumentViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
