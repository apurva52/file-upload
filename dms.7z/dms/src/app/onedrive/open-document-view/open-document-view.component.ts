
import { Component, ViewChild, ElementRef, OnInit, OnDestroy } from '@angular/core';
import { DmsService } from '../../dms.service';
import {DmsDialogService} from '../../dialogs/dms-dialog.service'
import {DmsDialogApiService} from '../../dialogs/dms-dialog-api.service'
import { DmsFileModel } from '../../dialogs/models/dms-file.model'
import { OnedriveOpenDocumentModel} from '../../dialogs/models/onedrive-open-document.model'
import {OneDriveDocumentUpload} from '../../dialogs/models/one-drive-document-upload.model'

@Component({
  selector: 'app-open-document-view',
  templateUrl: './open-document-view.component.html',
  styleUrls: ['./open-document-view.component.scss']
})
export class OpenDocumentViewComponent implements OnInit, OnDestroy {

  fileId: number;
  ondriveDocument: OneDriveDocumentUpload;

  constructor(private dmsService: DmsService, private dmsDialogService: DmsDialogService, private dmsDialogApiService: DmsDialogApiService ) { }

  ngOnInit(): void {
    this.fileId = this.dmsService.getParamValueQueryString("id");
    if(this.fileId)
    {
      this.OpenDocument(this.fileId)
    }
    }

    async OpenDocument(fileId: number)
    {
      var res = await this.dmsDialogApiService.getDocumentById(fileId);
      if(res.success)
      {
        this.dmsDialogService.openDialog('opendocument', this.MapOnedriveDocuments(res.data), null);
      }
    }

    MapOnedriveDocuments(dmsFileModel : any) : OnedriveOpenDocumentModel
    {
      var openDocument = new OnedriveOpenDocumentModel();
      openDocument.FileId = this.fileId;
      openDocument.EntityType = dmsFileModel.EntityType;
      openDocument.EntityId = dmsFileModel.EntityId;
      openDocument.Hierarchy = dmsFileModel.Hierarchy;
      openDocument.FileType = dmsFileModel.Type;
      openDocument.FileName = dmsFileModel.FileName;
      openDocument.FileGuid = dmsFileModel.Guid;
      openDocument.OpenEditPayload = dmsFileModel.OpenEditPayload;
      openDocument.ExtensionType =  dmsFileModel.Type? dmsFileModel.Type.Extension: '';
      openDocument.IsReadOnly = false;
      openDocument.IsOpenThroughUrl = true;
      openDocument.updateLockEvent = this.setIframeReady;
      return openDocument;
    }

    setIframeReady(ondriveDocument: OneDriveDocumentUpload): void {
      window.location.href = ondriveDocument.WebUrl;
    }

    ngOnDestroy() {
     
    }
}


