import { Directive, ElementRef, HostListener } from '@angular/core';
import { AbstractControl, NgControl } from '@angular/forms';

@Directive({
  selector: '[removeUnsupportedCharacters]'
})
export class RemoveUnsupportedCharactersDirective {
  private ctrl: AbstractControl;

  constructor(private elementRef: ElementRef<HTMLInputElement>, private ngControl: NgControl) { }

  @HostListener('focusout') focusOut() {
    this.ctrl.setValue(this.elementRef.nativeElement.value.replace(/[/\\?*:|"<>]/g, '').trim(), { emitEvent: false });
  }

  @HostListener('keyup') keyUp() {
    this.ctrl.setValue(this.elementRef.nativeElement.value.replace(/[/\\?*:|"<>]/g, ''), { emitEvent: false });
  }

  ngOnInit() {
    this.ctrl = this.ngControl.control;
  }
}
