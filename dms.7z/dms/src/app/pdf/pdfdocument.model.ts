import { PropertyName } from "@ifirm";
import { documentType, entityType, fileSource } from "../constants/app-constants";
import { FileType } from "../dialogs/models/dms-filetype.model";

export class Pdfdocument {
    @PropertyName("FileName")
    FileName: string;

    @PropertyName("FileData")
    FileData: BlobPart[];

    @PropertyName("Size")
    Size: number;

    @PropertyName("EntityType")
    EntityType: entityType;

    @PropertyName("EntityId")
    EntityId: number;
	
	@PropertyName("FolderId")
    FolderId: number;
	
	@PropertyName("Hierarchy")
    Hierarchy: string;
	
	@PropertyName("FileGuid")
    FileGuid: string;
	
	@PropertyName("FileType")
    FileType: FileType;
	
	@PropertyName("DocumentType")
    DocumentType: documentType;
	
	@PropertyName("Source")
    Source: fileSource;

    @PropertyName("PartIndex")
    PartIndex: number;

    @PropertyName("TotalParts")
    TotalParts: number;

    @PropertyName("PartByteOffsetIndex")
    PartByteOffsetIndex: number;

    @PropertyName("ChunkSize")
    ChunkSize: number;

    @PropertyName("CreatedDateTime")
    createdDateTime? : Date;

    @PropertyName("IsUploadFromTrayapp")
    IsUploadFromTrayapp : boolean;
}