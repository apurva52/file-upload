import { HttpParams } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ResourceService, ToasterService, GlobalScopeService } from '@ifirm';
import { Subscription } from 'rxjs';
import { ApiValidationCode, LockType } from '../constants/app-constants';
import { PdfdocumentService } from './pdfdocument.service';
import { Pdfsettings } from './pdfsettings.model';
import { PostData,FileDetails } from './models/formData.model'

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.scss']
})
export class ViewComponent implements OnInit {
  fileIds: string[];
  pdfSettings: Pdfsettings;
  isSuccess: boolean = false;
  subscriptions: Subscription[] = [];
  chunkSize: number;
  loggedInUserFullName: string = '';
  enhancedPdfLicenseKey: string = '';
  isHr: boolean = false;
  isUser: boolean = false;
  postData: PostData;
  fileDetails: FileDetails;
  allowApmAccess: boolean =false;
  forceUnLockFileDateTimeToGetFile: number;
  isReadOnlyMode: boolean=false;

  constructor(private toasterService: ToasterService, private resourceService: ResourceService, private pdfdocumentService: PdfdocumentService, private globalScope: GlobalScopeService) { }

  ngOnInit(): void {
    this.getFormData();
    this.isReadOnlyMode = this.globalScope.appFrame.GetUrlVariable('isreadonly');
    this.fileIds = this.fileDetails.ids.split(",");
    if (this.fileIds.some(this.checkIfNumbers)) {
      this.fileIds = [];
      this.displayMessage('dms.settings.anerroroccurred');
    }
    else {
        //API call to lock files
        if(this.isReadOnlyMode === undefined || this.isReadOnlyMode === false){
        this.pdfdocumentService.LockFiles(this.fileIds, LockType.PdfEdit).then((result) => {
          if (result.success) {
            this.pushPdfsubscriptions();
          }
          else {
            //unable to lock files
            // Display access denied message
            if (result.errorcode === ApiValidationCode.FileLockExist) {
              this.toasterService.error(result.message);
            }
            else {
              this.displayMessage('ifirm.common.accessdenied');
            }
          }
        });
      }
      else{
        this.pushPdfsubscriptions();
      }
    }
  }

  pushPdfsubscriptions()
  {
    this.subscriptions.push(this.pdfdocumentService.GetEnhancedpdfSettings().subscribe(pdfsettings => {
      this.pdfSettings = pdfsettings;
      if (this.pdfSettings.EnhancedPdfSwitch) {
        this.chunkSize = this.pdfSettings.ChunkSize;
        this.loggedInUserFullName = this.pdfSettings.UserFullName;
        this.enhancedPdfLicenseKey = this.pdfSettings.EnhancedPdfLicenseKey;
        this.forceUnLockFileDateTimeToGetFile = this.pdfSettings.ForceUnLockFileDateTimeToGetFile;
        if (this.fileIds.length <= this.pdfSettings.EnhancedPdfFileCount) {
          this.isSuccess = true;
        }
        else {
          this.displayMessage('dms.settings.anerroroccurred');
        }
      }
      else {
        this.displayMessage('ifirm.common.accessdenied');
      }
    }))
  }


  displayMessage(resourceKey: string) {
    const error = this.resourceService.get(resourceKey);
    if (error instanceof Promise) {
      (error as Promise<string>).then((message) => {
        this.toasterService.error(message);
      });
    } else {
      this.toasterService.error("An error occurred. Try again.");
    }
  }

  checkIfNumbers(fileId: string) {
    if (Number.isNaN(Number(fileId)) || Number(fileId) === 0) {
      return true;
    }
    return false;
  }

  getFormData() {
    this.postData = new PostData();
    this.postData.Data = window;
    this.fileDetails =new FileDetails();
    this.fileDetails = this.postData.Data.iFirmPostData;
  }

  getParamValueQueryString(paramName: string) {
    const url = window.location.href;
    let paramValue;
    if (url.includes('?')) {
      const httpParams = new HttpParams({ fromString: url.split('?')[1] });
      paramValue = httpParams.get(paramName);
    }
    return paramValue;
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(a => a.unsubscribe());
  }
}
