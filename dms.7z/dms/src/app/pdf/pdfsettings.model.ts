import { PropertyName } from "@ifirm";

export class Pdfsettings {
    @PropertyName("EnhancedPdfMaxSize")
    EnhancedPdfMaxSize: number;

    @PropertyName("EnhancedPdfFileCount")
    EnhancedPdfFileCount: number;

    @PropertyName("EnhancedPdfSwitch")
    EnhancedPdfSwitch: number;

    @PropertyName("ChunkSize")
    ChunkSize: number;

    @PropertyName("UserFullName")
    UserFullName: string;

    @PropertyName("EnhancedPdfLicenseKey")
    EnhancedPdfLicenseKey: string;

    @PropertyName("AllowApmAccess")
    AllowApmAccess: boolean;

    @PropertyName("ForceUnLockFileDateTimeToGetFile")
    ForceUnLockFileDateTimeToGetFile: number;
    
    @PropertyName("HasContactViewRole")
    HasContactViewRole: boolean;

    @PropertyName("IsAllowInternaldocuments")
    IsAllowInternaldocuments: boolean;

    @PropertyName("IsAllowFirmdocuments")
    IsAllowFirmdocuments: boolean;

    @PropertyName("IsAllowHRManagerDocuments")
    IsAllowHRManagerDocuments: boolean;

    @PropertyName("IsAllowDocumentsEdit")
    IsAllowDocumentsEdit: boolean;
    
}
