export class PostData {
    Data: any;
}

export class FileDetails {
    ids: string;
    entityType: number;
    fileName:string;
    isHr: boolean;
    isUser: boolean;
    entityId:number;
    isSingleEntityId:boolean;
    hierarchy:string;
}