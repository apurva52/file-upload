import { PropertyName } from '@ifirm';
import { entityType, fileKind } from '../../constants/app-constants';
import { Pdfsettings } from '../pdfsettings.model';

export class DmsFile {
    
    @PropertyName("EntityType")
    EntityType: entityType;

   @PropertyName("EntityId")
    EntityId: number;

   @PropertyName("Id")
    Id: number;

   @PropertyName("JobTypeId")
    JobTypeId: number;
    
    @PropertyName("Name")
    Name: string;

   @PropertyName("Kind")
    FileKind: fileKind;

   @PropertyName("Hierarchy")
    Hierarchy: string;

    @PropertyName("FolderId")
    FolderId: number;

    @PropertyName("IsSingleEntity")
    IsSingleEntity:boolean;

  @PropertyName("Pdfsettings")
    Pdfsettings: Pdfsettings;
}


