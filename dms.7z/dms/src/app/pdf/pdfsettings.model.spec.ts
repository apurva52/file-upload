import { Pdfsettings } from './pdfsettings.model';

describe('Pdfsettings', () => {
  it('should create an instance', () => {
    expect(new Pdfsettings()).toBeTruthy();
  });
});
