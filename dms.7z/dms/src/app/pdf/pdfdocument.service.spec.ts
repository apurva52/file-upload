import { TestBed } from '@angular/core/testing';

import { PdfdocumentService } from './pdfdocument.service';

describe('PdfdocumentService', () => {
  let service: PdfdocumentService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PdfdocumentService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
