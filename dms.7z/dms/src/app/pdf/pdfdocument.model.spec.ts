import { Pdfdocument } from './pdfdocument.model';

describe('Pdfdocument', () => {
  it('should create an instance', () => {
    expect(new Pdfdocument()).toBeTruthy();
  });
});
