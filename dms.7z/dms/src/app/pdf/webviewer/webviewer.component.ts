import { DOCUMENT } from '@angular/common';
import { Component, ViewChild, OnInit, ElementRef, AfterViewInit, Inject, Input, NgZone, ChangeDetectorRef, HostListener } from '@angular/core';
import { PdfdocumentService } from '../pdfdocument.service';
import { LanguageService, ModalPopupService, ResourceService, ModalPopupConfig, ToasterService, GlobalScopeService } from '@ifirm';
import { forkJoin, Observable, of, Subscription, switchMap } from 'rxjs';
import { Pdfdocument } from '../pdfdocument.model';
import { fileSource, LockType } from '../../constants/app-constants';
import { UUID } from 'angular2-uuid';
import { FileSaveComponent } from '../../dialogs/file-save/file-save.component';
import { DmsFile } from '../../pdf/models/dms-file.model'
import { Title } from '@angular/platform-browser';
import { FileDetails } from '../models/formData.model';
import { Pdfsettings } from '../pdfsettings.model';
import { entityType } from '../../constants/app-constants';

@Component({
  selector: 'web-viewer',
  templateUrl: './webviewer.component.html',
  styleUrls: ['./webviewer.component.scss']
})
export class WebviewerComponent implements OnInit, AfterViewInit {
  @Input() fileIds: number[];
  @Input() chunkSize: number;
  @Input() loggedInUserFullName: string = '';
  @Input() enhancedPdfLicenseKey: string = '';
  @Input() isHr: boolean;
  @Input() isUser: boolean;
  @Input() fileDetails: FileDetails;
  @Input() pdfSettings: Pdfsettings;
  @Input() forceUnLockFileDateTimeToGetFile: number;
  allBlob: Blob[];
  WebViewer: any;
  mergedBlob: Blob;
  blobResult$: Observable<Blob[]>;
  subscriptions: Subscription[] = [];
  createdDateTime: Date = new Date();
  partIndex: number = 0;
  totalParts: number = 1;
  partByteOffsetIndex: number = 0;
  isWindowClosed: boolean = false;
  dmsFile: DmsFile = new DmsFile();
  divInnerHeight: number;
  isDocumentEdited: boolean = false;
  allowedPdfEditingFileExtension: any[] = ["png", "gif", "jpg", "jpeg", "bmp", "jpe", "tif", "tiff", "pdf"];
  fileExtension : string = '';
  officeFileExtensions: any[]=["docx", "xlsx", "pptx", "ppt", "doc", "xls"];
  isReadOnlyMode: boolean =false;
  fileName : string = '';

  constructor(private readonly pdfDocumentService: PdfdocumentService, @Inject(DOCUMENT) private readonly document: any, private languageService: LanguageService, private cdRef: ChangeDetectorRef, private resourceService: ResourceService, private popupService: ModalPopupService, private zone: NgZone, private title: Title, private toasterService: ToasterService, private globalScope: GlobalScopeService) {
    this.divInnerHeight = window.innerHeight - 85;
  }

  @ViewChild('viewer', { static: true }) viewer: ElementRef;

  wvInstance: any;
  progressBar: boolean = false;

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.divInnerHeight = event.target.innerHeight - 85;
  }

  ngOnInit(): void {
    if (this.fileIds.length > 0) {
      let fileIdList$ = of(this.fileIds);
      this.blobResult$ = fileIdList$.pipe(
        switchMap((fileIdList: number[]) => {
          const resultArray$: Observable<Blob>[] = [];
          fileIdList.forEach(id => {
            const result$: Observable<Blob> = this.pdfDocumentService.GetFileStreamAsync(id);
            resultArray$.push(result$);
          });
          return forkJoin(resultArray$);
        })
      );
      this.pdfDocumentService.updateLastEditedDateTimeForFiles(this.fileIds);
      setInterval(() => { this.pdfDocumentService.updateLastEditedDateTimeForFiles(this.fileIds); }, this.forceUnLockFileDateTimeToGetFile * 60 * 1000 - 30000);
    }
    this.progressBar = true;

    if (this.fileIds.length > 1) {
      this.setTitle("document 1");
    }
    else {
      this.pdfDocumentService.getDocumentById(this.fileIds[0]).then(result => {
        if (result != null) {
          this.fileDetails.fileName = result.data.Name;
          let index = this.fileDetails.fileName.lastIndexOf(".");
          this.fileName = this.fileDetails.fileName.substring(0, index);
          this.fileExtension = this.fileDetails.fileName.substring(index+1).toLowerCase();
          this.setTitle(this.fileName);
        }
      })
    }

    this.isReadOnlyMode = this.IsReadOnlyMode() || this.globalScope.appFrame.GetUrlVariable('isreadonly');
    if(this.isReadOnlyMode){
      this.toasterService.success(this.resourceService.getText('dms.openedit.fileopenasreadonlymode'));
    }
    this.setCustomCSS();
  }

  @HostListener('window:beforeunload', ['$event'])
  onbeforeunloadHandler(e: any) {
    if (this.isDocumentEdited && !this.isReadOnlyMode) {
      e.preventDefault();
      return e.returnValue = "Are you sure you want to exit?";
    }
  }

  @HostListener('window:unload', ['$event'])
  onunloadHandler(e: any) {
    if(this.isReadOnlyMode == undefined || !this.isReadOnlyMode){
    this.pdfDocumentService.unLockFiles(this.fileIds, LockType.PdfEdit);
    }
  }

  @HostListener('window:pagehide', ['$event'])
  onPageHideHandler(e: any) {
    if(this.isReadOnlyMode == undefined || !this.isReadOnlyMode){
      this.pdfDocumentService.unLockFiles(this.fileIds, LockType.PdfEdit);
      }
  }

  private setTitle(setTitle: string) {
    const title = "iFirm | " + setTitle;
    this.title.setTitle(title);
  }

  private setCustomCSS() {
    let breadCrumBox = document.getElementsByClassName('breadcrumbBox')[0];
    breadCrumBox.remove();
    let pageContent = document.getElementsByClassName('pageMinHeightMinusMarginPadding')[0];
    pageContent.className = "page-content";
  }

  setupWebViewer() {
    if (!this.WebViewer) {
      return;
    }
  }

  ngAfterViewInit(): void {
    if (this.fileIds.length > 0) {
      this.pdfDocumentService.GetApplicationVersion().then(appVersion => {
        let result = appVersion.split(".");
        let buildNumber = [...result].pop();
        this.subscriptions.push(this.pdfDocumentService.lazyLoadPdfTron(buildNumber).subscribe(_ => {
          if (!this.WebViewer) {
            this.WebViewer = this.document.defaultView.WebViewer;
            let webviewerInstance = this.WebViewer({
                licenseKey: this.enhancedPdfLicenseKey,
                path: '../../../wv-resources-8.12.1/lib',
                fullAPI: true,
                annotationUser: this.loggedInUserFullName,
                isReadOnly: this.isReadOnlyMode == undefined ? false : this.isReadOnlyMode,
              },this.viewer.nativeElement);
            
              webviewerInstance.then(instance => {
                this.wvInstance = instance;
                this.subscriptions.push(this.blobResult$.subscribe({
                  next: async (blob: Blob[]) => {
                    this.allBlob = blob;
                    this.main().then(() => {
                      const type=  this.allBlob[0].type.toString();
                      let fileName = 'merged';
                      if (this.fileIds.length === 1) {
                        fileName = this.fileName;
                      }
                      instance.UI.loadDocument(this.mergedBlob,{filename : `${fileName}.pdf`}); 
                      this.progressBar = false;
                      const userCulture = this.languageService.getCurrentCulture();
                      const language = userCulture.split("-");
                      if (language && language.length > 0) { 
                        instance.UI.setLanguage(language[0]);
                      }

                      // instance.UI.setLanguage(currentCulture);
                      const { documentViewer, annotationManager, Tools } = instance.Core;
                      // now you can access APIs through this.webviewer.getInstance()
                      instance.UI.openElement('notesPanel');
                      instance.UI.disableElements(['toolbarGroup-FillAndSign']);
                      instance.UI.enableElements(['contentEditButton']);
                      //instance.UI.disableTool([Tools.ToolNames.RUBBER_STAMP]);
                      instance.UI.disableElements(['signaturePanelButton']);
                      instance.UI.disableElements(['languageButton']);
                      instance.UI.disableTool([Tools.ToolNames.REDACTION]);
                      instance.UI.setToolbarGroup(instance.UI.ToolbarGroup.EDIT);
                      // see https://www.pdftron.com/documentation/web/guides/ui/apis
                      // for the full list of APIs

                      // or listen to events from the viewer element
                      this.viewer.nativeElement.addEventListener('pageChanged', (e) => {
                        const [pageNumber] = e.detail;
                        console.log(`Current page is ${pageNumber}`);
                      });

                        instance.UI.setHeaderItems(header => {
                        header.push({
                          type: 'actionButton',
                          img: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M0 0h24v24H0z" fill="none"/><path d="M17 3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V7l-4-4zm-5 16c-1.66 0-3-1.34-3-3s1.34-3 3-3 3 1.34 3 3-1.34 3-3 3zm3-10H5V5h10v4z"/></svg>',
                          title: 'save',
                          onClick: async () => {
                            const doc = documentViewer.getDocument();
                            const xfdfString = await annotationManager.exportAnnotations();
                            const data: Blob = await doc.getFileData({
                              xfdfString
                            });
                            //Default Chunk size to be from config
                            this.progressBar = true;
                            this.cdRef.detectChanges();
                            this.fileSavePopup(data);
                            //  await this.documentSave(data);
                          },
                          dataElement: 'saveButton'
                        });
                        
                        header.getHeader('toolbarGroup-Forms').delete(2);
                        header.getHeader('toolbarGroup-Insert').delete(1);
                      });
                    
                      // or from the docViewer instance
                      instance.Core.documentViewer.addEventListener('annotationsLoaded', () => {
                        console.log('annotations loaded');
                      });

                      annotationManager.addEventListener('annotationChanged', (e) => {
                        if (e.length >= 1) {
                          this.isDocumentEdited = true;
                        }
                      });

                      instance.Core.documentViewer.addEventListener('rotationUpdated', () => {
                        this.isDocumentEdited = true;
                      });

                      instance.Core.documentViewer.addEventListener('pagesUpdated', () => {
                        this.isDocumentEdited = true;
                      });

                      instance.UI.addEventListener('outlineBookmarksChanged', () => {
                        this.isDocumentEdited = true;
                      });
                      instance.UI.disableElements(['urlInputPanelButton' ,'urlInputPanel']);
                      instance.UI.setPrintQuality(2);
                      if(this.isReadOnlyMode)
                      {
                        instance.Core.documentViewer.setToolMode(instance.Core.documentViewer.getTool(instance.Core.Tools.ToolNames.PAN));
                        instance.UI.disableElements(['menuButton','contentEditButton','toggleNotesButton','selectToolButton','ribbons','panToolButton','leftPanelButton',
                        'toolbarGroup-View', 'notesPanelResizeBar','notesPanel','contextMenuPopup','cropToolGroupButton','saveButton']);
                      }
                    });
                  },
                  error: (e) => { this.toasterService.error(this.resourceService.getText('dms.propertiesdialog.saveerror')); }
                }));
              })
          }
          this.setupWebViewer();
        }));
      });
    }
  }

  IsReadOnlyMode(): boolean {
    return ((!this.pdfSettings.IsAllowInternaldocuments && Number(this.fileDetails.entityType) === entityType.Firm) 
             || (!this.pdfSettings.IsAllowDocumentsEdit && (Number(this.fileDetails.entityType) === entityType.Contact || Number(this.fileDetails.entityType) === entityType.Job)));
  } 

  async saveDocument(fileData: Blob, dmsFile: DmsFile) {
    let pdfdocument = new Pdfdocument();
    pdfdocument.FileName = dmsFile.Name;
    pdfdocument.ChunkSize = this.chunkSize;
    pdfdocument.createdDateTime = this.createdDateTime;
    pdfdocument.Source = fileSource.Desktop;
    pdfdocument.EntityType = dmsFile.EntityType;
    pdfdocument.EntityId = dmsFile.EntityId;
    pdfdocument.FolderId = dmsFile.FolderId;
    pdfdocument.Hierarchy = dmsFile.Hierarchy;
    pdfdocument.FileGuid = UUID.UUID();
    pdfdocument.IsUploadFromTrayapp = true;
    var uploadRequest = await this.BuildUploadRequest(fileData, pdfdocument);

    if(this.pdfSettings.EnhancedPdfMaxSize < new Blob([fileData]).size)
    {
      const pdfMaxSizeInMB : string =  ((this.pdfSettings.EnhancedPdfMaxSize / 1024)/1024).toString();
      this.toasterService.error(this.resourceService.getText('dms.editpdf.pdfmaxsize').replace('{0}', pdfMaxSizeInMB));
      this.progressBar = false;
      return;
    }

    if (uploadRequest.length > 1) {
      let firstAPIRequest = (uploadRequest[0].TotalParts - 1);
      // fetch request excuding last request
      var apiRequestExcludingLast = uploadRequest.filter(x => x.PartIndex < firstAPIRequest);
      //Last API Request
      var lastApiRequest = uploadRequest.find(x => x.PartIndex === firstAPIRequest);
      var count = 0;
      apiRequestExcludingLast.forEach(async (request: Pdfdocument) => {
        this.pdfDocumentService.uploadPdfFilesInChunk(request).then(response => {
          if (response && response.success) {
            count++;
            if (count === apiRequestExcludingLast.length) {
              this.pdfDocumentService.uploadPdfFilesInChunk(lastApiRequest).then(res => {
                if (res && res.success) {
                  let fileIds: number[] = [];
                  fileIds.push(res.data)
                  this.pdfDocumentService.updateRetentionDateForFiles(fileIds);
                  this.toasterService.success(this.resourceService.getText('dms.editpdf.success'));
                }
                else {
                  this.toasterService.error(this.resourceService.getText('dms.editpdf.error'));
                }
                this.progressBar = false;
                this.cdRef.detectChanges();
              })
            }
          }
          else {
            this.progressBar = false;
            this.toasterService.error(this.resourceService.getText('dms.editpdf.error'));
            this.cdRef.detectChanges();
          }
        })
      });
    }
    else {
      this.pdfDocumentService.uploadPdfFilesInChunk(uploadRequest[0]).then(res => {
        if (res && res.success) {
          let fileIds: number[] = [];
          fileIds.push(res.data)
          this.pdfDocumentService.updateRetentionDateForFiles(fileIds);
          this.toasterService.success(this.resourceService.getText('dms.editpdf.success'));
        }
        else {
          this.toasterService.error(this.resourceService.getText('dms.editpdf.error'));
        }

        this.cdRef.detectChanges();
        this.progressBar = false;
      })
    }
    this.isDocumentEdited = false;
  }

  async BuildUploadRequest(fileData: Blob, pdfdocumentRequest: Pdfdocument): Promise<Pdfdocument[]> {
    let uploadRequests: Pdfdocument[] = [];
    const blob = new Blob([fileData], { type: 'application/pdf' });
    if (this.chunkSize >= blob.size) {
      pdfdocumentRequest.TotalParts = 1;
    } else {
      this.totalParts = blob.size / this.chunkSize;
      pdfdocumentRequest.TotalParts = Math.ceil(this.totalParts);
    }
    let i = 0;
    let startOffsetIndex = 0;
    let totalOffsetIndex = 0;
    do {
      var uploadRequest = new Pdfdocument();
      if (blob.size < (totalOffsetIndex + this.chunkSize)) {
        totalOffsetIndex = totalOffsetIndex + (blob.size - totalOffsetIndex);
      }
      else {
        totalOffsetIndex = totalOffsetIndex + this.chunkSize;
      }
      var slice: BlobPart = blob.slice(startOffsetIndex, totalOffsetIndex);
      startOffsetIndex = startOffsetIndex + this.chunkSize;
      uploadRequest.PartIndex = i;
      uploadRequest.PartByteOffsetIndex = totalOffsetIndex;
      uploadRequest.FileData = [slice];
      uploadRequest.Size = blob.size;
      uploadRequest.TotalParts = pdfdocumentRequest.TotalParts;
      uploadRequest.ChunkSize = pdfdocumentRequest.ChunkSize;
      uploadRequest.createdDateTime = pdfdocumentRequest.createdDateTime;
      uploadRequest.Source = pdfdocumentRequest.Source;
      uploadRequest.EntityType = pdfdocumentRequest.EntityType;
      uploadRequest.EntityId = pdfdocumentRequest.EntityId;
      uploadRequest.Hierarchy = pdfdocumentRequest.Hierarchy;
      uploadRequest.FolderId = pdfdocumentRequest.FolderId;
      uploadRequest.FileGuid = pdfdocumentRequest.FileGuid;
      uploadRequest.FileName = pdfdocumentRequest.FileName;
      uploadRequest.IsUploadFromTrayapp = pdfdocumentRequest.IsUploadFromTrayapp;
      uploadRequests.push(uploadRequest);
      i++;
    } while (i < pdfdocumentRequest.TotalParts)

    return uploadRequests;
  }

  async mergePDF(wvInstance: any): Promise<any> {
    await wvInstance.PDFNet.initialize();
    await wvInstance.PDFNet.initialize(this.enhancedPdfLicenseKey);
    
    if(this.allBlob.length === 1 && this.allBlob[0].type === "application/pdf"){
      this.mergedBlob = this.allBlob[0];
    }
    else {
      const newDoc = await this.GetPDFDocument(wvInstance);
      const buf = await newDoc.saveMemoryBuffer(wvInstance.PDFNet.SDFDoc.SaveOptions.e_linearized);
      const blob = new Blob([buf], { type: 'application/pdf' });
      this.mergedBlob = blob;
    }
  }

  async GetPDFDocument(wvInstance:any): Promise<any> {
    const newDoc = await wvInstance.PDFNet.PDFDoc.create();
    for (let i = 0; i < this.allBlob.length; i++) {
      const blob = new Blob([this.allBlob[i]], { type: this.allBlob[i].type.toString() });
      const doc = await this.CreatePDFDocument(wvInstance, blob, this.fileIds[i]);

      const copy_pages = new wvInstance.UI.iframeWindow.Array();
      for (const itr = await doc.getPageIterator(); await itr.hasNext(); await itr.next()) {
        copy_pages.push(await itr.current());
      }

      const imported_pages = await newDoc.importPages(copy_pages, true);
      for (let i = 0; i < imported_pages.length; ++i) {
        newDoc.pagePushBack(imported_pages[i]);
      }
    }
    return newDoc;
  }

  async CreatePDFDocument(wvInstance:any, blob:Blob, fileId:number): Promise<any> {
    var doc: any;
    if(blob.type === "application/octet-stream") {
      const fileExtension = await this.getFileExtension(fileId);
      const buffer = await blob.arrayBuffer();
      var pdfBuffer = await wvInstance.Core.officeToPDFBuffer(buffer, {extension: fileExtension, l: this.enhancedPdfLicenseKey});
      doc = await wvInstance.PDFNet.PDFDoc.createFromBuffer(pdfBuffer);
    }
    else if (blob.type != "application/pdf") {
      const pdfdoc = await wvInstance.PDFNet.PDFDoc.create();
      await pdfdoc.initSecurityHandler();
      const extension = blob.type.split('/');
      const buffer = await blob.arrayBuffer();
      await wvInstance.PDFNet.Convert.toPdfWithBuffer(pdfdoc, buffer, extension[1]);
      doc = pdfdoc;
    }
    else {
      const buffer = await blob.arrayBuffer();
      doc = await wvInstance.PDFNet.PDFDoc.createFromBuffer(buffer);
    }
    return doc;
  }

  async getFileExtension(fileId:number) : Promise<any>{
    var result = await this.pdfDocumentService.getDocumentById(fileId);
    const index = result.data.Name.lastIndexOf(".");
    return result.data.Name.substring(index+1).toLowerCase();
  }

  async main(): Promise<any> {
    try {
      // await this.mergePDF(this.wvInstance);
      //await this.wvInstance.PDFNet.runWithCleanup(await this.mergePDF(this.wvInstance));
      await this.wvInstance.PDFNet.runWithCleanup(await this.mergePDF(this.wvInstance), this.enhancedPdfLicenseKey);

    } catch (err) {
      //this.popupService.toast(this.resourceService.getText('ifirm.common.error'), this.resourceService.getText('dms.settings.anerroroccurred'));
    }
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(a => a.unsubscribe());
  }

  fileSavePopup(fileData: Blob) {
    const dmsFile = new DmsFile();
    if (this.fileIds.length === 1) {
      let index = this.fileDetails.fileName.lastIndexOf(".");
      let fileName = this.fileDetails.fileName.substring(0, index);
      dmsFile.Name = fileName;
    }
    else {
      dmsFile.Name = "document 1";
    }
    dmsFile.EntityId = this.fileDetails.entityId;
    dmsFile.EntityType = Number(this.fileDetails.entityType);
    if (this.fileDetails.hierarchy == undefined || this.fileDetails.hierarchy == null || this.fileDetails.hierarchy == "null") {
      this.fileDetails.hierarchy = "";
    }
    dmsFile.Hierarchy = this.fileDetails.hierarchy;
    if (this.fileDetails.isSingleEntityId == undefined || this.fileDetails.isSingleEntityId == null) {
      dmsFile.IsSingleEntity = true;
    }
    else {
      dmsFile.IsSingleEntity = this.fileDetails.isSingleEntityId;
    }

    this.setTitle(dmsFile.Name);
    this.OpenFileSavePopup(fileData, dmsFile)
  }

  OpenFileSavePopup(fileData: Blob, dmsFile: DmsFile) {
    let instance;
    if (this.fileIds.length > 1) {
      dmsFile.Name = "document 1";
    }
    this.setTitle(dmsFile.Name);
    let title = this.resourceService.getText('dms.editpdf.savefile');
    this.zone.run(() => {
      const config: ModalPopupConfig<any> = new ModalPopupConfig<any>();
      dmsFile.Pdfsettings = this.pdfSettings;
      config.data = dmsFile;
      instance = this.popupService.open<FileSaveComponent>(title, FileSaveComponent, config);
    });

    const subscription = instance.afterClosed.subscribe(x => {
      if (subscription) {
        subscription.unsubscribe();
      }
      if (x && !x.cancel) {
        if (x.action == "save") {
          var dmsFileResult = x.data;
          dmsFileResult.Name = dmsFile.Name + ".pdf";
          this.setTitle(dmsFileResult.Name);
          this.saveDocument(fileData, dmsFileResult)
        }
      }
      else {
        this.progressBar = false;
        this.cdRef.detectChanges();
      }
    });
  }

}
