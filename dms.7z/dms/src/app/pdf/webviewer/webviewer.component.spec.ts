import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WebviewerComponent } from './webviewer.component';

describe('WebviewerComponent', () => {
  let component: WebviewerComponent;
  let fixture: ComponentFixture<WebviewerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WebviewerComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(WebviewerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
