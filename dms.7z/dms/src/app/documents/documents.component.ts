import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { BreadCrumbModel, BreadCrumbService, IFirmTabItemComponent, ResourceService } from '@ifirm';
import { Subscription } from 'rxjs';
import { Router } from '@angular/router';
import { DmsService} from '../dms.service'

@Component({
  selector: 'app-documents',
  templateUrl: './documents.component.html',
  styleUrls: ['./documents.component.scss']
})
export class DocumentsComponent implements OnInit, AfterViewInit {
  selectedTab: string;
  private resourceChangedSubscription: Subscription;
  showClientDocument: boolean= true;
  showFirmDocument: boolean = true;
  showRecycleBin: boolean= true;
  showSpaceUsages: boolean = true;
  private breadCrumb = new BreadCrumbModel();
  @ViewChild('tabGroup') tabGroup;
  constructor(private resourceService: ResourceService, private breadCrumbService: BreadCrumbService, private title: Title, private router: Router, private dmsservice: DmsService) { }

  ngOnInit(): void {
    this.selectedTab = 'active';
    let headingTitlePromise = this.resourceService.get('dms.home.title')
    let headingTitle : string;
    if(headingTitlePromise instanceof Promise)
    {
      headingTitlePromise.then(x=>{
        headingTitle = x;
        this.setTitle(headingTitle);
      });
    }
    else{
      headingTitle = headingTitlePromise;
      this.setTitle(headingTitle);
    }

    this.breadCrumb.heading = headingTitle;
    this.breadCrumbService.setBreadCrumb(this.breadCrumb);
    this.resourceChangedSubscription = this.resourceService.resourcesChanged.subscribe(a => {
      this.setBreadcrumb(Pagetitle => {
        const breadCrumb = new BreadCrumbModel();
        breadCrumb.heading = Pagetitle;
        this.breadCrumbService.setBreadCrumb(breadCrumb);
        this.setTitle(Pagetitle);
      });
    });
    this.resourceService.mySubj.next('Client Document');
    this.applyUserRoles();
  }

  private setBreadcrumb(breadCrumbFn) {
    const jobsTitle = this.resourceService.get("dms.home.title");
    if (jobsTitle instanceof Promise) {
      jobsTitle.then(value => {
        breadCrumbFn(value);
      });
    }
    else {
      breadCrumbFn(jobsTitle);
    }
  }

  private setTitle(setTitle: string) {
    const title = "iFirm | " + setTitle;
    this.title.setTitle(title);
  }

  ontabSelectionChanged(tab: IFirmTabItemComponent) {
    this.router.navigateByUrl("/dms/home/" + tab.name)
    if (this.selectedTab !== tab.name) {
      this.selectedTab = tab.name || 'active';
    }
  }

  ngAfterViewInit(): void {
  this.dmsservice.clientDocument.subscribe((res)=>{ 
    this.router.navigateByUrl("/dms/home/"+this.tabGroup._selectedTabName);
  })
  }

  applyUserRoles() {
    this.dmsservice.getNewUserInfo().then((response) => {
      if (response) {
        this.dmsservice.userInfoMap.set('userInfoValue',response);
        this.showClientDocument= ((response.DmsView || response.DmsViewUpload || response.DmsViewEdit || response.DmsViewEditCopyMove || response.DmsViewDelete || response.DmsViewPermanentDelete || response.DmsViewUnlock || response.DmsViewDownloadMultiple || response.DmsViewRecycleBinRestore) && response.ContactView);
        this.dmsservice.clientDocument.emit(this.showClientDocument);
        this.showFirmDocument = response.DmsFirmDocuments;
        this.showRecycleBin = (response.DmsView || response.DmsViewUpload || response.DmsViewEdit || response.DmsViewEditCopyMove || response.DmsViewDelete || response.DmsViewPermanentDelete || response.DmsViewUnlock || response.DmsViewDownloadMultiple || response.DmsViewRecycleBinRestore || response.DmsFirmDocuments);
        this.showSpaceUsages = (response.DmsView || response.DmsViewUpload || response.DmsViewEdit || response.DmsViewEditCopyMove || response.DmsViewDelete || response.DmsViewPermanentDelete || response.DmsViewUnlock || response.DmsViewDownloadMultiple || response.DmsViewRecycleBinRestore)
      };
    })
  }

}
