import { General } from './general.model';

describe('General', () => {
  it('should create an instance', () => {
    expect(new General()).toBeTruthy();
  });
});
