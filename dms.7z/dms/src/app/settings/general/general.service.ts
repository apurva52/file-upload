import { Injectable } from '@angular/core';
import { ApiService } from '@ifirm'
import { GeneralSetting } from './general.model'

@Injectable({
  providedIn: 'root'
})
export class GeneralService {

  constructor(private api: ApiService) { }

  public getEmailAddinSettings(): Promise<any> {
    const url = '/dms/api/settings/GetEmailAddinSettings';
    return this.api.get<GeneralSetting>(url, GeneralSetting).toPromise();
  }
  
  public updateEmailAddinSettings(settings : GeneralSetting): Promise<any> {
    const url = '/dms/api/settings/UpdateEmailAddinSettings';
    return this.api.post<GeneralSetting>(url, null, settings).toPromise();
  }

}
