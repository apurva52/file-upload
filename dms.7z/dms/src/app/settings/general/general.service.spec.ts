import { Injectable } from '@angular/core';
import { ApiService} from '@ifirm';

import { GeneralService } from './general.service';

describe('GeneralService', () => {
  let service: GeneralService;

  
});
