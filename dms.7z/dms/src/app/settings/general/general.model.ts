import { PropertyName } from '@ifirm'

export class GeneralSetting {

    @PropertyName("SettingId")
    settingId:number;

    @PropertyName("EnableSeparateAttachement")
    enableSeparateAttachement:boolean;  

    @PropertyName("CountryCode")
    countryCode:string;

    @PropertyName("AutoFileAllOrSubsequentEmail")
    autoFileAllOrSubsequentEmail:number;

    @PropertyName("DMSEmailAutoFiling")
    dmsEmailAutoFiling:boolean
}
