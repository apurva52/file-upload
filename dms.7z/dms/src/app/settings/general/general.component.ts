import { Component, OnInit } from '@angular/core';
import { GeneralService } from './general.service';
import { GeneralSetting } from './general.model';
import { FormControl, FormGroup } from '@angular/forms';
import { ResourceService } from '@ifirm';
import { ToasterService } from 'projects/ifirm-common-components/src/lib/toaster//toaster.service';
import { DmsService } from '../../dms.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-general',
  templateUrl: './general.component.html',
  styleUrls: ['./general.component.scss']
})
export class GeneralComponent implements OnInit {
  generalSettingForm: FormGroup;
  settings: GeneralSetting = new GeneralSetting();
  rData: boolean = false;
  isUserHaveViewRole: boolean = false;
  isDMSEmailAutoFiling: boolean = false;
  private resourceChangedSubscription: Subscription;

  constructor(private generalService: GeneralService, private resourceService: ResourceService, private toasterService: ToasterService, private dmsService: DmsService) {

    this.generalSettingForm = new FormGroup({
      enableSeparateAttachement: new FormControl(false),
      settingId: new FormControl(0),
      autoFileAllOrSubsequentEmail: new FormControl(0)
    });

  }

  ngOnInit(): void {
    this.dmsService.getDmsRoles().then(x => {
      if (x != null && x.DmsSettingsDocuments) {
        this.isUserHaveViewRole = true;
       this.dmsService.setBreadCrumbAndTitle(this.resourceService.get('dms.settings.generalsettings'));
        this.rData = true;
        this.generalService.getEmailAddinSettings().then(x => {
          this.rData = false;
          this.settings = x;
          this.isDMSEmailAutoFiling = this.settings.dmsEmailAutoFiling;
          this.generalSettingForm.setValue({
            enableSeparateAttachement: this.settings.enableSeparateAttachement,
            settingId: this.settings.settingId,
            autoFileAllOrSubsequentEmail: this.settings.autoFileAllOrSubsequentEmail.toString()  
          });
        })
          .catch(
            exception => {
              this.rData = false;
              this.toasterService.error(this.resourceService.getText('dms.settings.errorviewsetting'));
            });

        this.resourceChangedSubscription = this.resourceService.resourcesChanged.subscribe(a => {
          this.dmsService.setBreadCrumbAndTitle(this.resourceService.get('dms.settings.generalsettings'));
        });
      }
      else {
        this.dmsService.showAccessDeniedMessage();
      }
    })
      .catch(
        exception => {
          this.toasterService.error(this.resourceService.getText('dms.settings.anerroroccurred'));
        });
  }

  ngOnDestroy() {
    if (this.resourceChangedSubscription) {
      this.resourceChangedSubscription.unsubscribe()
    }
  }

  cancelSettings() {
    window.location.hash = '/dms/settings/main';
  }

  saveSettings() {
    if (this.generalSettingForm.status === 'VALID') {
      {
        this.rData = true;
        this.settings = this.generalSettingForm.value;
        this.generalService.updateEmailAddinSettings(this.settings).then(result => {
          this.rData = false;
          this.toasterService.success(this.resourceService.getText('ifirm.common.settingssaved'));
        }).catch(
          exception => {
            this.rData = false;
            this.toasterService.error(this.resourceService.getText('dms.settings.errorsavesetting'));
          });
      }
    }
  }

}
