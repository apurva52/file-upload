import { PropertyName } from '@ifirm';

export  class VersionControlModel
{
    @PropertyName("SettingId")
    settingId:number;

    @PropertyName("EnableUnlimitedVersionRetention")
    enableUnlimitedVersionRetention:boolean;  

    @PropertyName("VersionLimitCount")
    versionLimitCount:number;
}

