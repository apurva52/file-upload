import { Injectable } from '@angular/core';
import { ApiService} from '@ifirm';
import { VersionControlModel } from "./version-control.model";

@Injectable({
  providedIn: 'root'
})
export class VersionControlService {

  constructor(private api: ApiService) {}

  public getSettings(): Promise<any> {
    const url = '/dms/api/settings/getsettings';
    return this.api.get<VersionControlModel>(url, VersionControlModel).toPromise();
  }
  
  public updateSettings(settings : VersionControlModel): Promise<any> {
    const url = '/dms/api/settings/updatesettings';
    return this.api.post<VersionControlModel>(url, null, settings).toPromise();
  }
}
