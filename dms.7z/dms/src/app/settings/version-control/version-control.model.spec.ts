import { VersionControl.Model } from './version-control.model';

describe('VersionControl.Model', () => {
  it('should create an instance', () => {
    expect(new VersionControl.Model()).toBeTruthy();
  });
});
