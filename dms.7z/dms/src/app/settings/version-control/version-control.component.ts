import { Component, OnInit } from '@angular/core';
import { AppConstants } from '../../constants/app-constants';
import { VersionControlService } from './version-control.service';
import { VersionControlModel } from './version-control.model';
import { FormControl, Validators, FormGroup } from '@angular/forms';
import { ResourceService } from '@ifirm';
import { ToasterService } from 'projects/ifirm-common-components/src/lib/toaster//toaster.service';
import { DmsService } from '../../dms.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-version-control',
  templateUrl: './version-control.component.html',
  styleUrls: ['./version-control.component.scss']
})
export class VersionControlComponent implements OnInit {
  maxVersion: number = 0;
  minVersion: number = 1;
  tempVersion: number = 0;
  settings: VersionControlModel = new VersionControlModel();
  versionControlForm: FormGroup;
  rData: boolean = false;
  isUserHaveViewRole: boolean = false;
  private resourceChangedSubscription: Subscription;

  constructor(private versionControlService: VersionControlService,
    private resourceService: ResourceService, private toasterService: ToasterService, private dmsService: DmsService) {
    this.maxVersion = AppConstants.maxVersionAllow;
    this.minVersion = AppConstants.minVersionAllow;
    this.versionControlForm = new FormGroup({
      versionLimitCount: new FormControl(1, [Validators.required, Validators.min(this.minVersion), Validators.max(this.maxVersion)]),
      enableUnlimitedVersionRetention: new FormControl(false),
      settingId: new FormControl(0),
    });
  }

  ngOnInit(): void {
    this.dmsService.getDmsRoles().then(x => {
      if (x != null && x.DmsSettingsDocuments) {
        this.isUserHaveViewRole = true;
        this.dmsService.setBreadCrumbAndTitle(this.resourceService.get('dms.settings.versioncontrol'));
        this.rData = true;
        this.versionControlService.getSettings().then(x => {
          this.rData = false;
          this.settings = x;
          this.tempVersion = x.versionLimitCount;
          this.versionControlForm.setValue({
            versionLimitCount: this.settings.versionLimitCount,
            enableUnlimitedVersionRetention: this.settings.enableUnlimitedVersionRetention,
            settingId: this.settings.settingId,
          });
        })
          .catch(
            exception => {
              this.rData = false;
              this.toasterService.error(this.resourceService.getText('dms.settings.errorviewsetting'));
            });
        this.resourceChangedSubscription = this.resourceService.resourcesChanged.subscribe(a => {
          this.dmsService.setBreadCrumbAndTitle(this.resourceService.get('dms.settings.versioncontrol'));
        });
      }
      else {
        this.dmsService.showAccessDeniedMessage();
      }
    })
      .catch(
        exception => {
          this.toasterService.error(this.resourceService.getText('dms.settings.anerroroccurred'));
        });
  }

  ngOnDestroy() {
    if (this.resourceChangedSubscription) {
      this.resourceChangedSubscription.unsubscribe();
    }
  }

  changeUnlimitedVersionRetain() {
    this.versionControlForm.controls['versionLimitCount'].setValue(this.versionControlForm.get('enableUnlimitedVersionRetention').value ? this.maxVersion : this.tempVersion);
  }

  cancelSettings() {
    window.location.hash = '/dms/settings/main';
  }

  saveSettings() {
    if (this.versionControlForm.status === 'VALID') {
      {
        this.rData = true;
        this.settings = this.versionControlForm.value;
        this.versionControlService.updateSettings(this.settings).then(result => {
          this.rData = false;
          this.toasterService.success(this.resourceService.getText('ifirm.common.settingssaved'));
        }).catch(
          exception => {
            this.rData = false;
            this.toasterService.error(this.resourceService.getText('dms.settings.errorsavesetting'));
          });
      }
    }
  }
}
