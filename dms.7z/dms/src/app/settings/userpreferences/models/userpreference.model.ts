import { PropertyName } from "@ifirm";

export class UserPreference {

    @PropertyName('UserId')
    userId: string;

    @PropertyName('UserName')
    userName: string;

    @PropertyName('FirstName')
    firstName: string;

    @PropertyName('LastName')
    lastName: string;

    @PropertyName('EnableAutoFiling')
    enableAutoFiling: boolean;

    @PropertyName('IsMarkEmailAsPrivate')
    isMarkEmailAsPrivate: boolean;

    @PropertyName('AutoAddContactEmail')
    autoAddContactEmail: boolean;
}

export class UserPreferenceSorting{
    @PropertyName('SortOrder')
    sortDirection: string;
    
    @PropertyName('SortColumn')
    sortColumnName: string;
}


export class PaginationModel {

    @PropertyName('TotalRecords')
    totalRecords: number;

    @PropertyName('RecordStart')
    recordStart: number;

    @PropertyName('PageSize')
    currentPageSize: number;

    @PropertyName('PageNumber')
    pageNumber: number;

    getPageNumber(): number {
        return Math.ceil(this.recordStart / this.currentPageSize);
    }
}

export class UserPreferenceListResponse {

    constructor(){
        this.users = new Array<UserPreference>();
        this.pagination = new PaginationModel();
    }

    @PropertyName<PaginationModel>('PaginationInfo', PaginationModel)
    pagination: PaginationModel;

    @PropertyName<UserPreference>('UserPreferencesList', UserPreference)
    users: UserPreference[];

    @PropertyName('IsEmailAutofilingEnabled')
    isEmailAutofilingEnabled: boolean;
}
