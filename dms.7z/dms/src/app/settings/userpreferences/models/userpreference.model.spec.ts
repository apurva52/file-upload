import { Userpreference } from './userpreference.model';

describe('Userpreference', () => {
  it('should create an instance', () => {
    expect(new Userpreference()).toBeTruthy();
  });
});
