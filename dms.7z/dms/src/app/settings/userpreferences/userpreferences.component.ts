import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { Subject } from 'rxjs'
import { UserpreferenceService } from '../userpreferences/services/userpreference.service'
import { PaginationModel, UserPreference } from '../userpreferences/models/userpreference.model'
import { BreadCrumbModel, BreadCrumbService, ModalPopupService, ResourceService, ToasterService } from '@ifirm';
import { Title } from '@angular/platform-browser';
import { DmsService } from '../../dms.service';

@Component({
  selector: 'app-userpreferences',
  templateUrl: './userpreferences.component.html',
  styleUrls: ['./userpreferences.component.scss']
})
export class UserpreferencesComponent implements OnInit {

  pagination: PaginationModel;
  usersPreferenceList: UserPreference[];
  initialUsersPreferenceList: UserPreference[];
  rData: boolean = false;
  isUserHaveViewRole: boolean = false;
  @Output() refreshGrid: EventEmitter<void> = new EventEmitter<void>();
  eventsRefreshSubject: Subject<boolean> = new Subject<boolean>();

  constructor(private userPreferenceService: UserpreferenceService, private breadCrumbService: BreadCrumbService,
    private resourceService: ResourceService, private toasterService: ToasterService, private title: Title, private dmsService: DmsService,private popupService: ModalPopupService) {
    this.usersPreferenceList = [];
    this.pagination = new PaginationModel();
    this.pagination.pageNumber = 1;
    this.pagination.currentPageSize = 10;
  }

  ngOnInit() {
    this.dmsService.getDmsRoles().then(x => {
      if (x != null && x.DmsSettingsDocuments) {
        this.isUserHaveViewRole = true;
        this.setBreadcrumb();
      }
      else {
        this.dmsService.showAccessDeniedMessage();
      }
    })
      .catch(
        exception => {
          this.toasterService.error(this.resourceService.getText('dms.settings.anerroroccurred'));
        });
  }

  private setBreadcrumb() {
    const breadCrumb = new BreadCrumbModel();
    let jobsTitle = this.resourceService.get("dms.settings.userpreferencessetting");

    if (jobsTitle instanceof Promise) {
      jobsTitle.then(value => {
        breadCrumb.heading = value;
        this.breadCrumbService.setBreadCrumb(breadCrumb);
        this.setTitle(value);
      });
    }
    else {
      breadCrumb.heading = jobsTitle;
      this.breadCrumbService.setBreadCrumb(breadCrumb);
      this.setTitle(jobsTitle);
    }
  }

  private setTitle(setTitle: string) {
    const title = "iFirm | " + setTitle;
    this.title.setTitle(title);
  }

  setInitialUserList(userpreferenceList) {
    this.initialUsersPreferenceList = userpreferenceList;
  }

  checkboxChangedEvent(userPreference) {
    var settingNotChanged = this.initialUsersPreferenceList.filter(x => x.userId == userPreference.userId && x.enableAutoFiling == userPreference.enableAutoFiling && x.isMarkEmailAsPrivate == userPreference.isMarkEmailAsPrivate && x.autoAddContactEmail == userPreference.autoAddContactEmail);
    if (settingNotChanged.length == 0) {

      if (this.usersPreferenceList.filter(i => i.userId == userPreference.userId).length > 0) {
        var removeIndex = this.usersPreferenceList.indexOf(this.usersPreferenceList.find(i => i.userId == userPreference.userId));
        this.usersPreferenceList.splice(removeIndex, 1);
        this.usersPreferenceList.push(userPreference);
      }
      else {
        this.usersPreferenceList.push(userPreference);
      }
    }
    else {
      var removeIndex = this.usersPreferenceList.indexOf(this.usersPreferenceList.find(i => i.userId == userPreference.userId));
      this.usersPreferenceList.splice(removeIndex, 1);
    }

  }

  saveUserPreferenceSetting() {
    if (this.usersPreferenceList.length > 0) {
      this.rData = true;
      this.userPreferenceService.saveUserPreferenceSetting(this.usersPreferenceList).then(result => {
        if (result.Status == 0) {
          var item = this.usersPreferenceList.filter(i => i.enableAutoFiling == false || i.isMarkEmailAsPrivate == true);
          if (item != null && item.length > 0) {
            this.popupService.info(this.resourceService.getText('dms.settings.firmdocuments.warning'), this.resourceService.getText('dms.settings.userpreferencessetting.message'))
          }
          else {
            this.toasterService.success(this.resourceService.getText('ifirm.common.settingssaved'));
          }
          this.rData = false;
          this.eventsRefreshSubject.next(false);
        }
        else {
          this.rData = false;
          this.toasterService.error(this.resourceService.getText('dms.settings.errorsavesetting'));
          this.eventsRefreshSubject.next(true);
        }
        this.usersPreferenceList = [];
      }).catch(
        exception => {
          this.rData = false;
          this.toasterService.error(this.resourceService.getText('dms.settings.errorsavesetting'));
        });
    }
  }

  cancelSettings() {
    window.location.hash = '/dms/settings/main';
  }

}
