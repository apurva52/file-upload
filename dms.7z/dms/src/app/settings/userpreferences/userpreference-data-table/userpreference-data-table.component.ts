import { ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output, ViewEncapsulation } from '@angular/core';
import { Observable, Subscription } from 'rxjs'
import { forEach } from 'angular';
import { PaginationModel, UserPreference, UserPreferenceListResponse, UserPreferenceSorting } from '../models/userpreference.model';
import { UserpreferenceService } from '../services/userpreference.service';

@Component({
  selector: 'app-userpreference-data-table',
  templateUrl: './userpreference-data-table.component.html',
  styleUrls: ['./userpreference-data-table.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class UserpreferenceDataTableComponent implements OnInit {

  users: UserPreference[];
  initialUserPreferenceList: UserPreference[];

  userpreferenceSorting: UserPreferenceSorting;
  private eventsSubscription: Subscription;
  @Input() eventRefreshGrid: Observable<void>
  @Input() pagination: PaginationModel;
  @Output() checkboxChecked: EventEmitter<UserPreference> = new EventEmitter<UserPreference>();
  @Output() userList: EventEmitter<UserPreference[]> = new EventEmitter<UserPreference[]>();
  trackByProperty = 'userId';
  selectAllMarkAsPrivate = false;
  selectAllEnableAutofiling = false;
  selectAllAutoAddContactEmail = false;
  isEmailAutofilingEnabled = false;

  constructor(private userpreferenceService: UserpreferenceService, private changedetect: ChangeDetectorRef) {
    this.userpreferenceSorting = new UserPreferenceSorting();
    this.userpreferenceSorting.sortColumnName = 'username';
    this.userpreferenceSorting.sortDirection = 'asc';
  }

  ngOnInit(): void {
    this.fetchUsersPreference();
    this.eventsSubscription = this.eventRefreshGrid.subscribe(() => this.refreshGrid());
    this.eventRefreshGrid.subscribe(response => {
      this.fetchUsersPreference();
      this.eventsSubscription = this.eventRefreshGrid.subscribe(() => this.refreshGrid());
    });
  }

  ngOnDestroy() {
    this.eventsSubscription.unsubscribe();
  }

  fetchUsersPreference() {
    this.userpreferenceService.getUserPreferenceList(this.pagination, this.userpreferenceSorting)
      .then(x => this.setProperties(x));
  }

  refreshGrid() {
    this.fetchUsersPreference();
  }

  private setProperties(data: UserPreferenceListResponse): void {
    this.users = data.users;
    this.isEmailAutofilingEnabled = data.isEmailAutofilingEnabled;
    this.pagination = data.pagination;
    this.pagination.pageNumber = this.pagination.getPageNumber();
    let objCopy = JSON.parse(JSON.stringify(this.users));
    this.userList.emit(objCopy);
    this.SetSelectAllCheckbox();
    this.changedetect.detectChanges();
  }

  SetSelectAllCheckbox() {
    if (this.users.filter(x => x.enableAutoFiling == false).length == 0) {
      this.selectAllEnableAutofiling = true;
    }
    else {
      this.selectAllEnableAutofiling = false;
    }

    if (this.users.filter(x => x.isMarkEmailAsPrivate == false).length == 0) {
      this.selectAllMarkAsPrivate = true;
    }
    else {
      this.selectAllMarkAsPrivate = false;
    }

    if (this.users.filter(x => x.autoAddContactEmail == false).length == 0) {
      this.selectAllAutoAddContactEmail = true;
    }
    else {
      this.selectAllAutoAddContactEmail = false;
    }
  }

  onEnableAutoFilingClick(event, userPreferenceSetting) {
    const selected = event.target.checked;
    userPreferenceSetting.enableAutoFiling = selected;
    if (this.users.filter(x => x.enableAutoFiling == false).length == 0) {
      this.selectAllEnableAutofiling = true;
    }
    else {
      this.selectAllEnableAutofiling = false;
    }
    this.checkboxChecked.emit(userPreferenceSetting);
  }

  onMarkAsPrivateClick(event, userPreferenceSetting) {
    const selected = event.target.checked;
    userPreferenceSetting.isMarkEmailAsPrivate = selected;
    if (this.users.filter(x => x.isMarkEmailAsPrivate == false).length == 0) {
      this.selectAllMarkAsPrivate = true;
    }
    else {
      this.selectAllMarkAsPrivate = false;
    }
    this.checkboxChecked.emit(userPreferenceSetting);
  }

  onAutoAddContactEmailClick(event, userPreferenceSetting) {
    const selected = event.target.checked;
    userPreferenceSetting.autoAddContactEmail = selected;
    if (this.users.filter(x => x.autoAddContactEmail == false).length == 0) {
      this.selectAllAutoAddContactEmail = true;
    }
    else {
      this.selectAllAutoAddContactEmail = false;
    }
    this.checkboxChecked.emit(userPreferenceSetting);
  }

  pageNumberOrSizeChanged(pagination: PaginationModel) {
    this.pagination = pagination;
    if (this.pagination.currentPageSize > this.pagination.totalRecords) {
      this.pagination.recordStart = 1;
      this.pagination.pageNumber = 1;
    }
    else if (this.pagination.pageNumber > 0) {

      let recordStart = ((this.pagination.pageNumber - 1) * this.pagination.currentPageSize) + 1;
      this.pagination.recordStart = isNaN(recordStart) ? 1 : recordStart;
    }

    this.fetchUsersPreference();
  }

  sort(event) {
    this.userpreferenceSorting.sortDirection = event.sortDirection;
    this.userpreferenceSorting.sortColumnName = event.columnName;
    this.fetchUsersPreference();
  }

  toggleAllEnableAutoFiling(event) {
    const selected = event.target.checked;
    if (this.users) {
      this.users.forEach(user => {
        user.enableAutoFiling = selected;
        this.checkboxChecked.emit(user);
      });
    }
  }

  toggleAllMarkAsPrivate(event) {
    const selected = event.target.checked;
    if (this.users) {
      this.users.forEach(user => {
        user.isMarkEmailAsPrivate = selected;
        this.checkboxChecked.emit(user);
      });
    }
  }

  toggleAllAutoAddContactEmail(event) {
    const selected = event.target.checked;
    if (this.users) {
      this.users.forEach(user => {
        user.autoAddContactEmail = selected;
        this.checkboxChecked.emit(user);
      });
    }
  }

}
