import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { UserpreferenceDataTableComponent } from './userpreference-data-table.component';

describe('UserpreferenceDataTableComponent', () => {
  let component: UserpreferenceDataTableComponent;
  let fixture: ComponentFixture<UserpreferenceDataTableComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ UserpreferenceDataTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserpreferenceDataTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
