import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { UserpreferencesComponent } from './userpreferences.component';

describe('UserpreferencesComponent', () => {
  let component: UserpreferencesComponent;
  let fixture: ComponentFixture<UserpreferencesComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ UserpreferencesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserpreferencesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
