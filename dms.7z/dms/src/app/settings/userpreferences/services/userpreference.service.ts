import { HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ApiService, ObjectDeserializer, toFormUrlEncoded} from '@ifirm';
import { PaginationModel, UserPreference, UserPreferenceListResponse, UserPreferenceSorting } from "../models/userpreference.model";

@Injectable({
  providedIn: 'root'
})
export class UserpreferenceService {

  constructor(private api: ApiService) { }

  public getUserPreferenceList(userPreferencesSettingRequest : PaginationModel, userPreferenceSorting: UserPreferenceSorting): Promise<any> {
    let serializer = new ObjectDeserializer();
    let serializedFilter1 = serializer.Serialize<PaginationModel>(userPreferencesSettingRequest);
    let serializedFilter2 = serializer.Serialize<UserPreferenceSorting>(userPreferenceSorting);
    var merged = Object.assign(serializedFilter1, serializedFilter2);
    const url = '/dms/api/Settings/GetUserPreferencesSetting?'+ toFormUrlEncoded(merged);
    return this.api.get<UserPreferenceListResponse>(url, UserPreferenceListResponse).toPromise();
  }

  public saveUserPreferenceSetting(userPreferenceList): Promise<any> {
    var userPreferenceSettingRequest = { UserPreferencesList : userPreferenceList };
    const url = '/dms/api/Settings/UpdateUserPreferencesSetting';
    return this.api.post<any>(url, null, userPreferenceSettingRequest).toPromise();
  }
  
}
