import { TestBed } from '@angular/core/testing';

import { UserpreferenceService } from './userpreference.service';

describe('UserpreferenceService', () => {
  let service: UserpreferenceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UserpreferenceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
