import { Component, OnInit, ChangeDetectorRef, ViewEncapsulation  } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { RetentionService } from '../retention.service';
import { DmsRetention} from '../retention.model';
import { ModalPopupInstance, ResourceService, ModalPopupConfig } from '@ifirm';
import { retentionType, firmFolder } from '../../../constants/app-constants';
import { ToasterService } from 'projects/ifirm-common-components/src/lib/toaster//toaster.service';

@Component({
  selector: 'app-addretention',
  templateUrl: './addretention.component.html',
  styleUrls: ['./addretention.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AddRetentionComponent implements OnInit {
  addRetentionForm: FormGroup;
  validationErrors = [];
  retentionTypeList = [];
  isEditMode: boolean = false;
  retention : DmsRetention = new DmsRetention();
  isDefault : boolean = false;
  defaultRetentionList:any;
  jobTypesForRetention = [{ JobTypeId : null , Type : null , month : null , IsActive : null}];
  retentionPeriod = { year : null , minYear : null , month : null , minMonth : null};
  firmFoldersForRetention= [{ FirmFolderId : null , FirmFolderName : null, IsVisible : null}];
  firmDocuemntsSettings = {EnableHRFolders : null, EnableUserFolders : null};
  tagList:any;
  retentionType : any = retentionType;
  dmsRetentionMonthDisabled : boolean = false;
  retentionDataUpdated : any;
  rData : boolean = false;
  isShow : boolean = false;

  constructor(private retentionService : RetentionService, private instance: ModalPopupInstance, 
              private resourceService: ResourceService, private changeDetection: ChangeDetectorRef,
              retentionData: ModalPopupConfig, private toasterService: ToasterService) {  
                
    this.isEditMode = retentionData.data != undefined ? true : false;
    this.retentionDataUpdated = retentionData.data != undefined ? retentionData.data.retentionitem : null;
    this.addRetentionForm = new FormGroup({
                            retentionTypeSelected : new FormControl(1),
                            jobTypeSelected : new FormControl(0),
                            tagTypeSelected : new FormControl(1),
                            defaultRetentionSelected : new FormControl(0),
                            firmFolderSelected : new FormControl(1),
                            year1 : new FormControl(0),
                            year2 : new FormControl(0),
                            month1 : new FormControl(0),
                            month2 : new FormControl(0),
                         });

    if (this.isEditMode) {
    this.getRetentionDetails(this.retentionDataUpdated);
    }
    else
    {
     this.fillComponents();
    }
  }
 
  ngOnInit(): void { }

  fillComponents()
  {
    this.retentionTypeList = [{ "id": 1, "name": this.resourceService.getText('dms.settings.retention.jobtype') }, { "id": 2, "name": this.resourceService.getText('dms.settings.retention.tag') }, { "id": 3, "name": this.resourceService.getText('dms.settings.retention.firmfolder') }];
    this.retentionPeriod.year = 7; // default year
    this.retentionPeriod.minYear = 1;
    this.retentionPeriod.month = 0; // default month
    this.retentionPeriod.minMonth = 0;
    this.getJobTypeList();
    this.getTagList();
    this.getFirmDocumentsSettingsForRetention();
  }

  closePopup(){
    this.instance.close({ result: false });
  }
  
  showAddMore()
  {
    this.isShow = !this.isShow;
  }
  
  onRetentionPeriodChange()
  {
   if (this.retentionPeriod.year > 30) {
       this.retentionPeriod.year = 30;
   }

   if (this.retentionPeriod.month > 11) {
      this.retentionPeriod.month = 11;
   }
   
   //If User selects the max value (eg 30), disable "Months" field 
   if (this.retentionPeriod.year == "30") {
       this.retentionPeriod.month = 0;
       this.dmsRetentionMonthDisabled = true;
   }
   else
       this.dmsRetentionMonthDisabled = false;

   // User cannot set both fields at 0.
   //If User set 0 Years, Months >= 1
   //If User set 0 Months, Years >= 1
     if (this.retentionPeriod.year != 0) {
         this.retentionPeriod.minMonth = 0;
     }
     else
         this.retentionPeriod.minMonth = 1;

     if (this.retentionPeriod.month != 0) {
         this.retentionPeriod.minYear = 0;
     }
     else
         this.retentionPeriod.minYear = 1;
  }

  
 resetToDefault()
  {
     //If User blanks a field, reset to default
     if (this.isEditMode) {
       if (this.retentionPeriod.year == "") {
         this.retentionPeriod.year = this.retention.retentionYear;
           if (this.retentionPeriod.year == 0 && this.retentionPeriod.month == 0)
           this.retentionPeriod.month = this.retention.retentionMonth;
       }
       if (this.retentionPeriod.month == "") {
         this.retentionPeriod.month = this.retention.retentionMonth;
           if (this.retentionPeriod.year === 0)
           this.retentionPeriod.year = this.retention.retentionYear;
       }
   }
   else {
       if (this.retentionPeriod.year == "") {
            this.retentionPeriod.year = 7;
       }
       if (this.retentionPeriod.month == "") {
         this.retentionPeriod.month = 0;
           if (this.retentionPeriod.year === 0)
           this.retentionPeriod.year = 7;
       }
   }
  }

  inputCharCodevalidation(event)
  {
   return (event.keyCode == 8 || event.keyCode == 0) ? null : event.keyCode >= 48 && event.keyCode <= 57
  }

  inputCharCodevalidation2(event, target)
  {
   return (event.keyCode == 8 || event.keyCode == 0) ? null : event.keyCode >= ((target>0)?48:49) && event.keyCode <= 57
  }

  addEditRetentionDialog(flag) {
    this.rData = true;
      if(this.isEditMode)
      {
      this.retention.retentionId = this.retentionDataUpdated.retentionId;
      this.retention.oldRetentionYear = this.retentionDataUpdated.retentionYear;
      this.retention.oldRetentionMonth = this.retentionDataUpdated.retentionMonth;
      this.retention.retentionYear = this.retentionPeriod.year;
      this.retention.retentionMonth = this.retentionPeriod.month;
      this.retention.retentionEntityType = this.retentionDataUpdated.retentionEntityType;
      this.retention.retentionEntityId = this.retentionDataUpdated.retentionEntityId;

        this.retentionService.updateRetention(this.retention).then(res => {
          this.rData = false;
          if (res.success == true) {
          this.instance.close({ result: false });
          this.toasterService.success(this.resourceService.getText('dms.settings.retention.savesuccessmessage'));
          }
          else
          {
            this.showValidations(res);
          }
        });
      }
      else
      {
        this.retention.retentionEntityType = parseInt(this.addRetentionForm.controls['retentionTypeSelected'].value);
        this.retention.retentionEntityId = (this.addRetentionForm.controls['retentionTypeSelected'].value == this.retentionType.JobType) ? parseInt(this.addRetentionForm.controls['jobTypeSelected'].value) :
        (this.addRetentionForm.controls['retentionTypeSelected'].value == this.retentionType.Tag) ? parseInt(this.addRetentionForm.controls['tagTypeSelected'].value) : parseInt(this.addRetentionForm.controls['firmFolderSelected'].value);
        this.retention.retentionYear = this.retentionPeriod.year;
        this.retention.retentionMonth = this.retentionPeriod.month;

        this.retentionService.addRetention(this.retention).then(res => {
          this.rData = false;
          if (res.success == true) {
          if(flag == "add")
          {  
          this.instance.close({ result: false });
          this.toasterService.success(this.resourceService.getText('dms.settings.retention.savesuccessmessage'));
          }
          this.fillComponents();
          }
          else
          {
            this.showValidations(res);
          }
        });
      }
   }

  ShowSaveButton()
  {
    if(!this.isEditMode)
    {
      switch(this.addRetentionForm.value.retentionTypeSelected)
      {
        case retentionType.JobType:
              return this.jobTypesForRetention != null && this.jobTypesForRetention.length>0;
              break;
        case retentionType.Tag:
              return this.tagList != null && this.tagList.length>0;
              break;
        case retentionType.FirmFolder:
              return this.firmFoldersForRetention != null && this.firmFoldersForRetention.length>0;
              break;
        Default:
              return true;
      }
    }

    return true;
  }

  IsAddMoreOpen()
  {
    return document.getElementById('retensionAddMore').getElementsByTagName('wk-dropdown')[0].className == 'wk-dropdown wk-is-open';
  }

  private showValidations(res :any)
    {  
     this.validationErrors = [];
     res.message.forEach(element => {
      if (element.Message === "retentionduplicatemsg")
      {
        this.instance.close({ result: false });
        return;
      }
       this.validationErrors.push(element.Message); 
       this.changeDetection.detectChanges();
     })
  }
   
  private getRetentionDetails(retentionData : any)
  {
  if (this.retentionType.Default==retentionData.retentionEntityType) {
      this.retentionTypeList = [{ "id": retentionData.retentionEntityType, "name": retentionData.retentionEntityTypeDisplayName }];
      this.defaultRetentionList = [{ "defaultId": 0, "defaultRetentionName": retentionData.retentionDisplayName }];
      this.addRetentionForm.controls['defaultRetentionSelected'].setValue(0);
  }
  else {
    this.retentionTypeList = [{ "id": retentionData.retentionEntityType, "name": retentionData.retentionEntityTypeDisplayName }];
    this.jobTypesForRetention = [{ JobTypeId: retentionData.retentionEntityId, Type: retentionData.retentionDisplayName, month : 0, IsActive : false }];
    this.addRetentionForm.controls['jobTypeSelected'].setValue(retentionData.retentionEntityId);
    this.tagList = [{ TagId: retentionData.retentionEntityId, TagNameForDisplay: retentionData.retentionDisplayName }];
    this.addRetentionForm.controls['tagTypeSelected'].setValue(retentionData.retentionEntityId);
    this.firmFoldersForRetention = [{ FirmFolderId: retentionData.retentionEntityId, FirmFolderName: retentionData.retentionDisplayName, IsVisible: true }];
    this.addRetentionForm.controls['firmFolderSelected'].setValue(retentionData.retentionEntityId);
  }
  this.addRetentionForm.controls['retentionTypeSelected'].setValue(retentionData.retentionEntityType);
  this.retentionPeriod.year = retentionData.retentionYear;
  this.retentionPeriod.month = retentionData.retentionMonth;
  if (this.retentionPeriod.year != 0) {
    this.retentionPeriod.minMonth = 0;
  }
  else
  {
    this.retentionPeriod.minMonth = 1;
  }

  if (this.retentionPeriod.month != 0) {
      this.retentionPeriod.minYear = 0;
  }
  else
  {
     this.retentionPeriod.minYear = 1;
  }
  }

  private getJobTypeList()
  { 
    var that = this;
    that.rData = true;
     this.retentionService.getJobTypesForRetention().then(function (data) { 
      that.rData = false;
      if (data) {
        that.jobTypesForRetention = data.JobTypeForRetentionList;
          if (that.jobTypesForRetention.length != 0) {
            that.addRetentionForm.controls['jobTypeSelected'].setValue(that.jobTypesForRetention[0].JobTypeId);
          }
          else
          {
           // that.isSaveRetentionDisabled = true; // disable save button if Job types list is empty
          }
      }
    });
  }

  private getTagList()
  {
    var that = this;
    that.rData = true;
    this.retentionService.getTagList().then(function (data) {
      that.rData = false;
      if (data) {
        that.tagList = data.TagList.filter(x=> !x.IsSystemTag);
        if (that.tagList.length != 0)
           that.addRetentionForm.controls['tagTypeSelected'].setValue(that.tagList[0].TagId);
        }
    });
  }

  private getFirmDocumentsSettingsForRetention()
  {
    var that = this;
    that.rData = true;
    this.retentionService.getFirmDocumentsSettingsForRetention().then(function (response) {
      that.rData = false;
      that.firmDocuemntsSettings = response;
      that.getFirmFolderList();
    })
  }

  private getFirmFolderList()
  {
    var that = this;
    that.rData = true;
    this.retentionService.getFirmFoldersForRetention(retentionType.FirmFolder).then(function (data) {
      that.rData = false;
      if (data) {
          var firmFoldersRetentionList = data.RetentionItemList;
          that.firmFoldersForRetention = [{ "FirmFolderId": firmFolder.InternalDocuments, "FirmFolderName": that.resourceService.getText('dms.settings.internaldocuments'), 
                                            "IsVisible": true }, { "FirmFolderId": firmFolder.HRDocuments, "FirmFolderName": that.resourceService.getText('dms.settings.hrdocuments'), 
                                            "IsVisible": that.firmDocuemntsSettings.EnableHRFolders }, { "FirmFolderId": firmFolder.UserDocuemnts, "FirmFolderName": that.resourceService.getText('dms.settings.userdocuments'), 
                                            "IsVisible": that.firmDocuemntsSettings.EnableUserFolders }];

          if (firmFoldersRetentionList.length != 0) {
              var retentionFirmFolderIds = firmFoldersRetentionList.map(function (value) { return value.RetentionEntityId });
              that.firmFoldersForRetention = that.firmFoldersForRetention.filter(function (value) { return retentionFirmFolderIds.indexOf(value.FirmFolderId) < 0 })
          }

          if (that.firmFoldersForRetention.length != 0) {
             that.addRetentionForm.controls['firmFolderSelected'].setValue(that.firmFoldersForRetention[0].FirmFolderId);
          }
      }
    })
  }
}
