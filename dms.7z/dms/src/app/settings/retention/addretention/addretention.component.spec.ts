import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { AddretentionComponent } from './addretention.component';

describe('AddretentionComponent', () => {
  let component: AddretentionComponent;
  let fixture: ComponentFixture<AddretentionComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ AddretentionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddretentionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
