import { RetentionService } from './retention.service';
import { RetentionModel, DmsRetention, SortingDetails } from './retention.model';
import { Component, OnInit } from '@angular/core';
import { AddRetentionComponent } from './addretention/addretention.component';
import { ResourceService, ConfirmationBoxType, ModalPopupConfig, ModalPopupService, ConfirmationBoxComponent } from '@ifirm';
import { ToasterService } from 'projects/ifirm-common-components/src/lib/toaster//toaster.service';
import { DmsService } from '../../dms.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-retention',
  templateUrl: './retention.component.html',
  styleUrls: ['./retention.component.scss']
})
export class RetentionComponent implements OnInit {
  retentionUpdate: DmsRetention = new DmsRetention();
  retentionData: RetentionModel;
  isDisabled: boolean = false;
  searchCriteria: SortingDetails;
  rData: boolean = false;
  isDesc: boolean = false;
  column: string = '';
  sortColumn: string = "retentionEntityTypeDisplayName";
  retentionSettingPermanentTagKey: string = "permanenttag";
  isUserHaveViewRole: boolean = false;
  private resourceChangedSubscription: Subscription;

  constructor(private retentionService: RetentionService, private resourceService: ResourceService,
    private popupService: ModalPopupService, private toasterService: ToasterService, private dmsService: DmsService) {
  }

  ngOnInit(): void {

    this.dmsService.getDmsRoles().then(x => {
      if (x != null && x.DmsSettingsDocuments) {
        this.isUserHaveViewRole = true;
        this.dmsService.setBreadCrumbAndTitle(this.resourceService.get('dms.settings.retentionsettings'));
        this.getretentionlist();
        this.searchCriteria = new SortingDetails("type", "asc");

        this.resourceChangedSubscription = this.resourceService.resourcesChanged.subscribe(a => {
          this.dmsService.setBreadCrumbAndTitle(this.resourceService.get('dms.settings.retentionsettings'));
        });
      }
      else {
        this.dmsService.showAccessDeniedMessage();
      }
    })
      .catch(
        exception => {
          this.toasterService.error(this.resourceService.getText('dms.settings.anerroroccurred'));
        });
  }

  ngOnDestroy() {
    if (this.resourceChangedSubscription) {
      this.resourceChangedSubscription.unsubscribe();
    }
  }

  private getretentionlist(): void {
    this.rData = true;
    let sortColumn = this.sortColumn;
    let isDesc = this.isDesc;
    let sortFn = this.sortFn;
    this.retentionService.getretentionlist()
      .then(x => {
        this.retentionData = x;
        if (this.retentionData.items) {
          if (!this.isDesc) {
            this.retentionData.items.sort(function (object1, object2) {
              if (object1['isDefault'] > object2['isDefault']) {
                return -1;
              }

              if (object1['isDefault'] < object2['isDefault']) {
                return 1;
              }
              return sortFn(object2, object1, sortColumn, isDesc);
            });
          } else {
            this.retentionData.items.sort(function (object1, object2) {
              if (object1['isDefault'] > object2['isDefault']) {
                return -1;
              }

              if (object1['isDefault'] < object2['isDefault']) {
                return 1;
              }
              return sortFn(object1, object2, sortColumn, isDesc);
            });
          }
        }
        this.rData = false;
      })
      .catch(
        exception => {
          this.rData = false;
          this.toasterService.error(this.resourceService.getText('dms.settings.errorviewsetting'));
        });
  }

  showAddEditRetentionDialog(retentionitem): void {
    this.isDisabled = true;
    let instance;
    const config = new ModalPopupConfig();

    if (retentionitem == null || retentionitem == undefined) {
      instance = this.popupService.open<AddRetentionComponent>(this.resourceService.getText('dms.settings.addretentionmodeltitle'), AddRetentionComponent, config);
      this.closePopup(instance);
    }
    else {
      config.data = { retentionitem };
      if (retentionitem.retentionKey != this.retentionSettingPermanentTagKey) {
        instance = this.popupService.open<AddRetentionComponent>(this.resourceService.getText('dms.settings.retention.editretention'), AddRetentionComponent, config);
        this.closePopup(instance);
      }
    }
  }

  showConfirmDeleteDialog(retention): void {
    const config: ModalPopupConfig<any> = new ModalPopupConfig<any>();
    config.data = { message: this.resourceService.getText('ifirm.common.areyousuretodelete'), type: ConfirmationBoxType.YesNo };

    let instance = this.popupService.open<ConfirmationBoxComponent>(this.resourceService.getText('ifirm.common.delete'), ConfirmationBoxComponent, config);
    const subscription = instance.afterClosed.subscribe(x => {
      if (subscription) {
        subscription.unsubscribe();
      }
      if (x.result) {
        this.rData = true;
        this.retentionUpdate.retentionId = retention.retentionId;
        this.retentionUpdate.retentionEntityType = retention.retentionEntityType;
        this.retentionUpdate.retentionEntityId = retention.retentionEntityId;

        this.retentionService.deleteRetention(this.retentionUpdate).then(x => {
          this.rData = false;
          if (x.message == "") {
            this.getretentionlist();
            this.toasterService.success(this.resourceService.getText('dms.settings.retentiondeletesuccess'));
          }
          else {
            this.toasterService.error(this.resourceService.getText('dms.validationmessages.' + x.message));
          }
        }).catch(
          exception => {
            this.toasterService.error(this.resourceService.getText('dms.delete.errormessage'));
          });
      }
    });
  }

  sortFn(object1, object2, sortColumn, isDesc) {
    if (sortColumn === "retentionDisplayName") {
      return object1['retentionDisplayName'].localeCompare(object2['retentionDisplayName']);
    }
    else {
      if (object1[sortColumn] < object2[sortColumn]) {
        return -1;
      }

      if (object1[sortColumn] > object2[sortColumn]) {
        return 1;
      }
    }

    if (sortColumn === "retentionEntityTypeDisplayName") {
      if (!isDesc) {
        return object1['retentionDisplayName'].localeCompare(object2['retentionDisplayName']);
      }
      else {
        return object2['retentionDisplayName'].localeCompare(object1['retentionDisplayName']);
      }
    }

    return 0;
  }

  sort(event) {
    this.isDesc = !this.isDesc;
    let direction = this.isDesc ? 1 : -1;
    let property = event;
    this.sortColumn = event;
    let sortFn = this.sortFn;
    let isDesc = this.isDesc
    let sortColumn = this.sortColumn;


    if (!this.isDesc) {
      this.retentionData.items.sort(function (object1, object2) {
        if (object1['isDefault'] > object2['isDefault']) {
          return -1;
        }

        if (object1['isDefault'] < object2['isDefault']) {
          return 1;
        }
        return sortFn(object2, object1, sortColumn, isDesc);
      });
    } else {
      this.retentionData.items.sort(function (object1, object2) {
        if (object1['isDefault'] > object2['isDefault']) {
          return -1;
        }

        if (object1['isDefault'] < object2['isDefault']) {
          return 1;
        }
        return sortFn(object1, object2, sortColumn, isDesc);
      });
    }

  };

  private closePopup(instance: any) {
    const subscription = instance.afterClosed.subscribe(x => {
      if (subscription) {
        subscription.unsubscribe();
      }
      this.getretentionlist();
      this.isDisabled = true;
    })
  }
}