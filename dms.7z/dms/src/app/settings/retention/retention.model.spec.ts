import { Retention.Model } from './retention.model';

describe('Retention.Model', () => {
  it('should create an instance', () => {
    expect(new Retention.Model()).toBeTruthy();
  });
});
