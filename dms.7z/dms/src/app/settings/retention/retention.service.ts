import { Injectable } from '@angular/core';
import { ApiService} from '@ifirm';
import { RetentionModel, DmsRetention } from "./retention.model";
import { retentionType } from '../../constants/app-constants';

@Injectable({
  providedIn: 'root'
})
export class RetentionService {

  constructor(private api: ApiService) { }

  public getretentionlist(): Promise<any> {
    const url = '/dms/api/retention/getretentionlist';
    return this.api.get<RetentionModel>(url, RetentionModel).toPromise();
  }
  
  public deleteRetention(settings : DmsRetention): Promise<any> {
    const url = '/dms/api/retention/deleteRetention';
    return this.api.post<any>(url, null, settings).toPromise();
  }

  public getJobTypesForRetention(): Promise<any> {
    const url = '/dms/api/retention/getjobtypesforretention';
    return this.api.get<any>(url).toPromise();
  }

  public getTagList(): Promise<any> {
    const url = '/dms/api/tag/gettaglist?selectOnlyShowTag=' + false + '&excludeRetentionTags=' + true;
    return this.api.get<any>(url).toPromise();
  }
  
  public addRetention(DmsRetention): Promise<any> {
    const url = '/dms/api/retention/addRetention';
    return this.api.post<any>(url,null,DmsRetention).toPromise();
  }

  public updateRetention(DmsRetention): Promise<any> {
    const url = '/dms/api/retention/updateRetention';
    return this.api.post<any>(url,null,DmsRetention).toPromise();
  }

  public getFirmFoldersForRetention(retentionType : retentionType): Promise<any> {
    const url = '/dms/api/retention/getretentionbyretentionentitytype?retentionType=' + retentionType;
    return this.api.get<any>(url).toPromise();
  }
  
  public getFirmDocumentsSettingsForRetention(): Promise<any> {
    const url = '/dms/api/settings/getfirmdocumentssettings';
    return this.api.get<any>(url).toPromise();
  }

}