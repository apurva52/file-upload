import { PropertyName } from '@ifirm';

export class DmsRetention
{
    @PropertyName("RetentionId")
    retentionId : number;

    @PropertyName("RetentionKey")
    retentionKey : string;
    
    @PropertyName("RetentionEntityType")
    retentionEntityType : number;
    
    @PropertyName("RetentionEntityTypeDisplayName")
    retentionEntityTypeDisplayName :string;

    @PropertyName("RetentionEntityId")
    retentionEntityId : number;

    @PropertyName("RetentionDisplayName")
    retentionDisplayName :string

    @PropertyName("RetentionYear")
    retentionYear : number;

    @PropertyName("RetentionMonth")
    retentionMonth : number;
    
    @PropertyName("OldRetentionYear")
    oldRetentionYear : number;

    @PropertyName("OldRetentionMonth")
    oldRetentionMonth : number;

    @PropertyName("RetentionPeriodInGrid")
    retentionPeriodInGrid : string;

    @PropertyName("RetentionPeriodInMonth")
    retentionPeriodInMonth : number;

    @PropertyName("SortOrder")
    sortOrder : number;

    @PropertyName("IsDefault")
    isDefault : boolean;

    @PropertyName("InfoMessage")
    infoMessage : string;

    @PropertyName("CreatedBy")
    createdBy : number;

    @PropertyName("CreatedDate")
    createdDate? : Date;

    @PropertyName("UpdatedBy")
    updatedBy : number;

    @PropertyName("UpdatedDate")
    updatedDate? : Date;

    @PropertyName("UpdatedDateToDisplay")
    updatedDateToDisplay : string;
}

export class RetentionModel {
    @PropertyName('RetentionList', DmsRetention)
    items: DmsRetention[];
}

export class SortingDetails {

    constructor(sortColumnName:string, sortDirection:string){
        this.sortColumnName = sortColumnName;
        this.sortDirection = sortDirection;
    }

    sortColumnName: string;

    sortDirection: string;
}