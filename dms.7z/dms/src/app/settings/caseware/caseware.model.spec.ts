import { Caseware.Model } from './caseware.model';

describe('Caseware.Model', () => {
  it('should create an instance', () => {
    expect(new Caseware.Model()).toBeTruthy();
  });
});
