import { Component, OnInit } from '@angular/core';
import { CasewareService } from './caseware.service';
import { CasewareModel } from './caseware.model';
import { FormControl, FormGroup } from '@angular/forms';
import { ResourceService } from '@ifirm';
import { ToasterService } from 'projects/ifirm-common-components/src/lib/toaster//toaster.service';
import { DmsService } from '../../dms.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-caseware',
  templateUrl: './caseware.component.html',
  styleUrls: ['./caseware.component.scss']
})

export class CasewareComponent implements OnInit {
  settings: CasewareModel = new CasewareModel();
  casewareForm: FormGroup;
  rData: boolean = false;
  isUserHaveViewRole: boolean = false;
  private resourceChangedSubscription: Subscription;

  constructor(private casewareService: CasewareService, private resourceService: ResourceService, private toasterService: ToasterService, private dmsService: DmsService) {
    this.casewareForm = new FormGroup({
      sharedNetworkPath: new FormControl(''),
      ignoreSharedNetworkPath: new FormControl(false),
      isLocked: new FormControl(false),
    });
  }

  ngOnInit(): void {
    this.dmsService.getDmsRoles().then(x => {
      if (x != null && x.DmsSettingsDocuments) {
        this.isUserHaveViewRole = true;
        this.dmsService.setBreadCrumbAndTitle(this.resourceService.get('dms.settings.casewaresettings'));
        this.rData = true;
        this.casewareService.getcasewareconfiguration().then(x => {
          this.rData = false;
          this.settings = x;
          this.casewareForm.setValue({
            sharedNetworkPath: this.settings.sharedNetworkPath == null ? "" : this.settings.sharedNetworkPath,
            ignoreSharedNetworkPath: this.settings.ignoreSharedNetworkPath,
            isLocked: this.settings.isLocked,
          });
        })
          .catch(
            exception => {
              this.rData = false;
              this.toasterService.error(this.resourceService.getText('dms.settings.errorviewsetting'));
            });

        this.resourceChangedSubscription = this.resourceService.resourcesChanged.subscribe(a => {
          this.dmsService.setBreadCrumbAndTitle(this.resourceService.get('dms.settings.casewaresettings'));
        });
      }
      else {
        this.dmsService.showAccessDeniedMessage();
      }
    })
      .catch(
        exception => {
          this.toasterService.error(this.resourceService.getText('dms.settings.anerroroccurred'));
        });
  }

  ngOnDestroy() {
    if (this.resourceChangedSubscription) {
      this.resourceChangedSubscription.unsubscribe()
    }
  }

  cancelSettings() {
    window.location.hash = '/dms/settings/main';
  }

  saveSettings() {
    if (this.casewareForm.status === 'VALID') {
      {
        this.rData = true;
        this.settings = this.casewareForm.value;
        this.casewareService.updatecasewareconfiguration(this.settings).then(result => {
          this.rData = false;
          this.toasterService.success(this.resourceService.getText('ifirm.common.settingssaved'));
        }).catch(
          exception => {
            this.rData = false;
            this.toasterService.error(this.resourceService.getText('dms.settings.errorsavesetting'));
          });
      }
    }
  }
}
