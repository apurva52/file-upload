import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { CasewareComponent } from './caseware.component';

describe('CasewareComponent', () => {
  let component: CasewareComponent;
  let fixture: ComponentFixture<CasewareComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ CasewareComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CasewareComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
