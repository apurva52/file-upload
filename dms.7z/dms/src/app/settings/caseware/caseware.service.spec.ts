import { TestBed } from '@angular/core/testing';

import { CasewareService } from './caseware.service';

describe('CasewareService', () => {
  let service: CasewareService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CasewareService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
