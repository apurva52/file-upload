import { Injectable } from '@angular/core';
import { ApiService} from '@ifirm';
import { CasewareModel } from "./caseware.model";

@Injectable({
  providedIn: 'root'
})
export class CasewareService {

  constructor(private api: ApiService) { }

  public getcasewareconfiguration(): Promise<any> {
    const url = '/dms/api/settings/getcasewareconfiguration';
    return this.api.get<CasewareModel>(url, CasewareModel).toPromise();
  }
  
  public updatecasewareconfiguration(settings : CasewareModel): Promise<any> {
    const url = '/dms/api/settings/updatecasewareconfiguration';
    return this.api.post<CasewareModel>(url, null, settings).toPromise();
  }
}
