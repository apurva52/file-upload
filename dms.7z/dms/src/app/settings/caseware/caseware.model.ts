import { PropertyName } from '@ifirm';

export class CasewareModel {

    @PropertyName("IgnoreSharedNetworkPath")
    ignoreSharedNetworkPath:boolean;  

    @PropertyName("SharedNetworkPath")
    sharedNetworkPath:string;

    @PropertyName("IsLocked")
    isLocked:boolean;
}
