import { PropertyName } from '@ifirm';

export class AddTagModel
{
    @PropertyName("TagId")
    tagId : number;

    @PropertyName("TagName")
    tagName : string;

    @PropertyName("TagNameLanguage1")
    tagNameLanguage1 : string;

    @PropertyName("ShowTag")
    showTag : boolean;
}
