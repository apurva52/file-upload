import { Component, OnInit, ChangeDetectorRef, ViewEncapsulation } from '@angular/core';
import { Validators, FormGroup, FormControl } from '@angular/forms';
import { TagService } from '../tag.service';
import { AddTagModel } from './addtag.model';
import { ModalPopupInstance, ResourceService, ModalPopupConfig, LanguageService, SupportedLanguages } from '@ifirm';
import { ViewChild, ElementRef } from '@angular/core';
import { ToasterService } from 'projects/ifirm-common-components/src/lib/toaster/toaster.service';
import { AppConstants } from '../../../constants/app-constants';

@Component({
  selector: 'app-addtag',
  templateUrl: './addtag.component.html',
  styleUrls: ['./addtag.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AddtagComponent implements OnInit {
  addTagForm: FormGroup;
  fieldlabelData = [];
  validationErrors = [];
  settings: AddTagModel = new AddTagModel();
  selectedItem = {lang : "", value : '' };
  IsEditMode: boolean = false;
  tagId: number;
  rData : boolean = false;
  isaddMoreValid : boolean = false;
  isButtonDisabled: boolean = true;
  isDisabled : boolean = false;
  isSupportMultiLanguages: boolean = false;
  @ViewChild('tagInput') input : ElementRef;
  languageData: SupportedLanguages;
  enLanguage: string = "";
  frLanguage: string = "";

  constructor(private tagService :TagService, private instance: ModalPopupInstance, 
              private resourceService: ResourceService, private changeDetection: ChangeDetectorRef,
              tagData: ModalPopupConfig, private languageService:LanguageService, private toasterService: ToasterService) {  
                
    this.IsEditMode = tagData.data != undefined ? true : false;
    if(this.IsEditMode){
      this.isButtonDisabled=false;
    }
    this.tagId = tagData.data != undefined ? tagData.data.tagitem.tagId : 0;
    this.languageData = this.languageService.getSupportedLanguages();
    this.enLanguage = this.languageData.languages != undefined ? this.languageData.languages[0].Id.substring(0,2) : "";
    this.frLanguage = this.languageData.languages != undefined ? this.languageData.languages[1].Id.substring(0,2) : "";
    this.getLangItems(tagData);
    this.addTagForm = new FormGroup({
      tagName: new FormControl(tagData.data != undefined ? tagData.data.tagitem.tagName != undefined ? tagData.data.tagitem.tagName : "" : "", Validators.required),
      existsen : new FormControl(false),
      existsfr : new FormControl(false),
      error : new FormControl(false),
    });
    if(tagData.data == undefined)
    {
      this.addTagForm.get("tagName").setValidators([Validators.required]);
    }
  }

  ngOnInit(): void {
    this.addTagForm.controls['tagName'].valueChanges.subscribe(changeValue => { 
      if (this.selectedItem.lang == "fr" && this.isSupportMultiLanguages) {
        this.fieldlabelData[1].value = changeValue;
      }
      else {
        this.fieldlabelData[0].value = changeValue;
      }
    });
  }

  closePopup(){
    this.instance.close({ result: false });
  }

  getLangItems(tagData){
    this.setMultilingualData(tagData);
    this.selectedItem = { lang: this.enLanguage, value: tagData.data != undefined ? tagData.data.tagitem.tagName != undefined ? tagData.data.tagitem.tagName : "" : ""  };
    if (this.languageData && this.languageData.languages && this.languageData.languages.length > 1) {
      this.isSupportMultiLanguages = true;
    }
  }

  setMultilingualData(tagData?)
  {
    this.fieldlabelData = [{ lang: this.enLanguage, value: tagData != undefined && tagData.data != undefined  ? tagData.data.tagitem.tagName != undefined ? tagData.data.tagitem.tagName : "" : ""  },
                           { lang : this.frLanguage, value: tagData != undefined && tagData.data != undefined  ? tagData.data.tagitem.tagNameLanguage1 != undefined ? tagData.data.tagitem.tagNameLanguage1 : "" : "" }];
  }

  select(item)
  {
    this.selectedItem = item;
    this.addTagForm.controls['tagName'].setValue(item.value);
    if(item.value!=""){
      this.isButtonDisabled=false;
    } else {
      this.isButtonDisabled=true;
    }
   
  }

  onKeyupEvent(event){
    if(this.fieldlabelData[0].value != "" || this.fieldlabelData[1].value != "" || event.target.value)
    {
      this.addTagForm.get("tagName").clearValidators();
    }
    else
    {
      this.addTagForm.get("tagName").setValidators([Validators.required]);
    }

    if(event.target.value.trim()!=""){
      this.isButtonDisabled=false;
    }else {
      this.isButtonDisabled=true;
    }
    this.addTagForm.get("tagName").updateValueAndValidity();
 }

  addEditTagDialog(flag) {
    if(this.addTagForm.status === 'VALID'){  
      if(flag == "addMore")
      {  
      this.isaddMoreValid = false;
      }
     this.rData = true;
      this.settings.tagName = this.fieldlabelData[0].value ;
      this.settings.tagNameLanguage1 = this.fieldlabelData[1].value ;
      
      if(this.IsEditMode)
      {
        this.settings.tagId = this.tagId;
        this.tagService.updatetag(this.settings).then(res => {
          this.rData = false;
          if (res.success == true) {
          this.instance.close({ result: false });
          this.toasterService.success(this.resourceService.getText('dms.settings.tagupdatesuccess'));
          }
          else
          {
            this.showValidations(res);
          }
        });
      }
    else
    {
     this.tagService.addtag(this.settings).then(res => {
      this.rData = false;
      if (res.success == true) {
          if(flag == "add")
          {  
          this.instance.close({ result: false });
          }
          this.input.nativeElement.value = "";
          this.setMultilingualData();
          this.addTagForm.get("tagName").setValidators([Validators.required]);
          this.toasterService.success(this.resourceService.getText('dms.settings.tagaddsuccess'));
          this.rData = true;
          this.tagService.gettaglist()
          .then(x => { 
          this.rData = false;
          this.isDisabled = x.items.length >= AppConstants.maxDmsTagLimit;
          if(this.isDisabled)
          {
            this.instance.close({ result: false });
         } 
      }).catch(
            exception => {
              this.rData = false;
              this.toasterService.error(this.resourceService.getText('dms.settings.errorviewsetting'));
          });
      }
      else
      {
        this.showValidations(res);
      }
      }).catch(exp => { 
        this.rData = false;
        this.validationErrors.push(this.resourceService.get('tagnamevalidationmessage2'));
        this.changeDetection.detectChanges(); });
     }
    }
    else if(flag == "addMore")
    {  
      this.isaddMoreValid = true;
    }
   }

   IsAddMoreOpen()
  {
    return document.getElementById('retensionAddMore').getElementsByTagName('wk-dropdown')[0].className == 'wk-dropdown wk-is-open';
  }

 
    private showValidations(res :any)
    {  
     this.validationErrors = [];
     res.message.forEach(element => {
      if (element.Message === "duplicatetagnameen") {
      this.validationErrors.push(this.resourceService.get('dms.settings.tagnamevalidationmessage1', ["en"]).toString().replace("<b>", "").replace("</b>", ""));
     } 
     else if (element.Message === "duplicatetagnamefr") {
      this.validationErrors.push(this.resourceService.get('dms.settings.tagnamevalidationmessage1', ["fr"]).toString().replace("<b>", "").replace("</b>", ""));
     }
     else { this.validationErrors.push(this.resourceService.get('tagnamevalidationmessage2')); } 
     this.changeDetection.detectChanges();
     })
    }
}
