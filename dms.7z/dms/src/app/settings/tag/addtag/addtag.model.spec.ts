import { Addtag.Model } from './addtag.model';

describe('Addtag.Model', () => {
  it('should create an instance', () => {
    expect(new Addtag.Model()).toBeTruthy();
  });
});
