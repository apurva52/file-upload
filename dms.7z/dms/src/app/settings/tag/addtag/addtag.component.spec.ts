import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { AddtagComponent } from './addtag.component';

describe('AddtagComponent', () => {
  let component: AddtagComponent;
  let fixture: ComponentFixture<AddtagComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ AddtagComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddtagComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
