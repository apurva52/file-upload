import { PropertyName } from '@ifirm';

export class TagList
{
    @PropertyName("TagId")
    tagId : number;

    @PropertyName("TagIdForMapping")
    tagIdForMapping : string;
    
    @PropertyName("TagNameForDisplay")
    tagNameForDisplay : number;
    
    @PropertyName("TagName")
    tagName :string;

    @PropertyName("TagNameLanguage1")
    tagNameLanguage1 : number;

    @PropertyName("ShowTag")
    showTag : boolean;

    @PropertyName("SortOrder")
    sortOrder : number;

    @PropertyName("IsSystemTag")
    isSystemTag : boolean;

    @PropertyName("CreatedBy")
    createdBy : number;

    @PropertyName("CreatedDateTime")
    createdDateTime? : Date;

    @PropertyName("UpdatedBy")
    updatedBy : number;

    @PropertyName("UpdatedDateTime")
    updatedDateTime? : Date;

    @PropertyName("IsSelected")
    isSelected : boolean;
}

export class TagModel {
    @PropertyName('TagList', TagList)
    items: TagList[];
}