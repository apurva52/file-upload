import { Tag.Model } from './tag.model';

describe('Tag.Model', () => {
  it('should create an instance', () => {
    expect(new Tag.Model()).toBeTruthy();
  });
});
