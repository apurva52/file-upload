import { Component, OnInit } from '@angular/core';
import { TagService } from './tag.service';
import { TagModel, TagList } from './tag.model';
import { AddtagComponent } from './addtag/addtag.component';
import { AddTagModel } from './addtag/addtag.model';
import { ResourceService, ConfirmationBoxType, ModalPopupConfig, ModalPopupService, ConfirmationBoxComponent } from '@ifirm';
import { AppConstants } from '../../constants/app-constants';
import { ToasterService } from 'projects/ifirm-common-components/src/lib/toaster//toaster.service';
import { DmsService } from '../../dms.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-tag',
  templateUrl: './tag.component.html',
  styleUrls: ['./tag.component.scss']
})
export class TagComponent implements OnInit {
  settings: TagModel = new TagModel();
  tagUpdate: TagList = new TagList();
  updateTagModel: AddTagModel = new AddTagModel();
  isDisabled: boolean = false;
  rData: boolean = false;
  isUserHaveViewRole: boolean = false;
  private resourceChangedSubscription: Subscription;

  constructor(private tagService: TagService, private resourceService: ResourceService,
    private popupService: ModalPopupService, private toasterService: ToasterService, private dmsService: DmsService) {
  }

  ngOnInit(): void {
    this.dmsService.getDmsRoles().then(x => {
      if (x != null && x.DmsSettingsDocuments) {
        this.isUserHaveViewRole = true;
        this.dmsService.setBreadCrumbAndTitle(this.resourceService.get('dms.settings.tagsettings'));
        this.gettaglist();
        this.resourceChangedSubscription = this.resourceService.resourcesChanged.subscribe(a => {
          this.dmsService.setBreadCrumbAndTitle(this.resourceService.get('dms.settings.tagsettings'));
        });
      }
      else {
        this.dmsService.showAccessDeniedMessage();
      }
    })
      .catch(
        exception => {
          this.toasterService.error(this.resourceService.getText('dms.settings.anerroroccurred'));
        });
  }

  ngOnDestroy() {
    if (this.resourceChangedSubscription) {
      this.resourceChangedSubscription.unsubscribe();
    }
  }

  cancelSettings() {
    window.location.hash = '/dms/settings/main';
  }

  showHideTagChecked(tag): void {
    this.updateTagModel.tagId = tag.tagId;
    this.updateTagModel.showTag = tag.showTag;
    this.tagService.updatetag(this.updateTagModel)
      .then(x => {
        this.gettaglist();
      });
  }

  showConfirmDeleteDialog(tag): void {
    const config: ModalPopupConfig<any> = new ModalPopupConfig<any>();
    config.data = { message: this.resourceService.getText('dms.settings.areyousuretodeletetag'), type: ConfirmationBoxType.YesNo };
    let instance = this.popupService.open<ConfirmationBoxComponent>(this.resourceService.getText('ifirm.common.delete'), ConfirmationBoxComponent, config);
    const subscription = instance.afterClosed.subscribe(x => {
      if (subscription) {
        subscription.unsubscribe();
      }
      if (x.result) {
        this.rData = true;
        this.tagUpdate.tagId = tag.tagId;
        this.tagService.deletetag(this.tagUpdate).then(x => {
          this.rData = false;
          if (x.message == "") {
            this.gettaglist();
            this.toasterService.success(this.resourceService.getText('dms.settings.tagdeletesuccess'));
          }
          else {
            this.toasterService.error(this.resourceService.getText('dms.settings.tagdeletevalidationmessage1'));
          }
        });
      }
    });
  }

  private gettaglist(): void {
    this.rData = true;
    this.tagService.gettaglist()
      .then(x => {
        this.rData = false;
        this.settings = x;
        this.isDisabled = x.items.length >= AppConstants.maxDmsTagLimit
      }).catch(
        exception => {
          this.rData = false;
          this.toasterService.error(this.resourceService.getText('dms.settings.errorviewsetting'));
        });
  }

  showAddEditTagDialog(tagitem): void {
    let instance;
    const config = new ModalPopupConfig();

    if (tagitem == null || tagitem == undefined) {
      instance = this.popupService.open<AddtagComponent>(this.resourceService.getText('dms.settings.tagadd'), AddtagComponent, config);
      this.closePopup(instance);
    }
    else {
      config.data = { tagitem };
      if (!config.data.tagitem.isSystemTag) {
        instance = this.popupService.open<AddtagComponent>(this.resourceService.getText('dms.settings.tagedit'), AddtagComponent, config);
        this.closePopup(instance);
      }
    }
  }

  private closePopup(instance: any) {
    const subscription = instance.afterClosed.subscribe(x => {
      if (subscription) {
        subscription.unsubscribe();
      }
      this.gettaglist();
    })
  }
}
