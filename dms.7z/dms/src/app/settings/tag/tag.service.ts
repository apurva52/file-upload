import { Injectable } from '@angular/core';
import { ApiService} from '@ifirm';
import { TagModel, TagList } from "./tag.model";
import { AddTagModel } from './addtag/addtag.model';

@Injectable({
  providedIn: 'root'
})
export class TagService {

  constructor(private api: ApiService) { }

  public gettaglist(): Promise<any> {
    const url = '/dms/api/tag/gettaglist?selectOnlyShowTag= false';
    return this.api.get<TagModel>(url,TagModel).toPromise();
  }

  public addtag(settings : AddTagModel) : Promise<any> {
    const url = '/dms/api/tag/addtag';
   return  this.api.post<any>(url, null, settings).toPromise();
  }

  public deletetag(settings : TagList): Promise<any> {
    const url = '/dms/api/tag/deletetag';
    return this.api.post<TagList>(url, null, settings).toPromise();
  }

  public updatetag(settings : AddTagModel): Promise<any> {
    const url = '/dms/api/tag/updatetag';
    return this.api.post<any>(url, null, settings).toPromise();
  }
}
