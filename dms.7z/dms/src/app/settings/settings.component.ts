import { Component, OnInit } from '@angular/core';
import { ResourceService, ToasterService } from '@ifirm';
import { DmsService } from '../dms.service';
import { Subscription } from 'rxjs';
import { DmsRole } from '../common/common.module';

@Component({
  selector: 'dms-settings',
  templateUrl: 'settings.component.html',
  styleUrls: ['settings.component.scss']
})

export class SettingsComponent implements OnInit {
  userAccessInfo: DmsRole = new DmsRole();
  isDataAvailable: boolean = false;
  private resourceChangedSubscription: Subscription;

  constructor(private resourceService: ResourceService, private toasterService: ToasterService, private dmsService: DmsService) {
  }

  ngOnInit() {
    this.dmsService.setBreadCrumbAndTitle(this.resourceService.get('dms.documents'));
    this.dmsService.getDmsRoles().then(x => {
      if (x != null && x.DmsSettingsDocuments) {
        this.userAccessInfo = x;
        this.isDataAvailable = true;
      }
      else {
        this.dmsService.showAccessDeniedMessage();
      }
    })
      .catch(
        exception => {
          this.toasterService.error(this.resourceService.getText('dms.settings.getUserAccessInfo'));
        });

    this.resourceChangedSubscription = this.resourceService.resourcesChanged.subscribe(a => {
      this.dmsService.setBreadCrumbAndTitle(this.resourceService.get('dms.documents'));
    });
  }

  ngOnDestroy() {
    if(this.resourceChangedSubscription)
    {
      this.resourceChangedSubscription.unsubscribe()
    }
  }
}
