import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { ModalPopupConfig, ModalPopupInstance, ResourceService, ToasterService } from '@ifirm';
import { ValidatorService } from '../../../validation/validator.service';
import { ContactsEntityModel } from '../models/foldertemplate.model';
import { FolderTemplatesService } from '../services/foldertemplates.service';
import { entityType } from '../../../constants/app-constants';

@Component({
  selector: 'app-add-template-popup',
  templateUrl: './add-template-popup.component.html',
  styleUrls: ['./add-template-popup.component.scss']
})
export class AddTemplatePopupComponent implements OnInit {
  addTemplateForm: FormGroup;
  entityInfo: ContactsEntityModel[];
  loader: boolean = false;
  templateType: string = null;

  constructor(private config: ModalPopupConfig<any>, private instance: ModalPopupInstance,
    private toasterService: ToasterService, private resourceService: ResourceService, private validatorService: ValidatorService, private folderTemplatesService: FolderTemplatesService) {
    this.templateType = config.data;
  }

  ngOnInit(): void {
    this.loader = true;
    this.createForm();
    if (this.templateType === 'contacts') {
      this.loadContactEntities();
    }
    else {
      this.loadJobsTypes();
    }
  }

  private createForm() {
    this.addTemplateForm = new FormGroup({
      entityType: new FormControl("", [Validators.required]),
      templateName: new FormControl("", [Validators.required, this.validatorService.noWhitespaceValidator]),
      copyfolder: new FormControl("", [Validators.required])
    });
  }

  private loadContactEntities() {
    this.folderTemplatesService.getContactEntities().then(res => {
      this.loader = false;
      this.entityInfo = res.ContactEntities;
    }).catch(
      exception => {
        this.loader = false;
        this.toasterService.error(this.resourceService.getText('dms.common.errormessage'));
      });
  }

  private loadJobsTypes() {
    this.folderTemplatesService.getJobTypes().then(res => {
      this.loader = false;
      this.entityInfo = res.JobTypeList;
    }).catch(
      exception => {
        this.loader = false;
        this.toasterService.error(this.resourceService.getText('dms.common.errormessage'));
      });
  }

  closePopup(result: boolean): void {
    this.instance.close(result);
  }

  addFolder() {
    if(this.addTemplateForm.get('entityType').value.length > 0 && this.addTemplateForm.get('templateName').value.length > 0){
      this.loader = true;
      let payload = {
      FolderTemplate: {
        EntityType: this.templateType === 'contacts' ? entityType.Contact : entityType.Job,
        EntitySubType: this.addTemplateForm.value.entityType,
        Description: this.addTemplateForm.value.templateName
      }
    }
    if (this.addTemplateForm.value.copyfolder.length > 0) {      
      payload.FolderTemplate['TemplateId'] = this.addTemplateForm.value.copyfolder;
    }
    this.addFolderTemplate(payload);
    }    
  }


  private addFolderTemplate(payload): void {
    this.folderTemplatesService.addFolderTemplate(payload).then(res => {
      this.loader = false;
      if (res.success == true) {
        this.closePopup(true);
        this.loadContactJobsList();
      }
      else {
        this.toasterService.error(this.resourceService.getText('dms.common.errormessage'));
      }
    }).catch(
      exception => {
        this.loader = false;
        this.toasterService.error(this.resourceService.getText('dms.common.errormessage'));
        console.log(exception);
      });

  }

  private loadContactJobsList() {
    const type = (this.templateType === 'contacts') ? entityType.Contact : entityType.Job;
    this.folderTemplatesService.getFolderTemplateList(type).then(data => {
      this.loader = false;
      if(this.templateType === 'contacts'){
        this.folderTemplatesService.setContactsSubject(data.FolderTemplateList);
      }
      else{
        this.folderTemplatesService.setJobsSubject(data.FolderTemplateList);
      }
    })
      .catch(
        exception => {
          this.loader = false;
          this.toasterService.error(this.resourceService.getText('dms.settings.errorviewsetting'));
        });
  }

  enableSave() {
    return this.addTemplateForm.get('entityType').value.length == 0 || this.addTemplateForm.get('templateName').value.length == 0;
  }

}
