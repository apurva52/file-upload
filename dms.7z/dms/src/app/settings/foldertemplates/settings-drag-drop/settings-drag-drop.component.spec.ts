import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SettingsDragDropComponent } from './settings-drag-drop.component';

describe('SettingsDragDropComponent', () => {
  let component: SettingsDragDropComponent;
  let fixture: ComponentFixture<SettingsDragDropComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SettingsDragDropComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SettingsDragDropComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
