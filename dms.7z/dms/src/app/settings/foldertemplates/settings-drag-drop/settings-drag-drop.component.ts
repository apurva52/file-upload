import { Component, ElementRef, OnInit, ViewChild, Renderer2 } from '@angular/core';
import { ConfirmationBoxComponent, ConfirmationBoxType, GlobalScopeService, ModalPopupConfig, ModalPopupInstance, ModalPopupService, ResourceService, ToasterService } from '@ifirm';
import { AddRenamePopupComponent } from '../add-rename-popup/add-rename-popup.component';
import { FolderTemplatesService } from '../services/foldertemplates.service';
import { DefaultFolderNode, DefaultFolderFlatNode } from '../models/settings-drag-drop.model';
import { FlatTreeControl } from '@angular/cdk/tree';
import { MatTreeFlatDataSource, MatTreeFlattener } from '@angular/material/tree';
import { SettingsDragDropService } from '../services/settings-drag-drop.service'
import { templateType, entityType } from '../../../constants/app-constants';

@Component({
  selector: 'settings-drag-drop',
  templateUrl: './settings-drag-drop.component.html',
  styleUrls: ['./settings-drag-drop.component.scss']
})
export class SettingsDragDropComponent implements OnInit {
  flatNodeMap = new Map<DefaultFolderFlatNode, DefaultFolderNode>();
  nestedNodeMap = new Map<DefaultFolderNode, DefaultFolderFlatNode>();
  treeControl: FlatTreeControl<DefaultFolderFlatNode>;
  treeFlattener: MatTreeFlattener<DefaultFolderNode, DefaultFolderFlatNode>;
  dataSource: MatTreeFlatDataSource<DefaultFolderNode, DefaultFolderFlatNode>;
  DestinationID: string = '';
  SourceID: string = '';
  dragNode: any;
  dragNodeExpandOverWaitTimeMs = 300;
  dragNodeExpandOverNode: any;
  dragNodeExpandOverTime: number | undefined;
  dragNodeExpandOverArea: string | undefined;
  btnDisabled: boolean = true;
  currentNode: any;
  loader: boolean = false;
  disableAdd: boolean = false;
  loadDefaultList: boolean = false;
  getLevel = (node: DefaultFolderFlatNode) => node.level;
  isExpandable = (node: DefaultFolderFlatNode) => node.expandable;
  getChildren = (node: DefaultFolderNode): DefaultFolderNode[] => node.children;
  hasChild = (_: number, _nodeData: DefaultFolderFlatNode) => _nodeData.expandable;
  templateId: string = null;
  entityType: any = null;
  selectedNode: DefaultFolderFlatNode | null = null;

  constructor(private popupService: ModalPopupService, private resourceService: ResourceService, private folderTemplatesService: FolderTemplatesService,
    private toasterService: ToasterService, private dragdropservice: SettingsDragDropService, private renderer: Renderer2, private elRef: ElementRef,
    private globalScope: GlobalScopeService) {
    this.treeFlattener = new MatTreeFlattener(this.transformer, this.getLevel, this.isExpandable, this.getChildren);
    this.treeControl = new FlatTreeControl<DefaultFolderFlatNode>(this.getLevel, this.isExpandable);
    this.dataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);    
  }

  ngOnInit(): void {
    this.loadDefaultFolderList();
  }

  //converting node to flatnode
  transformer = (node: DefaultFolderNode, level: number) => {
    const existingNode = this.nestedNodeMap.get(node);
    const flatNode = existingNode && existingNode.item === node.item
      ? existingNode
      : new DefaultFolderFlatNode();
    flatNode.item = node.item;
    flatNode.DefaultFolderId = node.DefaultFolderId;
    flatNode.Isrestrict = node.Isrestrict;
    flatNode.ParentFolderId = node.ParentFolderId;
    flatNode.level = level;
    flatNode.DefaultFolderHierarchy = node.DefaultFolderHierarchy;
    flatNode.EntityType = node.EntityType;
    flatNode.TemplateId = node.TemplateId;
    flatNode.TemplateType = node.TemplateType;
    flatNode.IsSystemFolder = node.IsSystemFolder;
    flatNode.expandable = (node.children && node.children.length > 0);
    this.flatNodeMap.set(flatNode, node);
    this.nestedNodeMap.set(node, flatNode);
    return flatNode;
  }

  loadDefaultFolderList() {
    this.loader = true;
    this.loadDefaultList = true;
    this.btnDisabled = true;
    this.templateId = this.globalScope.appFrame.GetUrlVariable('id');
    this.entityType = this.globalScope.appFrame.GetUrlVariable('entitytype');
    this.folderTemplatesService.getDefaultFolderList(this.entityType, this.templateId).then((res: any) => {
      this.loader = false;
      let convertedTree = this.dragdropservice.convertToTree(res.DefaultFolderList);
      this.dataSource.data = convertedTree;
      this.treeControl.expandAll();
      this.dragdropservice.dataChange.next(convertedTree);
    })
      .catch(
        exception => {
          this.loader = false;
          this.toasterService.error(this.resourceService.getText('dms.common.errormessage'));
        });
  }

  openAddRenamePopup(type: string) {
    const config: ModalPopupConfig<any> = new ModalPopupConfig<any>();
    this.currentNode = (this.loadDefaultList == true ? undefined : this.currentNode);
    config.data = [type, this.currentNode, this.templateId, this.entityType];
    let label = (type == 'add' ? 'dms.common.addfolder' : 'dms.rename');
    let instance = this.popupService.open<AddRenamePopupComponent>(this.resourceService.getText(label), AddRenamePopupComponent, config);
    const sub = instance.afterClosed.subscribe(response => {
      if (sub) {
        sub.unsubscribe();
      }
      if (response) {
        this.btnDisabled = true;
        this.loadDefaultFolderList();
        setTimeout(() => {
          this.treeControl.expandAll();
        }, 500);
      }
    });
  }

  deletePopup(event) {
    if (event && event.stopPropagation) {
      event.stopPropagation();
    }
    var deleteMessage = this.resourceService.getText('ifirm.common.areyousuretodelete');
    let payload = {
      DefaultFolderId: this.currentNode.DefaultFolderId
    }
    this.showConfirmDeleteDialog(payload, deleteMessage);
  }

  showConfirmDeleteDialog(item: any, deletMessage: string): void {
    const config: ModalPopupConfig<any> = new ModalPopupConfig<any>();
    config.data = { message: deletMessage, type: ConfirmationBoxType.YesNo };
    let instance = this.popupService.open<ConfirmationBoxComponent>(this.resourceService.getText('ifirm.common.delete'), ConfirmationBoxComponent, config);
    const subscription = instance.afterClosed.subscribe(x => {
      if (subscription) {
        subscription.unsubscribe();
      }
      if (x && x.result) {
        this.folderTemplatesService.deleteDefaultfolder(item).then(data => {
          if (data.success === true) {
            this.btnDisabled = true;
            this.loadDefaultFolderList();
            setTimeout(() => {
              this.treeControl.expandAll();
            }, 500);
          }
          else {
            this.toasterService.error(this.resourceService.getText('ifirm.common.error'));
          }
        }).catch(y => {
          this.toasterService.error(this.resourceService.getText('ifirm.common.error'));
        });
      }
    })
  }

  handleDragStart(event: any, node: any) {
    this.SourceID = node.DefaultFolderId
    this.dragNode = node;
  }

  handleDragOver(event: any, node: any) {
    event.preventDefault();
  }

  handleDrop(event: any, node: any, type: string) {
    event.preventDefault();   
    let deafultfolderids = node.DefaultFolderHierarchy == null ? '' : node.DefaultFolderHierarchy.split("/");
    let isvalidfolderids: boolean = false;
    isvalidfolderids = deafultfolderids.includes(this.SourceID.toString());
      if ((node !== this.dragNode) && (!this.dragNode.IsSystemFolder) && (!isvalidfolderids)) {
      let newitem: DefaultFolderNode;
      newitem = this.dragdropservice.copyPasteitem(this.flatNodeMap.get(this.dragNode) as DefaultFolderNode, this.flatNodeMap.get(node) as DefaultFolderNode);    
      this.dragdropservice.deleteitem(this.flatNodeMap.get(this.dragNode) as DefaultFolderNode);
      this.DestinationID = (type == 'select' ? node.ParentFolderId : node.DefaultFolderId);
      if (this.DestinationID != null && node.TemplateType != templateType.TaxTemplate) {
        this.updateHierarchyCall(this.DestinationID, this.SourceID);
      }
      else if (this.DestinationID == null && node.EntityType == entityType.Job) {
         //URL encoding value of #
        this.DestinationID = '%23'; 
        this.updateHierarchyCall(this.DestinationID, this.SourceID);
      }
    }
    this.dragNode = null;
    this.dragNodeExpandOverNode = null;
    this.dragNodeExpandOverTime = 0;
  }

  handleDragEnd(event: any) {
    this.dragNode = null;
    this.dragNodeExpandOverNode = null;
    this.dragNodeExpandOverTime = 0;
    this.DestinationID = '';
    this.SourceID = '';
  }

  updateHierarchyCall(destId, sourceId) {
    this.folderTemplatesService.updateDefaultFolderHierarchy(destId, sourceId).then(data => {
      if (data.success === true) {
        this.btnDisabled = true;
        this.loadDefaultFolderList();
        setTimeout(() => {
          this.treeControl.expandAll();
        }, 500);
      }
    }).catch(y => {
      this.toasterService.error(this.resourceService.getText('ifirm.common.error'));
    });
  }

  nodeSelect(node) {
    this.currentNode = node;
    this.loadDefaultList = false;
      this.btnDisabled = node.IsSystemFolder ? true : false;
      this.disableAdd = (node.TemplateType == templateType.TaxTemplate) ? true : false;
    if (this.selectedNode) {
      this.selectedNode = null;
    }
    this.selectedNode = node;   
  }

}
