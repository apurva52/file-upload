import { Component, OnInit } from '@angular/core';
import { ResourceService, GlobalScopeService } from '@ifirm';
import { ToasterService } from 'projects/ifirm-common-components/src/lib/toaster//toaster.service';
import { DmsService } from '../../../dms.service';
import { FolderTemplatesService } from '../../foldertemplates/services/foldertemplates.service';
import { entityType } from '../../../constants/app-constants';

@Component({
  selector: 'app-folderstructure',
  templateUrl: './folderstructure.component.html',
  styleUrls: ['./folderstructure.component.scss']
})
export class FolderstructureComponent implements OnInit {
  loader: boolean = false;
  folderTemplate: any;
  oldDescription: string = null;
  description: string = null;
  oldIsDefault: boolean = false;
  isDefault: boolean = false;
  isBtnSaveFolderTemplateDisabled: boolean = true;
  btnLabel: string = 'ifirm.common.save';
  btnDisabled: string = 'disabled';
  isDefaultFolderTemplateDisabled: boolean;
  templateId: string = null;
  entityType: any = null;
  typeLabelTxt: string = 'dms.settings.entitytype';
  defaultTxt: string = 'dms.settings.setasdefaultmsgcontact';

  constructor(private resourceService: ResourceService, private toasterService: ToasterService, private dmsService: DmsService,
    private globalScope: GlobalScopeService, private folderTemplatesService: FolderTemplatesService) { }

  ngOnInit(): void {
    this.templateId = this.globalScope.appFrame.GetUrlVariable('id');
    this.entityType = this.globalScope.appFrame.GetUrlVariable('entitytype');
    if (this.entityType == entityType.Contact) {
      this.dmsService.setBreadCrumbAndTitle(this.resourceService.get('dms.settings.foldertemplatescontacts'));
      this.typeLabelTxt = 'dms.settings.entitytype';
      this.defaultTxt = 'dms.settings.setasdefaultmsgcontact';
    }
    else {
      this.dmsService.setBreadCrumbAndTitle(this.resourceService.get('dms.settings.foldertemplatesjobs'));
      this.typeLabelTxt = 'dms.settings.jobtype';
      this.defaultTxt = 'dms.settings.setasdefaultmsgjob';
    }

    this.loadFolderTemplate();
  }

  loadFolderTemplate() {
    this.btnDisabled = 'btnDisabled';
    this.folderTemplatesService.getFolderTemplate(this.entityType, this.templateId).then(data => {
      this.loader = false;
      this.folderTemplate = data.FolderTemplate;
      this.oldDescription = data.FolderTemplate.Description;
      this.description = data.FolderTemplate.Description;
      this.oldIsDefault = data.FolderTemplate.IsDefault;
      this.isDefault = data.FolderTemplate.IsDefault;
      this.isDefaultFolderTemplateDisabled = data.DefaultFolderTemplateId !== data.FolderTemplate.TemplateId && data.DefaultFolderTemplateId > 0;
    })
      .catch(
        exception => {
          this.loader = false;
          this.toasterService.error(this.resourceService.getText('dms.settings.errorviewsetting'));
        });
  }

  updateFolderEvent() {
    this.btnDisabled = (this.oldDescription !== this.description || this.oldIsDefault !== this.isDefault) ? '' : 'disabled';
  }

  updateFolderTemplate() {
    this.loader = true;
    const payload = {
      FolderTemplate: {
        TemplateId: this.folderTemplate.TemplateId,
        EntityType: this.folderTemplate.EntityType,
        EntitySubType: this.folderTemplate.EntitySubType,
        Type: this.folderTemplate.Type,
        Description: this.description,
        IsDefault: this.isDefault
      }
    }

    this.folderTemplatesService.updateFolderTemplate(payload).then(res => {
      this.loader = false;
      if (res.success === false) {
        this.toasterService.error(this.resourceService.getText('dms.common.errormessage'));
      }
      else {
        this.loadFolderTemplate();
      }
    }).catch(
      exception => {
        this.loader = false;
        this.toasterService.error(this.resourceService.getText('dms.common.errormessage'));
        console.log(exception);
      });

  }

}
