import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FolderstructureComponent } from './folderstructure.component';

describe('FolderstructureComponent', () => {
  let component: FolderstructureComponent;
  let fixture: ComponentFixture<FolderstructureComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FolderstructureComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FolderstructureComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
