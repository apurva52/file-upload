import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FoldertemplatesComponent } from './foldertemplates.component';

describe('FoldertemplatesComponent', () => {
  let component: FoldertemplatesComponent;
  let fixture: ComponentFixture<FoldertemplatesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FoldertemplatesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FoldertemplatesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
