import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ContactsRowsModel } from '../models/foldertemplate.model';
import { ModalPopupService, GridColumnModel, ResourceService, ToasterService, ModalPopupConfig, ConfirmationBoxType, ConfirmationBoxComponent } from '@ifirm';
import { FolderTemplatesService } from '../services/foldertemplates.service';
import { AddTemplatePopupComponent } from '../add-template-popup/add-template-popup.component';

@Component({
  selector: 'dms-jobs-tab',
  templateUrl: './jobs-tab.component.html',
  styleUrls: ['./jobs-tab.component.scss']
})
export class JobsTabComponent implements OnInit {
  @Input() jobsList: ContactsRowsModel[];
  contactsGridColumns: GridColumnModel[] = [];
  constructor(private resourceService: ResourceService, private toasterService: ToasterService,
    private popupService: ModalPopupService, private folderTemplatesService: FolderTemplatesService) { }

  ngOnInit(): void {
  }

  openAddTemplatePopup() {
    const config: ModalPopupConfig<any> = new ModalPopupConfig<any>();
    config.data = 'jobs';
    let instance = this.popupService.open<AddTemplatePopupComponent>(this.resourceService.getText('dms.settings.addtemplate'), AddTemplatePopupComponent, config);
    const sub = instance.afterClosed.subscribe(response => {
      if (sub) {
        sub.unsubscribe();
      }
    });
  }

  onRowSelected(contacts) {
    window.location.hash = `/dms/settings/folderstructure?id=${contacts.TemplateId}&entitytype=${contacts.EntityType}`;
  }

  deleteContact(contacts, event) {
    if (event && event.stopPropagation) {
      event.stopPropagation();
    }
    var deleteMessage = this.resourceService.getText('ifirm.common.areyousuretodelete');
    this.folderTemplatesService.showConfirmDeleteDialog(contacts, deleteMessage,'jobs');
  }

}
