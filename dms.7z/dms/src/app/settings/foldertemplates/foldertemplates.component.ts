import { Component, OnInit } from '@angular/core';
import { ResourceService, IFirmTabItemComponent, GlobalScopeService } from '@ifirm';
import { ToasterService } from 'projects/ifirm-common-components/src/lib/toaster//toaster.service';
import { DmsService } from '../../dms.service';
import { Subscription } from 'rxjs';
import { FolderTemplatesService } from '../foldertemplates/services/foldertemplates.service'
import { entityType } from '../../constants/app-constants';

@Component({
  selector: 'app-foldertemplates',
  templateUrl: './foldertemplates.component.html',
  styleUrls: ['./foldertemplates.component.scss']
})
export class FoldertemplatesComponent implements OnInit {
  loader: boolean = false;
  isUserHaveViewRole: boolean = false;
  currentTabName: string;
  currentTabChanged: string;
  selectedTabName: string;
  private resourceChangedSubscription: Subscription;
  contactsList: any;
  jobsList: any;

  constructor(private resourceService: ResourceService, private toasterService: ToasterService, private dmsService: DmsService,
    private globalScope: GlobalScopeService, private folderTemplatesService: FolderTemplatesService) {
    this.contactsList = this.folderTemplatesService.getContactsSubject();
    this.jobsList = this.folderTemplatesService.getJobsSubject();
  }


  ngOnInit(): void {
    console.log("contact source>>"+ this.contactsList.source.value)

    this.dmsService.getDmsRoles().then(x => {
      if (x != null && x.DmsSettingsDocuments) {
        this.loader = true;
        this.isUserHaveViewRole = true;
        this.dmsService.setBreadCrumbAndTitle(this.resourceService.get('dms.settings.foldertemplates'));
        this.loadContactList();
        this.loadJobsList();
      }
      else {
        this.dmsService.showAccessDeniedMessage();
      }
    })
      .catch(
        exception => {
          this.toasterService.error(this.resourceService.getText('dms.settings.anerroroccurred'));
        });
  }

  loadContactList() {
    this.folderTemplatesService.getFolderTemplateList(entityType.Contact).then(data => {
      this.loader = false;
      this.folderTemplatesService.setContactsSubject(data.FolderTemplateList);
    })
      .catch(
        exception => {
          this.loader = false;
          this.toasterService.error(this.resourceService.getText('dms.settings.errorviewsetting'));
        });
    this.resourceChangedSubscription = this.resourceService.resourcesChanged.subscribe(a => {
      this.dmsService.setBreadCrumbAndTitle(this.resourceService.get('dms.settings.foldertemplates'));
    });
  }

  loadJobsList() {
    this.folderTemplatesService.getFolderTemplateList(entityType.Job).then(data => {
      this.loader = false;
      this.folderTemplatesService.setJobsSubject(data.FolderTemplateList);
    })
      .catch(
        exception => {
          this.loader = false;
          this.toasterService.error(this.resourceService.getText('dms.settings.errorviewsetting'));
        });
    this.resourceChangedSubscription = this.resourceService.resourcesChanged.subscribe(a => {
      this.dmsService.setBreadCrumbAndTitle(this.resourceService.get('dms.settings.foldertemplates'));
    });
  }

  tabSelectionChanged(ifirmTabItemComponent: IFirmTabItemComponent) {
    this.globalScope.sendTabDeatilsToGA(ifirmTabItemComponent.name);
    if ((this.currentTabName || 'contacts') != ifirmTabItemComponent.name) {
      this.currentTabName = ifirmTabItemComponent.name;
      this.currentTabChanged = ifirmTabItemComponent.name;
    }
  }

  tabChanged(data: string) {
    if ((this.currentTabName || 'contacts') != 'contacts') {
      this.currentTabName = 'contacts';
      this.selectedTabName = data;
    }
  }

  ngOnDestroy() {
    if (this.resourceChangedSubscription) {
      this.resourceChangedSubscription.unsubscribe();
    }
  }

}
