import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { DefaultFolderNode } from '../models/settings-drag-drop.model';

@Injectable({
  providedIn: 'root'
})
export class SettingsDragDropService {
  JsonData: any[] = [];
  dataChange = new BehaviorSubject<DefaultFolderNode[]>([]);
  get data(): DefaultFolderNode[] { return this.dataChange.value; }

  constructor() {
  }

  public convertToTree(data: any[]): DefaultFolderNode[] {
    const tree: any[] = [];
    const map = new Map<number, DefaultFolderNode>();
    data.forEach(node => {
      const nodes = map.set(node.DefaultFolderId, {
        item: node.FolderName, Isrestrict: node.IsRestricted, DefaultFolderId: node.DefaultFolderId, ParentFolderId: node.ParentFolderId,
        DefaultFolderHierarchy: node.DefaultFolderHierarchy, EntityType: node.EntityType, TemplateId: node.TemplateId, TemplateType: node.TemplateType, IsSystemFolder: node.IsSystemFolder, children: []
      });
    });

    data.forEach(node => {
      if (node.ParentFolderId !== null) {
        const parent = map.get(node.ParentFolderId)
        if (parent) {
          parent.children.push(map.get(node.DefaultFolderId) as DefaultFolderNode)
        } 
      } else {
        tree.push(map.get(node.DefaultFolderId));
      }
    });
    return tree;
  }

  initialize() {
    const data = this.JsonData;
    this.dataChange.next(data);
  }

  insertitem(parent: DefaultFolderNode, name: string, defaultfolderid: any, isrestrict: boolean, ParentFolderId: any, DefaultFolderHierarchy: string,
    EntityType: string, TemplateId: string, TemplateType: string, IsSystemFolder: boolean): DefaultFolderNode {
    if (!parent.children) {
      parent.children = [];
    }
    const newitem = {
      item: name, DefaultFolderId: defaultfolderid, Isrestrict: isrestrict, ParentFolderId: ParentFolderId,
      DefaultFolderHierarchy: DefaultFolderHierarchy, EntityType: EntityType, TemplateId: TemplateId, TemplateType: TemplateType,
      IsSystemFolder: IsSystemFolder } as DefaultFolderNode;
    parent.children.push(newitem);
    this.dataChange.next(this.data);
    return newitem;
  }

  getParent(currentRoot: DefaultFolderNode, node: DefaultFolderNode): DefaultFolderNode {
    if (currentRoot.children && currentRoot.children.length > 0) {
      for (let i = 0; i < currentRoot.children.length; ++i) {
        const child = currentRoot.children[i];
        if (child === node) {
          return currentRoot;
        } else if (child.children && child.children.length > 0) {
          const parent = this.getParent(child, node);
          if (parent != null) {
            return parent;
          }
        }
      }
    }
    return null!;
  }

  deleteitem(node: DefaultFolderNode) {
    this.deleteNode(this.data, node);
    this.dataChange.next(this.data);
  }

  copyPasteitem(from: DefaultFolderNode, to: DefaultFolderNode): DefaultFolderNode {
    const newitem = this.insertitem(to, from.item, from.DefaultFolderId, from.Isrestrict, from.ParentFolderId, from.DefaultFolderHierarchy,
      from.EntityType, from.TemplateId, from.TemplateType, from.IsSystemFolder);
    if (from.children) {
      from.children.forEach(child => {
        this.copyPasteitem(child, newitem);
      });
    }
    return newitem;
  }

  deleteNode(nodes: DefaultFolderNode[], nodeToDelete: DefaultFolderNode) {
    const index = nodes.indexOf(nodeToDelete, 0);
    if (index > -1) {
      nodes.splice(index, 1);
    } else {
      nodes.forEach(node => {
        if (node.children && node.children.length > 0) {
          this.deleteNode(node.children, nodeToDelete);
        }
      });
    }
  }

}
