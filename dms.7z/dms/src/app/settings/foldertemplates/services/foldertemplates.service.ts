import { EventEmitter, Injectable, Output } from '@angular/core';
import { ApiService, ConfirmationBoxComponent, ConfirmationBoxType, ModalPopupConfig, ModalPopupService, ResourceService, ToasterService } from '@ifirm';
import { BehaviorSubject } from 'rxjs';
import { ContactsRowsModel } from '../models/foldertemplate.model';
import { HttpClient } from '@angular/common/http';
import { entityType } from '../../../constants/app-constants';


@Injectable({
  providedIn: 'root'
})
export class FolderTemplatesService {
  private contactsListSubject = new BehaviorSubject<ContactsRowsModel>(null);
  private jobsListSubject = new BehaviorSubject<ContactsRowsModel>(null);

  constructor(private api: ApiService, private http: HttpClient,private resourceService: ResourceService, 
    private toasterService: ToasterService, private popupService: ModalPopupService) { }

  public getFolderTemplateList(etype: number): Promise<any> {
    const url = '/dms/api/foldertemplates/getfoldertemplatelist?entityType=' + etype;
    return this.api.get<any>(url).toPromise();
  }

  public deleteContacts(payload: any): Promise<any> {
    return this.api.post<any>('/dms/api/foldertemplates/deletefoldertemplate', null, payload).toPromise();
  }

  public getContactEntities(): Promise<any> {
    const url = '/dms/api/foldertemplates/getcontactentities';
    return this.api.get<any>(url).toPromise();
  }

  public getJobTypes(): Promise<any> {
    const url = '/dms/api/foldertemplates/getjobtypes';
    return this.api.get<any>(url).toPromise();
  }

  public addFolderTemplate(payload: any): Promise<any> {
    return this.api.post<any>('/dms/api/foldertemplates/addfoldertemplate', null, payload).toPromise();
  }

  public getFolderTemplate(etype: string, tempid: string): Promise<any> {
    const url = '/dms/api/foldertemplates/getfoldertemplate?entityType=' + etype + '&templateId=' + tempid;
    return this.api.get<any>(url).toPromise();
  }

  public updateFolderTemplate(payload: any): Promise<any> {
    return this.api.post<any>('/dms/api/foldertemplates/updatefoldertemplate', null, payload).toPromise();
  }

  public addDefaultfolder(payload: any): Promise<any> {
    return this.api.post<any>('/dms/api/foldertemplates/adddefaultfolder', null, payload).toPromise();
  }

  public renameDefaultfolder(payload: any): Promise<any> {
    return this.api.post<any>('/dms/api/foldertemplates/renamedefaultfolder', null, payload).toPromise();
  }

  public deleteDefaultfolder(payload: any): Promise<any> {
    return this.api.post<any>('/dms/api/foldertemplates/deletedefaultfolder', null, payload).toPromise();
  }

  public updateDefaultFolderHierarchy(destId: string, sourceId: string): Promise<any> {
    const url = '/dms/api/foldertemplates/updatedefaultfolderhierarchy?DestinationId=' + destId + '&SourceId=' + sourceId;
    return this.api.get<any>(url).toPromise();
  }

  public setContactsSubject(val: ContactsRowsModel) {
    this.contactsListSubject.next(val);
  }

  public getContactsSubject() {
    return this.contactsListSubject.asObservable();
  }

  public setJobsSubject(val: ContactsRowsModel) {
    this.jobsListSubject.next(val);
  }

  public getJobsSubject() {
    return this.jobsListSubject.asObservable();
  }

  public getDefaultFolderList(etype: string, tempid: string): Promise<any> {
    const url = '/dms/api/foldertemplates/getdefaultfolderlist?EntityType=' + etype + '&TemplateId=' + tempid;
    return this.api.get<any>(url).toPromise();
  }

  showConfirmDeleteDialog(item: any, deletMessage: string, type: string): void {
    const config: ModalPopupConfig<any> = new ModalPopupConfig<any>();
    config.data = { message: deletMessage, type: ConfirmationBoxType.YesNo };
    let instance = this.popupService.open<ConfirmationBoxComponent>(this.resourceService.getText('ifirm.common.delete'), ConfirmationBoxComponent, config);
    const subscription = instance.afterClosed.subscribe(x => {
      if (subscription) {
        subscription.unsubscribe();
      }
      if (x && x.result) {
        const payload: any = {
          TemplateId: item.TemplateId,
          EntityType: item.EntityType
        };
        this.deleteContacts(payload).then(data => {
          if (data.success === true) {
            if(type === 'contacts'){
              this.getFolderTemplateList(entityType.Contact).then(data => {
                this.setContactsSubject(data.FolderTemplateList);
              })
            }
            else{
              this.getFolderTemplateList(entityType.Job).then(data => {
                this.setJobsSubject(data.FolderTemplateList);
              })
            }

          }
          else {
            this.toasterService.error(this.resourceService.getText('ifirm.common.error'));
          }
        }).catch(y => {
          this.toasterService.error(this.resourceService.getText('ifirm.common.error'));
        });
      }
    })
  }

}
