import { TestBed } from '@angular/core/testing';

import { FolderTemplatesService } from './foldertemplates.service';

describe('FolderTemplatesService', () => {
  let service: FolderTemplatesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FolderTemplatesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
