export class DefaultFolderNode {
    children: DefaultFolderNode[] = [];
    item: string ='';
    Isrestrict:boolean = true;
    DefaultFolderId: string;
    ParentFolderId:string;
    DefaultFolderHierarchy: string;
    EntityType: string;
    TemplateId: string;
    TemplateType: string;
    IsSystemFolder: boolean;
  }

  export class DefaultFolderFlatNode {
    item: string='';
    level?: number=0;
    expandable: boolean=true;
    Isrestrict:boolean=true;
    DefaultFolderId: string;
    ParentFolderId:string;
    DefaultFolderHierarchy: string;
    EntityType: string;
    TemplateId: string;
    TemplateType: string;
    IsSystemFolder: boolean;
  }