import { PropertyName } from '../../../../../../ifirm-common-components/src/public-api';

export class ContactsRowsModel {

    @PropertyName('Description') Description: string;      
    @PropertyName('EntityId') EntityId: string;  
    @PropertyName('EntitySubType') EntitySubType: string; 
    @PropertyName('EntityType') EntityType: string;  
    @PropertyName('IsDefault') IsDefault: boolean;  
    @PropertyName('IsStructureChanged') IsStructureChanged: boolean;  
    @PropertyName('IsSystemTemplate') IsSystemTemplate: boolean;  
    @PropertyName('LastUpdatedBy') LastUpdatedBy: string;  
    @PropertyName('LastUpdatedOn') LastUpdatedOn: string;  
    @PropertyName('TemplateId') TemplateId: string;  
    @PropertyName('TemplateType') TemplateType: string;  
    @PropertyName('Type') Type: string;  
}

export class ContactsEntityModel {

    @PropertyName('ContactEntityId') Description: string;      
    @PropertyName('ContactEntityName') EntityId: string;  
    @PropertyName('Description') EntitySubType: string;  
    @PropertyName('IsTemplateExist') EntityType: boolean;  
    @PropertyName('IsDefault') IsDefault: boolean;  
    @PropertyName('LastUpdatedOn') LastUpdatedOn: string;  
    @PropertyName('TemplateId') IsStructureChanged: string;  
}

export class JobsEntityModel {

    @PropertyName('JobTypeId') JobTypeId: string;      
    @PropertyName('TemplateId') TemplateId: string;  
    @PropertyName('IsDefault') IsDefault: boolean;  
    @PropertyName('Type') Type: string; 
    @PropertyName('Description') Description: string;  
    @PropertyName('LastUpdatedOn') LastUpdatedOn: string;  
    @PropertyName('IsTemplateExist') EntityType: boolean;  
    @PropertyName('IsActive') IsActive: boolean; 
}