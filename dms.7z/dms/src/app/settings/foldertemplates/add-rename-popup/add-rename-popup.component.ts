import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormControl, Validators, AbstractControl } from '@angular/forms';
import { ResourceService, ModalPopupConfig, ModalPopupInstance } from '@ifirm';
import { ToasterService } from 'projects/ifirm-common-components/src/lib/toaster//toaster.service';
import { FolderTemplatesService } from '../services/foldertemplates.service';
import { ValidatorService } from '../../../validation/validator.service';
import { entityType } from '../../../constants/app-constants';

@Component({
  selector: 'app-add-rename-popup',
  templateUrl: './add-rename-popup.component.html',
  styleUrls: ['./add-rename-popup.component.scss']
})
export class AddRenamePopupComponent implements OnInit {

  addRenameForm: FormGroup;
  entityInfo: string = null;
  loader: boolean = false;
  inputLabel: string = null;
  nodeValues: any;
  templateId: string = null;
  entityType: any = null;

  constructor(private config: ModalPopupConfig<any>, private instance: ModalPopupInstance, private folderTemplatesService: FolderTemplatesService,
    private toasterService: ToasterService, private resourceService: ResourceService, private validatorService: ValidatorService) {
    this.entityInfo = config.data[0];
    this.nodeValues = config.data[1];
    this.templateId = config.data[2];
    this.entityType = config.data[3];
  }

  ngOnInit(): void {
    this.createForm();
    if (this.entityInfo == 'add') {
      this.inputLabel = 'dms.common.foldername';
    }
    else {
      this.inputLabel = 'dms.newname';
      this.addRenameForm.patchValue({ folderName: this.nodeValues.item });
    }
  }

  private createForm() {
    this.addRenameForm = new FormGroup({
      folderName: new FormControl("", [Validators.required, this.validatorService.noWhitespaceValidator])
    });
  }

  addRenameFolder(): void {
    if (this.addRenameForm.status === 'VALID' && this.entityInfo == 'add') {
      this.loader = true;
      let payload = {
        EntityType: this.nodeValues == undefined ? this.entityType : this.nodeValues.EntityType,
        TemplateId: this.nodeValues == undefined ? this.templateId : this.nodeValues.TemplateId,
        ParentFolderId: this.nodeValues == undefined ? entityType.Contact : this.nodeValues.DefaultFolderId,
        DefaultFolderHierarchy: this.nodeValues == undefined ? null : this.nodeValues.DefaultFolderHierarchy,
        TemplateType: this.nodeValues == undefined ? 1 : this.nodeValues.TemplateType,
        FolderName: this.getFolderNameFormControl.value.trim()
      }
      if (this.nodeValues == undefined && this.entityType == entityType.Job) {
        payload['ParentFolderId'] = null;
        delete payload['TemplateType'];
      }
      this.addFolder(payload);
    }
    else if (this.addRenameForm.status === 'VALID' && this.entityInfo == 'rename') {
      this.loader = true;
      const payloadrename = {
        DefaultFolderId: this.nodeValues.DefaultFolderId,
        EntityType: this.nodeValues.EntityType,
        ParentFolderId: this.nodeValues.ParentFolderId,
        Kind: this.nodeValues.TemplateType,
        OldName: this.nodeValues.item,
        Name: this.nodeValues.item,
        Hierarchy: this.nodeValues.DefaultFolderHierarchy,
        TemplateId: this.nodeValues.TemplateId,
        NewName: this.getFolderNameFormControl.value.trim()
      }
      this.renameFolder(payloadrename);
    }
  }

  closePopup(result: boolean): void {
    this.instance.close(result);
  }

  get getFolderNameFormControl() { 
    return this.addRenameForm.get('folderName'); 
  }

  private addFolder(payload): void {
    this.folderTemplatesService.addDefaultfolder(payload).then(res => {
      this.loader = false;
      if (res.success == true) {
        this.closePopup(true);
      }
      else {
        this.toasterService.error(this.resourceService.getText('dms.common.errormessage'));
      }
    }).catch(
      exception => {
        this.loader = false;
        this.toasterService.error(this.resourceService.getText('dms.common.errormessage'));
        console.log(exception);
      });

  }

  private renameFolder(payload): void {
    this.folderTemplatesService.renameDefaultfolder(payload).then(res => {
      this.loader = false;
      if (res.success == true) {
        this.closePopup(true);
      }
      else {
        this.toasterService.error(this.resourceService.getText('dms.common.errormessage'));
      }
    }).catch(
      exception => {
        this.loader = false;
        this.toasterService.error(this.resourceService.getText('dms.common.errormessage'));
        console.log(exception);
      });

  }

}
