import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddRenamePopupComponent } from './add-rename-popup.component';

describe('AddRenamePopupComponent', () => {
  let component: AddRenamePopupComponent;
  let fixture: ComponentFixture<AddRenamePopupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddRenamePopupComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddRenamePopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
