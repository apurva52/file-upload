import { Injectable } from '@angular/core';
import { ApiService} from '@ifirm';
import { Firmdocument } from "./firmdocument.model";

@Injectable({
  providedIn: 'root'
})
export class FirmdocumentService {

  constructor(private api: ApiService) { }

  public getFirmDocumentsSettings(): Promise<any> {
    const url = '/dms/api/settings/getfirmdocumentssettings';
    return this.api.get<Firmdocument>(url, Firmdocument).toPromise();
  }

  public updateFirmDocumentsSettings(settings : Firmdocument) : Promise<any> {
    const url = '/dms/api/settings/updateFirmDocumentsSettings';
    return  this.api.post<any>(url, null, settings).toPromise();
  }
}
