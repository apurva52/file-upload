import { PropertyName } from '@ifirm';

export class Firmdocument {

    @PropertyName("SettingId")
    settingId : number;

    @PropertyName("EnableUnlimitedVersionRetention")
    enableUnlimitedVersionRetention : boolean;

    @PropertyName("VersionLimitCount")
    versionLimitCount : boolean;

    @PropertyName("EnableUserFolders")
    enableUserFolders : boolean;

    @PropertyName("EnableHRFolders")
    enableHRFolders : boolean;

    @PropertyName("IsInternalDocumentsPermanent")
    isInternalDocumentsPermanent : boolean;

    @PropertyName("IsHrDocumentsPermanent")
    isHrDocumentsPermanent : boolean;

    @PropertyName("IsUserDocumentsPermanent")
    isUserDocumentsPermanent : boolean;
}
