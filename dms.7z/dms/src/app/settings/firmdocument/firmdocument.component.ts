import { Component, OnDestroy, OnInit } from '@angular/core';
import { FirmdocumentService } from './firmdocument.service';
import { Firmdocument } from './firmdocument.model';
import { ConfirmationBoxType, ModalPopupConfig, ModalPopupService, ConfirmationBoxComponent, ResourceService } from '@ifirm';
import { ToasterService } from 'projects/ifirm-common-components/src/lib/toaster//toaster.service';
import { Subscription } from 'rxjs';
import { DmsService } from '../../dms.service';

@Component({
  selector: 'app-firmdocument',
  templateUrl: './firmdocument.component.html',
  styleUrls: ['./firmdocument.component.scss']
})
export class FirmdocumentComponent implements OnInit, OnDestroy {
  resourceChangedSubscription: Subscription;
  rData: boolean = false;
  infoTitle: string = "";
  setting: Firmdocument = new Firmdocument();
  oldSetting: Firmdocument = new Firmdocument();
  isUserHaveViewRole: boolean = false;

  constructor(private fdService: FirmdocumentService,
    private resourceService: ResourceService, private popupService: ModalPopupService, private toasterService: ToasterService, private dmsService: DmsService) {
  }

  ngOnInit(): void {
    this.dmsService.getDmsRoles().then(x => {
      if (x != null && x.DmsSettingsDocuments) {
        this.isUserHaveViewRole = true;
        this.getFirmDocumentsSettings();
        this.infoTitle = this.resourceService.getText('dms.settings.permanenttagtooltip');
        this.dmsService.setBreadCrumbAndTitle(this.resourceService.get('dms.settings.firmdocuments'));
        this.resourceChangedSubscription = this.resourceService.resourcesChanged.subscribe(a => {
          this.dmsService.setBreadCrumbAndTitle(this.resourceService.get('dms.settings.firmdocuments'));
        });
      }
      else {
        this.dmsService.showAccessDeniedMessage();
      }
    })
      .catch(
        exception => {
          this.toasterService.error(this.resourceService.getText('dms.settings.anerroroccurred'));
        });
  }

  ngOnDestroy() {
    if (this.resourceChangedSubscription) {
      this.resourceChangedSubscription.unsubscribe()
    }
  }

  cancelSettings() {
    window.location.hash = '/dms/settings/main';
  }

  saveFirmDocumentsSettings() {
    let confirmMessage: string = "";
    if ((!this.setting.enableHRFolders && (this.oldSetting.enableHRFolders && !this.setting.enableHRFolders)) && (!this.setting.enableUserFolders && (this.oldSetting.enableUserFolders && !this.setting.enableUserFolders))) {
      confirmMessage = this.resourceService.getText('dms.settings.firmdocuments.warningmsgforhr');
    }
    else if (!this.setting.enableHRFolders && (this.oldSetting.enableHRFolders && !this.setting.enableHRFolders)) {
      confirmMessage = this.resourceService.getText('dms.settings.firmdocuments.warningmsgforhr');
    }
    else if (!this.setting.enableUserFolders && (this.oldSetting.enableUserFolders && !this.setting.enableUserFolders)) {
      confirmMessage = this.resourceService.getText('dms.settings.firmdocuments.warningmsgforuser');
    }

    if (confirmMessage != "") {
      const config: ModalPopupConfig<any> = new ModalPopupConfig<any>();
      config.data = { message: confirmMessage, type: ConfirmationBoxType.OkCancel };
      let instance = this.popupService.open<ConfirmationBoxComponent>(this.resourceService.getText('dms.settings.firmdocuments.warning'), ConfirmationBoxComponent, config);
      const subscription = instance.afterClosed.subscribe(x => {
        if (subscription) {
          subscription.unsubscribe();
        }
        if (x.result) {
          this.saveSettings();
        }
      });
    }
    else {
      this.saveSettings();
    }
  }

  private saveSettings() {
    this.rData = true;
    this.fdService.updateFirmDocumentsSettings(this.setting).then(x => {
      this.rData = false;
      if (x.success == true) {
        this.toasterService.success(this.resourceService.getText('ifirm.common.settingssaved'));
      }
      else {
        this.toasterService.error(this.resourceService.getText('dms.settings.errorsavesetting'));
      }
    });
  }

  private getFirmDocumentsSettings(): void {
    this.rData = true;
    this.fdService.getFirmDocumentsSettings()
      .then(x => {
        this.setting = x;
        this.rData = false;
        this.oldSetting = JSON.parse(JSON.stringify(this.setting));
      })
      .catch(
        exception => {
          this.rData = false;
          this.toasterService.error(this.resourceService.getText('dms.settings.errorviewsetting'));
        });
  }
}
