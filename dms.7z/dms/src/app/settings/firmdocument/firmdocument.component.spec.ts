import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { FirmdocumentComponent } from './firmdocument.component';

describe('FirmdocumentComponent', () => {
  let component: FirmdocumentComponent;
  let fixture: ComponentFixture<FirmdocumentComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ FirmdocumentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FirmdocumentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
