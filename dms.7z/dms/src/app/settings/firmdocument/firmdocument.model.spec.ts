import { Firmdocument.Model } from './firmdocument.model';

describe('Firmdocument.Model', () => {
  it('should create an instance', () => {
    expect(new Firmdocument.Model()).toBeTruthy();
  });
});
