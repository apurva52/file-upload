import { TestBed } from '@angular/core/testing';

import { FirmdocumentService } from './firmdocument.service';

describe('FirmdocumentService', () => {
  let service: FirmdocumentService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FirmdocumentService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
