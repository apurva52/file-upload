import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { APP_COMPONENTS, APP_ROUTES } from './constants/app-components';
import { ComponentRouteService, IFirmButtonModule, IFirmDatePickerModule, JobLookupModule, JobAutoCompleteModule, ClientLookupModule, ClientAutoCompleteModule,IFirmTabModule,IFirmDataTableModule } from '@ifirm';
import { PreloadAllModules, RouterModule } from '@angular/router';
import { APP_MODULES} from './constants/app-modules';
import { NumbersOnlyDirective } from './constants/numbers-only.directive';
import { UserpreferencesComponent } from './settings/userpreferences/userpreferences.component';
import { AddFolderComponent } from './dialogs/add-folder/add-Folder.component';
import { FileNotesComponent } from './dialogs/file-notes/file-notes.component';
import { RemoveUnsupportedCharactersDirective } from './directive/remove-unsupported-characters.directive';
import { RenameDocumentComponent } from './dialogs/rename-document/rename-document.component';
import { FileNoteItemComponent } from './dialogs/file-notes/file-note-item/file-note-item.component';
import { EmailPreviewComponent } from './dialogs/email-preview/email-preview.component';
import { FileVersionComponent } from './dialogs/file-version/file-version.component';
import { OpenDocumentComponent } from './dialogs/open-document/open-document.component';
import { FileversionspaceComponent } from './dialogs/file-versionspace/file-versionspace.component';
import { FolderSelectionComponent } from './dialogs/folder-selection/folder-selection.component';
import {CdkTreeModule} from '@angular/cdk/tree';
import { WebviewerComponent } from './pdf/webviewer/webviewer.component';
import { ViewComponent } from './pdf/view.component';
import { FileSaveComponent } from './dialogs/file-save/file-save.component';
import {UploadDocumentComponent} from './dialogs/upload-documents/upload-documents.component';
import {FilePropertyComponent} from './dialogs/file-property/file-property.component';
import { OpenDocumentViewComponent } from './onedrive/open-document-view/open-document-view.component';
import { InsertLinkComponent } from './dialogs/insert-link/insert-link.component';
import { NgSelectModule } from '@ng-select/ng-select';
import { CommonModule } from '@angular/common';
import { DocumentsComponent } from './documents/documents.component';
import { FirmModule } from "./module/firm/firm.module";
import { ImportsModule } from "./module/imports/imports.module";
import { RecyclebinModule } from "./module/recyclebin/recyclebin.module";
import { SpaceUsageModule } from "./module/space-usage/space-usage.module";
import { ClientModule } from "./module/client/client.module";
import { MatTreeModule } from "@angular/material/tree";
import { NgxFileDropModule } from 'ngx-file-drop';
import { FileCopyComponent } from './dialogs/file-copy/file-copy.component';
import { ConversationsModule } from "./module/conversations/conversations.module";

import { IfirmGridDropdownModule } from '../../../ifirm-common-components/src/lib/ifirm-dropdown-checkbox/ifirm-grid-dropdown.module';


@NgModule({
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
    declarations: [APP_COMPONENTS, NumbersOnlyDirective,FileCopyComponent,FilePropertyComponent,UploadDocumentComponent,UserpreferencesComponent, AddFolderComponent, FileNotesComponent, RemoveUnsupportedCharactersDirective, FileNoteItemComponent, RenameDocumentComponent, EmailPreviewComponent, FileVersionComponent, OpenDocumentComponent, FileversionspaceComponent, FolderSelectionComponent, WebviewerComponent, ViewComponent, FileSaveComponent, OpenDocumentViewComponent, InsertLinkComponent, DocumentsComponent],
  imports: [
    APP_MODULES,
    RouterModule.forRoot(APP_ROUTES, {preloadingStrategy: PreloadAllModules}),
    IFirmDataTableModule,
    IFirmButtonModule,
    IFirmTabModule,
    IFirmDatePickerModule,
    CdkTreeModule,
    JobAutoCompleteModule,
    ClientLookupModule,
    JobLookupModule,
    ClientAutoCompleteModule,
    CommonModule,
    NgSelectModule,
    FirmModule,
    ImportsModule,
    NgxFileDropModule,
    RecyclebinModule,
    SpaceUsageModule,
    ClientModule,
    MatTreeModule,
    IFirmTabModule,
    IfirmGridDropdownModule,
    ConversationsModule
  ],
  providers: [],
  exports: [ APP_COMPONENTS ]
})
export class DMSModule {
  constructor(private service: ComponentRouteService){
    this.service.registerRoutes(APP_ROUTES);
  }
}
