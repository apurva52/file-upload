import { HttpParams } from '@angular/common/http';
import { EventEmitter, Injectable, Output } from '@angular/core';
import { BreadCrumbModel, BreadCrumbService } from '@ifirm';
import { Title } from '@angular/platform-browser';
import { ApiService } from '@ifirm';
import { DmsRole } from './common/common.module';
import { ResourceService } from '@ifirm';
import { ToasterService } from 'projects/ifirm-common-components/src/lib/toaster//toaster.service';
import { DmsFileModel } from './dialogs/models/dms-fIle.model';
import { BehaviorSubject, Subject } from 'rxjs';
import { Folder } from './shared/tools/breadcrumbs/model/folder.model';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root',
})
export class DmsService {
  public currentBreadcrumbs: string[] = [];
  currentFolder: Folder | any = null;
  currentPage = new Subject<any>();
  currentPageData$ = this.currentPage.asObservable();
  breadCrumb = new Subject<any>();
  breadCrumbData$ = this.breadCrumb.asObservable();
  userInfoMap:Map<string,any> ;
  @Output() public breadCrumbClickedEvent: EventEmitter<any> = new EventEmitter();
  @Output() public clearSearchFilter: EventEmitter<any> = new EventEmitter();
  @Output() public clientDocument: EventEmitter<any> = new EventEmitter();
  payloadForFilter$ = new Subject();
  clientDocList$ = new BehaviorSubject<any>(null);
  

  folders: Folder[] = [

  ];
  initial: { Name: string; EntityId: number; Id: number; Hierarchy: any } = {
    Name: '',
    EntityId: 0,
    Id: 0,
    Hierarchy: null,
  };

  constructor(
    private breadCrumbService: BreadCrumbService,
    private title: Title,
    private api: ApiService,
    private resourceService: ResourceService,
    private toasterService: ToasterService,
    private router: Router
  ) {
    this.resourceService.tabName$.subscribe((value) => {
      this.initial = { Name: value, EntityId: 0, Id: 0, Hierarchy: null };
      this.breadCrumbsubject.next([this.initial]);
    });
    this.userInfoMap = new Map();
  }

  // Breadcrumbs starts

  public breadCrumbsubject = new BehaviorSubject<any[]>([this.initial]);
  breadcrumb$ = this.breadCrumbsubject.asObservable();

  public folderSubject = new BehaviorSubject<any>([this.currentFolder]);
  folder$ = this.folderSubject.asObservable();

  updateBreadcrumbs(breadCrumbs: string[]) {
    this.currentBreadcrumbs = breadCrumbs;
    this.breadCrumbsubject.next(this.currentBreadcrumbs);
  }

  navigateCrumb(index: any) {
    this.currentBreadcrumbs.splice(index + 1);
    this.breadCrumbsubject.next(this.currentBreadcrumbs);
  }

  // breadcrumbs ends

  navigateToparent(crumb, index) {
    if (index == 0) {
      this.currentFolder = null;
      this.folderSubject.next(this.currentFolder);
    } else {
      let foundFolder = this.folders.find((folder) => folder.name == crumb);
      this.currentFolder = foundFolder;
      console.log('after parent nav' + foundFolder);

      this.folderSubject.next(this.currentFolder);
    }
  }

  navigateToSubfolder(folder: Folder) {
    this.currentFolder = folder;
    this.folderSubject.next(this.currentFolder);
  }

  setBreadCrumbAndTitle(title: any) {
    const breadCrumb = new BreadCrumbModel();
    if (typeof title === 'string') {
      this.setTitle(title);
      breadCrumb.heading = `${title}`;
      this.breadCrumbService.setBreadCrumb(breadCrumb);
    } else {
      title.then((resultText) => {
        this.setTitle(resultText);
        breadCrumb.heading = `${resultText}`;
        this.breadCrumbService.setBreadCrumb(breadCrumb);
      });
    }
  }

  navigateToPage(event) {
    this.currentPage.next(event);
  }
  getDmsRoles() {
    const url = '/dms/api/settings/getdmsroles';
    return this.api.get<DmsRole>(url).toPromise();
  }

  showAccessDeniedMessage() {
    const accessdenied = this.resourceService.get('ifirm.common.accessdenied');
    if (accessdenied instanceof Promise) {
      (accessdenied as Promise<string>).then((text) => {
        this.toasterService.error(text);
      });
    } else {
      this.toasterService.error(accessdenied);
    }
  }

  private setTitle(newTitle: string) {
    const title = 'iFirm | ' + newTitle;
    this.title.setTitle(title);
  }

  downloademailFile(dmsFileModel: DmsFileModel) {
    const downloadObject = (({
      FolderId,
      Hierarchy,
      Id,
      FileGuid,
      FileName,
      FileType,
      StoragePath,
      EntityType,
      EntityId,
    }) => ({
      FolderId,
      Hierarchy,
      Id,
      FileGuid,
      FileName,
      FileType,
      StoragePath,
      EntityType,
      EntityId,
    }))(dmsFileModel);
    var downloadContractBtoa = encodeURIComponent(
      btoa(unescape(encodeURIComponent(JSON.stringify(downloadObject))))
    );
    var target = '_parent';
    var form = document.createElement('form');
    form.setAttribute('method', 'POST');
    form.setAttribute('action', '/dms/api/Export/DownloadFile/');
    form.setAttribute('target', target);

    var inputdownloadContractBtoa = document.createElement('input');
    inputdownloadContractBtoa.type = 'hidden';
    inputdownloadContractBtoa.name = 'downloadContractBtoa';
    inputdownloadContractBtoa.value = downloadContractBtoa;
    form.appendChild(inputdownloadContractBtoa);
    document.body.appendChild(form);
    form.target = target;
    form.submit();
    document.body.removeChild(form);
  }

  getParamValueQueryString(paramName: string) {
    const url = window.location.href;
    let paramValue;
    if (url.includes('?')) {
      const httpParams = new HttpParams({ fromString: url.split('?')[1] });
      paramValue = httpParams.get(paramName);
    }
    return paramValue;
  }

  public getNewUserInfo():Promise<any>{
    return this.api.get<any>("/dms/api/user/getuserinfo").toPromise();
  }
  shareBreadCrumb(event) {
    this.breadCrumb.next(event);
  }

  getClientDocList$() {
    return this.clientDocList$.asObservable();
  }

  navigateToHome(){
    if (this.userInfoMap.get('userInfoValue') == undefined) {
      this.router.navigate(['/dms/home/main']).then(() => {
       window.location.reload();
      });
    }
  }
}
