import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { APP_MODULES} from '../../constants/app-modules';
import { ConversationsRoutingModule } from './conversations-routing.module';
import { BreadcrumbsComponent } from '../../shared/tools/breadcrumbs/breadcrumbs.component';
import { SearchBarComponent } from '../../shared/tools/search-bar/search-bar.component';
import { IFirmButtonModule } from '@ifirm';
import { ConversationsComponent } from './conversations/conversations.component';
import { FilterComponentsComponent } from '../../filter-components/filter-components.component';
import { ConversationsGridComponent } from './conversations/components/conversations-grid/conversations-grid.component';
import { ConversationsSearchBarComponent } from './conversations/components/conversations-searchbar/conversations-searchbar.component';
import { ConversationGroupListComponent } from './conversations/components/conversation-group-list/conversation-group-list.component';
import { DirectivesModule } from '../../shared/directives/directives.module';
import { NgSelectModule } from '@ng-select/ng-select';


@NgModule({
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  declarations: [
    ConversationsComponent,
    ConversationsGridComponent,
    ConversationsSearchBarComponent,
    ConversationGroupListComponent
  ],
  imports: [
    CommonModule,
    APP_MODULES,
    ConversationsRoutingModule,
    // LocalizationModule,
    FilterComponentsComponent,
    BreadcrumbsComponent,
    SearchBarComponent,
    DirectivesModule,
    IFirmButtonModule,
    NgSelectModule,
    
  ]
})
export class ConversationsModule { }
