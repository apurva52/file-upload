import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchButtonActionComponent } from './search-button-action.component';

describe('SearchButtonActionComponent', () => {
  let component: SearchButtonActionComponent;
  let fixture: ComponentFixture<SearchButtonActionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SearchButtonActionComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SearchButtonActionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
