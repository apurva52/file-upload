import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import {  ResourceService,  ModalPopupConfig, ModalPopupService, ConfirmationBoxType, ConfirmationBoxComponent, ToasterService } from '@ifirm';
import { antivirusScanStatus, entityType, eventType, fileKind } from 'projects/dms/src/app/constants/app-constants';
import { FirmDocumentsService } from '../../../../firm/firm-documents/services/firm-documents.service';
import { GridServiceService } from 'projects/dms/src/app/shared/tools/service/grid-service.service';
import { ConfirmationBoxInputModel } from 'projects/apm/src/app/timesheet/model/timesheet-common.model';
import { ConversationsService } from '../../services/conversations.service';
import { DmsDialogApiService } from '../../../../../dialogs/dms-dialog-api.service';
import { EmailPreviewComponent } from 'projects/dms/src/app/dialogs/email-preview/email-preview.component';

@Component({
  selector: 'conversation-group-list',
  templateUrl: './conversation-group-list.component.html',
  styleUrls: ['./conversation-group-list.component.scss']
})
export class ConversationGroupListComponent implements OnInit { 
  conversationsResponse: any;
  conversationLoader: any;
  conversationsPayload: any;
  conversationsPaginationResponse: any;  
  noRecordsError: any;
  @Input() singleConversation: any;
  @Input() conversationList: any;
  @Input() index: any;

  constructor( private resourceService: ResourceService,
    private popupService: ModalPopupService, private conversationsService: ConversationsService,
    public gridService: GridServiceService, private toasterService: ToasterService, private dmsDialogApiService: DmsDialogApiService) { 
      this.conversationLoader = this.conversationsService.getLoaderSubject();
      this.conversationsResponse = this.conversationsService.getConversationsList$();
      this.conversationsPaginationResponse = this.conversationsService.getConversationsPaginationSubject();
      this.noRecordsError = this.conversationsService.getNoRecordsSubject();
    }

  ngOnInit(): void {
    const payload: any = this.conversationsService.getPayload$();
    this.conversationsPayload = payload.source.value;
  }

  onEmailLocationMouseOver(conversation, event){
    this.conversationsService.getEmailLocationInfo(conversation.EmailMetadataId, this.conversationsPayload.EntityId, this.conversationsPayload.EntityType).then((response) => {
      if (response) {
        response.forEach(location =>{
          location.Infoby = this.resourceService.getText('dms.conversation.infoby') + " " + location?.ActionByUseName;
        });
        conversation.EmailLocations = response;
      };
    })
  }

  onConversationClick(conversation){
    this.conversationsService.getDocumentById(conversation.FileId).subscribe({
      next: (result) => {
       if (result && result.success) {
         if (result.data?.AVScanStatus === antivirusScanStatus.Queued || result.data?.AVScanStatus === antivirusScanStatus.NotStarted || result.data?.AVScanStatus === antivirusScanStatus.Error) {              
           const confirmInstance = this.popupService.confirm(this.resourceService.getText('dms.downloadwarning'), this.resourceService.getText('dms.common.filenotscanned'));
           const subscription = confirmInstance.afterClosed.subscribe(a => {
           subscription.unsubscribe();
           if (a && a.result == true) {
              this.openPreview(result);
           }
           });
         }
         else if (result.data?.AVScanStatus === antivirusScanStatus.Fail || result.data?.AVScanStatus === antivirusScanStatus.InvalidExtension) {
             this.showConfirmDeleteDialog(result.data);
         }
         else {
             this.openPreview(result);
         }
       }
       else {
           this.toasterService.error(result.message);
       }
      },
      error: (e) => {
       this.toasterService.error(this.resourceService.getText('ifirm.common.error'));
      }
     });
  }

  threadClass(singleConversation,conversationList, index){
    const isFilterApplied = this.conversationsPayload.IsFiltering;
    let isSerching = (this.conversationsPayload.SearchText &&
      this.conversationsPayload.SearchText.length > 0) ? true : false;
    // if (singleConversation.Selected == 1) {
    //   return "dms-conversation-parent-selected";
    // } else {
    //   if (isFilterApplied || isSerching) {
    //       return "dms-conversation-parent-transparent";
    //   }
    //   else {
    //       return "dms-conversation-parent";
    //   }
    //   }
        if (index > 0) {
          if (conversationList[index - 1].ParentInternetMessageId == singleConversation.ParentInternetMessageId || conversationList[index - 1].ConversationId == singleConversation.ConversationId) {
              if (singleConversation.Selected == 1) {
                index++;
                  if (conversationList[index - 1].Selected == 1) {
                      return "dms-conversation-child-selectedWithPrevious";
                  } else {
                      return "dms-conversation-child-selected";
                  }
              } else {
                  if (isFilterApplied || isSerching) {
                      return "dms-conversation-child-transparent";
                  }
                  else {
                      return "dms-conversation-child";
                  }
              }
          }

          if (conversationList[index - 1].ParentInternetMessageId != singleConversation.ParentInternetMessageId) {
              if (singleConversation.Selected == 1) {
                  return "dms-conversation-parent-selected";
              } else {
                  if (isFilterApplied || isSerching) {
                      return "dms-conversation-parent-transparent";
                  }
                  else {
                      return "dms-conversation-parent";
                  }
              }
          }

      }
      else {
          if (singleConversation.Selected == 1) {
              return "dms-conversation-parent-selected";
          } else {
              if (isFilterApplied) {
                  return "dms-conversation-parent-transparent";
              }
              else {
                  return "dms-conversation-parent";
              }
          }
          
      }
  }


  openPreview(file){  
    const data = {
        file: file.data,
        folderId: ''
    };
    let instance = this.popupService.open<EmailPreviewComponent>(this.resourceService.getText('dms.emailpreview.title'), EmailPreviewComponent, {data: data});
    const sub = instance.afterClosed.subscribe(response => {
      if (response) {
      }
    });     
  }

  showConfirmDeleteDialog(data){
    const message = (data.AVScanStatus === antivirusScanStatus.Fail) ? this.resourceService.getText('dms.common.filequarantined') : this.resourceService.getText('dms.common.fileinvalidextention');
    const config: ModalPopupConfig<ConfirmationBoxInputModel> = new ModalPopupConfig<ConfirmationBoxInputModel>();
    let model = new ConfirmationBoxInputModel();
    model.message = message;
    model.type = ConfirmationBoxType.YesNo;
    config.data = model;
    let instance = this.popupService.open<ConfirmationBoxComponent>(this.resourceService.getText('dms.delete.permanenttitle'), ConfirmationBoxComponent, config);
    const subscription = instance.afterClosed.subscribe(x => {
      if (subscription) {
        subscription.unsubscribe();
      }
      if (x && x.result) {
        const deleteContract = {
          FileGuid: data.Guid,
          EntityType: data.EntityType,
          EntityId: data.EntityId
      };
      this.dmsDialogApiService.DeleteDocumentspermanently(deleteContract).then((res)=>{
        if (res.success === true) {
          this.conversationsService.setLoaderSubject(true);
          this.conversationsService.showGridList = false;  
          this.conversationsService.loadEmailConversations(this.conversationsPayload);  
      }
      else{
        this.popupService.info(this.resourceService.get('ifirm.common.error') as string, this.resourceService.get('dms.delete.errormessage') as string);
      }
    })
  }
  });
  }

}
