import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import {  ResourceService,  ModalPopupConfig, ModalPopupService, ConfirmationBoxType, ConfirmationBoxComponent, ToasterService } from '@ifirm';
import { entityType, eventType, fileKind } from 'projects/dms/src/app/constants/app-constants';
import { FirmDocumentsService } from '../../../../firm/firm-documents/services/firm-documents.service';
import { GridServiceService } from 'projects/dms/src/app/shared/tools/service/grid-service.service';
import { ConfirmationBoxInputModel } from 'projects/apm/src/app/timesheet/model/timesheet-common.model';
import { ConversationsService } from '../../services/conversations.service';

@Component({
  selector: 'app-conversations-grid',
  templateUrl: './conversations-grid.component.html',
  styleUrls: ['./conversations-grid.component.scss']
})
export class ConversationsGridComponent implements OnInit { 
  conversationsResponse: any;
  conversationLoader: any;
  conversationsPayload: any;
  conversationsPaginationResponse: any;  
  noRecordsError: any;
  showNoRecordsFoundMessage:boolean = false;
  showNoRecordsFoundWithoutFilterMessage:boolean = false;
  showErrorMessage:boolean = false;
  hasMoreRecords:boolean = false; 
  conversationList: any;
  thisWeekConversationList: any;
  thisMonthConversationList: any;
  thisYearConversationList: any;
  olderConversationList: any;
  pageSize: any;
  ind: any;

  constructor( private resourceService: ResourceService,
    private popupService: ModalPopupService, private conversationsService: ConversationsService,
    public gridService: GridServiceService, private toasterService: ToasterService) { 
      this.conversationLoader = this.conversationsService.getLoaderSubject();      
      this.conversationsResponse = this.conversationsService.getConversationsList$();
      this.conversationsPaginationResponse = this.conversationsService.getConversationsPaginationSubject();
      this.pageSize = this.conversationsService.getConversationPageSizeSubject();
      this.noRecordsError = this.conversationsService.getNoRecordsSubject();
    }

  ngOnInit(): void {
    const payload: any = this.conversationsService.getPayload$();
    this.conversationsPayload = payload.source.value;
    this.gridService.applyUserRoles();
    this.conversationList = this.conversationsResponse.source.value;
    this.displayList();
  }

  
  displayList(){
    let thisWeek = this.conversationList.filter((singleConversation) => {
        return singleConversation.IsCurrentWeek == 1 && singleConversation.IsCurrentYear == 1;
    });
    this.thisWeekConversationList = thisWeek;

    let thisMonth = this.conversationList.filter((singleConversation) => {
        return singleConversation.IsCurrentWeek == 0 && singleConversation.IsCurrentMonth == 1 && singleConversation.IsCurrentYear == 1;
    });
    this.thisMonthConversationList = thisMonth;

    let thisYear = this.conversationList.filter((singleConversation) => {
        return singleConversation.IsCurrentWeek == 0 && singleConversation.IsCurrentMonth == 0 && singleConversation.IsCurrentYear == 1;
    });
    this.thisYearConversationList = thisYear;

    let older = this.conversationList.filter((singleConversation) => {
        return singleConversation.IsCurrentYear == 0;
    });
    this.olderConversationList = older;
    
  }

  ngAfterViewInit(){
    this.conversationsService.scrollTop();
  }


   onConversationGridScroll() {
    if (this.conversationsPaginationResponse.source.value) {
      const scrollContainer = document.querySelector('#dmsConversationListTable');
      this.conversationsService.scrolledAxis = scrollContainer.scrollTop;
      this.conversationsPayload.Page = this.pageSize.source.value + this.conversationsPayload.Page;
      this.conversationsService.setPayload$(this.conversationsPayload);
      this.conversationsService.showGridList = false;
      this.conversationsService.loadEmailConversations(this.conversationsPayload, this.conversationsPaginationResponse.source.value);

    }
  }


  rowClick(file) {    
    if (file.Kind === fileKind.Folder) {
      const data = {
        Name: file.Name,
        EntityId: file.EntityId,
        Id: file.Id,
        Hierarchy: file.Hierarchy,
        EntityType: file.EntityType
      }
    }
    else{
     this.gridService.getGridFile(file, 'firmDoc');
    }
      
  }

  fileNameMouseOver(file) {
    this.gridService.fileNameHierarchy(file);
  }
  

}
