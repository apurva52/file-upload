import { Component, OnDestroy, OnInit } from '@angular/core';
import { ResourceService } from '@ifirm';
import { ConversationsService } from '../../services/conversations.service';

@Component({
  selector: 'app-conversations-searchbar',
  templateUrl: './conversations-searchbar.component.html',
  styleUrls: ['./conversations-searchbar.component.scss'],
})
export class ConversationsSearchBarComponent implements OnInit, OnDestroy {
  constructor(
    private resourceService: ResourceService,
    public conversationsService: ConversationsService
  ) {
    this.conversationLoader = this.conversationsService.getLoaderSubject();
    this.conversationsResponse = this.conversationsService.getConversationsList$();
  } 

  placeHoldervalue = this.resourceService.getText('dms.conversation.searchtextplaceholder');
  searchtext: any;
  loader:boolean = false;  
  conversationsResponse: any;
  conversationLoader: any;
  conversationsPayload: any;
  ngOnInit(): void {
    const payload: any = this.conversationsService.getPayload$();
    this.conversationsPayload = payload.source.value;
  }

  searchDocuments(){
      this.conversationsService.setLoaderSubject(true);
      this.conversationsService.showGridList = false;
      this.conversationsPayload.SearchText = this.searchtext;
      this.conversationsPayload.Page = 0;
      this.conversationsService.scrolledAxis = 0;
      this.conversationsService.setPayload$(this.conversationsPayload);    
      this.conversationsService.loadEmailConversations(this.conversationsPayload);    
  }

  clearSearch(){
    this.conversationsService.showGridList = false;
    this.conversationsService.setLoaderSubject(true);
    this.searchtext = '';
    this.conversationsPayload.SearchText = "";
    this.conversationsPayload.Page = 0;
    this.conversationsService.setPayload$(this.conversationsPayload);    
    this.conversationsService.loadEmailConversations(this.conversationsPayload);
    this.conversationsService.scrollTop();
  }

  ngOnDestroy(): void {
  }


}
