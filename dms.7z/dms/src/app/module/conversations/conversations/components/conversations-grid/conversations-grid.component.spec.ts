import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FirmDocumentRootCheckboxGridComponent } from './firm-document-root-checkbox-grid.component';

describe('FirmDocumentRootCheckboxGridComponent', () => {
  let component: FirmDocumentRootCheckboxGridComponent;
  let fixture: ComponentFixture<FirmDocumentRootCheckboxGridComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FirmDocumentRootCheckboxGridComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FirmDocumentRootCheckboxGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
