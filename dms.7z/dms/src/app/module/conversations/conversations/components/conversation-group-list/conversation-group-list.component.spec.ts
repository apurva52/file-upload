import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConversationGroupListComponent } from './conversation-group-list.component';

describe('ConversationGroupListComponent', () => {
  let component: ConversationGroupListComponent;
  let fixture: ComponentFixture<ConversationGroupListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConversationGroupListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ConversationGroupListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
