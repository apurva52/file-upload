import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { GlobalScopeService, ModalPopupService, ResourceService } from '@ifirm';
import { DmsService } from '../../../dms.service';
import { ConversationsService } from './services/conversations.service';

@Component({
  selector: 'app-conversations',
  templateUrl: './conversations.component.html',
  styleUrls: ['./conversations.component.scss']
})
export class ConversationsComponent implements OnInit, OnDestroy {

  dmsFilterToggle: boolean = false;
  callFromParent: boolean = false;
  resourceLoadCheck = false;
  userRole;
  permantUserId = null;
  conversationsPayload: any;
  conversationLoader: any;

  constructor(private popupService: ModalPopupService, private resourceService: ResourceService, private dmsServices: DmsService,
    public conversationsService: ConversationsService,private router: Router, private globalScopeService:GlobalScopeService) {
      this.conversationLoader = this.conversationsService.getLoaderSubject();
   }

  ngOnDestroy(): void {
   this.conversationsService.showGridList = false;
   this.conversationsService.scrolledAxis = 0;
  }
 
  ngOnInit(): void { 
    const data = this.globalScopeService.getDMSConversationData();
    this.conversationsService.setLoaderSubject(true);
    const payload: any = this.conversationsService.getPayload$();
    this.conversationsPayload = payload.source.value
    this.conversationsPayload.EntityType = data.EntityType;
    this.conversationsPayload.EntityId = data.EntityId;
    this.conversationsPayload.Page = 0;
    this.conversationsService.setPayload$(this.conversationsPayload);
    this.conversationsService.loadEmailConversations(this.conversationsPayload);
  }


  dmsFilterPaneHideShow(){
    return this.dmsFilterToggle ? "hideFilter" : "showFilter";
  }

  dmsFilterToggleButtonSlide(){
    return this.dmsFilterToggle ? "filterToggleButton filterToggleButtonExpand" : "filterToggleButton filterToggleButtonCollapse";
  }

  dmsFilterToggleDirection(){
    return this.dmsFilterToggle ? "fa fa-angle-double-right rightToggle rightToggleR dmsFilterPointers" : "fa fa-angle-double-left rightToggle rightToggleL dmsFilterPointers";
  }

  toggleDmsFilter(){
    this.dmsFilterToggle = !this.dmsFilterToggle;
  }

  eventFromFilter(event){
    this.callFromParent = true;
    setTimeout(() => {
      this.callFromParent = false;
    }, 100);
    // this.dmsconversationsService.setLoaderSubject(true);
    // const payload: any = this.dmsconversationsService.getPayload$();
    // this.dmsconversationsService.loadFirmDocuments(payload.source.value);
  }
}
