import { Injectable } from '@angular/core';
import { ApiService, ResourceService, ToasterService } from '@ifirm';
import { DmsService } from 'projects/dms/src/app/dms.service';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import {ConversationsCommonRequest} from '../models/conversations.model'
@Injectable({
  providedIn: 'root'
})
export class ConversationsService {
  conversationsPayloadSub  = new BehaviorSubject<ConversationsCommonRequest>(null);
  conversationsDefaultPayload: ConversationsCommonRequest;
  conversationsList$ = new BehaviorSubject<any>(null);
  responseList: any = [];
  userRoles = null;
  loaderSubject = new BehaviorSubject<boolean>(false);
  payloadForFilter$ = new Subject();
  callFromButtons$ = new Subject();
  conversationsPaginationRespone$ = new BehaviorSubject<boolean>(false);
  conversationsPaginationPageSize$ = new BehaviorSubject<any>(null);
  listNoRecords = new BehaviorSubject<boolean>(false);
  showGridList:boolean = false;
  scrolledAxis: number = 0;
    
  conversationsPayload(){
    this.conversationsDefaultPayload = {
      EntityType: null,
      EntityId: null,
      SearchText: "",
      SearchNote: "",
      Page: 0,
      IsFiltering: false,
      IsDeleted: false,
      Filters : {
        SentBy:"",
        SavedBy: "",
        ReceivedDateFrom: "",
        ReceivedDateTo: "",
        SavedDateFrom: "",
        SavedDateTo: "",
        WithAttachment: false,
      }
    }
    return  this.conversationsDefaultPayload;
  }

  constructor(private api: ApiService, private toasterService: ToasterService, private resourceService: ResourceService,
    private dmsServices: DmsService) { 
    this.setPayload$(this.conversationsPayload());
  }
 
  loadEmailConversations(payload, isLoadMore?: boolean) {
    this.searchConversations(payload).then(data => {
    this.setLoaderSubject(false);
    this.responseList = isLoadMore ? this.responseList.concat(data.EmailPreviewResponse) : data.EmailPreviewResponse;   
    this.setConversationsList$(this.responseList);
    this.showGridList = true;
    this.setConversationsPaginationSubject(data.HasMoreRecords);
    this.setConversationPageSizeSubject(data.PageSize);
      if(this.responseList.length === 0){
        this.setNoRecordsSubject(true);
      }
      else{
        this.setNoRecordsSubject(false);
      }
    })
    .catch(
      exception => {
        this.setLoaderSubject(false);
        this.toasterService.error(this.resourceService.getText('ifirm.common.error'));
      });
  }
  
  searchConversations(payload: any): Promise<any> {
    return this.api.post<any>('/dms/api/emailcontact/searchconversation',null, payload).toPromise();
  }

  setPayload$(response: ConversationsCommonRequest) {
    this.conversationsPayloadSub.next(response);
  }

  getPayload$() {
    return this.conversationsPayloadSub.asObservable();
  }

  resetPayload$(){
    this.setPayload$(this.conversationsPayload());
  }

  setConversationsList$(response: any) {
    this.conversationsList$.next(response);
  }

  getConversationsList$() {
    return this.conversationsList$.asObservable();
  }

  setLoaderSubject(val: boolean) {
    this.loaderSubject.next(val);
  }
 
  getLoaderSubject() {
    return this.loaderSubject.asObservable();
  }
  
  public setConversationsPaginationSubject(val: boolean) {
    this.conversationsPaginationRespone$.next(val);
  }

  public getConversationsPaginationSubject() {
    return this.conversationsPaginationRespone$.asObservable();
  }

  public setConversationPageSizeSubject(val: any) {
    this.conversationsPaginationPageSize$.next(val);
  }

  public getConversationPageSizeSubject() {
    return this.conversationsPaginationPageSize$.asObservable();
  }

  public scrollTop(){
    const scrollContainer = document.querySelector('#dmsConversationListTable');
    if (scrollContainer) {
      scrollContainer.scrollTop = this.scrolledAxis;
    }
  }


  isHomePageEnableOnFilter(defaultPayload){
    const payload: any = this.getPayload$();
    const defaultResponse = JSON.stringify(defaultPayload);
    const defaulLatestPayload = JSON.parse(defaultResponse)
    const response = JSON.stringify(payload.source.value);
    const latestPayload = JSON.parse(response)
    const deleteArray = ['UserFolders', 'ShowInActiveUserCheckBox', 'IsInActiveUser', 'IsArchivedContacts'];
    deleteArray.forEach(element => {
      delete defaulLatestPayload?.[element];
      delete latestPayload.Filters?.[element];
    });
    const result = JSON.stringify(defaulLatestPayload) === JSON.stringify(latestPayload.Filters);
    return result;
  }

  isdefaultFilter(defaultPayload){
    const payload: any = this.getPayload$();
    const defaultResponse = JSON.stringify(defaultPayload);
    const defaulLatestPayload = JSON.parse(defaultResponse)
    defaulLatestPayload.IsArchivedContacts = false;
    const response = JSON.stringify(payload.source.value);
    const latestPayload = JSON.parse(response)
    const result = JSON.stringify(defaulLatestPayload) === JSON.stringify(latestPayload.Filters);
    return result;
  }

  public setNoRecordsSubject(val: boolean) {
    this.listNoRecords.next(val);
  }

  public getNoRecordsSubject() {
    return this.listNoRecords.asObservable();
  }

  public getEmailLocationInfo(emailId: any,entityId: any, entityType: any):Promise<any>{
    return this.api.get<any>("/dms/api/emailcontact/GetEmailLocationInfo/?emailMetadataId="+emailId+"&entityId="+entityId+"&entityType="+entityType).toPromise();
  }

  public getDocumentById(fileId: number): Observable<any> {
    return this.api.get<any>('/dms/api/document/GetDocumentById/?fileId=' + fileId);
  }

}
