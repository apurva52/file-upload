// import { PropertyName } from "@ifirm";
import { PropertyName } from "../../../../../../../ifirm-common-components/src/public-api";

export class ConversationsCommonRequest {
    constructor() { }

    @PropertyName('EntityType') EntityType: null | number;
    @PropertyName('EntityId') EntityId: null | number;
    @PropertyName('SearchText') SearchText: string;
    @PropertyName('SearchNote') SearchNote: string;   
    @PropertyName('Page') Page: number;  
    @PropertyName('IsFiltering') IsFiltering: boolean;
    @PropertyName('IsDeleted') IsDeleted: boolean;
    @PropertyName('Filters') Filters: FilterAcceptanceCriteria;
}

export class FilterAcceptanceCriteria {
    constructor() { }
    @PropertyName('SentBy') SentBy: string;
    @PropertyName('SavedBy') SavedBy: string;
    @PropertyName('ReceivedDateFrom') ReceivedDateFrom: string;
    @PropertyName('ReceivedDateTo') ReceivedDateTo: string;
    @PropertyName('SavedDateFrom') SavedDateFrom: string;
    @PropertyName('SavedDateTo') SavedDateTo: string;
    @PropertyName('WithAttachment') WithAttachment: boolean;
}

export class SearchTagCriteria {
    constructor() { }
    @PropertyName('Tags') Tags: any;
    @PropertyName('JobTypeTags') JobTypeTags: any;
    @PropertyName('ContactsTypeTags') ContactsTypeTags: any;
    @PropertyName('PermentContactsTagType') PermentContactsTagType: number;
    @PropertyName('PermentTagType') PermentTagType: number;
    @PropertyName('IsSearchPortalTag') IsSearchPortalTag: boolean;
}

export class FileTypeResponse{
    @PropertyName('Id') Id: string | number;
    @PropertyName('GroupName') GroupName: string;
    @PropertyName('Extension') Extension: string;
    @PropertyName('FileExtensionId') FileExtensionId: string | number;
    @PropertyName('ResourceKey') ResourceKey: string;
}
export class TagsListResponse{
    TagList: TagsResponse[];
}
export class TagsResponse{
    @PropertyName('TagId') TagId: string | number;
    @PropertyName('TagIdForMapping') TagIdForMapping: string;
    @PropertyName('TagNameForDisplay') TagNameForDisplay: string;
    @PropertyName('TagNameLanguage1') TagNameLanguage1: string ;
    @PropertyName('ShowTag') ShowTag: boolean;
    @PropertyName('SortOrder') SortOrder: number;
    @PropertyName('IsSystemTag') IsSystemTag: boolean;
    @PropertyName('CreatedBy') CreatedBy: number;
    @PropertyName('CreatedDateTime') CreatedDateTime: string ;
    @PropertyName('UpdatedBy') UpdatedBy: number;
    @PropertyName('UpdatedDateTime') UpdatedDateTime: string;
    @PropertyName('IsDisabled') IsDisabled: boolean;
    @PropertyName('IsSelected') IsSelected: boolean;
}

export class userInfoResponse{
    @PropertyName('viewAny') viewAny: boolean;
    @PropertyName('viewEdit') viewEdit: boolean;
    @PropertyName('viewEditCopyMove') viewEditCopyMove: boolean;
    @PropertyName('firmDocuments') firmDocuments: boolean;
    @PropertyName('internalDocumentsView') internalDocumentsView: boolean;
    @PropertyName('internalDocumentsViewEdit') internalDocumentsViewEdit: boolean;
    @PropertyName('hrManager') hrManager: boolean;
    @PropertyName('dmsPdfOpenWithApplication') dmsPdfOpenWithApplication: string;
    @PropertyName('DmsOfficeOnlineSwitch') DmsOfficeOnlineSwitch: boolean;
    @PropertyName('userId') userId: any;
}
