import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SpaceUsageChartComponent } from './space-usage-chart.component';

describe('SpaceUsageChartComponent', () => {
  let component: SpaceUsageChartComponent;
  let fixture: ComponentFixture<SpaceUsageChartComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SpaceUsageChartComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SpaceUsageChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
