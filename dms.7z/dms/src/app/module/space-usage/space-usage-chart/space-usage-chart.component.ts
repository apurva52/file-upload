import { Component, OnInit } from '@angular/core';
import { Observable, Subscription } from 'rxjs';
import { SpaceUsageService } from '../../space-usage/services/spaceusage.service';
import { Chart,registerables ,scales} from 'chart.js';
import { DatePipe } from '@angular/common';
import { ResourceService } from '@ifirm';



@Component({
  selector: 'app-space-usage-chart',
  templateUrl: './space-usage-chart.component.html',
  styleUrls: ['./space-usage-chart.component.scss'],

})

export class SpaceUsageChartComponent implements OnInit {
 
  loader = false;
  spaceUsageChartData$: Observable<any>;
  label:any;
  min:any;
  public chart:any;
  private labeldata: any[] = [];
  private UserDocumentsUsage: any[]=[];
  private HrDocumentsUsage: any[] = [];
  private InternalDocumentsUsage: any[] = [];
  private importUsage: any[] = [];
  private RecycleBinUsage: any[] = [];
  private WorkSpaceUsage: any[] = [];
  display: boolean;
  Month:any;
  sizeDividingFactor:any;
  lastReportGeneratedTimeStampText:any;

  public workspaceBgColor:any[] = [];
   recycleBinBgColor = [];
   importBgColor = [];
   internaldocumentsBgColor = [];
   userdocumentsBgColor = [];
   hrdocumentsBgColor = [];
   resourceSubscription: Subscription;
   dataLableList = [];
  

  
  constructor(private spaceusageservice: SpaceUsageService,private datePipe: DatePipe,private resourceservice:ResourceService) {
   Chart.register(...registerables);
    this.getSpaaceChartData();
  }


  ngOnInit()
  { 
   

   this.getSpaaceChartData();
   this.sizeDividingFactor = Math.pow(1024, 3);
   for ( let i = 0; i < 11; i++) {

   
    this.workspaceBgColor.push("#969696");
    this.recycleBinBgColor.push("#82a68e");
    this.importBgColor.push("#409bd2");
    this.internaldocumentsBgColor.push("#ca86b9");
    this.userdocumentsBgColor.push("#fbff90");
    this.hrdocumentsBgColor.push("#f5c780");
}

this.workspaceBgColor.push("#3d3d3d");
this.recycleBinBgColor.push("#3c874e");
this.importBgColor.push("#007ac3");
this.internaldocumentsBgColor.push("#940c72");
this.userdocumentsBgColor.push("#ffff00");
this.hrdocumentsBgColor.push("#ea8f00");



this.resourceSubscription = this.resourceservice.resourcesChanged.subscribe(value => {
  this.getSpaaceChartData();
})
}


createChartLabelList(hr,importUsage,internal,user,recyle,work)
{
  this.dataLableList =  [    
    {
      label: "WorkSpaceUsage",
      data: work,
      backgroundColor: this.workspaceBgColor,
      stack:'1',

    } ,
    {
      label: "HrDocumentsUsage",
      data: hr,
      backgroundColor: this.hrdocumentsBgColor,
      
      stack:'1'   
    },
    {
      label: "ImportUsage",
      data:importUsage, 
     
      backgroundColor: this.importBgColor,
      stack:'1'
    }  ,
    {
      label: "InternalDocumentsUsage",
      data:internal,
      backgroundColor:this.internaldocumentsBgColor,
      stack:'1'
    }  ,
    
    {
      label: "UserDocumentsUsage",
      data: user,
      backgroundColor:this.userdocumentsBgColor,
      stack:'1',
    }  ,
    {
      label: "RecycleBinUsage",
      data:recyle,
      backgroundColor: this.recycleBinBgColor,
      stack:'1',
    }  

  ];
}

  createChart(labeldata){

    if (this.chart) {
      this.chart.destroy();
    }
  
    this.chart = new Chart("MyChart", {
      type: 'bar', //this denotes tha type of chart

      data: {// values on X-Axis
        labels: labeldata, 
	       datasets: this.dataLableList
      },
      
      options: {
       
        maintainAspectRatio: false,
        plugins: {
          tooltip: {
            mode: 'index',
            intersect: false
          }
        },
        scales: {
          
          x: {
           
            grid: {
              
              display: false,
 
            },
            ticks: {
              minRotation:30
          }
          },
          y: {
            type: 'linear',
        position: 'right',
           
            grid: {
              display: false,
             
            }
          },
          
        }
      }
      
   
      
    });
  }


  getSpaaceChartData(): void {
    this.loader = true;
    let datasets=
      {
        label: "",
        data: [],
        backgroundColor: '',
        stack:'1'

      } 
     
    this.spaceusageservice.getspacechartdatareport()
    .subscribe((response) => {
      this.lastReportGeneratedTimeStampText =  "Space Usage  History" +'(' + "Last Generated"+ " " +response.ReportGeneratedTimeStamp + ')';
      if (response != null) {
        this.labeldata= response.SpaceUsageData.map(data=>{
          if(data.IsCurrentMonth){
            this.Month = 'Currentmonth';
            
          }
          else{
            this.Month = this.datePipe.transform(data.CreatedDateTime, 'MMMM-yyyy');
          }
          data.borderWidth= 50;
          return this.Month;
           
          })      
   
        var workspaceData = [], recycleBinData = [], labels = [], importData = [];
            var internaldocumentsData = [], userdocumentsData = [], hrdocumentsData = [];
            var currentMonthTotalUsage = 0;
            var elementsCount = response.SpaceUsageData.length;
      

            for (var i = 0; i < elementsCount; i++) {
                if (response.SpaceUsageData[i].IsCurrentMonth == false) {
                    labels.push(response.SpaceUsageData[i].ReportDateTime);
                }
                else {
                    currentMonthTotalUsage = response.SpaceUsageData[i].importUsage + response.SpaceUsageData[i].WorkSpaceUsage + response.SpaceUsageData[i].RecycleBinUsage;
                    currentMonthTotalUsage += response.SpaceUsageData[i].InternalDocumentsUsage + response.SpaceUsageData[i].UserDocumentsUsage + response.SpaceUsageData[i].HrDocumentsUsage;
                   
                }
                hrdocumentsData.push((response.SpaceUsageData[i].HrDocumentsUsage / this.sizeDividingFactor).toFixed(2));
                importData.push((response.SpaceUsageData[i].importUsage / this.sizeDividingFactor).toFixed(2));
                internaldocumentsData.push((response.SpaceUsageData[i].InternalDocumentsUsage / this.sizeDividingFactor).toFixed(2));
                userdocumentsData.push((response.SpaceUsageData[i].UserDocumentsUsage / this.sizeDividingFactor).toFixed(2));
                recycleBinData.push((response.SpaceUsageData[i].RecycleBinUsage / this.sizeDividingFactor).toFixed(2));
                workspaceData.push((response.SpaceUsageData[i].WorkSpaceUsage / this.sizeDividingFactor).toFixed(2));
               
               
               
                
               
            }
            this.createChartLabelList(
              hrdocumentsData,importData,internaldocumentsData,userdocumentsData,recycleBinData,workspaceData
              
              );
       
      }
  
    
     
      let lableFound = [];

      for(let i=0; i<this.dataLableList.length; i++)
      {
        lableFound[this.dataLableList[i].label] = 0;
          for(let j=0; j<response.SpaceUsageData.length; j++)
          {
              if(response.SpaceUsageData[j][this.dataLableList[i].label]>0)
              {
                lableFound[this.dataLableList[i].label] = lableFound[this.dataLableList[i].label] + 1;
              }
          }
      }

      let newDataList = [];

      for(let i=0; i<this.dataLableList.length; i++)
      {
          if(lableFound[this.dataLableList[i].label]>0)
          {
            this.dataLableList[i].barPercentage =0.5;
            this.dataLableList[i].barPercentage =50;
            this.dataLableList[i].maxBarThickness =50;
            this.dataLableList[i].maxBarThickness =40;

            newDataList.push(this.dataLableList[i]);
          }
      }

      this.dataLableList = newDataList;

      this.createChart(this.labeldata);
    });

  }

  

}

function transformDate(date: any) {
  throw new Error('Function not implemented.');
}
