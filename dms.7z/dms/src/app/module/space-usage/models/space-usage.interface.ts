export interface DeleteFileFolderList
{
    EntityId:number;
    EntityType:number;
    Guid:string;
    Hierarchy:string;
    Id:number;
    Kind:number;
    Name:string;
    StoragePath:string;
    Type:FileType
}

interface FileType{
    Extension:string;
    FileExtensionId:number;
    GroupName:string;
    Id:number;
    ResourceKey:string;
}