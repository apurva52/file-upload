import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SpaceUsageRoutingModule } from './space-usage-routing.module';
import { SpaceUsageComponent } from './space-usage/space-usage.component';
import { SpaceUsageChartComponent } from './space-usage-chart/space-usage-chart.component';
import { FirmModule } from '../firm/firm.module';
import { IFirmButtonModule, IFirmDataTableModule, LoaderModule } from '@ifirm';




@NgModule({
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  declarations: [
    SpaceUsageComponent, SpaceUsageChartComponent
    
  ],
  providers: [SpaceUsageComponent,SpaceUsageChartComponent],
  exports:[SpaceUsageComponent, SpaceUsageChartComponent],
  imports: [
    CommonModule,
    IFirmButtonModule,
    LoaderModule,
    SpaceUsageRoutingModule,
    IFirmDataTableModule,
    FirmModule,
    
    
  ]
})
export class SpaceUsageModule { }
