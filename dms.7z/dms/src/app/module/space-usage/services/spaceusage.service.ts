import { HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ApiService } from '@ifirm';
import { catchError, map, Observable, tap, throwError } from 'rxjs';
import { DeleteFileFolderList } from '../models/space-usage.interface';

@Injectable({
  providedIn: 'root'
})
export class SpaceUsageService {
  spaceusagecomp :any;

constructor(private api: ApiService){}
    getFirmDocumentResultContractList(isTotalSize:boolean,pageSize =100,loader): Observable<any> {
      this.spaceusagecomp = loader
            const url = `dms/api/report/GetFirmLargestFiles?isTotalSize=${isTotalSize}&pageSize=${pageSize}`;
            return this.api.get(url).pipe(map(x=>
               { this.spaceusagecomp.loader = false ;
                return x.FirmDocumentResultContractList
              }),catchError(
               this.handleError
              ));         
    }
    getspacechartdatareport(): Observable<any> {
    return this.api.get<any>('/dms/api/report/GetSpaceUsageReport/');
                 
     }

    public handleError(error: HttpErrorResponse) {
    
      let errorMessage: string = ''
      if (error.error instanceof ErrorEvent) {
          errorMessage = `Error:${error.message}`
      }
      else {
          errorMessage = `Status: ${error.status} \n Message:${error.message}`;
      }
      return throwError(errorMessage)
  }

  deleteDocuments(documentlist:DeleteFileFolderList[]):Promise<any> {
          const url = 'dms/api/document/deletedocuments';
          console.log(url,documentlist)
          return this.api.post<any>(url,null,{DeleteFileFolderList:documentlist}).toPromise();      
  }
  unLockFile(fieldId:number,loader): Observable<any> {
          const url = `dms/api/document/forceunlockfile?fileId=${fieldId}`;
          return this.api.get(url).pipe(tap(x=>
             { this.spaceusagecomp.loader = false ;
              this.getFirmDocumentResultContractList(false,100,loader)
            }),catchError(
             this.handleError
            ));         
  }
}