import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {SpaceUsageComponent} from './space-usage/space-usage.component'


const routes: Routes = [
  { path: '', component: SpaceUsageComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SpaceUsageRoutingModule { }
