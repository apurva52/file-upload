import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SpaceUsageComponent } from './space-usage.component';

describe('SpaceUsageComponent', () => {
  let component: SpaceUsageComponent;
  let fixture: ComponentFixture<SpaceUsageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SpaceUsageComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SpaceUsageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
