import { Component, OnInit } from '@angular/core';
import { ModalPopupService, ResourceService, ConfirmationBoxComponent, ModalPopupConfig, ConfirmationBoxType, ToasterService } from '@ifirm';
import { Observable } from 'rxjs';
import { SpaceUsageService } from './../services/spaceusage.service';
import { DeleteFileFolderList } from './../models/space-usage.interface';
import { ConfirmationBoxInputModel } from 'projects/apm/src/app/timesheet/model/timesheet-common.model';
import { AppConstants, fileKind } from '../../../constants/app-constants';
import { FileversionspaceComponent } from '../../../dialogs/file-versionspace/file-versionspace.component';
import { DmsDialogService } from '../../../dialogs/dms-dialog.service';
import { DmsService } from '../../../dms.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-space-usage',
  templateUrl: './space-usage.component.html',
  styleUrls: ['./space-usage.component.scss']
})
export class SpaceUsageComponent implements OnInit {
  loader = false;
  deleteDisFlag = true;
  totoalSizeLabel = false;
  rowDataDelete:DeleteFileFolderList[] = []
  spaceUsageData$:Observable<any>;
  resourceLoadCheck: boolean;
  constructor(private spaceusageservice:SpaceUsageService,private dmsDialogService: DmsDialogService,private resourceService: ResourceService,  private toasterService: ToasterService,private popupService: ModalPopupService,private dmsService: DmsService, private router: Router) { 
    this.getSpaaceUsageData(false);
  }

  ngOnInit(): void {
    this.dmsService.navigateToHome();
    var res = this.resourceService.get('dms.uploadfiles');
    if (res instanceof Promise) {
      res.then((_) => {
        this.resourceLoadCheck = true;
        
      });
    } else {
      this.resourceLoadCheck = true;
     
  }
  }
  replaceSlash(str) {

    return str.replace(/\\/g, "");
  }
  getSpaaceUsageData(sizeflag): void {
    this.loader = true;
    this.spaceUsageData$ = this.spaceusageservice.getFirmDocumentResultContractList(sizeflag, 100, this);
    
  }
  SpaceGridtruncate(source, size) {
    return source.length > size ? source.slice(0, size - 1) + "…" : source;
  }

  rowChange(event: any, rowData): void {
    if (event.target.checked) {
      this.deleteDisFlag = false;
      this.rowDataDelete.push(this.createDeleteRow(rowData))
    }
    else {
      const ind = this.rowDataDelete.findIndex((res: DeleteFileFolderList) => res.Guid == rowData.Guid)
      this.rowDataDelete.splice(ind, 1);
      !this.rowDataDelete.length && (this.deleteDisFlag = true);
    }
   
  }

  createDeleteRow(rowData): DeleteFileFolderList {
    const obj = {} as DeleteFileFolderList
    obj.EntityId = rowData.EntityId;
    obj.EntityType = rowData.EntityType;
    obj.Guid = rowData.Guid;
    obj.Hierarchy = rowData.Hierarchy;
    obj.Id = rowData.Id;
    obj.Kind = rowData.Kind;
    obj.Name = rowData.Name;
    obj.StoragePath = rowData.StoragePath;
    obj.Type = rowData.Type;
    return obj;
  }

  deleteDocument(): void {
    const config: ModalPopupConfig<ConfirmationBoxInputModel> = new ModalPopupConfig<ConfirmationBoxInputModel>();
    let model = new ConfirmationBoxInputModel();
    model.message = this.resourceService.getText('dms.delete.permanentconfirm');
    model.type = ConfirmationBoxType.YesNo;
    config.data = model;
    let instance = this.popupService.open<ConfirmationBoxComponent>(this.resourceService.getText('dms.notedelete'), ConfirmationBoxComponent, config);
    this.loader = true;
    const subscription = instance.afterClosed.subscribe(x => {
      if (subscription) {
        subscription.unsubscribe();
      }
      if (x && x.result) {
        this.spaceusageservice.deleteDocuments(this.rowDataDelete).then(res => {
          if (res.success) {
            this.getSpaaceUsageData(false);
            this.loader = false;
            this.deleteDisFlag = true;
            this.rowDataDelete = [];
          }
        }).catch(e => {
          this.loader = false;
        })
      }
    });
  }

  displaySize(): void {
    this.totoalSizeLabel = !this.totoalSizeLabel
    this.getSpaaceUsageData(this.totoalSizeLabel);
  }

  lockClick(data) {
    const config: ModalPopupConfig<ConfirmationBoxInputModel> = new ModalPopupConfig<ConfirmationBoxInputModel>();
    let model = new ConfirmationBoxInputModel();
    model.message = this.resourceService.getText('dms.openedit.unlockfileconfirmmessage');
    model.type = ConfirmationBoxType.YesNo;
    config.data = model;
    let instance = this.popupService.open<ConfirmationBoxComponent>(this.resourceService.getText('dms.openedit.unlockfile'), ConfirmationBoxComponent, config);
    const subscription = instance.afterClosed.subscribe(x => {
      if (subscription) {
        subscription.unsubscribe();
      }
      if (x && x.result) {
        this.loader = true;
        this.spaceusageservice.unLockFile(data.Id, this).subscribe(res => {
          this.getSpaaceUsageData(100);
          this.loader = false;
        }), (errore => {
          this.loader = false;
        })
      }

    });


  }
  openFile(rowdata: any) {
    if (rowdata.Type.Extension.toLowerCase() === "pdf")
      window.open("/dms/api/Export/GetFileInNewWindow?id=" + rowdata.Id + "&guid=" + rowdata.Guid, '_blank', '');
    else if (rowdata.Type.GroupName.toLowerCase() === 'picture') {
      window.open("/dms/api/Export/GetFileInNewWindow?id=" + rowdata.Id + "&guid=" + rowdata.Guid, '_blank', '');
    }
    else if ((rowdata.Type.Extension.toLowerCase() === "ac_" && rowdata.Type.GroupName.toLowerCase() === 'caseware')) {
      this.toasterService.error(this.resourceService.getText('dms.spaceusage.cannotopencwfile'));
    }
    else if (rowdata.Kind === fileKind.File && rowdata.Type.Extension === "") {
      this.toasterService.error(this.resourceService.getText('dms.openedit.extnlessmessage'));
    }
    else if (AppConstants.disAllowedCompressedFileExtensions.indexOf(rowdata.Type.Extension.toLowerCase()) > -1) {
      this.toasterService.error(this.resourceService.getText('dms.openedit.disallowedcompressedfilemessage'));
    }
  }

  versionClick(item) {
    this.dmsDialogService.openDialog('fileversionspace', item, null);
  }
  
  refreshdoc() {
    this.getSpaaceUsageData(false);
  }

}
