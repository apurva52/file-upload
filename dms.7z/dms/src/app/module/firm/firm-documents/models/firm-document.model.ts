// import { PropertyName } from "@ifirm";
import { PropertyName } from "../../../../../../../ifirm-common-components/src/public-api";

export class FirmDocumentCommonRequest {
    constructor() { }

    @PropertyName('EntityType') EntityType: null | number;
    @PropertyName('EntityId') EntityId: null | number;
    @PropertyName('FolderId') FolderId: null | number;
    @PropertyName('Hierarchy') Hierarchy: null;
    @PropertyName('SearchText') SearchText: string;
    @PropertyName('SearchNote') SearchNote: string;
    @PropertyName('Page') Page: number;
    @PropertyName('SortColumn') SortColumn: string;
    @PropertyName('SortOrder') SortOrder: string;
    @PropertyName('IsFiltering') IsFiltering: boolean;
    @PropertyName('IsDeleted') IsDeleted: boolean;
    @PropertyName('IsOnlyUserFolderFiltering') IsOnlyUserFolderFiltering: boolean;
    @PropertyName('DisplayArea') DisplayArea: number;
    @PropertyName('HasMoreEntityRecords') HasMoreEntityRecords: boolean;
    @PropertyName('HasMoreRecords') HasMoreRecords: boolean;
    @PropertyName('ContentSearchOffset') ContentSearchOffset: any;
    @PropertyName('IsFileSearch') IsFileSearch: boolean;
    @PropertyName('SearchMore') SearchMore: boolean;
    @PropertyName('IsContentSearch') IsContentSearch?: boolean;
    @PropertyName('IsPurgeDate') IsPurgeDate?: boolean;
    @PropertyName('Filters') Filters: FilterAcceptanceCriteria;
    @PropertyName('SearchTags') SearchTags: SearchTagCriteria;
}

export class FilterAcceptanceCriteria {
    constructor() { }
    @PropertyName('DateFrom') DateFrom: string;
    @PropertyName('DateTo') DateTo: string;
    @PropertyName('IsJobClosed') IsJobClosed: string;
    @PropertyName('FileTypes') FileTypes: string[];
    @PropertyName('UserId') UserId: string;
    @PropertyName('TagList') TagList: string[];
    @PropertyName('JobTypeTagList') JobTypeTagList: any;
    @PropertyName('ContactsTagList') ContactsTagList: any;
    @PropertyName("FirmSystemTag") FirmSystemTag: string;
    @PropertyName('ContactGroupId') ContactGroupId: string;
    @PropertyName('IsArchivedContacts') IsArchivedContacts: boolean;
    @PropertyName('ShowArchivedContactsCheckBox') ShowArchivedContactsCheckBox: boolean;
    @PropertyName('ShowInActiveUserCheckBox') ShowInActiveUserCheckBox: boolean;
    @PropertyName('IsInActiveUser') IsInActiveUser: boolean;
    @PropertyName('ContactList') ContactList: string[];
    @PropertyName('MyRecentFiles') MyRecentFiles: boolean;
    @PropertyName('UserFolders') UserFolders: number;
    @PropertyName('NoteStatus') NoteStatus: string;
    @PropertyName('NoteAssignTo') NoteAssignTo: string;
    @PropertyName('NoteCreatedBy') NoteCreatedBy: string;
    @PropertyName('NoteDueDate') NoteDueDate: string;
    @PropertyName('IsFilterPortalTag') IsFilterPortalTag: boolean;
}

export class SearchTagCriteria {
    constructor() { }
    @PropertyName('Tags') Tags: any;
    @PropertyName('JobTypeTags') JobTypeTags: any;
    @PropertyName('ContactsTypeTags') ContactsTypeTags: any;
    @PropertyName('PermentContactsTagType') PermentContactsTagType: number;
    @PropertyName('PermentTagType') PermentTagType: number;
    @PropertyName('IsSearchPortalTag') IsSearchPortalTag: boolean;
}

export class FileTypeResponse{
    @PropertyName('Id') Id: string | number;
    @PropertyName('GroupName') GroupName: string;
    @PropertyName('Extension') Extension: string;
    @PropertyName('FileExtensionId') FileExtensionId: string | number;
    @PropertyName('ResourceKey') ResourceKey: string;
}
export class TagsListResponse{
    TagList: TagsResponse[];
}
export class TagsResponse{
    @PropertyName('TagId') TagId: string | number;
    @PropertyName('TagIdForMapping') TagIdForMapping: string;
    @PropertyName('TagNameForDisplay') TagNameForDisplay: string;
    @PropertyName('TagNameLanguage1') TagNameLanguage1: string ;
    @PropertyName('ShowTag') ShowTag: boolean;
    @PropertyName('SortOrder') SortOrder: number;
    @PropertyName('IsSystemTag') IsSystemTag: boolean;
    @PropertyName('CreatedBy') CreatedBy: number;
    @PropertyName('CreatedDateTime') CreatedDateTime: string ;
    @PropertyName('UpdatedBy') UpdatedBy: number;
    @PropertyName('UpdatedDateTime') UpdatedDateTime: string;
    @PropertyName('IsDisabled') IsDisabled: boolean;
    @PropertyName('IsSelected') IsSelected: boolean;
}

export class userInfoResponse{
    @PropertyName('viewAny') viewAny: boolean;
    @PropertyName('viewEdit') viewEdit: boolean;
    @PropertyName('viewEditCopyMove') viewEditCopyMove: boolean;
    @PropertyName('firmDocuments') firmDocuments: boolean;
    @PropertyName('internalDocumentsView') internalDocumentsView: boolean;
    @PropertyName('internalDocumentsViewEdit') internalDocumentsViewEdit: boolean;
    @PropertyName('hrManager') hrManager: boolean;
    @PropertyName('dmsPdfOpenWithApplication') dmsPdfOpenWithApplication: string;
    @PropertyName('DmsOfficeOnlineSwitch') DmsOfficeOnlineSwitch: boolean;
    @PropertyName('userId') userId: any;
}
