import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ModalPopupService, ResourceService } from '@ifirm';
import { AddFolderComponent } from '../../../dialogs/add-folder/add-Folder.component';
import { InsertLinkComponent } from '../../../dialogs/insert-link/insert-link.component';
import { UploadDocumentComponent } from '../../../dialogs/upload-documents/upload-documents.component';
import { DmsService } from '../../../dms.service';
import { FirmDocumentsService } from './services/firm-documents.service';

@Component({
  selector: 'app-firm-documents',
  templateUrl: './firm-documents.component.html',
  styleUrls: ['./firm-documents.component.scss']
})
export class FirmDocumentsComponent implements OnInit, OnDestroy {

  dmsFilterToggle: boolean = false;
  callFromParent: boolean = false;

  constructor(private popupService: ModalPopupService, private resourceService: ResourceService, private dmsServices: DmsService,
    private firmDocService: FirmDocumentsService,private router: Router) {
    
   }
  ngOnDestroy(): void {
    this.firmDocService.isEnableConditionalButton = false;
    this.firmDocService.isFilterSearchArea = false;
  }
  isEnableDialog(){
    return this.firmDocService.isEnableConditionalButton;
  }

  resourceLoadCheck = false;
  ngOnInit(): void {
 
    var res = this.resourceService.get('dms.uploadfiles');
    if (res instanceof Promise) {
      res.then((_) => {
        this.afterResourceLoad();
      });
    } else {
     
      this.afterResourceLoad();
    }

    
  }

  afterResourceLoad()
  {
    this.dmsServices.navigateToHome();
    this.resourceLoadCheck = true;
    const newBreadCrumbs: any = {
      Name: "Firm Documents",
      EntityId: 1,
      Id: null,
      Hierarchy: null,
      EntityType: 1
    }
    this.dmsServices.updateBreadcrumbs([newBreadCrumbs]);
    this.firmDocService.currentcrumb = [newBreadCrumbs];
    this.updateUserInfo();
  }

  userRole
  permantUserId = null;
  updateUserInfo(): void {
    if (this.dmsServices.userInfoMap.get('userInfoValue') != undefined) {
      const response = this.dmsServices.userInfoMap.get('userInfoValue');
      this.userRole = {
        allowApmAccess: response.IsAllowApmAccess,
        viewUpload: response.DmsViewUpload, contactView: response.ContactView,
        internalDocumentsViewEdit: response.DmsInternalDocumentsViewEdit,
        viewEditCopyMove: response.DmsViewEditCopyMove,
        firmDocuments: response.DmsFirmDocuments,
        addCustomFolder: response.DmsAddCustomFolder,
        userId: response.UserId
      }
      this.permantUserId = response.UserId;
      this.firmDocService.userRoles = this.userRole;
    }
  }
  openUploadDocument():void{
    const payload: any = this.firmDocService.getPayload$();
    const payloadResponse = payload.source.value;
    const internalDocfolderId = this.firmDocService.defaultFolderIds;
    // const folderId = payloadResponse.EntityId === 1 && payloadResponse.EntityType === 1 && payloadResponse.FolderId === null ?
    // this.firmDocService.defaultFolderId : payloadResponse.FolderId
    const folderName = this.firmDocService.selectedFolderName;
    // const folderName = payloadResponse.EntityId === 1 && payloadResponse.EntityType === 1 && 
    // (payloadResponse.FolderId === null || payloadResponse.FolderId === this.firmDocService.defaultFolderId) ?
    // 'Internal Documents': payloadResponse.FolderName
    // console.log("payload", payloadResponse);
    if (payloadResponse.EntityId === -1 && payloadResponse.EntityType === 6){
      this.userRole.userId = -1;
    }else {
      this.userRole.userId = this.permantUserId
    }
    let data = {
      EntityId:payloadResponse.EntityId,
      EntityType:payloadResponse.EntityType,
      FolderId: this.firmDocService.shareNullOnFolderId ? null: this.firmDocService.defaultFolderId,  // initial stage 14(internal document)
      FolderName: folderName, // initial stage internal document
      Hierarchy: payloadResponse.Hierarchy,
      InternalDocumentsFolderId: internalDocfolderId,
      UserRoles: this.userRole};
      // console.log("uipload document", data)
      let instance = this.popupService.open<UploadDocumentComponent>(this.resourceService.getText('dms.uploadfiles'), UploadDocumentComponent, {data:data});
      const sub = instance.afterClosed.subscribe(response => {
        if (response) {
          this.userRole.userId = this.permantUserId
          this.firmDocService.setButtonAlert(response);
        }
      });
  }

  dmsFilterPaneHideShow(){
    return this.dmsFilterToggle ? "hideFilter" : "showFilter";
  }

  dmsFilterToggleButtonSlide(){
    return this.dmsFilterToggle ? "filterToggleButton filterToggleButtonExpand" : "filterToggleButton filterToggleButtonCollapse";
  }

  dmsFilterToggleDirection(){
    return this.dmsFilterToggle ? "fa fa-angle-double-right rightToggle rightToggleR dmsFilterPointers" : "fa fa-angle-double-left rightToggle rightToggleL dmsFilterPointers";
  }

  toggleDmsFilter(){
    this.dmsFilterToggle = !this.dmsFilterToggle;
  }

  showAddFolderDialog(){
    const payload: any = this.firmDocService.getPayload$();
    const payloadResponse = payload.source.value;
    const data = {
      EntityType: payloadResponse.EntityType,
      EntityId: payloadResponse.EntityId,
      ParentFolderId: payloadResponse.FolderId,
      Hierarchy: payloadResponse.Hierarchy
    };
    let instance = this.popupService.open<AddFolderComponent>(this.resourceService.getText('dms.common.addfolder'), AddFolderComponent, { data: data });
    const sub = instance.afterClosed.subscribe(response => {
      if (response) {
        this.firmDocService.setButtonAlert(response);
      }
    });
  }

  showInsertLinkDialog(){
    const payload: any = this.firmDocService.getPayload$();
    const payloadResponse = payload.source.value;
    const data = {
      EntityType: payloadResponse.EntityType,
      EntityId: payloadResponse.EntityId,
      FolderId: payloadResponse.FolderId,
      Hierarchy: payloadResponse.Hierarchy
    };
    let instance = this.popupService.open<InsertLinkComponent>(this.resourceService.getText('dms.common.link'), InsertLinkComponent, { data: data });
    const sub = instance.afterClosed.subscribe(response => {
      if (response) {
        this.firmDocService.setButtonAlert(response);
      }
    });
  }
  eventFromFilter(event){
    this.callFromParent = true;
    setTimeout(() => {
      this.callFromParent = false;
    }, 100);
    // this.dmsFirmDocService.setLoaderSubject(true);
    // const payload: any = this.dmsFirmDocService.getPayload$();
    // this.dmsFirmDocService.loadFirmDocuments(payload.source.value);
  }
}
