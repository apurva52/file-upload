import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FirmDocumentRootGridComponent } from './firm-document-root-grid.component';

describe('FirmDocumentRootGridComponent', () => {
  let component: FirmDocumentRootGridComponent;
  let fixture: ComponentFixture<FirmDocumentRootGridComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FirmDocumentRootGridComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FirmDocumentRootGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
