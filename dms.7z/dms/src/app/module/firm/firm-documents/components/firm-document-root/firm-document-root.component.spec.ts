import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FirmDocumentRootComponent } from './firm-document-root.component';

describe('FirmDocumentRootComponent', () => {
  let component: FirmDocumentRootComponent;
  let fixture: ComponentFixture<FirmDocumentRootComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FirmDocumentRootComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FirmDocumentRootComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
