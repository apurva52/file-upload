import { Component, Input, OnChanges, OnDestroy, OnInit, SimpleChanges } from '@angular/core';
import { ResourceService } from '@ifirm';
import { DMSFirmDocument } from 'projects/dms/src/app/constants/app-constants';
import { DmsService } from 'projects/dms/src/app/dms.service';
import { DmsFiltersService } from 'projects/dms/src/app/filter-components/dms-filters.service';
import { SearchServiceService } from 'projects/dms/src/app/shared/tools/search-bar/search-service.service';
import { GridServiceService } from 'projects/dms/src/app/shared/tools/service/grid-service.service';
import { Subscription } from 'rxjs';
import { FirmDocumentCommonRequest } from '../../models/firm-document.model';
import { FirmDocumentsService } from '../../services/firm-documents.service'
@Component({
  selector: 'app-firm-document-root',
  templateUrl: './firm-document-root.component.html',
  styleUrls: ['./firm-document-root.component.scss']
})
export class FirmDocumentRootComponent implements OnInit, OnDestroy, OnChanges {

  firmDocPayload: FirmDocumentCommonRequest;
  isEnabledRootGrid: boolean = true;
  @Input() isCallFromParent: boolean;
  isEnableFourCoulmn: boolean = false;
  searchEventSubs: Subscription;
  breadsub: Subscription;
  buttonSubs: Subscription;
  bred: Subscription;
  constructor(private firmDocService: FirmDocumentsService, private dmsServices: DmsService, private filterService: DmsFiltersService,
    private SearchServiceService: SearchServiceService, private resourceService: ResourceService, private gridService: GridServiceService) { 
      this.buttonSubs = this.firmDocService.getButtonAlert().subscribe(response =>{
          if (response){
            this.callFromButton();
          }
      })
    }

  ngOnChanges(changes: SimpleChanges): void {
    if (this.isCallFromParent){
      this.firmDocService.isFilterSearchArea = true;
      this.callForComponentLoad();      
      this.isCallFromParent = false;
    }
  }

  ngOnDestroy(): void {
    this.firmDocService.setFirmDocList$(null);
    this.searchEventSubs?.unsubscribe();
    this.buttonSubs?.unsubscribe();
    this.breadsub?.unsubscribe();
    this.bred?.unsubscribe();
    this.clearServiceVariables();
  }
  ngOnInit(): void {
    this.firmDocService.resetPayload$();
    this.firmDocService.setLoaderSubject(true);
    const firmDocPayload: any = this.firmDocService.getPayload$();
    this.firmDocPayload = firmDocPayload.source.value
    this.firmDocService.filterTags(firmDocPayload.source.value);
    this.firmDocService.filterTypes(firmDocPayload.source.value);
    this.firmDocService.loadFirmDocuments(firmDocPayload.source.value);
    const tempVariable = JSON.stringify(firmDocPayload.source.value);
    const payloadCopy = JSON.parse(tempVariable);
    this.firmDocService.setPayloadForFilter(payloadCopy);
    this.breadsub = this.dmsServices.breadCrumbData$.subscribe(data =>{
     this.bred = this.resourceService.tabName$.subscribe((value)=>{
      // console.log("tab name ", value)
       if (value === 'Firm Documents'){
        if (data?.Name === 'Firm Documents'){
          this.firmDocService.resetPayload$();
        }
        const firmDocPayload: any = this.firmDocService.getPayload$();
        this.firmDocPayload = firmDocPayload.source.value;
        this.dataFromGrid(data);
       }
     })
    })
    this.searchEventSubs = this.SearchServiceService.searchEvent.subscribe(
      (data: any) => {
        this.firmDocService.setPayload$(data);
        this.firmDocService.isFilterSearchArea = true;
        this.callForComponentLoad();
      }
    );
  }
  dataFromGrid(selectedRecord){
    this.firmDocService.isFilterSearchArea = false;
    this.firmDocService.setFirmDocList$(null);   
    this.firmDocPayload.FolderId = selectedRecord.Id;
    this.firmDocPayload.EntityId = selectedRecord.EntityId;
    this.firmDocPayload.EntityType = selectedRecord.EntityType;
    this.firmDocPayload.Hierarchy = selectedRecord?.Hierarchy ? selectedRecord.Hierarchy : null;
    this.firmDocService.selectedFolderName = selectedRecord?.Name ? selectedRecord?.Name: null;
    this.firmDocService.defaultFolderId = selectedRecord.Id? selectedRecord.Id: null;
    this.setEmptyFilterKeys();
    this.isEnableFourCoulmn = false;
    const tempVariable = JSON.stringify(this.firmDocPayload);
    const payloadCopy = JSON.parse(tempVariable);
    this.firmDocService.setPayloadForFilter(payloadCopy);
    this.firmDocService.filterTags(this.firmDocPayload);
    this.firmDocService.filterTypes(this.firmDocPayload);
    this.firmDocService.setLoaderSubject(true);
    this.firmDocService.loadFirmDocuments(this.firmDocPayload);
    this.clearServiceVariables();
    this.validateRedirectComponent();
  }
  callForComponentLoad(){
    this.firmDocService.setFirmDocList$(null);
    this.firmDocService.setLoaderSubject(true);
    const firmDocPayload: any = this.firmDocService.getPayload$();
    this.firmDocPayload = firmDocPayload.source.value
    const isFilterApplied = this.firmDocService.isdefaultFilter(this.filterService.defaultFilter);
    if (isFilterApplied){
      this.setEmptyFilterKeys();
    }
    this.firmDocService.setPayloadForFilter(this.firmDocPayload);
    this.firmDocService.loadFirmDocuments(this.firmDocPayload);
    this.clearServiceVariables();
    // this.addSearchResultBreadcrumb();
    this.firmDocService.addSearchResultBreadcrumb(this.firmDocPayload);
    if (this.firmDocPayload.IsFiltering === true){
      this.validateRedirectFilterComponent();
    }else {
      this.isEnableFourCoulmn = false;
      this.validateRedirectComponent();
    }
  }

  validateRedirectComponent(){
    this.firmDocService.isEnableConditionalButton = false;
    switch (this.firmDocPayload?.EntityType) {
      case DMSFirmDocument.InternalDocuments:
        switch (true){
          case this.firmDocPayload.FolderId === null: case this.firmDocPayload.FolderId === 0: case this.firmDocPayload.FolderId === -1:
            this.isEnabledRootGrid = true;
            break
          default:
            this.isEnabledRootGrid = false;
            this.firmDocService.isEnableConditionalButton = true;
        }  
      break;
      case DMSFirmDocument.HRDocuments:
        switch (true){
          case this.firmDocPayload.EntityId === null: case this.firmDocPayload.EntityId === 0:
            this.isEnabledRootGrid = true;
            break
          default:
            this.firmDocService.isEnableConditionalButton = true;
            this.isEnabledRootGrid = false;
        }  
      break
      case DMSFirmDocument.User:
        this.isEnabledRootGrid = false;
        this.firmDocService.isEnableConditionalButton = true;
        break
      default:
        this.isEnabledRootGrid = true;
        break;
    }
  }
  validateRedirectFilterComponent(){
    const isSelectedUniqueFilter = this.firmDocService.isHomePageEnableOnFilter(this.filterService.defaultFilter);
    this.isEnableFourCoulmn = isSelectedUniqueFilter;
    switch (this.firmDocPayload?.EntityType) {
      case DMSFirmDocument.InternalDocuments:
        switch (true){
          case this.firmDocPayload.FolderId === null && isSelectedUniqueFilter:
          case this.firmDocPayload.FolderId === 0 && isSelectedUniqueFilter:
          case this.firmDocPayload.FolderId === -1 && isSelectedUniqueFilter:
            this.isEnabledRootGrid = true;
            break
          default:
            this.isEnabledRootGrid = false;
        }  
      break;
      case DMSFirmDocument.HRDocuments:
        switch (true){
          case this.firmDocPayload.EntityId === null && isSelectedUniqueFilter:
          case this.firmDocPayload.EntityId === 0 && isSelectedUniqueFilter:
            this.isEnabledRootGrid = true;
            break
          default:
            this.isEnabledRootGrid = false;
        }  
      break
      case DMSFirmDocument.User:
        this.isEnabledRootGrid = false;
        break
      default:
        this.isEnabledRootGrid = true;
        break;
    }
  }
  setEmptyFilterKeys(){
    const defaultResponse = JSON.stringify(this.firmDocService.defaultFilter);
    const defaulLatestPayload = JSON.parse(defaultResponse);
    defaulLatestPayload.IsArchivedContacts = false;
    this.firmDocPayload.Filters = defaulLatestPayload;
    this.firmDocPayload.IsFiltering = false;
    this.firmDocPayload.IsContentSearch = false;
    this.firmDocPayload.IsFileSearch = false;
    this.firmDocPayload.SearchMore = true;
    this.firmDocPayload.Page = 0;
    this.firmDocService.setPayload$(this.firmDocPayload);
  }
  callFromButton(){
    this.firmDocService.setFirmDocList$(null);
    this.firmDocService.setLoaderSubject(true);
    const firmDocPayload: any = this.firmDocService.getPayload$();
    this.firmDocPayload = firmDocPayload.source.value;
    this.firmDocService.loadFirmDocuments(this.firmDocPayload);
    this.validateRedirectComponent();
  }
  clearServiceVariables(){
    this.gridService.checkedDatalist = [];
    this.gridService.dmsRenameButton = true;
    this.gridService.dmsCopyMoveButton = true;
    this.gridService.dmsDeleteButton = true;
    this.gridService.resetDownloadMergePDFButton();
  }
}
