import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ModalPopupService, ResourceService } from '@ifirm';
import { FilePropertyComponent } from 'projects/dms/src/app/dialogs/file-property/file-property.component';
import { DmsService } from 'projects/dms/src/app/dms.service';
import { FirmDocumentsService } from '../../services/firm-documents.service';

@Component({
  selector: 'app-firm-document-root-grid',
  templateUrl: './firm-document-root-grid.component.html',
  styleUrls: ['./firm-document-root-grid.component.scss']
})
export class FirmDocumentRootGridComponent implements OnInit {

  firmDocResponse;
  firmDocPayload;
  firmDocLoader;
  @Input()isEnableFourCoulmn;
  onhoverSelectedRecord: number = null
  @Output() passDataToParent = new EventEmitter();
  firmDocPaginationResponse: any;
  noRecordsError: any;

  constructor(private firmDocService: FirmDocumentsService, private popupService: ModalPopupService, private resourceService: ResourceService,
    private dmsServices: DmsService) { 
    this.firmDocResponse = this.firmDocService.getFirmDocList$();
    this.firmDocLoader = this.firmDocService.getLoaderSubject();
    this.firmDocPaginationResponse = this.firmDocService.getFirmPaginationSubject();
    this.noRecordsError = this.firmDocService.getNoRecordsSubject();
  }
  
  ngOnInit(): void {
    const payload: any = this.firmDocService.getPayload$();
    this.firmDocPayload = payload.source.value;
  }
  sortingTable(sort: string) {
    this.firmDocService.setLoaderSubject(true);
    this.firmDocPayload.SortColumn = sort;
    this.firmDocPayload.SortOrder = (this.firmDocPayload.SortOrder == 'desc') ? 'asc' : (this.firmDocPayload.SortOrder == 'asc') ? 'desc' : 'desc';
    this.firmDocService.setPayload$(this.firmDocPayload);
    this.firmDocService.loadFirmDocuments(this.firmDocPayload);
  }
  sortingOrder(sort: string) {
    const firmDocPayload: any = this.firmDocService.getPayload$();
    this.firmDocPayload = firmDocPayload.source.value;
    if (this.firmDocPayload.SortColumn === sort) {
      if (this.firmDocPayload?.SortOrder === "asc") {
        return "ascendImg dms-sort";
      } else {
        return "descendImg dms-sort";
      }
    }
  }
  updateFileIcon(record) {
    let iconName;
    if (record.Type != null && record.Type.Extension != null && record.Type.Extension.toLowerCase() === "msg" && record.EmailMetaDataId > 0) {
      iconName = "email-logged";
    } else {
      iconName = record.Icon;
    }
    return "dms-" + iconName + " dms-type-icon";
  }

  showIcons(index) {
    this.onhoverSelectedRecord == index? this.onhoverSelectedRecord = null : this.onhoverSelectedRecord = index
  }

  fileNameMouseOver(record){
    if (this.firmDocService.FolderHierarchyList?.length > 0){
        const response = this.firmDocService.FolderHierarchyList[0]
        record.HierarchyPath = `${response.FolderName} \\ ${record.Name}`
    }else {
      record.HierarchyPath = record.Name
    }
  }
  rowClick(record){
    this.passDataToParent.emit(record);
    // this.addSearchResultBreadcrumb();
    this.firmDocService.addSearchResultBreadcrumb(this.firmDocPayload);
    const data = {
      Name: record.Name,
      EntityId: record.EntityId,
      Id: record.Id,
      Hierarchy: record.Hierarchy,
      EntityType: record.EntityType
    }
    this.firmDocService.creatBreadcrumbs(data);
  }
  addSearchResultBreadcrumb(){
    if (this.firmDocService.currentcrumb){
      const currentBreadcrumb:any = this.firmDocService.currentcrumb[this.firmDocService.currentcrumb.length - 1];
      if (this.firmDocPayload.IsFiltering || this.firmDocPayload.SearchText !="" || this.firmDocPayload.SearchNote !="" ||
      this.firmDocPayload.SearchTags.Tags.length>0){
        if (currentBreadcrumb.Name !== 'Search Result'){
          const data = {
            Name: 'Search Result',
            isColorChange: true
          }
          this.firmDocService.creatBreadcrumbs(data);
        }
      }else {
        if (currentBreadcrumb.Name === 'Search Result'){
          const newBreadCrumbs: any = this.firmDocService.currentcrumb.slice(0, this.firmDocService.currentcrumb.length-1)
          console.log("newBreadCrumbs", newBreadCrumbs)
          this.dmsServices.updateBreadcrumbs(newBreadCrumbs);
        }
      }
    }
  }
  showPropertiesDialog(record){
    let data = {  Name: "", DefaultFolderId: null, isDeleted: false,
    file: { kind: record.Kind, EntityId: record.EntityId, EntityType: record.EntityType, Icon: record.Icon,
      Source: record.Source, EmailMetaDataId: record.EmailMetaDataId, Name: record.Name, id: record.Id, Hierarchy: record.Hierarchy,
      IsRecycleBin: false, isJobFolder: false, IsSystemFolder: record.IsSystemFolder } }
    let instance = this.popupService.open<FilePropertyComponent>(this.resourceService.getText('dms.propertiesdialog.properties'), FilePropertyComponent, {data:data});
    const sub = instance.afterClosed.subscribe(response => {
      if (response) {
        const payload: any = this.firmDocService.getPayload$();
        this.firmDocPayload = payload.source.value;
        this.firmDocService.setLoaderSubject(true);
        this.firmDocService.loadFirmDocuments(this.firmDocPayload);
        this.firmDocService.scrollTop();
      }
    });
  }
  onFirmGridScroll(){
    if (this.firmDocPaginationResponse.source.value.IsLoadMore) {
      const payload: any = this.firmDocService.getPayload$();
      this.firmDocPayload = payload.source.value;
      this.firmDocPayload.Page = this.firmDocPaginationResponse.source.value.PageSize + this.firmDocPayload.Page;
      this.firmDocService.setPayload$(this.firmDocPayload);
      this.firmDocService.loadFirmDocuments(this.firmDocPayload, this.firmDocPaginationResponse.source.value.IsLoadMore);
    }
  }
  
}
