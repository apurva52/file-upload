import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import {  ResourceService,  ModalPopupConfig, ModalPopupService, ConfirmationBoxType, ConfirmationBoxComponent, ToasterService } from '@ifirm';
import { entityType, eventType, fileKind } from 'projects/dms/src/app/constants/app-constants';
import { FileVersionComponent } from '../../../../../dialogs/file-version/file-version.component';
import { FilePropertyComponent } from '../../../../../dialogs/file-property/file-property.component';
import { FirmDocumentsService } from '../../services/firm-documents.service';
import { FileNotesComponent } from 'projects/dms/src/app/dialogs/file-notes/file-notes.component';
import { GridServiceService } from 'projects/dms/src/app/shared/tools/service/grid-service.service';
import { RenameDocumentComponent } from 'projects/dms/src/app/dialogs/rename-document/rename-document.component';
import { FileCopyComponent } from 'projects/dms/src/app/dialogs/file-copy/file-copy.component';
import { CopyMovePayload } from 'projects/dms/src/app/shared/tools/model/files-documents-grid.model';
import { ConfirmationBoxInputModel } from 'projects/apm/src/app/timesheet/model/timesheet-common.model';

@Component({
  selector: 'app-firm-document-root-checkbox-grid',
  templateUrl: './firm-document-root-checkbox-grid.component.html',
  styleUrls: ['./firm-document-root-checkbox-grid.component.scss']
})
export class FirmDocumentRootCheckboxGridComponent implements OnInit {
  dmsOpenPdfButton: boolean = true;
  dmsDeleteButton: boolean = true;
  isLoader: boolean = false;
  selectedAll: any;
  firmResponse: any;
  paddingLeftVersionHeader = "25px";
  copyLinkLabel = this.resourceService.getText('dms.copylink');
  versionTooltipLabel = this.resourceService.getText('dms.common.versiontooltip');
  firmDocResponse: any;
  firmDocLoader: any;
  firmDocPayload: any;
  @Output() passDataToRoot = new EventEmitter();
  firmDocPaginationResponse: any;  
  name: string;
  searchTag = this.resourceService.getText('dms.searchtag.search');  
  noRecordsError: any;

  constructor( private resourceService: ResourceService,
    private popupService: ModalPopupService, private firmDocService: FirmDocumentsService,
    public gridService: GridServiceService, private toasterService: ToasterService) { 
      this.firmDocResponse = this.firmDocService.getFirmDocList$();
      this.firmDocLoader = this.firmDocService.getLoaderSubject();
      this.firmDocPaginationResponse = this.firmDocService.getFirmPaginationSubject();
      this.noRecordsError = this.firmDocService.getNoRecordsSubject();
    }

  ngOnInit(): void {
    const payload: any = this.firmDocService.getPayload$();
    this.firmDocPayload = payload.source.value;
    this.gridService.applyUserRoles();
    this.gridService.getEnhancedpdfSettings('firmDoc');
  }

  showRenameDialog(){
    const record = this.gridService.getList();
    if (record?.length === 1){
      const payloadForRename = this.gridService.createRenamePayload(record[0]);
      const config = new ModalPopupConfig();
      config.data = payloadForRename;
      let instance = this.popupService.open<RenameDocumentComponent>(this.resourceService.getText('dms.rename'), RenameDocumentComponent, config);
      const subscription = instance.afterClosed.subscribe((response) => {
        subscription.unsubscribe();
        if (response) {
          // this.gridService.checkedDatalist = [];
          this.clearServiceVariables();
          this.firmDocService.setLoaderSubject(true);
          this.firmDocPayload.Page = 0;
          this.firmDocService.loadFirmDocuments(this.firmDocPayload);
          this.firmDocService.scrollTop();
        }
      });
    }
  }

  startDownload(){
    if (this.gridService.checkedDatalist.length === 1 &&
      this.gridService.checkedDatalist[0].Kind === fileKind.File)
     {
      this.gridService.downloadSingleFile(this.gridService.checkedDatalist[0], 'firmDoc',this.firmDocPayload);
     } 
     else 
     {
      this.gridService.downloadMultipleFiles(this.gridService.checkedDatalist, 'firmDoc',this.firmDocPayload);
     }
   }

   createPdf(){
    this.gridService.openPdf(this.gridService.checkedDatalist,'firmDoc',this.firmDocPayload);
  }

  createMergePdf(){
    this.gridService.openMergePdf(this.gridService.checkedDatalist,this.firmDocPayload,'firmDoc');
  }

  showCopyMoveDialog(operationType: string){
    const payload: any = this.firmDocService.getPayload$();
    const payloadResponse = payload.source.value;
    let selectedEvent = eventType.Move;
    let headerText = 'dms.move.movedocuments'
    const record = this.gridService.getList()
    const selectedItems = this.gridService.fetchSelecctedItem(record);
    if (operationType === 'copy'){
      selectedEvent = eventType.Copy;
      headerText = 'dms.copy.copydocuments'
    }
    let copyMoveData: CopyMovePayload = {
      EventType: selectedEvent,
      LocationDetails: {EntityType: payloadResponse.EntityType, EntityId: payloadResponse.EntityId,
        FolderId: payloadResponse.FolderId,
        FolderName:this.firmDocService.selectedFolderName,
         Hierarchy: payloadResponse.Hierarchy
      },
      UserRoles: this.firmDocService.userRoles,
      SelectedItems: selectedItems,
    }
    const config = new ModalPopupConfig();
    config.data = copyMoveData;
    // console.log("copy payload", copyMoveData)
    let instance = this.popupService.open<FileCopyComponent>( this.resourceService.getText(headerText), FileCopyComponent, config);
    const subscription = instance.afterClosed.subscribe((response) => {
      subscription.unsubscribe();
      if (response) {
        // this.gridService.checkedDatalist = [];
        this.firmDocService.setLoaderSubject(true);
        this.firmDocPayload.Page = 0;
        this.firmDocService.loadFirmDocuments(this.firmDocPayload);
        this.firmDocService.scrollTop();
        this.clearServiceVariables();
      }
    })
  }

  showMultipleDeleteConfirmDialog(){
    // const rowItem = this.gridService.checkedDatalist[0]
    // this.dmsDeleteButton = this.isDeleteAllowed(rowItem);
    let selectedRecord = []
    const record = this.gridService.getList()
      // const deleteObj = {} as ContactDataModel;
      record.forEach(element => {
        selectedRecord.push({
          EntityId : element.EntityId,
          EntityType : element.EntityType,
          Guid : element.Guid,
          Id : element.Id,
          Kind : element.Kind,
          Name : element.Name,
          ParentFolderId : element.ParentId,
          Hierarchy : element.Hierarchy,
          IsVersionExist : element.IsVersionExist,
          StoragePath : element.StoragePath,
          Type : element.Type,
          LinkUrl : element.LinkUrl,
        })
      });
      const config: ModalPopupConfig<ConfirmationBoxInputModel> = new ModalPopupConfig<ConfirmationBoxInputModel>();
      let model = new ConfirmationBoxInputModel();
      model.message = this.resourceService.getText('ifirm.common.areyousuretodelete');
      model.type = ConfirmationBoxType.YesNo;
      config.data = model;
      let instance = this.popupService.open<ConfirmationBoxComponent>(this.resourceService.getText('ifirm.common.delete'), ConfirmationBoxComponent, config);
      const subscription = instance.afterClosed.subscribe(x => {
        if (subscription) {
          subscription.unsubscribe();
        }
        if (x && x.result) {
        this.firmDocService.removeSelectedRecord(selectedRecord).subscribe(res => {
            if (res.success) {
              this.firmDocService.setLoaderSubject(true);
              this.firmDocPayload.Page = 0;
              this.firmDocService.loadFirmDocuments(this.firmDocPayload);
              this.firmDocService.scrollTop();
              this.clearServiceVariables();
            }
            else {
              this.toasterService.error(this.resourceService.getText('dms.delete.errormessage'));
            }
          })
        }
      });
  }
  isDeleteAllowed(file) {
    const userRoles = this.firmDocService.userRoles;
    if (file.Kind == fileKind.Contact || (file.Kind == fileKind.Folder && (file.Id <= 0 || file.IsSystemFolder || file.DefaultFolderId > 0))) return false;
    if (userRoles.DmsFirmDocuments && (file.EntityType == entityType.Firm || file.EntityType == entityType.User || file.EntityType == entityType.Hr)) {
      if (file.EntityType == entityType.Firm && userRoles.DmsInternalDocumentsViewEdit) return true;
      if (file.EntityType == entityType.Hr && userRoles.hrManager) return true;
      if (file.EntityType == entityType.User && file.EntityId > 0 && file.EntityId == userRoles.userId) return true;
      if (file.EntityType == entityType.User && file.EntityId > 0 && file.EntityId != userRoles.userId && userRoles.DmsUserFolderAdmin) return true;
    }
      return false;
  };
  selectAllFiles(event): void{
    this.firmDocResponse.source.value.forEach(file =>{
      file.selected = this.selectedAll; 
      if(event.target.checked){
        this.gridService.removeFromDataList(file);
        this.gridService.addToDataList(file);
      }
      else{
        this.gridService.removeFromDataList(file);
      }
    });
  }
 
  selectAllFilesChanged(){
   this.selectedAll = this.firmDocResponse.source.value.every(file => file.selected);
  }
  
  onChecked(event, file) {
    if (event && event.stopPropagation) {
      if (event.target.checked) {
        this.gridService.addToDataList(file);        
      } else {
        this.gridService.removeFromDataList(file);
      }
      event.stopPropagation();
    }
  }

   onFirmGridScroll() {
    if (this.firmDocPaginationResponse.source.value.IsLoadMore) {
      this.firmDocPayload.Page = this.firmDocPaginationResponse.source.value.PageSize + this.firmDocPayload.Page;
      this.firmDocPayload.IsContentSearch = false;
      this.firmDocService.setPayload$(this.firmDocPayload);
      this.firmDocService.loadFirmDocuments(this.firmDocPayload, this.firmDocPaginationResponse.source.value.IsLoadMore);
      this.selectAllFilesChanged();
      this.selectedAll = false;
    }
  }

  showIcons(file) {
    let elShowNote = document.getElementById('dmsGridShowMoreNote-' + file.Id + file.Kind + file.EntityId);
    elShowNote?.classList?.add("dms-showmoreonhover");
    let elShowProperty = document.getElementById('dmsProperties-' + file.Id + file.Kind + file.EntityId);
    elShowProperty?.classList?.add("dms-propertyBoxOnHover");
    let elShowVersion = document.getElementById('dmsVersion-' + file.Id + file.Kind + file.EntityId);
    elShowVersion?.classList?.add("dms-versionBoxOnHover");
    let elShowTag = document.getElementById('dmsTag-' + file.Id + file.Kind + file.EntityId);
    elShowTag?.classList?.add("dms-addtagonhover");
    let elShowFileLink = document.getElementById('dmsGridCopyLink-' + file.Id + file.Kind + file.EntityId);
    elShowFileLink?.classList?.add("dms-fileLinkOnHover");
  }

  hideIcons(file) {
    let elShowNote = document.getElementById('dmsGridShowMoreNote-' + file.Id + file.Kind + file.EntityId);
    elShowNote?.classList?.remove("dms-showmoreonhover");
    let elShowProperty = document.getElementById('dmsProperties-' + file.Id + file.Kind + file.EntityId);
    elShowProperty?.classList?.remove("dms-propertyBoxOnHover");
    let elShowVersion = document.getElementById('dmsVersion-' + file.Id + file.Kind + file.EntityId);
    elShowVersion?.classList?.remove("dms-versionBoxOnHover");
    let elShowTag = document.getElementById('dmsTag-' + file.Id + file.Kind + file.EntityId);
    elShowTag?.classList?.remove("dms-addtagonhover");
    let elShowFileLink = document.getElementById('dmsGridCopyLink-' + file.Id + file.Kind + file.EntityId);
    elShowFileLink?.classList?.remove("dms-fileLinkOnHover");
  }

  fileIcon(file) {
    let iconName;
    if (file.Type != null && file.Type.Extension != null && file.Type.Extension.toLowerCase() === "msg" && file.EmailMetaDataId > 0) {
      iconName = "email-logged";
    } else {
      iconName = file.Icon;
    }
    return "dms-" + iconName + " dms-type-icon";
  }

  lockClick(file){
    this.gridService.openLockClick(file,'firmDoc',this.firmDocPayload);
  }

  rowClick(file) {    
    if (file.Kind === fileKind.Folder) {
      this.passDataToRoot.emit(file);
      this.clearServiceVariables();
      const data = {
        Name: file.Name,
        EntityId: file.EntityId,
        Id: file.Id,
        Hierarchy: file.Hierarchy,
        EntityType: file.EntityType
      }
      this.firmDocService.creatBreadcrumbs(data);
    }
    else{
     this.gridService.getGridFile(file, 'firmDoc');
    }
      
  }

  fileNameMouseOver(file) {
    this.gridService.fileNameHierarchy(file);
  }
  

  onClickAddTags(file) {
    this.gridService.gridAddTags(file, 'firmDoc');
  }

  hideTags(file, fromIcon){
    this.gridService.hideGridTags(file, fromIcon);
  }

  showTags(file){
    this.gridService.showGridTags(file);
  } 

  updateTagList(file){     
    this.gridService.updateGridTagList(file);
  }

  removeTag(event): void {
    this.gridService.removeGridTag(event);
  }

  openNote(id,val){
    let instance = this.popupService.open<FileNotesComponent>(this.resourceService.getText('dms.filenotes'), FileNotesComponent, { data: { FileId: id } });
    const sub = instance.afterClosed.subscribe(response => {
      if (response) {
        this.firmDocService.setLoaderSubject(true);
        this.firmDocPayload.Page = 0;
        this.firmDocService.loadFirmDocuments(this.firmDocPayload);
        this.firmDocService.scrollTop();
      }
    });
  }

  showPropertiesDialog(file) {
    let data = {  Name: "", DefaultFolderId: null, isDeleted: false, file: { kind: file.Kind, EntityId: file.EntityId, EntityType: file.EntityType, Icon: file.Icon, Source: file.Source, EmailMetaDataId: file.EmailMetaDataId, Name: file.Name, id: file.Id, Hierarchy: file.Hierarchy, IsRecycleBin: false, isJobFolder: false, IsSystemFolder: file.IsSystemFolder } }
    let instance = this.popupService.open<FilePropertyComponent>(this.resourceService.getText('dms.propertiesdialog.properties'), FilePropertyComponent, {data:data});
    const sub = instance.afterClosed.subscribe(response => {
      if (response) {
        this.firmDocService.setLoaderSubject(true);
        this.firmDocPayload.Page = 0;
        this.firmDocService.loadFirmDocuments(this.firmDocPayload);
        this.firmDocService.scrollTop();
      }
    });
  }

  showListVersionDialog(file) {
    this.gridService.applyUserRoles();
    let data = {
      File: file,
      UserRoles: this.gridService.userInfoMap,
      broadCastFunc: this.broadCastFunc()
    };
    let instance = this.popupService.open<FileVersionComponent>(this.resourceService.getText('dms.versionsdialog.versionhistory'), FileVersionComponent, {data: data});
    const sub = instance.afterClosed.subscribe(response => {
      if (response) {
        this.firmDocService.setLoaderSubject(true);
        this.firmDocPayload.Page = 0;
        this.firmDocService.loadFirmDocuments(this.firmDocPayload);
        this.firmDocService.scrollTop();
      }
    });
  }

  broadCastFunc(){
      console.log('broadcast sent from popup');
  }

  addToClipboardLink(file){
    this.gridService.gridClipboardLink(file);    
  }

  sortType(sort: string) {
    this.firmDocService.setLoaderSubject(true);
    this.firmDocService.scrollTop();
    const payload: any = this.firmDocService.getPayload$();
    this.firmDocPayload = payload.source.value;
    this.firmDocPayload.Page = 0;
    this.firmDocPayload.IsContentSearch = true;
    switch (sort) {
      case "type":
        this.firmDocPayload.IsFileSearch = (this.firmDocPayload.IsFiltering) ? true : !this.firmDocPayload.IsFileSearch;
        this.firmDocService.setPayload$(this.firmDocPayload);
        break;
      default:
        this.firmDocPayload.SortColumn = sort;
        this.firmDocPayload.SortOrder = (this.firmDocPayload.SortOrder == 'desc') ? 'asc' : (this.firmDocPayload.SortOrder == 'asc') ? 'desc' : 'desc';
        this.firmDocService.setPayload$(this.firmDocPayload);
    }
    this.firmDocService.loadFirmDocuments(this.firmDocPayload);
  }

  sortClass(sort: string) {
    if (this.firmDocPayload.SortColumn === sort) {
      if (this.firmDocPayload.SortOrder === "asc") {
        return "ascendImg dms-sort";
      } else {
        return "descendImg dms-sort";
      }
    }
  }

  versionToolTip(fileCount) {
    return this.versionTooltipLabel?.replace(/(\{0\})/g, fileCount);
  }

  clearServiceVariables(){
    this.gridService.checkedDatalist = [];
    this.gridService.dmsRenameButton = true;
    this.gridService.dmsCopyMoveButton = true;
    this.gridService.dmsDownloadButton = true;
    this.gridService.dmsDeleteButton = true; 
    this.gridService.resetDownloadMergePDFButton();
  }
}
