import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FirmDocumentsComponent } from './firm-documents.component';

describe('FirmDocumentsComponent', () => {
  let component: FirmDocumentsComponent;
  let fixture: ComponentFixture<FirmDocumentsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FirmDocumentsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FirmDocumentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
