import { TestBed } from '@angular/core/testing';

import { FirmDocumentsService } from './firm-documents.service';

describe('FirmDocumentsService', () => {
  let service: FirmDocumentsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FirmDocumentsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
