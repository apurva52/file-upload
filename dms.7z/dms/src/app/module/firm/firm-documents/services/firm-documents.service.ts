import { Injectable } from '@angular/core';
import { ApiService, ResourceService, ToasterService } from '@ifirm';
import { DmsService } from 'projects/dms/src/app/dms.service';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import {FirmDocumentCommonRequest} from '../models/firm-document.model'
@Injectable({
  providedIn: 'root'
})
export class FirmDocumentsService {
  firmDocPayloadSub  = new BehaviorSubject<FirmDocumentCommonRequest>(null);
  firmDocdDfaultPayload: FirmDocumentCommonRequest;
  firmDocList$ = new BehaviorSubject<any>(null);
  responseList: any = [];
  userRoles = null;
  public loaderSubject = new BehaviorSubject<boolean>(false);
  payloadForFilter$ = new Subject();
  callFromButtons$ = new Subject();
  filterFileTypeSub$ = new BehaviorSubject<any>(null);
  filterFileTagsSub$ = new BehaviorSubject(null);
  firmPaginationRespone$ = new BehaviorSubject<any>(null);
  currentcrumb: string[];
  
  firmDocpayload(){
    this.firmDocdDfaultPayload = {
      EntityType: 1,
      EntityId: 1,
      FolderId: null,
      Hierarchy: null,
      SearchText: "",
      SearchNote: "",
      SearchTags : {
        Tags: [],
        JobTypeTags: [],
        ContactsTypeTags: [],
        PermentContactsTagType: 0,
        PermentTagType: 0,
        IsSearchPortalTag: false
      },
      Filters : {
      ContactGroupId:"",
      ContactList: [],
      ContactsTagList: [],
      DateFrom: "",
      DateTo:"",
      FileTypes:[],
      FirmSystemTag: "",
      IsArchivedContacts: false,
      IsFilterPortalTag: false,
      IsInActiveUser: false,
      IsJobClosed:"0",
      JobTypeTagList: [],
      MyRecentFiles: false,
      NoteAssignTo: "",
      NoteCreatedBy: "",
      NoteDueDate: "",
      NoteStatus: "",
      ShowArchivedContactsCheckBox:false,
      ShowInActiveUserCheckBox: false,
      TagList: [],
      UserFolders: 1,
      UserId: ""
      },
      Page: 0,
      SortColumn: "Name",
      SortOrder: "asc",
      IsFiltering: false,
      IsDeleted: false,
      IsOnlyUserFolderFiltering: false,
      DisplayArea: 2,
      HasMoreEntityRecords: null,
      HasMoreRecords: null,
      IsContentSearch: true,
      ContentSearchOffset: null,
      IsFileSearch: false,
      SearchMore: true
    }
    return  this.firmDocdDfaultPayload;
  }
  defaultFilter =  {
    ContactGroupId:"",
    ContactList: [],
    ContactsTagList: [],
    DateFrom: "",
    DateTo:"",
    FileTypes:[],
    FirmSystemTag: "",
    IsArchivedContacts: false,
    IsFilterPortalTag: false,
    IsInActiveUser: false,
    IsJobClosed:"0",
    JobTypeTagList: [],
    MyRecentFiles: false,
    NoteAssignTo: "",
    NoteCreatedBy: "",
    NoteDueDate: "",
    NoteStatus: "",
    ShowArchivedContactsCheckBox:false,
    ShowInActiveUserCheckBox: false,
    TagList: [],
    UserFolders: 1,
    UserId: ""
    }
    isEnableConditionalButton: boolean = false;
    FolderHierarchyList = [];
    isFilterSearchArea: boolean = false;
    public listNoRecords = new BehaviorSubject<boolean>(false);
  constructor(private api: ApiService, private toasterService: ToasterService, private resourceService: ResourceService,
    private dmsServices: DmsService) { 
    this.setPayload$(this.firmDocpayload());
  }
  defaultFolderIds = null;
  defaultFolderId = null;
  shareNullOnFolderId = false;
  selectedFolderName = null;
  firmDocFolderName = null;
  loadFirmDocuments(payload, isLoadMore?: boolean) {
    // console.log("load firm callinned")
    this.FolderHierarchyList = [];
    this.searchFirmDocs(payload).then(data => {
    this.setLoaderSubject(false);
    this.responseList = isLoadMore ? this.responseList.concat(data.DocumentContractList) : data.DocumentContractList;
    this.FolderHierarchyList = data?.FolderHierarchyList;
    if (this.updateFolderId(payload)){
      const index = this.responseList.findIndex(item => item.Id !== null);
      if (index >= 0){
        this.defaultFolderIds = this.responseList[index].Id;
        this.selectedFolderName = this.responseList[index].Name;
      }
    }
    if (this.updateFolderIdForInternal(payload)){
      if (data){
        if (this.FolderHierarchyList?.length < 2){
          this.shareNullOnFolderId = true;
        }else {
          this.shareNullOnFolderId = false;
        }
      }
    }
    this.setFirmDocList$(this.responseList);
    this.setFirmPaginationSubject(data.PaginationInfo);
      if(this.responseList.length === 0){
        this.setNoRecordsSubject(true);
      }
      else{
        this.setNoRecordsSubject(false);
      }
    })
  }
  updateFolderId(payload){
    return payload.EntityId === 1 && payload.EntityType === 1 && payload.FolderId === null;
  }
  updateFolderIdForInternal(payload){
    return payload.EntityId === 1 && payload.EntityType === 1;
  }
  filterTags(payload) {
    this.filterTagList(payload).then(data => {
    this.setLoaderSubject(false);
    this.setFilterTags(data);
    })
  }
  filterTypes(payload) {
    this.filterFileTypes(payload).then(data => {
    this.setLoaderSubject(false);
    this.setFilterFilesType(data);
    })
  }
  searchFirmDocs(payload: any): Promise<any> {
    return this.api.post<any>('/dms/api/documentsearch/searchdocuments',null, payload).toPromise();
  }

  filterFileTypes(data:any): Promise<any>{
    return this.api.post<any>('/dms/api/documentsearch/getfiletypes/',null,data).toPromise();
  }

  filterTagList(data:any): Promise<any>{
    return this.api.post<any>('dms/api/tag/getfiltertaglist',null,data).toPromise();
  }

  setPayload$(response: FirmDocumentCommonRequest) {
    this.firmDocPayloadSub.next(response);
  }
  getPayload$() {
    return this.firmDocPayloadSub.asObservable();
  }
  resetPayload$(){
    this.setPayload$(this.firmDocpayload());
  }

  setFirmDocList$(response: any) {
    this.firmDocList$.next(response);
  }
  getFirmDocList$() {
    return this.firmDocList$.asObservable();
  }
  setLoaderSubject(val: boolean) {
    this.loaderSubject.next(val);
  }
  setFilterFilesType(response) {
    this.filterFileTypeSub$.next(response);
  }
  getFilterFilesType() {
    return this.filterFileTypeSub$.asObservable();
  }
  setFilterTags(response) {
    this.filterFileTagsSub$.next(response);
  }
  getFilterTags() {
    return this.filterFileTagsSub$.asObservable();
  }
  getLoaderSubject() {
    return this.loaderSubject.asObservable();
  }
  setPayloadForFilter(response){
    this.payloadForFilter$.next(response);
  }
  getPayloadForFilter(){
    return this.payloadForFilter$.asObservable();
  }
  setButtonAlert(response){
    this.callFromButtons$.next(response);
  }
  getButtonAlert(){
    return this.callFromButtons$.asObservable();
  }
  creatBreadcrumbs(folder) {
    this.dmsServices.breadcrumb$.subscribe((value) => {
      this.currentcrumb = value;
    });
    const newBreadCrumbs = [...this.currentcrumb, folder];
    this.dmsServices.updateBreadcrumbs(newBreadCrumbs);
  }

  public setFirmPaginationSubject(val: any) {
    this.firmPaginationRespone$.next(val);
  }

  public getFirmPaginationSubject() {
    return this.firmPaginationRespone$.asObservable();
  }

  public scrollTop(){
    const scrollContainer = document.querySelector('#dmsFileListTable');
    if (scrollContainer) {
      scrollContainer.scrollTop = 0;
    }
  }
  isHomePageEnableOnFilter(defaultPayload){
    const payload: any = this.getPayload$();
    const defaultResponse = JSON.stringify(defaultPayload);
    const defaulLatestPayload = JSON.parse(defaultResponse)
    const response = JSON.stringify(payload.source.value);
    const latestPayload = JSON.parse(response)
    const deleteArray = ['UserFolders', 'ShowInActiveUserCheckBox', 'IsInActiveUser', 'IsArchivedContacts'];
    deleteArray.forEach(element => {
      delete defaulLatestPayload?.[element];
      delete latestPayload.Filters?.[element];
    });
    const result = JSON.stringify(defaulLatestPayload) === JSON.stringify(latestPayload.Filters);
    return result;
  }
  isdefaultFilter(defaultPayload){
    const payload: any = this.getPayload$();
    const defaultResponse = JSON.stringify(defaultPayload);
    const defaulLatestPayload = JSON.parse(defaultResponse)
    defaulLatestPayload.IsArchivedContacts = false;
    const response = JSON.stringify(payload.source.value);
    const latestPayload = JSON.parse(response)
    const result = JSON.stringify(defaulLatestPayload) === JSON.stringify(latestPayload.Filters);
    return result;
  }
  
  
  addSearchResultBreadcrumb(firmDocPayload: FirmDocumentCommonRequest){
    const searchKey = this.resourceService.getText('dms.common.searchresult') ? this.resourceService.getText('dms.common.searchresult') : 'Search Result';
    if (this.currentcrumb){
      const currentBreadcrumb:any = this.currentcrumb[this.currentcrumb.length - 1];
      if (firmDocPayload.IsFiltering || firmDocPayload.SearchText !="" || firmDocPayload.SearchNote !="" ||
        firmDocPayload.SearchTags.Tags.length>0){
        if (currentBreadcrumb.Name !== searchKey){
          const data = {
            Name: searchKey,
            isColorChange: true
          }
          this.creatBreadcrumbs(data);
        }
      }else {
        if (currentBreadcrumb.Name === searchKey){
          const newBreadCrumbs: any = this.currentcrumb.slice(0, this.currentcrumb.length-1)
          this.dmsServices.updateBreadcrumbs(newBreadCrumbs);
        }
      }
    }
  }
  removeSelectedRecord(selectedRecord): Observable<any>{
    return this.api.post<any>('/dms/api/recyclebin/movetorecyclebin',null,{MoveToRecycleFileFolderList:selectedRecord});
  }

  public setNoRecordsSubject(val: boolean) {
    this.listNoRecords.next(val);
  }

  public getNoRecordsSubject() {
    return this.listNoRecords.asObservable();
  }

}
