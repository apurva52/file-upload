import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { APP_MODULES} from '../../constants/app-modules';
import { FirmDocumentsRoutingModule } from './firm-documents-routing.module';
//import { DocumentGridComponent } from '../../module/client/client-documents/components/client-documents-root-grid/client-documents-root-grid.component';
import { BreadcrumbsComponent } from '../../shared/tools/breadcrumbs/breadcrumbs.component';
import { SearchBarComponent } from '../../shared/tools/search-bar/search-bar.component';
import { IFirmButtonModule } from '@ifirm';
import { FirmDocumentsComponent } from './firm-documents/firm-documents.component';
import { FilterComponentsComponent } from '../../filter-components/filter-components.component';
import { FirmDocumentRootComponent } from './firm-documents/components/firm-document-root/firm-document-root.component';
import { FirmDocumentRootGridComponent } from './firm-documents/components/firm-document-root-grid/firm-document-root-grid.component';
import { FirmDocumentRootCheckboxGridComponent } from './firm-documents/components/firm-document-root-checkbox-grid/firm-document-root-checkbox-grid.component';
import { DirectivesModule } from '../../shared/directives/directives.module';
import { NgSelectModule } from '@ng-select/ng-select';

@NgModule({
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  declarations: [
    FirmDocumentsComponent,
    FirmDocumentRootComponent,
    FirmDocumentRootGridComponent,
    FirmDocumentRootCheckboxGridComponent
  ],
  imports: [
    CommonModule,
    APP_MODULES,
    FirmDocumentsRoutingModule,
    // LocalizationModule,
    FilterComponentsComponent,
    BreadcrumbsComponent,
    SearchBarComponent,
    DirectivesModule,
    IFirmButtonModule,
    NgSelectModule,
    
  ]
})
export class FirmModule { }
