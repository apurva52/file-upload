import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ImportsRoutingModule } from './imports-routing.module';
import { ImportsComponent } from './imports/imports.component';



@NgModule({
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  declarations: [
    ImportsComponent
  ],
  imports: [
    CommonModule,
    ImportsRoutingModule
  ]
})
export class ImportsModule { }
