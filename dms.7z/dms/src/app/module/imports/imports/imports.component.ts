import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-imports',
  templateUrl: './imports.component.html',
  styleUrls: ['./imports.component.scss']
})
export class ImportsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
