import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { APP_MODULES} from '../../constants/app-modules';
import { RecyclebinRoutingModule } from './recyclebin-routing.module';
import { RecyclebinComponent } from './recyclebin/recyclebin.component';
import { RecycleBinCheckboxDataGridComponent } from './recyclebin-checkbox-data-grid/recyclebin-checkbox-data-grid.component';
import { SearchButtonActionComponent } from './searchbar-button-action/search-button-action/search-button-action.component';
import { FormsModule } from '@angular/forms';
import { BreadcrumbsComponent} from '../../shared/tools/breadcrumbs/breadcrumbs.component';
import { FilterComponentsComponent } from './../../filter-components/filter-components.component';
import { DirectivesModule } from '../../shared/directives/directives.module';

@NgModule({
  declarations: [
    RecyclebinComponent,
    RecycleBinCheckboxDataGridComponent,
    SearchButtonActionComponent
  ],
  imports: [
    CommonModule,
    APP_MODULES,
    DirectivesModule,
    RecyclebinRoutingModule,
    FormsModule,
    BreadcrumbsComponent,
    FilterComponentsComponent
  ],
  exports: [FilterComponentsComponent]
})
export class RecyclebinModule { }
