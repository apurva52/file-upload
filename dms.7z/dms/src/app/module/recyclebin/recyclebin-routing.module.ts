import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RecyclebinComponent } from './recyclebin/recyclebin.component'

const routes: Routes = [
  { path: '', component: RecyclebinComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RecyclebinRoutingModule { }
