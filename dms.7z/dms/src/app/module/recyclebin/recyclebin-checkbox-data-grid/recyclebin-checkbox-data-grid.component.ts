import { Component, OnInit } from '@angular/core';
import { GridColumnModel, ToasterService, ResourceService, ModalPopupService } from '@ifirm';
import { SearchCriteriaRecycleBin } from '../../recyclebin/recyclebin/recyclebin.model';
import { RecycleBinService } from '../../recyclebin/recyclebin/recyclebin.service';
import { fileKind } from '../../../../app/constants/app-constants';
import { DmsService } from '../../../dms.service';
import { FilePropertyComponent } from '../../../dialogs/file-property/file-property.component';

@Component({
  selector: 'dms-recyclebin-checkbox-data-grid',
  templateUrl: './recyclebin-checkbox-data-grid.component.html',
  styleUrls: ['./recyclebin-checkbox-data-grid.component.scss']
})
export class RecycleBinCheckboxDataGridComponent implements OnInit {
  allSelection: boolean = false;
  loader: any;
  recyclebinList: any;
  recyclePayload: SearchCriteriaRecycleBin;
  recyclebinPaginationResp: any;
  purgeResource: any;
  recycleGridColumns: GridColumnModel[] = [];
  selectedAll: any;
  currentcrumb: string[];
  preventFileNameMouseOver: boolean = false;
  noRecordsError: any;

  constructor(private recycleBinService: RecycleBinService, private toasterService: ToasterService,
    private dmsServices: DmsService, private resourceService: ResourceService, private popupService: ModalPopupService) {
    this.loader = this.recycleBinService.getLoaderSubject();
    this.recyclebinList = this.recycleBinService.getRecycleListSubject();
    this.recyclebinPaginationResp = this.recycleBinService.getRecyclePaginationSubject();
    this.selectedAll = this.recycleBinService.getAllSelected();
    this.noRecordsError = this.recycleBinService.getNoRecordsSubject();
  }


  ngOnInit(): void {
    this.recycleBinService.resetPayloadSubject();
    const payload: any = this.recycleBinService.getPayloadSubject();
    this.recyclePayload = payload.source.value;
    this.recycleBinService.getPurgeColumnResources().subscribe(value => {
      this.purgeResource = value;
    });
    this.recycleBinService.getAllSelected().subscribe((value)=>{
      this.selectedAll = value;
    });
   
  }

  selectAllFiles(event): void{
    this.recyclebinList.source.value.forEach(file =>{
      file.selected = this.selectedAll; 
      if(event.target.checked){
        this.recycleBinService.removeFromDataList(file);
        this.recycleBinService.addToDataList(file);
        this.recycleBinService.setAllowAction(true);
      }
      else{
        this.recycleBinService.removeFromDataList(file);
        if(this.recycleBinService.checkedDatalist.length === 0 ){
             this.recycleBinService.setAllowAction(false);
        }
      }
    });
  }
 
  selectAllFilesChanged(){
   this.selectedAll = this.recyclebinList.source.value.every(file => file.selected);
  }

  creatBreadcrumbs(folder) {
    this.dmsServices.breadcrumb$.subscribe((value) => {
      this.currentcrumb = value;
    });
    const newBreadCrumbs = [...this.currentcrumb, folder];
    this.dmsServices.updateBreadcrumbs(newBreadCrumbs);
  }

  onChecked(event, file) {
    if (event && event.stopPropagation) {
      if (event.target.checked) {
        this.recycleBinService.setAllowAction(true);
        this.recycleBinService.addToDataList(file);        
      } else {
        this.recycleBinService.removeFromDataList(file);
        if (this.recycleBinService.checkedDatalist.length === 0) {
          this.recycleBinService.setAllowAction(false);
        }
      }
      event.stopPropagation();
    }
  }

  fileIcon(file) {
    let iconName;
    if (file.Type != null && file.Type.Extension != null && file.Type.Extension.toLowerCase() === "msg" && file.EmailMetaDataId > 0) {
      iconName = "email-logged";
    } else {
      iconName = file.Icon;
    }
    return "dms-" + iconName + " dms-type-icon";
  }

  showIcons(file) {
    let el = document.getElementById('dmsProperties-' + file.Id + file.Kind + file.EntityId);
    el.classList.add("dms-propertyBoxOnHover");
  }

  hideIcons(file) {
    let el = document.getElementById('dmsProperties-' + file.Id + file.Kind + file.EntityId);
    el.classList.remove("dms-propertyBoxOnHover");
  }

  showPropertiesDialog(file) {
    let data = {  Name: "", DefaultFolderId: null, isDeleted: true, file: { kind: file.Kind, EntityId: file.EntityId, EntityType: file.EntityType, Icon: file.Icon, Source: file.Source, EmailMetaDataId: file.EmailMetaDataId, Name: file.Name, id: file.Id, Hierarchy: file.Hierarchy, IsRecycleBin: true, isJobFolder: false, IsSystemFolder: file.IsSystemFolder } }
    let instance = this.popupService.open<FilePropertyComponent>(this.resourceService.getText('dms.propertiesdialog.properties'), FilePropertyComponent, {data:data});
    const sub = instance.afterClosed.subscribe(response => {
      if (response) {
        this.recycleBinService.setLoaderSubject(true);
        this.recyclePayload.Page = 0;
        this.recycleBinService.loadRecycleList(this.recyclePayload);
        this.recycleBinService.scrollTop();
      }
    });
  }

  sortType(sort: string) {
    this.recycleBinService.setLoaderSubject(true);
    this.recycleBinService.scrollTop();
    this.recyclePayload.Page = 0;
    this.recyclePayload.IsContentSearch = false;
    this.recyclePayload.IsPurgeDate = false;
    switch (sort) {
      case "type":
        this.recyclePayload.IsFileSearch = (this.recyclePayload.IsFiltering) ? true : !this.recyclePayload.IsFileSearch;
        this.recycleBinService.setPayloadSubject(this.recyclePayload);
        break;
      default:
        this.recyclePayload.SortColumn = sort;
        this.recyclePayload.SortOrder = (this.recyclePayload.SortOrder == 'desc') ? 'asc' : (this.recyclePayload.SortOrder == 'asc') ? 'desc' : 'desc';
        this.recycleBinService.setPayloadSubject(this.recyclePayload);
    }
    this.recycleBinService.loadRecycleList(this.recyclePayload);
  }

  sortClass(sort: string) {
    if (this.recyclePayload.SortColumn === sort) {
      if (this.recyclePayload.SortOrder === "asc") {
        return "ascendImg dms-sort";
      } else {
        return "descendImg dms-sort";
      }
    }
  }

  rowClick(file) {
    this.recycleBinService.setCleanSearch();
    if (file.Kind === fileKind.Folder) {
      const data = {
        Name: file.Name,
        EntityId: file.EntityId,
        Id: file.Id,
        Hierarchy: file.Hierarchy,
      };
      this.creatBreadcrumbs(data);
      this.recycleBinService.setLoaderSubject(true);
      this.recyclePayload.FolderId = file.Id;
      this.recyclePayload.Hierarchy = file.Hierarchy;
      this.recycleBinService.setPayloadSubject(this.recyclePayload);
      this.recycleBinService.loadRecycleList(this.recyclePayload);
      this.recycleBinService.loadRecycleBinFilterTypes(this.recyclePayload);
      this.recycleBinService.setAllSelected(false);
      this.recycleBinService.checkedDatalist = [];
      this.recycleBinService.setAllowAction(false);
      this.recycleBinService.setfolderId(file.Id);
    }
  }

  onScrolled() {
    if (this.recyclebinPaginationResp.source.value.IsLoadMore) {
      this.recyclePayload.Page = this.recyclebinPaginationResp.source.value.PageSize + this.recyclePayload.Page;
      this.recyclePayload.IsContentSearch = false;
      this.recyclePayload.IsPurgeDate = false;
      this.recycleBinService.setPayloadSubject(this.recyclePayload);
      this.recycleBinService.loadRecycleList(this.recyclePayload, this.recyclebinPaginationResp.source.value.IsLoadMore);
      this.selectAllFilesChanged();
      this.selectedAll = false;
    }
  }

  fileNameMouseOver(file) {
    if (file.Hierarchy) {
      
      if (!file.HierarchyPath) {
        if (!this.preventFileNameMouseOver) {
          this.preventFileNameMouseOver = true;
          this.recycleBinService.getFolderHierarchy(file.Hierarchy).subscribe({
            next: (response) => {
              if (response && response.FolderHierarchies) {               
                response.FolderHierarchies.map(function (value) {
                  file.HierarchyPath = !file.HierarchyPath ? value.FolderName : file.HierarchyPath + '\\' + value.FolderName;
                });
                file.HierarchyPath = file.HierarchyPath + '\\' + file.Name;
                this.preventFileNameMouseOver = false;
              }
            },
            error: (e) => {
              this.toasterService.error(this.resourceService.getText('ifirm.common.error'));
            }
          })
        }
      }      
    }
    else {
      file.HierarchyPath = file.Name;
    }
  }

}
