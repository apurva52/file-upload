import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RecycleBinCheckboxDataGridComponent } from './recyclebin-checkbox-data-grid.component';

describe('RecycleBinCheckboxDataGridComponent', () => {
  let component: RecycleBinCheckboxDataGridComponent;
  let fixture: ComponentFixture<RecycleBinCheckboxDataGridComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RecycleBinCheckboxDataGridComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RecycleBinCheckboxDataGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
