import { Component, OnDestroy, OnInit } from '@angular/core';
import {
  ResourceService,
  ModalPopupConfig,
  ConfirmationBoxType,
  ConfirmationBoxComponent,
  ModalPopupService,
  ToasterService,
} from '@ifirm';
import { ErrorBoxComponent } from 'projects/ifirm-common-components/src/lib/modal-popup/error-box/error-box.component';
import { RecycleBinService } from '../../recyclebin/recyclebin.service';
import { SearchCriteriaRecycleBin } from '../../recyclebin/recyclebin.model';
import { DmsService } from 'projects/dms/src/app/dms.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-search-button-action',
  templateUrl: './search-button-action.component.html',
  styleUrls: ['./search-button-action.component.scss'],
})
export class SearchButtonActionComponent implements OnInit, OnDestroy {
  constructor(
    private resourceService: ResourceService,
    private popupService: ModalPopupService,
    private toasterService: ToasterService,
    private recycleBinService: RecycleBinService,
    private dmsServices: DmsService
  ) {
    const payload: any = this.recycleBinService.getPayloadSubject();
    this.recyclePayload = payload.source.value;    
  }
  ngOnDestroy(): void {
    this.recyclebinSub?.unsubscribe();
    this.recyclebinTabSub?.unsubscribe();
  }
  recyclebinSub: Subscription;
  recyclebinTabSub: Subscription;
  displayOverAllocationMessage: boolean = false;
  OverAllocationMessage: string = '';
  searchtext: string = '';
  placeHoldervalue = this.resourceService.getText('dms.filelist.searchtextplaceholder');
  isPurgeDate: boolean = false;
  purgeDateButtonResource: any;
  purgeDateColumnResource: any;
  showRestore: boolean = false;
  showDelete: boolean = false;
  canRestore: boolean = false;
  canDelete: boolean = false;
  loader: boolean = false;
  userRoles: any;
  recyclePayload: SearchCriteriaRecycleBin;
  folderId:any ;

  ngOnInit(): void {
    this.loader = true;  
    this.resetPurgeDateParams();
    this.getOverAllocatedSpace();
    this.applyUserRoles();
    this.recycleBinService.getAllowAction().subscribe(data => {
      this.canRestore = data;
      this.canDelete = data;
    });
    this.loader = false;

    // this.dmsServices.breadCrumbClickedEvent.subscribe(data =>{
    this.recyclebinSub = this.dmsServices.breadCrumbData$.subscribe(data =>{
      this.recyclePayload.FolderId = data.Id;
      this.recyclePayload.Hierarchy = data.Hierarchy;
      this.recyclebinTabSub = this.resourceService.tabName$.subscribe((value)=>{
        if(value === 'Recycle Bin'){
          this.recycleBinService.setPayloadSubject(this.recyclePayload);
           this.recycleBinService.setfolderId(data.Id);
           this.cleanSearch();
           this.recycleBinService.loadRecycleList(this.recyclePayload);
           this.recycleBinService.loadRecycleBinFilterTypes(this.recyclePayload);
        }
      });
    });
    this.recycleBinService.getCleanSearch().subscribe(()=>{
      this.cleanSearch();
    });
    this.folderId = this.recycleBinService.getfolderId();
  }

  getOverAllocatedSpace() {
    this.recycleBinService.getOverAllocatedSpace().then((result) => {
        if (result) {
          this.displayOverAllocationMessage =result.OverAllocatedSpace != '' ? true : false;
          if ( result.LastGeneratedDateTime != null && result.LastGeneratedDateTime != '') {
            var lastGeneratedText ='(' + this.resourceService.get('dms.report.lastgenerated',[result.LastGeneratedDateTime]) +')';            
            this.OverAllocationMessage = result.OverAllocatedSpace != 'null' ? this.resourceService.getText('dms.home.overallocationmessage',[result.OverAllocatedSpace]) + lastGeneratedText: '';
            } else {
                this.OverAllocationMessage = result.OverAllocatedSpace != 'null' ? this.resourceService.getText('dms.home.overallocationmessage',[result.OverAllocatedSpace]) : '';
          }
        }
      }).catch((exception) => {
        this.displayOverAllocationMessage = false;
        this.OverAllocationMessage = '';
      });
  };

  deletePermenantely() {
    var deleteMessage = this.resourceService.getText('dms.delete.permanentconfirm');
    this.showConfirmDeleteDialog(deleteMessage);
  }

  showConfirmDeleteDialog(deleteMessage: string): void {    
    const config: ModalPopupConfig<any> = new ModalPopupConfig<any>();
    config.data = { message: deleteMessage, type: ConfirmationBoxType.YesNo };
    let instance = this.popupService.open<ConfirmationBoxComponent>(this.resourceService.getText('ifirm.common.delete'),ConfirmationBoxComponent,config);
    const subscription = instance.afterClosed.subscribe((x) => {
      if (subscription) {
        subscription.unsubscribe();
      }
      var selectedFiles: any[] = this.recycleBinService.getList();
      var deleteFilesList: any[] = [];
      if (x && x.result) {
        this.loader = true;
        selectedFiles.forEach((file: any) => {
          deleteFilesList.push({
            Id: file.Id,
            Guid: file.Guid,
            Name: file.Name,
            StoragePath: file.StoragePath,
            Hierarchy: file.Hierarchy,
            Kind: file.Kind,
            Type: file.Type,
            EntityType: file.EntityType,
            EntityId: file.EntityId,
          });
        });
        var deleteContract = {
          DeleteFileFolderList: deleteFilesList,
        };

        this.recycleBinService.deleteDocuments(deleteContract).then((data) => {
            if (data.success === true) {
              this.loader = false;
              this.recycleBinService.loadRecycleList(this.recyclePayload);
              this.recycleBinService.scrollTop();
              this.recycleBinService.setAllowAction(false);
            this.recycleBinService.checkedDatalist = []; 
            this.recycleBinService.setAllSelected(false);
            } else if (data.ValidationCode > 0) {
              this.loader = false;
              if ( data.maxallowedfilecount > 0 && data.maxallowedfoldercount > 0 && (data.userselectedfilecount > 0 || data.userselectedfoldercount > 0) ) {
                this.popupService.info(this.resourceService.getText("dms.common.limitexceededheader"),this.resourceService.getText(`dms.validationmessages.${data.ValidationCode}`,[data.maxallowedfilecount, data.maxallowedfoldercount, data.userselectedfilecount, data.userselectedfoldercount]));
                this.recycleBinService.checkedDatalist = []; 
                this.recycleBinService.setAllowAction(false);
                this.recycleBinService.setAllSelected(false);
              } else {
                this.popupService.open<ErrorBoxComponent>(this.resourceService.getText( 'ifirm.common.error'),ErrorBoxComponent,{data: this.resourceService.get(`dms.validationmessages.${data.ValidationCode}`),});
                this.recycleBinService.checkedDatalist = [];
                this.recycleBinService.setAllowAction(false);
                this.recycleBinService.setAllSelected(false);
              }
            } else {
              this.loader = false;
              this.popupService.open<ErrorBoxComponent>(this.resourceService.getText('ifirm.common.error'),ErrorBoxComponent,{data: this.resourceService.getText('dms.delete.errormessage'),});
              this.recycleBinService.checkedDatalist = [];
              this.recycleBinService.setAllowAction(false);
              this.recycleBinService.setAllSelected(false);
            }
          })
          .catch((exception) => {
            this.loader = false;
            this.popupService.open<ErrorBoxComponent>(this.resourceService.getText('ifirm.common.error'), ErrorBoxComponent,{ data: this.resourceService.getText('dms.common.error') });
            this.recycleBinService.checkedDatalist = [];
            this.recycleBinService.setAllowAction(false);
            this.recycleBinService.setAllSelected(false);
          }).finally(() => {
            this.loader = false;
          });
      }
      else{
        this.loader = false;
      }
    });
    this.loader = false;
  };

  showConfirmRestoreDialog() {
    var selectedFiles: any[] = this.recycleBinService.getList();
    var restoreFilesList: any[] = [];
    this.loader = true;
    selectedFiles.forEach((file: any) => {
      restoreFilesList.push({
        Id: file.Id,
        Guid: file.Guid,
        Name: file.Name,
        Hierarchy: file.Hierarchy,
        Kind: file.Kind,
        Type: file.Type,
        EntityType: file.EntityType,
        EntityId: file.EntityId,
        OriginalLocation: file.OriginalLocation,
        LinkUrl: file.LinkUrl,
      });
    });

    var restoreContract = {
      RestoreFileFolderList: restoreFilesList,
    };

    this.recycleBinService.restoreDocuments(restoreContract).then((data) => {
         if (data.success) {
          this.recycleBinService.loadRecycleList(this.recyclePayload);
          this.recycleBinService.scrollTop();
          this.recycleBinService.setAllowAction(false);
          this.recycleBinService.checkedDatalist = [];  
          this.recycleBinService.setAllSelected(false);
          this.loader = false;
          }
           else {
          if (data.message == 'cwfileexists') {this.toasterService.error(this.resourceService.getText('dms.restore.casewarefileexist'));
            this.recycleBinService.loadRecycleList(this.recyclePayload);
            this.recycleBinService.checkedDatalist = [];
            this.recycleBinService.setAllowAction(false);
                this.recycleBinService.setAllSelected(false);
          }
           else if (data.message == 'emailfileexists') {this.toasterService.error(this.resourceService.getText('dms.restore.emailfileexist'));
            this.recycleBinService.loadRecycleList(this.recyclePayload);
            this.recycleBinService.checkedDatalist = [];
            this.recycleBinService.setAllowAction(false);
                this.recycleBinService.setAllSelected(false);
          } 
          else if (data.message == 'linkUrlfileexist') {this.toasterService.error(this.resourceService.getText('dms.restore.linkurlfileexist'));
            this.recycleBinService.loadRecycleList(this.recyclePayload);
            this.recycleBinService.checkedDatalist = [];
            this.recycleBinService.setAllowAction(false);
            this.recycleBinService.setAllSelected(false);
          } else if (data.ValidationCode > 0) {
             if (
               data.maxallowedfilecount > 0 && data.maxallowedfoldercount > 0 && (data.userselectedfilecount > 0 || data.userselectedfoldercount > 0)) {
                this.popupService.info(this.resourceService.getText("dms.common.limitexceededheader"),this.resourceService.getText(`dms.validationmessages.${data.ValidationCode}`,[data.maxallowedfilecount, data.maxallowedfoldercount, data.userselectedfilecount, data.userselectedfoldercount]));
               this.recycleBinService.checkedDatalist = [];
               this.recycleBinService.setAllowAction(false);
                this.recycleBinService.setAllSelected(false);
             }
              else { this.popupService.open<ErrorBoxComponent>(this.resourceService.getText( 'ifirm.common.error'),ErrorBoxComponent,{data: this.resourceService.get(`dms.validationmessages.${data.ValidationCode}`),});
              this.recycleBinService.checkedDatalist = [];
              this.recycleBinService.setAllowAction(false);
                this.recycleBinService.setAllSelected(false);
             };
          }
           else {
            this.toasterService.error( this.resourceService.getText('dms.restore.errormessage'));
            this.recycleBinService.checkedDatalist = [];
            this.recycleBinService.setAllowAction(false);
            this.recycleBinService.setAllSelected(false);
          };
          this.loader = false;
        };
      })
      .catch((exception) => {this.toasterService.error(this.resourceService.getText('dms.restore.errormessage'));
        this.recycleBinService.checkedDatalist = [];
        this.recycleBinService.setAllowAction(false);
        this.recycleBinService.setAllSelected(false);
        this.loader = false;
      }).finally(() => {
        this.loader = false;
      });
  }

  searchDocuments() {
    this.searchtext = this.searchtext.trimStart();
    if (this.recyclePayload.SearchText !== this.searchtext) {
      if (this.searchtext.length !== 1) {
        this.recyclePayload.SearchText = this.searchtext;
        this.recyclePayload.FolderId = this.folderId.source.value;
        this.recycleBinService.setLoaderSubject(true);
        this.recycleBinService.setPayloadSubject(this.recyclePayload);
        this.recycleBinService.loadRecycleList(this.recyclePayload);
        this.recycleBinService.scrollTop();
        this.recycleBinService.setAllowAction(false);
         this.recycleBinService.checkedDatalist = [];
         this.recycleBinService.setAllSelected(false);
      }
    }
  }

  cleanSearch() {
    this.searchtext = '';
    this.recyclePayload.SearchText = "";
    this.recyclePayload.SearchNote = "";
    this.recycleBinService.setPayloadSubject(this.recyclePayload);
  }

  clearSearch() {
    this.cleanSearch();
    this.recycleBinService.setLoaderSubject(true);
    this.recycleBinService.loadRecycleList(this.recyclePayload);
    this.recycleBinService.scrollTop();
  }

  resetPurgeDateParams() {
    this.isPurgeDate = false;
    this.purgeDateButtonResource = this.resourceService.getText('dms.recyclebin.displaypurgeon');
    this.purgeDateColumnResource = this.resourceService.getText('dms.recyclebin.purgeon');
  }

  showPurgeDateColumn() {
    const payload: any = this.recycleBinService.getPayloadSubject();
    this.recyclePayload = payload.source.value;
    console.log('purge data payload----',this.recyclePayload);
    this.isPurgeDate = this.isPurgeDate ? false : true;
    this.purgeDateButtonResource = this.isPurgeDate ? this.resourceService.getText('dms.recyclebin.displaydeletedon') : this.resourceService.getText('dms.recyclebin.displaypurgeon');
    this.recyclePayload.IsPurgeDate = !this.recyclePayload.IsPurgeDate;
    this.recycleBinService.setPayloadSubject(this.recyclePayload);
    this.recycleBinService.setLoaderSubject(true);
    this.recycleBinService.loadRecycleList(this.recyclePayload);
    this.recycleBinService.scrollTop();
    this.recycleBinService.setPurgeColumnResources();
  }

  applyUserRoles() {
    if(this.dmsServices.userInfoMap.get('userInfoValue') != undefined){
      const response = this.dmsServices.userInfoMap.get('userInfoValue');
      this.showRestore = response.DmsViewRecycleBinRestore || response.DmsFirmDocuments;
      this.showDelete = response.DmsViewPermanentDelete || response.DmsFirmDocuments;
    }
  }
}
