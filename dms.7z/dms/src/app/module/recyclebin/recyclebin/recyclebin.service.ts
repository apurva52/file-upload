import { Injectable } from '@angular/core';
import { ApiService, ResourceService, ToasterService } from '../../../../../../ifirm-common-components/src/public-api';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { SearchCriteriaRecycleBin, RecycleBinRowsModel } from './recyclebin.model';
import { FileTypeResponse } from '../../../shared/filters/model/user.model';

@Injectable({
  providedIn: 'root'
})
export class RecycleBinService {
  constructor(private api: ApiService, private toasterService: ToasterService, private resourceService: ResourceService) {
    this.setPayloadSubject(this.payloads());
   }

  private recyclePayloadSubject  = new BehaviorSubject<SearchCriteriaRecycleBin>(null);
 public defaultPayload: SearchCriteriaRecycleBin;
 public recyclebinListSubject = new BehaviorSubject<RecycleBinRowsModel>(null);
 public recyclebinPaginationRespSubject = new BehaviorSubject<RecycleBinRowsModel>(null);
 public loaderSubject = new BehaviorSubject<boolean>(false);
 public checkedDatalist :any[] = [];
 public responseList: any = [];
 public columnTypeSource = new BehaviorSubject<string>('delete');
 public allowActionSubject = new BehaviorSubject<boolean>(false);
 public recyclebinFilterTypesSubject = new BehaviorSubject<FileTypeResponse[]>(null);
 public allSelected = new BehaviorSubject<boolean>(false);
 public cleanSearch = new Subject<void>();
 public folderId = new BehaviorSubject<number|null>(null);
 public listNoRecords = new BehaviorSubject<boolean>(false);
 public payloads(){
  this.defaultPayload = {
    EntityType: null,
    EntityId: null,
    FolderId: null,
    Hierarchy: null,
    SearchText: "",
    SearchNote: "",
    SearchTags : {
      Tags: [],
      JobTypeTags: [],
      ContactsTypeTags: [],
      PermentContactsTagType: 0,
      PermentTagType: 0,
      IsSearchPortalTag: false
    },
    Filters : {
    ContactGroupId:"",
    ContactList: [],
    ContactsTagList: [],
    DateFrom: "",
    DateTo:"",
    FileTypes:[],
    FirmSystemTag: "",
    IsArchivedContacts: false,
    IsFilterPortalTag: false,
    IsInActiveUser: false,
    IsJobClosed:"0",
    JobTypeTagList: [],
    MyRecentFiles: false,
    NoteAssignTo: "",
    NoteCreatedBy: "",
    NoteDueDate: "",
    NoteStatus: "",
    ShowArchivedContactsCheckBox:false,
    ShowInActiveUserCheckBox: false,
    TagList: [],
    UserFolders: 1,
    UserId: ""
    },
    Page: 0,
    SortColumn: "DeletedDate",
    SortOrder: "desc",
    IsFiltering: false,
    IsDeleted: true,
    IsOnlyUserFolderFiltering: false,
    DisplayArea: 3,
    HasMoreEntityRecords: true,
    HasMoreRecords: true,
    ContentSearchOffset: null,
    IsFileSearch: false,
    SearchMore: true
  }
  return  this.defaultPayload;
 }

 loadRecycleList(payload, isLoadMore?: boolean) {
  this.searchRecyclebinDocuments(payload).then(data => {
  this.setLoaderSubject(false);
  this.responseList = isLoadMore ? this.responseList.concat(data.DocumentContractList) : data.DocumentContractList;
  this.setRecycleListSubject(this.responseList);
  this.setRecyclePaginationSubject(data.PaginationInfo);
  if(this.responseList.length === 0){
    this.setNoRecordsSubject(true);
  }
  else{
    this.setNoRecordsSubject(false);
  }
})
  .catch(
    exception => {
      this.setLoaderSubject(false);
      this.toasterService.error(this.resourceService.getText('ifirm.common.error'));
    });   
}

loadRecycleBinFilterTypes(payload, isLoadMore?: boolean) {
  this.filterFileType(payload).then(data => {
  this.setLoaderSubject(false);
  this.setRecycleBinFilterTypesSubject(data);
})
  .catch(
    exception => {
      this.setLoaderSubject(false);
      this.toasterService.error(this.resourceService.getText('ifirm.common.error'));
    });   
}

  public searchRecyclebinDocuments(payload: any): Promise<any> {
    return this.api.post<any>('/dms/api/recyclebin/searchrecyclebindocuments',null, payload).toPromise();
  }

  public setPayloadSubject(val: SearchCriteriaRecycleBin) {
    this.recyclePayloadSubject.next(val);
  }

  public getPayloadSubject() {
    return this.recyclePayloadSubject.asObservable();
  }

  public setRecycleListSubject(val: any) {
    this.recyclebinListSubject.next(val);
  }

  public getRecycleListSubject() {
    return this.recyclebinListSubject.asObservable();
  }

  public setRecycleBinFilterTypesSubject(val: any) {
    this.recyclebinFilterTypesSubject.next(val);
  }

  public getRecycleBinFilterTypesSubject() {
    return this.recyclebinFilterTypesSubject.asObservable();
  }

  public setRecyclePaginationSubject(val: any) {
    this.recyclebinPaginationRespSubject.next(val);
  }

  public getRecyclePaginationSubject() {
    return this.recyclebinPaginationRespSubject.asObservable();
  }

  public setLoaderSubject(val: boolean) {
    this.loaderSubject.next(val);
  }

  public getLoaderSubject() {
    return this.loaderSubject.asObservable();
  }

  public setNoRecordsSubject(val: boolean) {
    this.listNoRecords.next(val);
  }

  public getNoRecordsSubject() {
    return this.listNoRecords.asObservable();
  }
  
  public getOverAllocatedSpace():Promise<any>{
    const url = '/dms/api/recyclebin/getoverallocatedspace';
    return this.api.get<any>(url).toPromise();
  }


  public  deleteDocuments(deleteContract:any):Promise<any>{
    return this.api.post<any>('/dms/api/recyclebin/deletedocuments',null,deleteContract).toPromise();
  }


  public restoreDocuments(restoreContract:any):Promise<any>{
    return this.api.post<any>('/dms/api/recyclebin/restoredocuments',null,restoreContract).toPromise();
  }

  public getNewUserInfo():Promise<any>{
    return this.api.get<any>("/dms/api/user/getuserinfo").toPromise();
  }

  public filterFileType(data:any): Promise<any>{
    return this.api.post<any>('/dms/api/documentsearch/getfiletypes/',null,data).toPromise();
  }

  public getFolderHierarchy(hierarchyId): Observable<any>{
    const url = '/dms/api/document/getfolderhierarchy?hierarchy='+hierarchyId;
    return this.api.get<any>(url);
  }

  public resetPayloadSubject(){
    this.setPayloadSubject(this.payloads());
  }

  public removeFromDataList(value:any[]):void{
    const index = this.checkedDatalist.indexOf(value);
    if(index !== -1){
      this.checkedDatalist.splice(index,1);
    }
  }

  public addToDataList(value:any[]):void{
    this.checkedDatalist.push(value);
  }

  public getList(){
    return this.checkedDatalist;
  }

  public setPurgeColumnResources(){
    this.columnTypeSource.next( this.columnTypeSource.value === 'delete' ? 'purge' : 'delete');
  }
 
  public getPurgeColumnResources(){
    return this.columnTypeSource.asObservable();
  }
 
  public setAllowAction(val : boolean){
    this.allowActionSubject.next(val);
  }
 
  public getAllowAction(){
    return this.allowActionSubject.asObservable();
  }

  public setAllSelected(val: boolean) {
    this.allSelected.next(val);
  }
 
  public getAllSelected() {
    return this.allSelected.asObservable();
  }

  public setCleanSearch() {
    this.cleanSearch.next();
  }
 
  public getCleanSearch() {
    return this.cleanSearch.asObservable();
  }
  public setfolderId(val: number) {
    this.folderId.next(val);
  }
 
  public getfolderId() {
    return this.folderId.asObservable();
  }

  public scrollTop(){
    const scrollContainer = document.querySelector('#dmsRecycleBinListTable');
    if (scrollContainer) {
      scrollContainer.scrollTop = 0;
    }
  }
}
