import { PropertyName } from '../../../../../../ifirm-common-components/src/public-api';

export class RecycleBinRowsModel {
    @PropertyName('Code') Code: string;      
    @PropertyName('DefaultFolderId') DefaultFolderId: string;  
    @PropertyName('DeletedBy') DeletedBy: string; 
    @PropertyName('DeletedDate') DeletedDate: string;  
    @PropertyName('EmailMetaDataId') EmailMetaDataId: string;  
    @PropertyName('EntityId') EntityId: number;  
    @PropertyName('EntityType') EntityType: number;  
    @PropertyName('FileSize') FileSize: string;  
    @PropertyName('Guid') Guid: string;  
    @PropertyName('Hierarchy') Hierarchy: string;  
    @PropertyName('Icon') Icon: string;  
    @PropertyName('Id') Id: number;  
    @PropertyName('IsLocked') IsLocked: boolean;      
    @PropertyName('IsNoteExist') IsNoteExist: boolean;  
    @PropertyName('IsReadOnly') IsReadOnly: boolean; 
    @PropertyName('IsSystemFolder')  IsSystemFolder: boolean;  
    @PropertyName('IsVersionExist') IsVersionExist: boolean;  
    @PropertyName('Kind') Kind: number;  
    @PropertyName('LinkUrl') LinkUrl: string;  
    @PropertyName('Location') Location: string;  
    @PropertyName('LockMessage') LockMessage: string;  
    @PropertyName('LockType') LockType: string;  
    @PropertyName('LockedBy') LockedBy: string;  
    @PropertyName('LockedDate') LockedDate: string;  
    @PropertyName('Name') Name: string;      
    @PropertyName('OpenEditPayload') OpenEditPayload: string;  
    @PropertyName('OriginalLocation') OriginalLocation: string; 
    @PropertyName('ParentId')  ParentId: number;  
    @PropertyName('Size') Size: string;  
    @PropertyName('Source') Source: number;  
    @PropertyName('StoragePath') StoragePath: string;  
    @PropertyName('TagCount') TagCount: number;  
    @PropertyName('Type') Type: string;  
    @PropertyName('UpdatedBy') UpdatedBy: string;  
    @PropertyName('UpdatedDate') UpdatedDate: string;  
    @PropertyName('VersionCount') VersionCount: number;  
}

export class SearchCriteriaRecycleBin {
    constructor() { }

    @PropertyName('EntityType')
    public EntityType: null | number;

    @PropertyName('EntityId')
    public EntityId: null | number;

    @PropertyName('FolderId')
    public FolderId: null | number;

    @PropertyName('Hierarchy')
    public Hierarchy: null;

    @PropertyName('SearchText')
    public SearchText: string;

    @PropertyName('SearchNote')
    public SearchNote: string;

    @PropertyName('Page')
    public Page: number;

    @PropertyName('SortColumn')
    public SortColumn: string;

    @PropertyName('SortOrder')
    public SortOrder: string;

    @PropertyName('IsFiltering')
    public IsFiltering: boolean;

    @PropertyName('IsDeleted')
    public IsDeleted: boolean;

    @PropertyName('IsOnlyUserFolderFiltering')
    public IsOnlyUserFolderFiltering: boolean;

    @PropertyName('DisplayArea')
    public DisplayArea: number;

    @PropertyName('HasMoreEntityRecords')
    public HasMoreEntityRecords: boolean;

    @PropertyName('HasMoreRecords')
    public HasMoreRecords: boolean;

    @PropertyName('ContentSearchOffset')
    public ContentSearchOffset: any;

    @PropertyName('IsFileSearch')
    public IsFileSearch: boolean;

    @PropertyName('SearchMore')
    public SearchMore: boolean;

    @PropertyName('IsContentSearch')
    public IsContentSearch?: boolean;

    @PropertyName('IsPurgeDate')
    public IsPurgeDate?: boolean;

    @PropertyName('Filters')
    public Filters: FilterCriteria;

    @PropertyName('SearchTags')
    public SearchTags: SearchTagCriteria;
}

export class FilterCriteria {
    constructor() { }

    @PropertyName('DateFrom')
    public DateFrom: string;

    @PropertyName('DateTo')
    public DateTo: string;

    @PropertyName('IsJobClosed')
    public IsJobClosed: string;

    @PropertyName('FileTypes')
    public FileTypes: any;

    @PropertyName('UserId')
    public UserId: string;

    @PropertyName('TagList')
    public TagList: any;

    @PropertyName('JobTypeTagList')
    public JobTypeTagList: any;

    @PropertyName('ContactsTagList')
    public ContactsTagList: any;

    @PropertyName("FirmSystemTag")
    public FirmSystemTag: string;

    @PropertyName('ContactGroupId')
    public ContactGroupId: string;

    @PropertyName('IsArchivedContacts')
    public IsArchivedContacts: boolean;

    @PropertyName('ShowArchivedContactsCheckBox')
    public ShowArchivedContactsCheckBox: boolean;

    @PropertyName('ShowInActiveUserCheckBox')
    public ShowInActiveUserCheckBox: boolean;

    @PropertyName('IsInActiveUser')
    public IsInActiveUser: boolean;

    @PropertyName('ContactList')
    public ContactList: string[];

    @PropertyName('MyRecentFiles')
    public MyRecentFiles: boolean;

    @PropertyName('UserFolders')
    public UserFolders: number;

    @PropertyName('NoteStatus')
    public NoteStatus: string;

    @PropertyName('NoteAssignTo')
    public NoteAssignTo: string;

    @PropertyName('NoteCreatedBy')
    public NoteCreatedBy: string;

    @PropertyName('NoteDueDate')
    public NoteDueDate: string;

    @PropertyName('IsFilterPortalTag')
    public IsFilterPortalTag: boolean;
}

export class SearchTagCriteria {
    constructor() { }

    @PropertyName('Tags')
    public Tags: any;

    @PropertyName('JobTypeTags')
    public JobTypeTags: any;

    @PropertyName('ContactsTypeTags')
    public ContactsTypeTags: any;

    @PropertyName('PermentContactsTagType')
    public PermentContactsTagType: number;

    @PropertyName('PermentTagType')
    public PermentTagType: number;

    @PropertyName('IsSearchPortalTag')
    public IsSearchPortalTag: boolean;
}
