import { Component, OnInit } from '@angular/core';
import { RecycleBinService } from './recyclebin.service';
import {ResourceService} from '@ifirm'
import { Router } from '@angular/router';
import { DmsService } from '../../../dms.service';

@Component({
  selector: 'app-recyclebin',
  templateUrl: './recyclebin.component.html',
  styleUrls: ['./recyclebin.component.scss']
})
export class RecyclebinComponent implements OnInit {
  dmsFilterToggle: boolean =false;
  loader: any;
  recyclebinList: any;
  payload: any;
  resourceLoadCheck: boolean = false;
  
  constructor(private recycleBinService: RecycleBinService, private resourceService:ResourceService, private router: Router,private dmsServices: DmsService) {
    this.recyclebinList = this.recycleBinService.getRecycleListSubject();
    this.loader = this.recycleBinService.getLoaderSubject();
   }

  ngOnInit(): void {
    var res = this.resourceService.get('dms.uploadfiles');
    if (res instanceof Promise) {
      res.then((_) => {
       // this.resourceLoadCheck = true;
        this.afterResourceLoad();
      });
    } else {
     // this.resourceLoadCheck = true;
      this.afterResourceLoad();
    }

  }

  afterResourceLoad():void {
    this.dmsServices.navigateToHome();
    this.resourceLoadCheck = true;
    this.recycleBinService.resetPayloadSubject();
    this.recycleBinService.setLoaderSubject(true);
    this.payload = this.recycleBinService.getPayloadSubject();
    this.recycleBinService.loadRecycleList(this.payload.source.value);
    this.recycleBinService.loadRecycleBinFilterTypes(this.payload.source.value);
  }
  dmsFilterPaneHideShow(){
    return this.dmsFilterToggle ? "hideFilter" : "showFilter";
  }

  dmsFilterToggleButtonSlide(){
    return this.dmsFilterToggle ? "filterToggleButton filterToggleButtonExpand" : "filterToggleButton filterToggleButtonCollapse";
  }

  dmsFilterToggleDirection(){
    return this.dmsFilterToggle ? "fa fa-angle-double-right rightToggle rightToggleR dmsFilterPointers" : "fa fa-angle-double-left rightToggle rightToggleL dmsFilterPointers";
  }

  toggleDmsFilter(){
    this.dmsFilterToggle = !this.dmsFilterToggle;
  }
  
  eventFromFilter(event){
    this.recycleBinService.setLoaderSubject(true);
    this.recycleBinService.loadRecycleList(this.payload.source.value);
  }

}
