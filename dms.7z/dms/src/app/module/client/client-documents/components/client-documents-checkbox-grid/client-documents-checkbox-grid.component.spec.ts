import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FilesDocumentsGridComponent } from './client-documents-checkbox-grid.component';

describe('FilesDocumentsGridComponent', () => {
  let component: FilesDocumentsGridComponent;
  let fixture: ComponentFixture<FilesDocumentsGridComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ FilesDocumentsGridComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FilesDocumentsGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
