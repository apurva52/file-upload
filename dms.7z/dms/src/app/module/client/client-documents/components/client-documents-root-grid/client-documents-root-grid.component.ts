import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GridServiceService } from '../../../../../shared/tools/service/grid-service.service';
import { payLoadModel } from '../../model/grid.model';
import {
  IFirmDataTableModule,
  IFirmButtonModule,
  LoaderModule,
  LocalizationModule,
  ResourceService, ModalPopupService, ModalPopupConfig, ConfirmationBoxComponent, ConfirmationBoxType
} from '@ifirm';
import { FolderDocumentGridComponent } from '../client-documents-folder-grid/client-documents-folder-grid.component';
import { FilesDocumentsGridComponent } from '../client-documents-checkbox-grid/client-documents-checkbox-grid.component';
import { FilterDocumentGridComponent } from '../client-documents-filters-grid/client-documents-filter-grid.component';
import { DmsService } from '../../../../../dms.service';
import { SearchServiceService } from '../../../../../shared/tools/search-bar/search-service.service';
import { Subscription } from 'rxjs';
import { DirectivesModule } from '../../../../../shared/directives/directives.module';
import { FilePropertyComponent } from '../../../../../dialogs/file-property/file-property.component';
import { DmsDialogApiService } from '../../../../../dialogs/dms-dialog-api.service';
import { DocumentKind, eventType,ApiValidationCode,fileKind,antivirusScanStatus, entityType } from '../../../../../constants/app-constants';
import { ConfirmationBoxInputModel } from 'projects/apm/src/app/timesheet/model/timesheet-common.model';
@Component({
  selector: 'app-document-grid',
  standalone: true,
  imports: [
    CommonModule,
    IFirmDataTableModule,
    IFirmButtonModule,
    FolderDocumentGridComponent,
    FilesDocumentsGridComponent,
    FilterDocumentGridComponent,
    LoaderModule,
    LocalizationModule,
    DirectivesModule,
  ],
  templateUrl: './client-documents-root-grid.component.html',
  styleUrls: ['./client-documents-root-grid.component.scss'],
})
export class ClientDocumentsRootGridComponent implements OnInit, OnDestroy {
  contactsList: any;
  data: any;
  payload = new payLoadModel();
  clientGridColumns = [];
  folder: boolean = false;
  fileGrid: boolean = false;
  contactsListData: any;
  contactsListFiles: any;
  isLoader = true;
  isSearchFilter: boolean = false;
  isFilter: boolean;
  isSearch: boolean;
  isContactSearch: boolean = false;
  filterEventSubs: Subscription;
  BreadcrumbsSubs: Subscription;
  clearSearchFilterSubs: Subscription;
  searchEventSubs: Subscription;
  contactResponse: any;
  loadpayload: any;
  openFolderPayload: any;
  responsedata: any;
  hrDocumentPayload: payLoadModel;

  constructor(
    private gs: GridServiceService,
    private dmsServices: DmsService,
    private SearchServiceService: SearchServiceService,
    private resourceService: ResourceService, private popupService: ModalPopupService, private dmsDialogService : DmsDialogApiService
  ) {
    // filter event

    this.filterEventSubs = this.gs.filterEvent.subscribe((data: any) => {
      if (!!data?.isOnlyContactSelected) {
        this.searchContactList(data.payload, false);
      } else {
        this.folder = false;
        this.fileGrid = false;
        this.isFilter = true;
        this.searchfolder(data.payload, false, false);
      }
    });
    //Breadcrumbs event
    this.BreadcrumbsSubs = this.dmsServices.breadCrumbClickedEvent.subscribe(
      (data: any) => {
        this.folder = false;
        this.fileGrid = false;
        if (data.EntityId == 0) {
          this.loadContactList(this.payload, false);
        } else if (data.Hierarchy == null && data.Id == null) {
          this.selectRow(data, false);
        } else {
          this.openfolder(data, false);
        }
      }
    );
    // clear filter Event
    this.clearSearchFilterSubs = this.dmsServices.clearSearchFilter.subscribe(
      (data: any) => {
        if (data.payload.EntityId == 0) {
          this.loadContactList(data.payload, false);
        } else if (data.payload.Hierarchy == null && data.payload?.FolderId == null) {
          this.selectRow(data.payload, false);
        } else {
          this.openfolder(data.payload, false);
        }
      }
    );
    
console.log("clearSearchFilterSubs",this.clearSearchFilterSubs)    


    // Search event

    this.searchEventSubs = this.SearchServiceService.searchEvent.subscribe(
      (data: any) => {
        this.folder = false;
        this.fileGrid = false;
        this.searchfolder(data, false);
        this.gs.addSearchResultBreadcrumb(data);
        
      }
    );
  }

  ngOnInit() {
    this.loadContactList(this.payload, false, 0);
  }
  loadContactList(payload, isScroll = false, PageSize = 0) {
    this.isLoader = true;
    this.enableView(false,false,false);
    this.isContactSearch = false;
    payload.EntityId = 0;
    payload.FolderId = null;
    payload.Hierarchy = null;
    payload.Page = PageSize;
    this.loadpayload = payload;
    this.gs.getContactList(payload, isScroll).subscribe((contactData) => {
      // this.gs.setContactsSubject(contactData.DocumentContractList);
      // this.data = this.gs.getContactsSubject();
      this.setResponseForFilter(contactData,payload)
      this.gs.commonPayloadData.set('commonPayloadData',payload)
      this.contactResponse = contactData;
      this.contactsList = isScroll
        ? this.contactsList.concat(contactData.DocumentContractList)
        : contactData.DocumentContractList;
      this.gs.isEnableConditionalButton= false;
      this.isLoader = false;
    });
  }

  //select HR folder
  selectRow(item, addBreadcrumbs = true, pageSize = 0) {
    this.enableView(true,false,false);
    this.isLoader = true;
    this.isContactSearch = false;
    if (!!addBreadcrumbs) this.gs.creatBreadcrumbs(item);
    const defaultFolderPayload = { ...this.payload };
    this.payload.EntityId = item.EntityId;
    this.payload.EntityType = item.EntityType;
    this.payload.FolderId = item.Id;
    this.payload.Page = pageSize;
    this.gs.getContactList(this.payload).subscribe((contactData) => {
      this.gs.folderHierarchyList.set("folderId",contactData.FolderId);
      this.gs.contactData.set("contactData",contactData);
      this.gs.commonPayloadData.set('commonPayloadData',this.payload)
      this.gs.setContactsSubject(contactData.DocumentContractList);
      this.gs.isEnableConditionalButton= false;
      this.setResponseForFilter(contactData,this.payload)
      this.contactsListData = contactData.DocumentContractList;
      this.hrDocumentPayload = this.payload;
      this.isLoader = false;
    });
  }

  //open file folder
  openfolder(event, addBreadcrumbs:boolean = true, onScroll:boolean = false) {
    this.isLoader = true;
    const filesFolderPayload = JSON.parse(JSON.stringify(this.payload));
   this.updateCheckboxPagePayload(event,filesFolderPayload);
    if (!!addBreadcrumbs) this.gs.creatBreadcrumbs(event);
    this.gs.getContactList(filesFolderPayload,onScroll).subscribe((contactData) => {
      this.enableView(false,true,false)
      this.openFolderPayload = event;
      this.gs.setContactsSubject(contactData.DocumentContractList);
      this.gs.folderHierarchyList.set("folderId",contactData.FolderId);
      this.gs.contactData.set("contactData",contactData);
      this.gs.commonPayloadData.set('commonPayloadData',filesFolderPayload)
      this.gs.isEnableConditionalButton= true;
      this.setResponseForFilter(contactData,filesFolderPayload);
      this.contactsListFiles = !!onScroll
        ? this.contactsListFiles.concat(contactData.DocumentContractList)
        : contactData.DocumentContractList;
      this.responsedata = contactData;
      this.isLoader = false;
    });
  }

  searchfolder(event, addBreadcrumbs = true, onScroll = false) {
    this.isContactSearch = false;
    this.enableView(false,true,true);
    this.updateSearchFilterPayload(event);
    if (!!addBreadcrumbs) this.gs.creatBreadcrumbs(event);
    this.gs.getSearchList(event).subscribe((contactData) => {
      this.gs.setContactsSubject(contactData.DocumentContractList);
      this.openFolderPayload = event;
      this.contactsListFiles = !!onScroll
        ? this.contactsListFiles.concat(contactData.DocumentContractList)
        : contactData.DocumentContractList;
      this.responsedata = contactData;
      this.gs.isEnableConditionalButton= false;
      this.isLoader = false;
    });
  }

  searchContactList(event, isScroll = false) {
    this.isContactSearch = true;
    this.folder = false;
    this.fileGrid = false;
    const searchpayload = { ...this.payload };
    // event?.Filters ? (searchpayload.Filters = event?.Filters) : '';
    event?.SearchTags ? (searchpayload.SearchTags = event?.SearchTags) : '';
    event?.SearchText ? (searchpayload.SearchText = event?.SearchText) : '';
    event?.SearchNote ? (searchpayload.SearchNote = event?.SearchNote) : '';
    searchpayload.Hierarchy = '';
    searchpayload.IsContentSearch = true;
    this.gs.getSearchList(event).subscribe((contactData) => {
      this.gs.setContactsSubject(contactData.DocumentContractList);
      this.gs.setFilterFields(contactData);
      this.contactResponse = contactData;
      this.contactsList = isScroll
        ? this.contactsList.concat(contactData.DocumentContractList)
        : contactData.DocumentContractList;
        this.gs.isEnableConditionalButton= false;
      this.isLoader = false;
    });
  }

  onScrolled(event) {
    if (this.contactResponse.PaginationInfo.IsLoadMore) {
      let pageRange =
        this.contactResponse.PaginationInfo.PageSize + this.loadpayload.Page;
      this.loadContactList(this.loadpayload, true, pageRange);
    }
  }

  showIcons(file) {
    let el = document.getElementById(
      'dmsProperties-' + file.Id + file.Kind + file.EntityId
    );
    el.classList.add(el.classList.value + 'OnHover');
    let elDownload = document.getElementById(
      'dmsDownload-' + file.Id + file.Kind + file.EntityId
    );
    elDownload.classList.add(elDownload.classList.value + 'OnHover');
  }

  hideIcons(file) {
    let el = document.getElementById(
      'dmsProperties-' + file.Id + file.Kind + file.EntityId
    );
    el.classList.remove(el.classList[1]);
    let elDownload = document.getElementById(
      'dmsDownload-' + file.Id + file.Kind + file.EntityId
    );
    elDownload.classList.remove(elDownload.classList[1]);
  }

  setResponseForFilter(contactData, payload){
    this.gs.setFilterFields(contactData);
      this.gs.setCommonPayload(payload);
  }

  showPropertiesDialog(file) {
    let data = {  Name: "", DefaultFolderId: null, isDeleted: true, file: { kind: file.Kind, EntityId: file.EntityId, EntityType: file.EntityType, Icon: file.Icon, Source: file.Source, EmailMetaDataId: file.EmailMetaDataId, Name: file.Name, id: file.Id, Hierarchy: file.Hierarchy, IsRecycleBin: false, isJobFolder: false, IsSystemFolder: file.IsSystemFolder } }
    let instance = this.popupService.open<FilePropertyComponent>(this.resourceService.getText('dms.propertiesdialog.properties'), FilePropertyComponent, {data:data});
    const sub = instance.afterClosed.subscribe(response => {
    });
  }

  downloadContact(contactId) {
    var selectedFileIds = [];
    var selectedFolderIds = [];
    var isSearchFilterApplied = false;
    var selecterFolderList = [];
    this.gs.downloadZip(selectedFolderIds, selecterFolderList, selectedFileIds, isSearchFilterApplied, contactId);
};

updateCheckboxPagePayload(event,filesFolderPayload){
  filesFolderPayload.EntityId = event.EntityId;
  filesFolderPayload.EntityType = event.EntityType;
  filesFolderPayload.Filters.IsArchivedContacts = false;
  event?.Id
      ? (filesFolderPayload.FolderId = event.Id)
      : (filesFolderPayload.FolderId = event.FolderId);
      filesFolderPayload.Hierarchy = event.Hierarchy;
      filesFolderPayload.Page = event?.pageSize ? event.pageSize : 0;
      filesFolderPayload.SortColumn = event?.SortColumn ? event.SortColumn : filesFolderPayload.SortColumn;
      filesFolderPayload.SortOrder = event?.SortOrder ? event.SortOrder : filesFolderPayload.SortOrder;
    event.pageSize = event?.pageSize ? event.pageSize : 0;
    if (filesFolderPayload.Page>0) {
      filesFolderPayload.IsFileSearch=true;
      filesFolderPayload.HasMoreEntityRecords= false;
      filesFolderPayload.HasMoreRecords = true; 
      filesFolderPayload.SearchMore = false;
    }
}

enableView(folder:boolean,files:boolean, isSeach:boolean){
  this.fileGrid = files;
  this.folder = folder;
  this.isSearchFilter = isSeach;
}

updateSearchFilterPayload(event){
  event.pageSize = event?.pageSize ? event?.pageSize : 0;
  event.Page = event?.pageSize ? event?.pageSize : 0;
  if (event.Page>0) {
    event.IsFileSearch=true;
    event.HasMoreEntityRecords= false;
    event.HasMoreRecords = true; 
    event.SearchMore = false;
  }
}
  ngOnDestroy(): void {
    this.filterEventSubs.unsubscribe();
    this.BreadcrumbsSubs.unsubscribe();
    this.clearSearchFilterSubs.unsubscribe();
    this.searchEventSubs.unsubscribe();
  }
}
