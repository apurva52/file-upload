import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IFirmButtonModule, IFirmDataTableModule, LoaderModule ,LocalizationModule, ModalPopupService, ResourceService} from '@ifirm';
import { DirectivesModule } from '../../../../../shared/directives/directives.module';
import { GridServiceService } from '../../../../../shared/tools/service/grid-service.service';
import { FilePropertyComponent } from '../../../../../dialogs/file-property/file-property.component';

@Component({
  selector: 'app-client-documents-filter-grid',
  standalone: true,
  imports: [CommonModule,IFirmDataTableModule, IFirmButtonModule, LoaderModule, LocalizationModule, DirectivesModule],
  templateUrl: './client-documents-filter-grid.component.html',
  styleUrls: ['./client-documents-filter-grid.component.scss']
})
export class FilterDocumentGridComponent implements OnInit {

  @Input() searchData:any=[];
  @Input() isLoader= true;
  @Input() isSearchFilter:boolean=false;
  contactsList:any;
  clientGridColumns: { columnName: string; }[];
  
  @Output() defaultFolderEvent = new EventEmitter();
  @Output() contactEvent = new EventEmitter();
  isContactSeach: boolean;
  responseData:any;
  constructor(private gridServics: GridServiceService, private resourceService: ResourceService, private popupService: ModalPopupService) { }

  ngOnInit(): void {
    this.gridServics.updateFilterFields.subscribe((data:any)=>{
      this.responseData = data.DocumentContractList
      this.isContactSeach = this.responseData.every(c => c.Kind == 3) ?  false: true;
    })


  }

  selectRow(item){
   this.contactEvent.emit(item);
  }

  onScrolled(event){
    console.log('scroll filter list');
   }


   showPropertiesDialog(file) {
    let data = {  Name: "", DefaultFolderId: null, isDeleted: true, file: { kind: file.Kind, EntityId: file.EntityId, EntityType: file.EntityType, Icon: file.Icon, Source: file.Source, EmailMetaDataId: file.EmailMetaDataId, Name: file.Name, id: file.Id, Hierarchy: file.Hierarchy, IsRecycleBin: false, isJobFolder: false, IsSystemFolder: file.IsSystemFolder } }
    let instance = this.popupService.open<FilePropertyComponent>(this.resourceService.getText('dms.propertiesdialog.properties'), FilePropertyComponent, {data:data});
    const sub = instance.afterClosed.subscribe(response => {
    });
  }

  downloadContact(contactId) {
    var selectedFileIds = [];
    var selectedFolderIds = [];
    var isSearchFilterApplied = false;
    var selecterFolderList = [];
    this.gridServics.downloadZip(selectedFolderIds, selecterFolderList, selectedFileIds, isSearchFilterApplied, contactId);
};
}
