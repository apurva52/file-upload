import { Component, EventEmitter, Input, OnChanges, OnDestroy, OnInit, Output, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DirectivesModule } from '../../../../../shared/directives/directives.module';
import { ContactDataModel, payLoadModel } from '../../model/grid.model';
import { GridServiceService } from '../../../../../shared/tools/service/grid-service.service';
import { ApiService, ConfirmationBoxComponent, ConfirmationBoxType, IFirmButtonModule, IFirmDataTableModule, InformationBoxComponent, LoaderModule, LocalizationModule, ModalPopupConfig, ModalPopupService, ResourceService, ToasterService } from '@ifirm';
import { RenameDocumentComponent } from '../../../../../dialogs/rename-document/rename-document.component';
import { DocumentKind, eventType, ApiValidationCode, fileKind, antivirusScanStatus, entityType, AppConstants , entityUrl } from '../../../../../constants/app-constants';
import { CopyMovePayload, PublishPortalPayload } from '../../../../../shared/tools/model/files-documents-grid.model'
import { FileCopyComponent } from '../../../../../dialogs/file-copy/file-copy.component';
import { DmsFiltersService } from '../../../../../filter-components/dms-filters.service';
import { Subscription } from 'rxjs/internal/Subscription';
import { payLoadCommonModel } from '../../../../../shared/filters/model/user.model';
import { DownloadFileModel } from '../../../../../dialogs/models/download-file.model';
import { DmsDialogApiService } from '../../../../../dialogs/dms-dialog-api.service';
import { DmsService } from '../../../../../dms.service';
import { DmsFileModel } from '../../../../../dialogs/models/dms-fIle.model';
import { DmsDialogService } from '../../../../../dialogs/dms-dialog.service';
import { FileType, RenameDocumentModelPayload } from '../../../../../dialogs/models/rename-document.model';
import { FileNotesComponent } from '../../../../../dialogs/file-notes/file-notes.component';
import { Clipboard } from '@angular/cdk/clipboard';
import { FilePropertyComponent } from '../../../../../dialogs/file-property/file-property.component';
import { ConfirmationBoxInputModel } from 'projects/apm/src/app/timesheet/model/timesheet-common.model';
import { FileVersionComponent } from '../../../../../dialogs/file-version/file-version.component';
import { FolderSelectionComponent } from '../../../../../dialogs/folder-selection/folder-selection.component';
import { NgSelectModule } from '@ng-select/ng-select';
import { TagList } from '../../../../../dialogs/file-property/models/file-property.model';
import { FilePropertyService } from '../../../../../dialogs/file-property/services/file-property.service';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

interface DownloadRequest {
  downloadContractBtoa: string;
}
@Component({
  selector: 'app-client-documents-checkbox-grid',
  standalone: true,
  imports: [
    CommonModule,
    IFirmDataTableModule,
    IFirmButtonModule,
    LoaderModule,
    LocalizationModule,
    DirectivesModule,
    NgSelectModule,
    FormsModule
  ],
  templateUrl: './client-documents-checkbox-grid.component.html',
  styleUrls: ['./client-documents-checkbox-grid.component.scss'],
})
export class FilesDocumentsGridComponent
  implements OnInit, OnChanges, OnDestroy {
  @Input() filesData: any = [];
  @Input() isLoader: boolean = false;
  @Input() isSearchFilter: boolean = false;
  @Input() gridPayload: any;
  @Input() contactResponse: any;
  @Output() folderEvent = new EventEmitter();
  @Output() fileEvent = new EventEmitter();
  @Output() loadMoreEvent = new EventEmitter();
  @Output() loadMoreSearchEvent = new EventEmitter();
  @Output() sortColumn = new EventEmitter();
  @Output() sortColumnSearch = new EventEmitter();
  clientGridColumns: { columnName: string }[];
  copyMoveData: CopyMovePayload = {} as CopyMovePayload;
  payload = new payLoadModel();
  listPayload: any;
  allChecked: boolean = false;
  dmsRenameButton: boolean = true;
  dmsDownloadButton: boolean = true;
  dmsOpenPdfButton: boolean = true;
  dmsMergePdfButton: boolean = false;
  dmsPublishButton: boolean = true;
  dmsSignatureButton: boolean = true;
  dmsCopyMoveButton: boolean = true;
  dmsMoveButton: boolean = true;
  dmsDeleteButton: boolean = true;
  count = [];
  selectedCheckBoxData = [];
  private subscriptions = new Subscription();
  previousPayload = new payLoadCommonModel();
  downloadFilespayload = new DownloadFileModel();
  rowIndex: any;
  dmsFileModel: DmsFileModel;
  FolderId: any;
  renameDocumentPayload = new RenameDocumentModelPayload();
  fileType: FileType;
  userInfoMap: any;
  failMessage: string;
  ClientId: number;
  seletedDocuments: ContactDataModel[] = [];
  deleteRoeList: ContactDataModel[] = [];
  userRoles: any;
  clientDocResponse: any;
  selectedAll: any;
  selectedTagList: TagList[] = [];
  initialSelectedTagList: TagList[] = [];
  tags: TagList[] = [];
  searchTag = this.resourceService.getText('dms.searchtag.search');
  tab: string = 'clientDoc';
  copyLinkLabel = this.resourceService.getText('dms.copylink');
  versionTooltipLabel = this.resourceService.getText('dms.common.versiontooltip');

  mergePdf: boolean = false;
  openPdf: boolean = true;
  constructor(public GridServiceService: GridServiceService, private toasterService: ToasterService, private resourceService: ResourceService, private dmsFilterService: DmsFiltersService, private clipboard: Clipboard, private popupService: ModalPopupService,
    private popupservice: ModalPopupService, public dmsDialogService: DmsDialogApiService, private dmsService: DmsService, private api: ApiService, private dmsDialogService1: DmsDialogService, private filepropertyservice: FilePropertyService,private router: Router) {
    this.fetchUserInfo()
    this.copyMoveData.SelectedItems = [];
    this.GridServiceService.checkedDatalist = [];
    this.clientDocResponse = this.dmsService.getClientDocList$();
  }
  ngOnChanges(changes: SimpleChanges): void {
    if(this.gridPayload?.EntityId != undefined){
      this.getClientPortalAccessInfo(this.gridPayload?.EntityId, this.gridPayload?.EntityType);
      }
  }

  ngOnInit(): void {
    this.GridServiceService.applyUserRoles();
    this.GridServiceService.getEnhancedpdfSettings(this.tab);
  }

  fetchUserInfo() {
    this.subscriptions.add(
      this.dmsFilterService.getUserInfo().subscribe({
        next: (response) => {
          this.userRoles = response;
          this.updateUserInfo(response)

        },
        error: (e) => {
          this.toasterService.error(
            this.resourceService.getText('ifirm.common.error')
          );
        },
      })
    );
  }

  updateUserInfo(response: any) {
    this.copyMoveData.UserRoles = {
      userId: response.UserId,
      allowApmAccess: response.IsAllowApmAccess,
      viewEditCopyMove: response.DmsViewEditCopyMove,
      addCustomFolder: response.DmsAddCustomFolder,
      contactView: response.ContactView,
      internalDocumentsViewEdit: response.DmsInternalDocumentsViewEdit,
      firmDocuments: response.DmsFirmDocuments,
    };
  }
  openGrid(item) {
    this.folderEvent.emit(item);
  }

  openFile(item) {
    this.GridServiceService.getGridFile(item, 'firmDoc');
  }

  private updateGrid(): void {
    const payload = {
      payload: this.gridPayload,
      isOnlyContactSelected: false,
      isEmptyEvent: true
    }
    this.dmsService.clearSearchFilter.next(payload);
  }

  showIcons(file) {
    let el = document.getElementById(
      'dmsProperties-' + file.Id + file.Kind + file.EntityId
    );
    el?.classList?.add("dms-propertyBoxOnHover");
    let elVersion = document.getElementById(
      'dmsVersion-' + file.Id + file.Kind + file.EntityId
    );

    elVersion?.classList?.add("dms-versionBoxOnHover");

    let elNote = document.getElementById(
      'dmsGridShowMoreNote-' + file.Id + file.Kind + file.EntityId
    );
    elNote?.classList.add('dms-showmoreonhover');

    let elLink = document.getElementById(
      'dmsGridCopyLink-' + file.Id + file.Kind + file.EntityId
    );
    elLink?.classList.add('dms-fileLinkOnHover');
    let elDownload = document.getElementById(
      'dmsDownload-' + file.Id + file.Kind + file.EntityId
    );
    elDownload?.classList.add('dms-downloadIconOnHover');
  }

  hideIcons(file) {
    let el = document.getElementById(
      'dmsProperties-' + file.Id + file.Kind + file.EntityId
    );
    el?.classList.remove("dms-propertyBoxOnHover");
    let elVersion = document.getElementById(
      'dmsVersion-' + file.Id + file.Kind + file.EntityId
    );
    elVersion?.classList.remove("dms-versionBoxOnHover");

    let elNote = document.getElementById(
      'dmsGridShowMoreNote-' + file.Id + file.Kind + file.EntityId
    );
    elNote?.classList.remove("dms-showmoreonhover");

    let elLink = document.getElementById(
      'dmsGridCopyLink-' + file.Id + file.Kind + file.EntityId
    );
    elLink?.classList.remove("dms-fileLinkOnHover");
    let elDownload = document.getElementById(
      'dmsDownload-' + file.Id + file.Kind + file.EntityId
    );
    elDownload?.classList.remove("dms-downloadIconOnHover");
  }

  onScrolled(event) {
    if (this.contactResponse.PaginationInfo.IsLoadMore) {
      this.gridPayload.pageSize =
        this.contactResponse.PaginationInfo.PageSize +
        this.gridPayload.pageSize;
      !!this.isSearchFilter
        ? this.loadMoreSearchEvent.emit(this.gridPayload)
        : this.loadMoreEvent.emit(this.gridPayload);
      this.selectedAll = false;
    }
  }


  onSelectAll(event) {
    this.filesData.forEach(file => {
      file.selected = this.selectedAll;
      if (event.target.checked) {
        this.GridServiceService.removeFromDataList(file);
        this.GridServiceService.addToDataList(file);
        this.dmsDownloadButton = false;
        this.dmsCopyMoveButton = false;
        this.dmsDeleteButton = false;
      }
      else {
        this.GridServiceService.removeFromDataList(file);
        this.dmsDownloadButton = true;
        this.dmsCopyMoveButton = true;
        this.dmsMoveButton = true;
        this.dmsDeleteButton = true;
        this.dmsOpenPdfButton = true;
       // this.dmsRenameButton = true;
        this.dmsPublishButton = true;
        this.dmsSignatureButton = true;
        if (this.GridServiceService.checkedDatalist.length === 0) {
        }
      }
    });
  }

  selectAllFilesChanged() {
    this.selectedAll = this.filesData.every(file => file.selected);
    if (this.GridServiceService.checkedDatalist.length === 1) {
     // this.dmsRenameButton = false;
    } else {
      //this.dmsRenameButton = true;
    }
  }

  onChecked(event, file) {
    if (event && event.stopPropagation) {
      if (event.target.checked) {
        this.GridServiceService.addToDataList(file);
        this.copyMoveDataStructure(file, 'add');
        this.publishToPortalStructure(file, true);
        this.deleteRowStructure(file, true);
        this.dmsDownloadButton = false;
        this.dmsPublishButton = false;
      } else {
        this.copyMoveDataStructure(file);
        this.publishToPortalStructure(file);
        this.deleteRowStructure(file);
        this.GridServiceService.removeFromDataList(file);
        this.dmsDownloadButton = true;
      }
      if (this.GridServiceService.checkedDatalist.length === 1) {
        this.dmsOpenPdfButton = false;
        this.openPdf = true;
        this.mergePdf = false;
      } else {
        this.dmsOpenPdfButton = true;
        this.openPdf = false;
        this.mergePdf = true;
        this.dmsMergePdfButton = false;
      }
      event.stopPropagation();
    }
  }


  payloadForRename() {
    this.renameDocumentPayload.EntityId = this.GridServiceService.checkedDatalist[0].EntityId;
    this.renameDocumentPayload.EntityType =
      this.GridServiceService.checkedDatalist[0].EntityType;
    this.renameDocumentPayload.Id = this.GridServiceService.checkedDatalist[0].Id;
    this.renameDocumentPayload.Guid = this.GridServiceService.checkedDatalist[0].Guid;
    this.renameDocumentPayload.ParentFolderId =
      this.GridServiceService.checkedDatalist[0].ParentId;
    this.renameDocumentPayload.Kind = this.GridServiceService.checkedDatalist[0].Kind;
    if (this.GridServiceService.checkedDatalist[0].Kind === DocumentKind.File) {
      this.fileType = {
        Id: this.GridServiceService.checkedDatalist[0].Type.Id,
        GroupName: this.GridServiceService.checkedDatalist[0].Type.GroupName,
        Extension: this.GridServiceService.checkedDatalist[0].Type.Extension,
        FileExtensionId: this.GridServiceService.checkedDatalist[0].Type.FileExtensionId,
        ResourceKey: this.GridServiceService.checkedDatalist[0].Type.ResourceKey,
      };
    } else {
      this.fileType = null;
    }
    this.renameDocumentPayload.FileType = this.fileType;
    this.renameDocumentPayload.OldName = this.GridServiceService.checkedDatalist[0].Name;
    this.renameDocumentPayload.Name = this.GridServiceService.checkedDatalist[0].Name;
    this.renameDocumentPayload.Hierarchy =
      this.GridServiceService.checkedDatalist[0].Hierarchy;
    this.renameDocumentPayload.EmailMetaDataId =
      this.GridServiceService.checkedDatalist[0].EmailMetaDataId;
    this.renameDocumentPayload.NewName = '';

  }

  onRenameButtonOpen() {
    this.payloadForRename();
    const convertedObject = this.GridServiceService.checkedDatalist.reduce(
      (result, currentItem) => {
        result = currentItem;
        return result;
      },
      {}
    );
    const config = new ModalPopupConfig();
    config.data = this.renameDocumentPayload;
    let instance = this.popupservice.open<RenameDocumentComponent>(
      this.resourceService.getText('dms.rename'),
      RenameDocumentComponent,
      config
    );

    const subscription = instance.afterClosed.subscribe((response) => {
      subscription.unsubscribe();

      if (response) {
        const payload = {
          payload: this.gridPayload,
          isOnlyContactSelected: false,
          isEmptyEvent: true
        };
        (!this.isSearchFilter) ? this.dmsService.clearSearchFilter.next(payload) : this.GridServiceService.filterEvent.next(payload);
      //  this.dmsRenameButton = true;
        this.GridServiceService.checkedDatalist = [];
      }
    });
  }

  copyMoveDataStructure(rowdata, flag?): void {
    if (flag === 'add') {
      this.copyMoveData.LocationDetails = { EntityType: rowdata.EntityType, EntityId: rowdata.EntityId, FolderId: this.gridPayload.Id, FolderName: this.gridPayload.Name }
      this.copyMoveData.SelectedItems.push({
        EmailMetaDataId: rowdata.EmailMetaDataId,
        EntityId: rowdata.EntityId,
        EntityType: rowdata.EntityType,
        Hierarchy: rowdata.Hierarchy,
        FileGuid: rowdata.Guid,
        Id: rowdata.Id,
        FileKind: rowdata.Kind,
        LinkUrl: rowdata.LinkUrl,
        FileName: rowdata.Name,
        StoragePath: rowdata.StoragePath,
        ParentId: rowdata.ParentId,
        FileType: rowdata.Type,
      });

      this.dmsCopyMoveButton = this.validateCopyMoveButton(this.copyMoveData.SelectedItems);
    } else {
      const ind = this.copyMoveData.SelectedItems.findIndex(
        (res) => res.Id === rowdata.Id
      );
      this.copyMoveData.SelectedItems.splice(ind, 1);
      !this.copyMoveData.SelectedItems.length &&
        (this.dmsCopyMoveButton = true);
    }
  }
  
  private validateCopyMoveButton(file)
  {
    const selectionHasFolder = file.Kind === 2 && file.DefaultFolderId <= 0;
    return this.userRoles.DmsViewEditCopyMove  && !file.IsSystemFolder && !file.IsLocked && file.DefaultFolderId > 0 && (selectionHasFolder ? this.userRoles.DmsAddCustomFolder ? true : false : true) ? true : false;
  }

  private publishToPortalStructure(rowItem, flag = false): void {
    if (flag) {
      const publishObj = {} as ContactDataModel;
      publishObj.EntityId = rowItem.EntityId;
      publishObj.EntityType = rowItem.EntityType;
      publishObj.Guid = rowItem.Guid;
      publishObj.Id = rowItem.Id;
      publishObj.Hierarchy = rowItem.Hierarchy
      publishObj.Kind = rowItem.Kind;
      publishObj.Name = rowItem.Name;
      publishObj.ParentFolderId = rowItem.ParentId;
      publishObj.Size = rowItem.FileSize;
      publishObj.StoragePath = rowItem.StoragePath;
      publishObj.Type = rowItem.Type;
      this.seletedDocuments.push(publishObj);
    }
    else {
      const ind = this.seletedDocuments.findIndex(res => res.Id === rowItem.Id)
      this.seletedDocuments.splice(ind, 1);
      !this.seletedDocuments.length && (this.dmsPublishButton = true);
    }
  }

  private deleteRowStructure(rowItem, flag = false): void {
    if (flag) {
      this.dmsDeleteButton = !this.isDeleteAllowed(rowItem);
      const deleteObj = {} as ContactDataModel;
      deleteObj.EntityId = rowItem.EntityId;
      deleteObj.EntityType = rowItem.EntityType;
      deleteObj.Guid = rowItem.Guid;
      deleteObj.Id = rowItem.Id;
      deleteObj.Kind = rowItem.Kind;
      deleteObj.Name = rowItem.Name;
      deleteObj.ParentFolderId = rowItem.ParentId;
      deleteObj.Hierarchy = rowItem.Hierarchy,
        deleteObj.IsVersionExist = rowItem.IsVersionExist;
      deleteObj.StoragePath = rowItem.StoragePath;
      deleteObj.Type = rowItem.Type;
      deleteObj.LinkUrl = rowItem.LinkUrl;
      this.deleteRoeList.push(deleteObj);
    }
    else {
      const ind = this.deleteRoeList.findIndex(res => res.Id === rowItem.Id)
      this.deleteRoeList.splice(ind, 1);
      !this.deleteRoeList.length && (this.dmsDeleteButton = true);
    }
  }

  onCopyMoveOpen(eventtype: number): void {
    this.copyMoveData.EventType = eventtype;
    const config = new ModalPopupConfig();
    config.data = this.copyMoveData;
    let instance = this.popupservice.open<FileCopyComponent>(
      eventtype == eventType.Copy
        ? this.resourceService.getText('dms.copy.copydocuments')
        : this.resourceService.getText('dms.move.movedocuments'),
      FileCopyComponent,
      config
    );
    const subscription = instance.afterClosed.subscribe(x => {
      if (subscription) {
        subscription.unsubscribe();
      }
      if (x) {
        this.updateGrid();
      }
    });
  }
  get EventType() {
    return eventType;
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }
  downloadFile() {
    if (
      this.GridServiceService.checkedDatalist.length === 1 &&
      this.GridServiceService.checkedDatalist[0].Kind === fileKind.File
    ) {
      this.GridServiceService.downloadSingleFile(this.GridServiceService.checkedDatalist[0], this.tab, this.gridPayload);
    } else {
      this.GridServiceService.downloadMultipleFiles(this.GridServiceService.checkedDatalist, this.tab, this.gridPayload);
    }
  }



  sortType(sort: string) {
    this.gridPayload.SortColumn = sort;
    this.gridPayload.SortOrder =
      this.gridPayload.SortOrder == 'desc'
        ? 'asc'
        : this.gridPayload.SortOrder == 'asc'
          ? 'desc'
          : 'desc';
    this.gridPayload.pageSize = 0;
    !!this.isSearchFilter
      ? this.sortColumnSearch.emit(this.gridPayload)
      : this.sortColumn.emit(this.gridPayload);
  }

  sortClass(sort: string) {
    if (this.gridPayload?.SortColumn === sort) {
      if (this.gridPayload?.SortOrder === 'asc') {
        return 'ascendImg dms-sort';
      } else {
        return 'descendImg dms-sort';
      }
    }
  }

  openFileNote(Id: number): void {
    let instance = this.popupService.open<FileNotesComponent>(
      this.resourceService.getText('dms.filenotes'),
      FileNotesComponent,
      { data: { FileId: Id } }
    );
  }

  addToClipboardLink(Id: number): void {
    this.subscriptions.add(
      this.GridServiceService.createFileLinkUrl(Id).subscribe(
        (res) => {
          if (res.success) {
            this.clipboard.copy(res.data);
            this.toasterService.success(
              this.resourceService.getText('dms.copiedtoclipboard')
            );
          } else {
            this.toasterService.error(
              this.resourceService.getText('dms.common.error')
            );
          }
        },
        (error) => {
          this.toasterService.error(
            this.resourceService.getText('dms.common.error')
          );
        }
      )
    );
  }

  showPropertiesDialog(file) {
    let data = { Name: "", DefaultFolderId: null, isDeleted: true, file: { kind: file.Kind, EntityId: file.EntityId, EntityType: file.EntityType, Icon: file.Icon, Source: file.Source, EmailMetaDataId: file.EmailMetaDataId, Name: file.Name, id: file.Id, Hierarchy: file.Hierarchy, IsRecycleBin: false, isJobFolder: false, IsSystemFolder: file.IsSystemFolder } }
    let instance = this.popupService.open<FilePropertyComponent>(this.resourceService.getText('dms.propertiesdialog.properties'), FilePropertyComponent, { data: data });
    const sub = instance.afterClosed.subscribe(response => {
    });
  }

  showListVersionDialog(file) {
    this.applyUserRoles();
    let data = {
      File: file,
      UserRoles: this.userInfoMap,
      broadCastFunc: this.broadCastFunc()
    };
    let instance = this.popupService.open<FileVersionComponent>(this.resourceService.getText('dms.versionsdialog.versionhistory'), FileVersionComponent, { data: data });
  }
  broadCastFunc() {
    console.log('broadcast sent from popup');
  }

  applyUserRoles() {
    if (this.dmsService.userInfoMap.get('userInfoValue') != undefined) {
      const userInfo = this.dmsService.userInfoMap.get('userInfoValue');
      this.userInfoMap = userInfo;
      this.userInfoMap.viewAny = userInfo?.DmsViewAny;
      this.userInfoMap.viewEdit = userInfo?.DmsViewEdit;
      this.userInfoMap.viewEditCopyMove = userInfo?.DmsViewEditCopyMove;
      this.userInfoMap.view = userInfo?.DmsView;
      this.userInfoMap.viewUpload = userInfo?.DmsViewUpload;
      this.userInfoMap.viewDelete = userInfo?.DmsViewDelete;
      this.userInfoMap.viewPermanentDelete = userInfo?.DmsViewPermanentDelete;
      this.userInfoMap.viewUnlock = userInfo?.DmsViewUnlock;
      this.userInfoMap.viewDownloadMultiple = userInfo?.DmsViewDownloadMultiple;
      this.userInfoMap.dmsViewRecycleBinRestore = userInfo?.DmsViewRecycleBinRestore;
      this.userInfoMap.addCustomFolder = userInfo?.DmsAddCustomFolder;
      this.userInfoMap.deleteCustomFolder = userInfo?.DmsDeleteCustomFolder;
    }
  }

  publishToPortal(): void {
    this.subscriptions.add(this.GridServiceService.validatePublishToPortalRequest({ clientId: this.ClientId, seletedDocuments: this.seletedDocuments }).subscribe(response => {
      if (response.success) {
        this.startPublishToPortalAction();
      }
      else {
        this.publishErrorDisplay(response);
      }
    }));
  }

  private publishErrorDisplay(data): void {
    if (data && data.errorcode == "ValidationError" && (data.ValidationCode === ApiValidationCode.FileQuarantined || data.ValidationCode === ApiValidationCode.FileInvalidExtension)) {
      const fileStatus = (data.ValidationCode === ApiValidationCode.FileQuarantined) ? antivirusScanStatus.Fail : antivirusScanStatus.InvalidExtension
     this.GridServiceService.showConfirmDeleteDialog(this.seletedDocuments[0], fileStatus,this.gridPayload,this.tab)
    }
    else if (data && data.errorcode == "ValidationError" && data.ValidationCode === ApiValidationCode.FileNotScanned) {
      const fileNotScannedMessage = (this.seletedDocuments.length > 1) ? this.resourceService.getText('cp.documents.filenotscannedfrombulk') : this.resourceService.getText('cp.documents.filenotscanned');

      const instance = this.popupService.confirm(this.resourceService.getText('ifirm.common.warning'), fileNotScannedMessage as string, ConfirmationBoxType.YesNo);
      const subscription = instance.afterClosed.subscribe(a => {
        subscription.unsubscribe();
        if (a && a.result == true) {
          this.startPublishToPortalAction();
        }
      });
    }
    else if (data && data.errorcode == "ValidationError" && data.ValidationCode === ApiValidationCode.AllFilesEitherQuarantinedOrInvalid) {
      this.toasterService.warning(data.message);
    }
    else if (data && data.errorcode == "ValidationError" && data.ValidationCode === ApiValidationCode.AllLinkFileInvalidExtension) {
      this.toasterService.error(this.resourceService.getText('dms.linkurlpublishtoportalvalidation'));
    }
    else {
      this.toasterService.error(data.ValidationCode > 0 ? this.resourceService.getText('dms.validationmessages.' + data.ValidationCode) : this.resourceService.getText('dms.common.fallbackerrormessage'));
    }
  }

  private startPublishToPortalAction() :void {
    this.dmsDialogService.getCurrentEntityForLookup(this.gridPayload.EntityId, this.gridPayload.EntityType).then(res => {
      if (res) {
        const config = new ModalPopupConfig();
        config.data = { ClientName: res.Name, ClientId: this.ClientId }
        let instance = this.popupservice.open<FolderSelectionComponent>(this.resourceService.getText('dms.selectfolder'), FolderSelectionComponent, config);
        const subscription = instance.afterClosed.subscribe(result => {
          if (subscription) {
            subscription.unsubscribe();
          }
          if (result !== null) {
            this.publishToPortalCallback(result);
          }
        });
      }
    })
  }
  private publishToPortalCallback(selectedNode: any): void {
    if (!selectedNode)
      return;
    const publishCallbackObj = {} as PublishPortalPayload;
    publishCallbackObj.ClientId = this.ClientId;
    publishCallbackObj.FolderId = selectedNode.Id;
    publishCallbackObj.SeletedDocuments = this.seletedDocuments;
    publishCallbackObj.isValidated = true;
    publishCallbackObj.ClientPortalDestinationPath = encodeURIComponent(selectedNode.FullPath);
    publishCallbackObj.SourceFolderHierarchyList = this.getFolderHierachy();
    publishCallbackObj.JobId = this.gridPayload.EntityType === entityType.Job ? this.gridPayload.EntityType : null;
    const config: ModalPopupConfig<any> = new ModalPopupConfig<any>();

    config.data = this.resourceService.getText("dms.publishtoportal.processingmessage");
    const instance = this.popupService.open<InformationBoxComponent>(this.resourceService.getText('ifirm.common.alert'), InformationBoxComponent, config);
    const subscription = instance.afterClosed.subscribe(x => {
      if (subscription) {
        subscription.unsubscribe();
      }
      if (x && x.result) {
        this.updateGrid();
      }
    });
    this.subscriptions.add(this.GridServiceService.PublishToPortalRequest(publishCallbackObj).subscribe(res => {
      if (!res.success) {
        instance.close();
        this.toasterService.error(this.resourceService.getText('dms.common.fallbackerrormessage'));
      }
    },
      (error) => {
        this.toasterService.error(this.resourceService.getText('dms.common.fallbackerrormessage'));
      }));
  }

  private getFolderHierachy(): Object {
    const obj = {} as { [id: number]: string }
    this.GridServiceService.contactData.get("contactData").FolderHierarchyList.forEach(x => { obj[x.FolderId] = x.FolderName });
    return obj;
  }

  private getClientPortalAccessInfo(entityId: number, entityTypes: entityType) {
    this.dmsDialogService.getClientPortalAccessInfo(entityId, entityTypes).then(res => {
      if (res) {
        this.ClientId = res.ClientId;
      }
    });
  }

  onDeleteOpen() {
    const config: ModalPopupConfig<ConfirmationBoxInputModel> = new ModalPopupConfig<ConfirmationBoxInputModel>();
    let model = new ConfirmationBoxInputModel();
    model.message = this.resourceService.getText('ifirm.common.areyousuretodelete');
    model.type = ConfirmationBoxType.YesNo;
    config.data = model;
    let instance = this.popupService.open<ConfirmationBoxComponent>(this.resourceService.getText('ifirm.common.delete'), ConfirmationBoxComponent, config);
    const subscription = instance.afterClosed.subscribe(x => {
      if (subscription) {
        subscription.unsubscribe();
      }
      if (x && x.result) {
        this.subscriptions.add(this.GridServiceService.moveToRecyclebinRequest(this.deleteRoeList).subscribe(res => {
          if (res.success) {
            this.updateGrid();
          }
          else {
            this.deleteErrorDisplay(res);
          }
        }))
      }
    });
  }

  private deleteErrorDisplay(data): void {
    if (data.ValidationCode > 0) {
      if (data.maxallowedfilecount > 0 && data.maxallowedfoldercount > 0 && (data.userselectedfilecount > 0 || data.userselectedfoldercount > 0)) {
        const config: ModalPopupConfig<any> = new ModalPopupConfig<any>();
        config.data = this.resourceService.getText('dms.validationmessages.' + data.ValidationCode);
        this.popupService.open<InformationBoxComponent>(this.resourceService.getText('dms.common.limitexceededheader'), InformationBoxComponent, config);
      }
      else {
        this.toasterService.warning(this.resourceService.getText('dms.validationmessages.' + data.ValidationCode));
      }
    }
    else {
      this.toasterService.error(this.resourceService.getText('dms.delete.errormessage'));
    }

  }

  isDeleteAllowed(file) {
    if (file.Kind == fileKind.Contact || (file.Kind == fileKind.Folder && (file.Id <= 0 || file.IsSystemFolder || file.DefaultFolderId > 0))) return false;

    if (file.EntityType == entityType.Contact || file.EntityType == entityType.Job) {
      if (this.userRoles.DmsViewDelete || this.userRoles.DmsViewPermanentDelete) {
        if (file.Kind == fileKind.File) {
          return true;
        }
        else if (file.Kind == fileKind.Folder) {
          if (this.userRoles.DmsDeleteCustomFolder) {
            return true;
          }
        }
      }
    }
    else if (this.userRoles.DmsFirmDocuments && (file.EntityType == entityType.Firm || file.EntityType == entityType.User || file.EntityType == entityType.Hr)) {
      if (file.EntityType == entityType.Firm && this.userRoles.DmsInternalDocumentsViewEdit) return true;
      if (file.EntityType == entityType.Hr && this.userRoles.hrManager) return true;
      if (file.EntityType == entityType.User && file.EntityId > 0 && file.EntityId == this.userRoles.userId) return true;
      if (file.EntityType == entityType.User && file.EntityId > 0 && file.EntityId != this.userRoles.userId && this.userRoles.DmsUserFolderAdmin) return true;
    }
      return false;
  };


  onClickAddTags(file) {
    this.GridServiceService.gridAddTags(file, 'firmDoc');
  }

  showTags(file) {
    this.GridServiceService.showGridTags(file);
  }

  updateTagList(file) {
    this.GridServiceService.updateGridTagList(file);
  }

  removeTag(event): void {
    this.GridServiceService.removeGridTag(event);
  }

  hideTags(file, fromIcon) {
    this.GridServiceService.hideGridTags(file, fromIcon);
  }

  fileNameMouseOver(file) {
    this.GridServiceService.getDocumentFullPathName(file);
  }
  createPdf(){
    this.GridServiceService.openPdf(this.GridServiceService.checkedDatalist,this.tab,this.gridPayload);
  }

  createMergePdf(){
    this.GridServiceService.openMergePdf(this.GridServiceService.checkedDatalist,this.gridPayload,this.tab);
  }

  openFilelock(file) :void{
      this.GridServiceService.openLockClick(file,this.tab, this.gridPayload)
  }

  versionToolTip(fileCount) {
      return this.versionTooltipLabel?.replace(/(\{0\})/g, fileCount);
  }

  openContainingFolder(EntityType:number,EntityId:number,ParentId:number){
    const reportUrl = this.router.createUrlTree(['/'], { queryParams: { mode: "edit",id:EntityId,tab:'dmsdocs',dmsfolderid:ParentId}}).toString();
    window.open(entityUrl['dmsdocs']+reportUrl, '_blank');
  }

  downloadContact(contactId) {
    var selectedFileIds = [];
    var selectedFolderIds = [];
    var isSearchFilterApplied = false;
    var selecterFolderList = [];
    this.GridServiceService.downloadZip(selectedFolderIds, selecterFolderList, selectedFileIds, isSearchFilterApplied, contactId);
};
}
