import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FolderDocumentGridComponent } from './client-documents-folder-grid.component';

describe('FolderDocumentGridComponent', () => {
  let component: FolderDocumentGridComponent;
  let fixture: ComponentFixture<FolderDocumentGridComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ FolderDocumentGridComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FolderDocumentGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
