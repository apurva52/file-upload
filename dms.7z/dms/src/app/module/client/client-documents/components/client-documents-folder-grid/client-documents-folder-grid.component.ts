import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IFirmButtonModule, IFirmDataTableModule, LoaderModule ,LocalizationModule, ModalPopupService, ResourceService} from '@ifirm';
import { FilePropertyComponent } from '../../../../../dialogs/file-property/file-property.component';
import { GridServiceService } from '../../../../../shared/tools/service/grid-service.service';
@Component({
  selector: 'app-client-documents-folder-grid',
  standalone: true,
  imports: [CommonModule,IFirmDataTableModule, IFirmButtonModule, LoaderModule, LocalizationModule],
  templateUrl: './client-documents-folder-grid.component.html',
  styleUrls: ['./client-documents-folder-grid.component.scss']
})
export class FolderDocumentGridComponent implements OnInit {

  @Input() folderData:any=[];
  @Input() isLoader= true;
  @Input() isSearchFilter:boolean=false;
  @Input() gridPayload:any;
  contactsList:any;
  clientGridColumns: { columnName: string; }[];
  
  @Output() defaultFolderEvent = new EventEmitter();
  @Output() sortColumn = new EventEmitter();

  constructor(  private resourceService: ResourceService, private popupService: ModalPopupService, private gridServices: GridServiceService) {
  }

  ngOnInit(): void {   
  }

  selectRowFolder(item) {
    this.defaultFolderEvent.emit(item)
  }

  sortType(sort: string) {
    this.gridPayload.SortColumn = sort;
    this.gridPayload.SortOrder = (this.gridPayload.SortOrder == 'desc') ? 'asc' : (this.gridPayload.SortOrder == 'asc') ? 'desc' : 'desc';
    this.gridPayload.pageSize = 0;
    this.sortColumn.emit(this.gridPayload); 
}

sortClass(sort: string) {
  if (this.gridPayload?.SortColumn === sort) {
    if (this.gridPayload?.SortOrder === "asc") {
      return "ascendImg dms-sort";
    } else {
      return "descendImg dms-sort";
    }
  }
}

showIcons(file) {
  let el = document.getElementById(
    'dmsProperties-' + file.Id + file.Kind + file.EntityId
  );
  el?.classList.add(el.classList.value + 'OnHover');

}

hideIcons(file) {
  let el = document.getElementById(
    'dmsProperties-' + file.Id + file.Kind + file.EntityId
  );
  el?.classList.remove(el.classList[1]);
}

showPropertiesDialog(file) {
  let data = {  Name: "", DefaultFolderId: null, isDeleted: true, file: { kind: file.Kind, EntityId: file.EntityId, EntityType: file.EntityType, Icon: file.Icon, Source: file.Source, EmailMetaDataId: file.EmailMetaDataId, Name: file.Name, id: file.Id, Hierarchy: file.Hierarchy, IsRecycleBin: false, isJobFolder: false, IsSystemFolder: file.IsSystemFolder } }
  let instance = this.popupService.open<FilePropertyComponent>(this.resourceService.getText('dms.propertiesdialog.properties'), FilePropertyComponent, {data:data});
  const sub = instance.afterClosed.subscribe(response => {
  });
}

fileNameMouseOver(file) {
  this.gridServices.getDocumentFullPathName(file);
}

}
