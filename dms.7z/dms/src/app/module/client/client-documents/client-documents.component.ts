import { Component, OnDestroy, OnInit } from '@angular/core';
import { ModalPopupService, ResourceService, ToasterService } from '@ifirm';
import { Subscription } from 'rxjs/internal/Subscription';
import { UploadDocumentComponent } from '../../../dialogs/upload-documents/upload-documents.component';
import { DmsService } from '../../../dms.service';
import { DmsFiltersService } from '../../../filter-components/dms-filters.service';
import { payLoadCommonModel } from '../../../shared/filters/model/user.model';
import { GridServiceService } from '../../../shared/tools/service/grid-service.service';
import { Router } from '@angular/router';
import { InsertLinkComponent } from '../../../dialogs/insert-link/insert-link.component';
import { AddFolderComponent } from '../../../dialogs/add-folder/add-Folder.component';
import { CopyMoveDocumentSelectionModel } from '../../../dialogs/file-copy/models/file-copy.mode';

@Component({
  selector: 'app-client-documents',
  templateUrl: './client-documents.component.html',
  styleUrls: ['./client-documents.component.scss']
})
export class ClientDocumentsComponent implements OnDestroy, OnInit {
  private subscriptions = new Subscription();
  gridPayload = {} as payLoadCommonModel;
  uploadPopupData = {} as { UserRoles: any, EntityId: number, EntityType: number, FolderId: number, Hierarchy: string, FolderName: string };
  resourceLoadCheck: boolean = false;
  folderData:any;
  resetPayload: { payload: any; isOnlyContactSelected: boolean; isEmptyEvent: boolean; };
  constructor(private popupService: ModalPopupService, private resourceService: ResourceService, private gs: GridServiceService, private toasterService: ToasterService, private dmsFilterService: DmsFiltersService, private dmsService: DmsService, private router: Router) {
  }

  ngOnInit(): void {


    var res = this.resourceService.get('dms.uploadfiles');
    if (res instanceof Promise) {
      res.then((_) => {
        this.resourceLoadCheck = true;
        this.afterResourceLoad();
      });
    } else {
      this.resourceLoadCheck = true;
      this.afterResourceLoad();
  }
}

  afterResourceLoad() {
    this.dmsService.navigateToHome();
    this.subscriptions.add(this.gs.getCommonPayload().subscribe((response: payLoadCommonModel) => {
      if (response) {
        this.gridPayload = response;
        this.uploadPopupData.EntityId = response.EntityId;
        this.uploadPopupData.EntityType = response.EntityType;
        this.uploadPopupData.FolderId = response.FolderId;
        this.uploadPopupData.Hierarchy = response.Hierarchy;
        this.uploadPopupData.FolderName = this.getFolderName();

      }
    }));
    this.updateUserInfo();
  }
  getFolderName():string {
    if (this.gs.contactData.get("contactData")?.Hierarchy == null) {
      const folderlist = this.gs.contactData.get("contactData")?.FolderHierarchyList;
      if (folderlist?.length > 0) {
        return folderlist.at(-1)?.FolderName;
      }
    }
  }

  dmsFilterToggle: boolean = false;

  openUploadDocument(): void {
    const payload = {
      payload: this.gridPayload,
      isOnlyContactSelected: false,
      isEmptyEvent: true
    }
    let instance = this.popupService.open<UploadDocumentComponent>(this.resourceService.getText('dms.uploadfiles'), UploadDocumentComponent, { data: this.uploadPopupData });
    const subscription = instance.afterClosed.subscribe(result => {
      if (subscription) {
        subscription.unsubscribe();
      }
      if (result !== null) {
        this.dmsService.clearSearchFilter.next(payload);
      }
    });
  }
  dmsFilterPaneHideShow() {
    return this.dmsFilterToggle ? "hideFilter" : "showFilter";
  }

  dmsFilterToggleButtonSlide() {
    return this.dmsFilterToggle ? "filterToggleButton filterToggleButtonExpand" : "filterToggleButton filterToggleButtonCollapse";
  }

  dmsFilterToggleDirection() {
    return this.dmsFilterToggle ? "fa fa-angle-double-right rightToggle rightToggleR dmsFilterPointers" : "fa fa-angle-double-left rightToggle rightToggleL dmsFilterPointers";
  }

  toggleDmsFilter() {
    this.dmsFilterToggle = !this.dmsFilterToggle;
  }


  updateUserInfo(): void {
    if (this.dmsService.userInfoMap.get('userInfoValue') != undefined) {
      const response = this.dmsService.userInfoMap.get('userInfoValue');
      this.uploadPopupData.UserRoles = {
        allowApmAccess: response.IsAllowApmAccess,
        viewUpload: response.DmsViewUpload, contactView: response.ContactView,
        internalDocumentsViewEdit: response.DmsInternalDocumentsViewEdit,
        firmDocuments: response.DmsFirmDocuments
      };
    }
  }

  isEnableDialog(){
    return this.gs.isEnableConditionalButton;
  }
  
  showAddFolderDialog(){
    const payloadResponse = this.gs.commonPayloadData.get("commonPayloadData");
        this.folderData = {
          EntityType: payloadResponse.EntityType,
          EntityId: payloadResponse.EntityId,
          ParentFolderId: payloadResponse.FolderId,
          Hierarchy: payloadResponse.Hierarchy
        };
        this.resetPayload = {
          payload: payloadResponse,
          isOnlyContactSelected: false,
          isEmptyEvent: true
        };
    let instance = this.popupService.open<AddFolderComponent>(this.resourceService.getText('dms.common.addfolder'), AddFolderComponent, { data: this.folderData });
    const sub = instance.afterClosed.subscribe(response => {
      if (response) {
       this.dmsService.clearSearchFilter.next(this.resetPayload);
      }
    });
  }

  showInsertLinkDialog(){
    const payloadResponse = this.gs.commonPayloadData.get("commonPayloadData");
        this.folderData = {
          EntityType: payloadResponse.EntityType,
          EntityId: payloadResponse.EntityId,
          FolderId: payloadResponse.FolderId,
          Hierarchy: payloadResponse.Hierarchy
        };
        this.resetPayload = {
          payload: payloadResponse,
          isOnlyContactSelected: false,
          isEmptyEvent: true
        };
    let instance = this.popupService.open<InsertLinkComponent>(this.resourceService.getText('dms.common.link'), InsertLinkComponent, { data: this.folderData });
    const sub = instance.afterClosed.subscribe(response => {
      if (response) {
        this.dmsService.clearSearchFilter.next(this.resetPayload);
      }
    });
  }
  
  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }
}
