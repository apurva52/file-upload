import { GridColumnModel, PropertyName } from '../../../../../../../ifirm-common-components/src/public-api';

export class ContactDataModel {

    @PropertyName('AVScanStatus') AVScanStatus: string;  
    
    @PropertyName('Code') Code: string;  

    @PropertyName('DefaultFolderId') DefaultFolderId: string;  

    @PropertyName('DeletedBy') DeletedBy: string;  

    @PropertyName('DeletedDate') DeletedDate: string;  

    @PropertyName('EmailMetaDataId') EmailMetaDataId: string;  

    @PropertyName('EntityId') EntityId: string;  

    @PropertyName('EntityType') EntityType: string;  

    @PropertyName('FileSize') FileSize: string;  

    @PropertyName('Guid') Guid: string;  

    @PropertyName('Hierarchy') TypeHierarchy: string;  

    @PropertyName('Icon') Icon: string;  

    @PropertyName('Id') Id: string;

    @PropertyName('IsLocked') IsLocked: boolean;

    @PropertyName('IsNoteExist') IsNoteExist: boolean;

    @PropertyName('IsReadOnly') IsReadOnly: boolean;

    @PropertyName ('IsSystemFolder') IsSystemFolder: boolean;

    @PropertyName('IsVersionExist') IsVersionExist: boolean;

    @PropertyName('Kind') Kind: number;

    @PropertyName('LinkUrl') LinkUrl: string;

    @PropertyName('Location') Location: string;

    @PropertyName('LockMessage') LockMessage:string;

    @PropertyName('LockType') LockType: string;

    @PropertyName('LockedBy') LockedBy: string;

    @PropertyName('LockedDate') LockedDate: string;

    @PropertyName('Name') Name: string;

    @PropertyName('OpenEditPayload') OpenEditPayload: string;

    @PropertyName('OriginalLocation') OriginalLocation: string;

    @PropertyName('ParentId') ParentId: string;

    @PropertyName('Size') Size: string;

    @PropertyName('Source') Source: string;

    @PropertyName('StoragePath') StoragePath: string;

    @PropertyName('TagCount') TagCount: number;

    @PropertyName('Type') Type: string;

    @PropertyName('UpdatedBy') UpdatedBy: string;

    @PropertyName('UpdatedDate') UpdatedDate: string;

    @PropertyName('VersionCount') VersionCount: number;

    @PropertyName('ParentFolderId') ParentFolderId :number;

    @PropertyName('Hierarchy') Hierarchy :string;

}





export class payLoadModel{
    
    ContentSearchOffset : string;
    DisplayArea: number;
    EntityId: number;
    EntityType : number;
    Filters: {
        ContactGroupId: string;
        ContactList: string[];
        ContactsTagList: [];
        DateFrom: string;
        DateTo:string;
        FileTypes:string[];
        FirmSystemTag: string;
        IsArchivedContacts: boolean;
        IsFilterPortalTag: boolean;
        IsInActiveUser: boolean;
        IsJobClosed:string;
        JobTypeTagList: string[];
        MyRecentFiles: boolean;
        NoteAssignTo:string;
        NoteCreatedBy:string;
        NoteDueDate: string;
        NoteStatus: string;
        ShowArchivedContactsCheckBox:boolean;
        ShowInActiveUserCheckBox: boolean;
        TagList: string[];
        UserFolders: number;
        UserId: string}

        FolderId:number;
        HasMoreEntityRecords: boolean;
        HasMoreRecords: boolean;
        Hierarchy: any;
        IsContentSearch?: boolean;
        IsDeleted: boolean;
        IsFileSearch: boolean;
        IsFiltering: boolean;
        IsOnlyUserFolderFiltering: boolean;
        Page: number;
        SearchMore: boolean;
        SearchNote: string;
 

            SearchTags:{
            ContactsTypeTags: string[];
            IsSearchPortalTag: boolean;
            JobTypeTags: string[];
            PermentContactsTagType: number;
            PermentTagType: number;
            Tags:string[]};
    
        SearchText: string;
        SortColumn: string;
        SortOrder: string;

        constructor(){

            this.ContentSearchOffset=null;
            this.DisplayArea=1;
            this.EntityId=0;
            this.EntityType=3;
            this.Filters={
                ContactGroupId:"",
                ContactList: [],
                ContactsTagList: [],
                DateFrom: "",
                DateTo:"",
                FileTypes:[],
                FirmSystemTag: "",
                IsArchivedContacts: true,
                IsFilterPortalTag: false,
                IsInActiveUser: false,
                IsJobClosed:"0",
                JobTypeTagList: [],
                MyRecentFiles: false,
                NoteAssignTo: "",
                NoteCreatedBy: "",
                NoteDueDate: "",
                NoteStatus: "",
                ShowArchivedContactsCheckBox:false,
                ShowInActiveUserCheckBox: false,
                TagList: [],
                UserFolders: 1,
                UserId: ""};
          
                this.FolderId= null;
                this.HasMoreEntityRecords= null;
                this.HasMoreRecords= null;
                this.Hierarchy= null;
                this.IsDeleted=false;
                this.IsFileSearch=false;
                this.IsFiltering= false;
                this.IsContentSearch = false
                this.IsOnlyUserFolderFiltering = false;
                this.Page= 0;
                this.SearchMore=true;
                this.SearchNote="";
            
                    this.SearchTags={
                    ContactsTypeTags: [],
                    IsSearchPortalTag: false,
                    JobTypeTags: [],
                    PermentContactsTagType: 0,
                    PermentTagType: 0,
                    Tags:[]};
            
                this.SearchText= "";
                this.SortColumn= "UpdatedDate";
                this.SortOrder= "asc";
        }

    };
     



// export class payLoadModel{
    
//     @PropertyName('ContentSearchOffset') ContentSearchOffset : string = null;
//     @PropertyName('DisplayArea') DisplayArea: number=1;
//     @PropertyName('EntityId') EntityId: number=0;
//     @PropertyName('EntityType') EntityType : number=3;

    
//     @PropertyName('FolderId') FolderId:number = null;
//     @PropertyName('HasMoreEntityRecords') HasMoreEntityRecords: number =null;
//     @PropertyName('HasMoreRecords') HasMoreRecords: number = null;
//     @PropertyName('Hierarchy') Hierarchy: number= null;
//     @PropertyName('IsContentSearch') IsContentSearch: boolean=true;
//     @PropertyName('IsDeleted') IsDeleted: boolean=false;
//     @PropertyName('IsFileSearch') IsFileSearch: boolean=false;
//     @PropertyName('IsFiltering') IsFiltering: boolean = false;
//     @PropertyName('IsOnlyUserFolderFiltering') IsOnlyUserFolderFiltering: boolean = false;
//     @PropertyName('Page') Page: number = 0;
//     @PropertyName('SearchMore') SearchMore: boolean =true;
//     @PropertyName('SearchNote') SearchNote: string ="";

//     @PropertyName('SearchText') SearchText: string= "";
//     @PropertyName('SortColumn') SortColumn: string= "UpdatedDate";
//     @PropertyName('SortOrder') SortOrder: string= "asc";
    
//     @PropertyName('Filters') Filters: {
//         @PropertyName('ContactGroupId') ContactGroupId: string ="";
//         @PropertyName('ContactList') ContactList: string[]=[];
//         @PropertyName('ContactsTagList') contactsList : string[]=[];
//         @PropertyName('DateFrom') DateFrom: string="";
//         @PropertyName('DateTo') DateTo: string= "";
//         @PropertyName('FileTypes') FileTypes: string[]=[];
//         @PropertyName('FirmSystemTag') FirmSystemTag: string ="";
//         @PropertyName('IsArchivedContacts') IsArchivedContacts: boolean= true;
//         @PropertyName('IsFilterPortalTag') IsFilterPortalTag: boolean= false;
//         @PropertyName('IsInActiveUser') IsInActiveUser: boolean = false;
//         @PropertyName('IsJobClosed') IsJobClosed: string = "0";
//         @PropertyName('JobTypeTagList') JobTypeTagList: string[]=[];
//         @PropertyName('MyRecentFiles') MyRecentFiles: boolean = false;
//         @PropertyName('NoteAssignTo') NoteAssignTo: string="";
//         @PropertyName('NoteCreatedBy') NoteCreatedBy: string="";
//         @PropertyName('NoteDueDate') NoteDueDate: string=""
//         @PropertyName('NoteStatus') NoteStatus: string="";
//         @PropertyName('ShowArchivedContactsCheckBox') ShowArchivedContactsCheckBox: boolean = false;
//         @PropertyName('ShowInActiveUserCheckBox') ShowInActiveUserCheckBox: boolean = false;
//         @PropertyName('TagList') TagList: string[] = [];
//         @PropertyName('UserFolders') UserFolders: number=1;
//         @PropertyName('UserId') UserId: string = ""}


//         @PropertyName('SearchTags') SearchTags:any={
//             @PropertyName('ContactsTypeTags') ContactsTypeTags: string[]=[];
//             @PropertyName('IsSearchPortalTag') IsSearchPortalTag: boolean= false;
//             @PropertyName('JobTypeTags') JobTypeTags: string []=[];
//             @PropertyName('PermentContactsTagType') PermentContactsTagType: number=0;
//             @PropertyName('PermentTagType') PermentTagType: number=0;
//             @PropertyName('Tags') Tags: string[]=[]};

      

//     };


