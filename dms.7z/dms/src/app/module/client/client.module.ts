import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import {IFirmDataTableModule} from '@ifirm'
import { ClientDocumentsRoutingModule } from './client-documents-routing.module';
import { FilterComponentsComponent } from './../../filter-components/filter-components.component';
import { ToolsComponentsComponent } from './../../tools-components/tools-components.component';
import {ClientDocumentsRootGridComponent} from './client-documents/components/client-documents-root-grid/client-documents-root-grid.component';
import {BreadcrumbsComponent} from '../../shared/tools/breadcrumbs/breadcrumbs.component';
import {SearchBarComponent} from '../../shared/tools/search-bar/search-bar.component';
import { IFirmButtonModule } from '@ifirm';
import { ClientDocumentsComponent } from './client-documents/client-documents.component';
import { DirectivesModule } from '../../shared/directives/directives.module';
import { CommonModule } from '@angular/common';


@NgModule({
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  declarations: [
    ClientDocumentsComponent, ToolsComponentsComponent
  ],
  imports: [
    CommonModule,
    IFirmDataTableModule,
    ClientDocumentsRoutingModule,
    FilterComponentsComponent,
    ClientDocumentsRootGridComponent,
    BreadcrumbsComponent,
    SearchBarComponent,
    IFirmButtonModule,
    DirectivesModule
  ],
  exports:[ FilterComponentsComponent, ToolsComponentsComponent]
})
export class ClientModule { }
