import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ModalPopupConfig, ModalPopupInstance, ResourceService, ToasterService } from '@ifirm';
import { DmsDialogApiService } from '../dms-dialog-api.service';
import { InsertLinkModel } from '../models/insert-link.model';
import {ValidatorService} from '../../validation/validator.service'
import { NgSelectConfig } from '@ng-select/ng-select';
import { fileKind, fileSource , ApiValidationCode } from '../../constants/app-constants';

@Component({
  selector: 'app-insert-link',
  templateUrl: './insert-link.component.html',
  styleUrls: ['./insert-link.component.scss', '../dms-dialog-style.scss']
})
export class InsertLinkComponent implements OnInit {

  selectedTagList: any[] = [];
  tags: any[] = [];
  tagNames = [];
  tagLoaded: boolean;
  insertLinkForm: FormGroup;
  rData: boolean = false;
  insertLinkInfo: InsertLinkModel = null;
  fileId : number;
  defaultTagIndex: number;
  searchTag: string;
  displayTextExist: string;
  @ViewChild('displayTextInput') displayTextInput: ElementRef;

  constructor(private config: ModalPopupConfig<any>, private instance: ModalPopupInstance, private toasterService: ToasterService,
    private resourceService: ResourceService, private dmsDialogApiService: DmsDialogApiService, private validatorService: ValidatorService, private ngSelectconfig: NgSelectConfig) {
    this.insertLinkInfo = config.data as InsertLinkModel;
  }

  ngOnInit(): void {
    this.tagLoaded = this.tagNames.length == 0 ? false:true ;
    this.insertLinkInfo.FileKind = fileKind.File;
    this.insertLinkInfo.FileSource = fileSource.LinkUrl;
    this.getTagList(this.insertLinkInfo);
    this.createForm();
    this.searchTag = this.resourceService.getText('dms.searchtag.searchtext');
    this.ngSelectconfig.notFoundText = this.resourceService.getText('dms.searchtag.nodatafound');
  }

  ngAfterViewInit(): void {
    this.displayTextInput.nativeElement.focus();
  }

  insertLink(): void {
    if (this.insertLinkForm.status === 'VALID') {
      this.rData = true;
      this.insertLinkInfo.TagList = this.selectedTagList.map(item => item.id);
      this.insertLinkInfo.FileId > 0 ? this.updateInsertLink(this.insertLinkInfo) : this.insertLinkDetails(this.insertLinkInfo);
    }
  }

  get displayText() {
    return this.insertLinkForm.get('displayText');
  }

  get linkUrl() {
    return this.insertLinkForm.get('linkUrl');
  }

  private createForm() {
    this.insertLinkForm = new FormGroup({
      displayText: new FormControl("", Validators.required),
      linkUrl: new FormControl("", [Validators.required, this.validatorService.noWhitespaceValidator]),
      tagList: new FormControl("")
    });
  }

  closePopup(result: boolean): void {
    this.instance.close(result);
  }

  private getTagList(insertLinkInfo: InsertLinkModel){
    this.dmsDialogApiService.GetTagList(insertLinkInfo).then(res => {
      this.tagNames = res.TagList;
      this.tags = res.TagList.map((value) => ({
        id: value.TagId,
        name: value.TagNameForDisplay
        }));
      if(this.tags.length != 0)
      {
        this.tagLoaded = true;
      }
      if(this.insertLinkInfo.FileId > 0){
         this.selectedTagList = this.tags.filter((item) => res.SelectedTagList.includes(item.id));
         this.defaultTagIndex = this.selectedTagList.findIndex(x => x.id == -99);
        if(this.defaultTagIndex > -1)
        {
          this.selectedTagList[this.defaultTagIndex].disabled = true;
        }
         }
    }).catch(
      exception => {
        this.rData = false;
        this.toasterService.error(this.resourceService.getText('dms.common.errormessage'));
        console.log(exception);
      });
  }

  private insertLinkDetails(insertLinkInfo : InsertLinkModel):void {
    this.displayTextExist = "";
    this.dmsDialogApiService.insertLink(insertLinkInfo).then(res => {
      this.rData = false;
      if (res.success == true) {
        this.closePopup(true);
      }
      else if(res.ValidationCode == ApiValidationCode.SameNameLinkUrlFileExists){
        this.displayTextExist = insertLinkInfo.DisplayText;
      }
      else {
        this.toasterService.error(this.resourceService.getText('dms.common.errormessage'));
      }
    }).catch(
      exception => {
        this.rData = false;
        this.toasterService.error(this.resourceService.getText('dms.common.errormessage'));
        console.log(exception);
      });
   }

   private updateInsertLink(insertLinkInfo : InsertLinkModel):void {
    this.displayTextExist = "";
    this.dmsDialogApiService.updateInsertLink(insertLinkInfo).then(res => {
      this.rData = false;
      if (res.success == true) {
        this.closePopup(true);
      }
      else if(res.ValidationCode == ApiValidationCode.SameNameLinkUrlFileExists){
        this.displayTextExist = insertLinkInfo.DisplayText;
      }
      else {
        this.toasterService.error(this.resourceService.getText('dms.common.errormessage'));
      }
    }).catch(
      exception => {
        this.rData = false;
        this.toasterService.error(this.resourceService.getText('dms.common.errormessage'));
        console.log(exception);
      });
   }
}

