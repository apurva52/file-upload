import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InsertLinkComponent } from './insert-link.component';

describe('InsertLinkComponent', () => {
  let component: InsertLinkComponent;
  let fixture: ComponentFixture<InsertLinkComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InsertLinkComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(InsertLinkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
