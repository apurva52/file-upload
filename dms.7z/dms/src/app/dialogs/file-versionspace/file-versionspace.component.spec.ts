import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FileversionspaceComponent } from './file-versionspace.component';

describe('FileversionspaceComponent', () => {
  let component: FileversionspaceComponent;
  let fixture: ComponentFixture<FileversionspaceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FileversionspaceComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FileversionspaceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
