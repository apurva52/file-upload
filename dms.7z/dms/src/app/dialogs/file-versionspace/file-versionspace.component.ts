import { Component, OnInit } from '@angular/core';
import { ResourceService, ModalPopupConfig, ModalPopupService } from '@ifirm';
import { FileVersion } from '../models/file-version.model';
import { ToasterService } from 'projects/ifirm-common-components/src/lib/toaster//toaster.service';
import { DmsDialogApiService } from '../dms-dialog-api.service';

@Component({
  selector: 'app-fileversionspace',
  templateUrl: './file-versionspace.component.html',
  styleUrls: ['./file-versionspace.component.scss']
})
export class FileversionspaceComponent  implements OnInit {

  data: any;
  fileVersions: FileVersion[];
  loadError: boolean = false;
  fileIcon: string;
  deleteTooltipMessage: string;

 constructor(private config: ModalPopupConfig<any>, private dmsDialogApiService: DmsDialogApiService,
  private toasterService: ToasterService, private resourceService: ResourceService, private popupService: ModalPopupService) {
    this.data = config.data;
  }

  ngOnInit(): void {
    this.fileIcon = this.data.Icon;
      this.getFileVersions(this.data.Id);
  }

  HeaderClick() {
    return false;
  }
  deleteFileVersions(fileVersion: FileVersion) {
    var confirmInstance = this.popupService.confirm(this.resourceService.getText('dms.delete.permanenttitle'), this.resourceService.getText('dms.delete.permanentconfirm'));
    const subscription = confirmInstance.afterClosed.subscribe(a => {
      subscription.unsubscribe();
      if (a && a.result == true) {
        var deleteContract = {
          VersionId: fileVersion.VersionId,
          VersionGuid: fileVersion.VersionGuid,
          FileId: fileVersion.FileId,
          UpdatedDateDisplay: fileVersion.UpdatedDateDisplay,
          Name: fileVersion.FileName,
          StoragePath: fileVersion.StoragePath,
          FileType: fileVersion.FileType,
          EntityType: fileVersion.EntityType,
          EntityId: fileVersion.EntityId,
          Size: fileVersion.Size,
          Hierarchy: fileVersion.Hierarchy
        };

        this.dmsDialogApiService.DeleteFileVersions(deleteContract).then(res => {
          if (res.success === true) {
            this.getFileVersions(this.data.Id);
          }
          else {
            this.toasterService.error(this.resourceService.getText('dms.delete.errormessage'));
          }
        })
      }
    });
  }

  getFileVersions(fileId: number) {
    this.dmsDialogApiService.GetFileVersions(fileId).then(res => {
      if (res.Errors.length === 0) {
        this.fileVersions = res.FileVersions;
        this.deleteTooltipMessage = this.resourceService.getText('dms.delete.permanenttooltip');
      }
      else {
        this.loadError = true;
      }
    });
  }
}
