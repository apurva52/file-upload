import { ClientModel } from 'projects/ifirm-common-components/src/lib/common-client-autocomplete/client-autocomplete/client-autocomplete/model/client.model';
import { entityType } from '../../../constants/app-constants';
import { JobModel } from '../../file-save/model/job.model';
import { UserContractModel } from '../../models/user-contract.model';

export class CopyMoveDocumentSelectionModel {
    EntityId: number;
    EntityType: entityType;
    EntityName: string;
    FolderId: number;
    Hierarchy: string;
    FolderName: string;
    DisplayHierarchy: string|undefined;
    SelectedEntity: JobModel | ClientModel | UserContractModel

    constructor(type?: entityType, entityId?: number, entityName?: string, folderId?: number, hierarchy?: string, folderName?: string, displayHierarchy?: string, entity?: JobModel | ClientModel | UserContractModel) {
        
        this.EntityId = entityId;
        this.EntityType = type;
        this.EntityName = entityName;
        this.FolderId = folderId;
        this.Hierarchy = hierarchy;
        this.FolderName = folderName;
        this.DisplayHierarchy = displayHierarchy;
        this.SelectedEntity = entity;
    }   
}