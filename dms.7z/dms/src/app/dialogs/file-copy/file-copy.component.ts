import { Component, OnInit } from '@angular/core';
import { ModalPopupConfig, ModalPopupInstance, ModalPopupService, ObjectDeserializer, ResourceService, ToasterService } from '@ifirm';
import { JobLookupComponent } from 'projects/ifirm-common-components/src/lib/job-lookup/job-lookup/job-lookup.component';
import { JobLookUpRow } from 'projects/ifirm-common-components/src/lib/job-lookup/job-lookup/model/job-lookup.model';
import { eventType, fileKind } from '../../constants/app-constants';
import { entityType } from '../../constants/app-constants';
import { JobModel } from '../file-save/model/job.model';
import { DmsFileModel } from '../models/dms-fIle.model';
import { catchError, map, mergeMap } from 'rxjs/operators';
import { ClientModel } from 'projects/ifirm-common-components/src/lib/common-client-autocomplete/client-autocomplete/client-autocomplete/model/client.model';
import { ClientLookupComponent } from 'projects/ifirm-common-components/src/lib/common-client-lookup/common-client-lookup/client-lookup.component';
import { UserContractModel } from '../models/user-contract.model';
import { DmsDialogApiService } from '../dms-dialog-api.service';
import { FolderSelectionComponent } from '../folder-selection/folder-selection.component';
import { CopyMoveSelectionService } from './services/file-copy.service';
import { CopyMoveDocumentModel } from './../models/copy-move-document-model';
import {  combineLatest, iif, of } from 'rxjs';
import { CopyMoveSelectionApiService } from './services/file-copy-api.service';

@Component({
  selector: 'app-file-copy',
  templateUrl: './file-copy.component.html',
  styleUrls: ['./file-copy.component.scss']
})
export class FileCopyComponent implements OnInit {
  private _selectionMode: boolean;
  copyMoveDialogData: CopyMoveDocumentModel;
  eventTypeData: eventType;
  entityTypeLookup: typeof entityType;
  entityTypes: {name: string | Promise<string>, id: number, isAllowed: boolean}[];
  roles: any;
  selectedItems: DmsFileModel[];
  locationDetails: any;
  selectedJob: JobModel;
  jobDescription: string;
  selectedClient: ClientModel;
  users: UserContractModel[];
  tabindex = 0;
  focusElement: number;
  displaySystemUserAsSharedFolder: boolean;
  eventTypeLookup: typeof eventType;
  itemsSelectedMessage: string;
  displayHierarchy: string;
  preselectedEntities: boolean;
  isFirmDocuments: boolean;
  isLoading: boolean;
  selectedUserId: number;

  constructor(private config: ModalPopupConfig<any>,private fileCopyApiService:CopyMoveSelectionApiService, private instance: ModalPopupInstance, private resourceService: ResourceService, private popupService: ModalPopupService, private dmsDialogApiService: DmsDialogApiService, private selectionService: CopyMoveSelectionService, private toasterService: ToasterService) {
    this._selectionMode = true;
    this.copyMoveDialogData = config.data;
   this.roles = this.copyMoveDialogData.UserRoles;
    this.eventTypeData = this.copyMoveDialogData.EventType;
    this.selectedItems = this.copyMoveDialogData.SelectedItems;
    this.locationDetails = this.copyMoveDialogData.LocationDetails;
    this.entityTypeLookup = entityType;
    this.eventTypeLookup = eventType;
    this.selectedJob = new JobModel();
    this.selectedClient = new ClientModel()
    this.displaySystemUserAsSharedFolder = this.copyMoveDialogData.LocationDetails.EntityType === entityType.Hr;
    this.displayHierarchy = "";
    this.selectionService.hierarchyChange.subscribe((value) => {
      this.displayHierarchy = value;
    });
    this.isFirmDocuments = this.copyMoveDialogData.LocationDetails.EntityType === entityType.Firm
    || this.copyMoveDialogData.LocationDetails.EntityType === entityType.Hr 
    || this.copyMoveDialogData.LocationDetails.EntityType === entityType.User;
    this.isLoading = false;
    this.preselectedEntities = true;
    this.selectedUserId = 0;

   
  }

  ngOnInit(): void {
    this.entityTypes = [{name: this.resourceService.get("ifirm.common.job"), id: entityType.Job, isAllowed: (this.isAllowApmAccess() && this.isCopyMoveAllowed())},
    {name: this.resourceService.get("ifirm.common.contact"), id: entityType.Contact, isAllowed: (this.hasContactViewRole() && this.isCopyMoveAllowed())},
    {name: this.resourceService.get("dms.settings.internaldocuments"), id: entityType.Firm, isAllowed: this.isAllowInternaldocuments()},
    {name: this.resourceService.get("dms.settings.hrdocuments"), id: entityType.Hr, isAllowed: this.locationDetails.EntityType == entityType.Hr},
    {name: this.resourceService.get("dms.fileuploaddialog.yourhrfolder"), id: entityType.Hr, isAllowed: this.locationDetails.EntityType == entityType.User},
    {name: this.resourceService.get("dms.fileuploaddialog.youruserfolder"), id: entityType.User, isAllowed: this.locationDetails.EntityType == entityType.User}];
    this.isLoading = true;
    const users$ = iif(() => this.isFirmDocuments, this.dmsDialogApiService.getUsers(this.displaySystemUserAsSharedFolder) 
    , of([]));
    
    const itemsSelected$ = this.getItemsSelected$();
    const folderId$ = this.GetFolderId$();
    const init$ = folderId$
    .pipe(
      mergeMap(folderId => this.selectionService.init(this.copyMoveDialogData.LocationDetails, this.roles, this.GetEntityType(), this.GetEntityId(), folderId.data, this.GetFolderName()))
    );

    combineLatest([users$, itemsSelected$, init$])
    .pipe(
    catchError(() => { this.toasterService.error("Unable to populate details");
     return of([,])}))
    .subscribe(([usersList, itemsSelected]) => {
      if (usersList === undefined || itemsSelected === undefined) {
        return;
      }
      this.isLoading = false;
      this.users = usersList;
      this.initializeItemsSelected(itemsSelected);
      if (this.CurrentSelection.EntityType === entityType.Job) {
        this.selectedJob = this.CurrentSelection.SelectedEntity as JobModel;
      }
      else if (this.CurrentSelection.EntityType === entityType.Contact) {
        this.selectedClient = this.CurrentSelection.SelectedEntity as ClientModel;
      }
      else if (this.CurrentSelection.EntityType === entityType.Hr) {
        this.selectedUserId = this.CurrentSelection.EntityId;
      }
      
      this.isLoading = false;
    });
    (this.selectedEntityType == this.entityTypeLookup.Hr && this.locationDetails.EntityType == this.entityTypeLookup.Hr) && this.getUsersList();
  }

  get EventType() {
    return eventType;
  }

  get selectionMode(): boolean {
    return this._selectionMode;
  }

  set selectionMode(value: boolean) {
    this._selectionMode = value;
    this.jobDescription = this.displayJobWith(this.selectedJob);
  }

  get selectedEntityType(): entityType {
    return this.selectionService.CurrentSelection.EntityType;
  }

  get CurrentSelection() {
    return this.selectionService.CurrentSelection;
  }

  onEntityTypeChanged(event) {
    const type = parseInt(event.target.value, 10) as entityType;
    if (type === entityType.Hr && this.locationDetails.EntityType == entityType.User) {
      this.selectionService.onEntityChanged(this.GetEntityId(), type);
    }
    else {
      this.selectionService.onEntityTypeChanged(type);
    }
  }

  jobSelectionChanged(event) {
    var newJob = event.item && !Array.isArray(event.item) ? event.item as JobModel : null;
    if (newJob === null && this.CurrentSelection.EntityType === entityType.Job && this.CurrentSelection.EntityId > 0) {
      this.preselectedEntities = false;
    }
    
    if (!this.preselectedEntities) {
      this.selectedJob = newJob;
      this.jobDescription = this.selectedJob !== null ? this.displayJobWith(this.selectedJob) : "";
      this.selectionService.onEntityChanged(this.selectedJob?.jobId, entityType.Job);
    }
  }

  jobSearchChanged(event) {
    this.preselectedEntities = false;
  }

  toggleSelectionMode(show: boolean) {
    this.selectionMode = show;
  }

  displayJobWith(item: JobModel) {
    return item && item.jobCode ? `${item.jobCode}\n${item.contactName}` : '';
  }

  onDropDownClosed() {
    if (this.selectedJob && this.selectedJob.jobCode) {
      this.selectionMode = false;
      this.jobDescription = this.displayJobWith(this.selectedJob);
    }
  }

  clientSelectionChanged(event) {
    var newClient = event.item && !Array.isArray(event.item) ? event.item as ClientModel : null;
    if (newClient === null && this.CurrentSelection.EntityType === entityType.Contact && this.CurrentSelection.EntityId > 0) {
      this.preselectedEntities = false;
    }
    
    if (!this.preselectedEntities) {
      this.selectedClient = newClient;
      this.selectionService.onEntityChanged(this.selectedClient?.ClientId, entityType.Contact);
    }
  }

  clientSearchChanged(event) {
    this.preselectedEntities = false;
  }

  contactLookupPopup() {
    const title = this.resourceService.getText("ifirm.common.contactlookup");
    this.PopupInstance(title, ClientLookupComponent, {},
      response => {
        if (response && response.result) {
          if (response.data) {
            const result = response.data;
            if (result.id) {
              const clientModel = new ClientModel();
              clientModel.ClientCode = result.clientCode;
              clientModel.ClientName = result.clientName;
              clientModel.ClientId = result.id;
              this.selectedClient = clientModel;
              this.selectionService.onEntityChanged(result.id, entityType.Contact);
            }
          }
        }
      },
      response => {
      }, "contact-lookup");
  }

 openJobLookupPopup() {
    this.PopupInstance(this.resourceService.getText("ifirm.common.joblookup"), JobLookupComponent, {clientId:this.copyMoveDialogData.LocationDetails.EntityId,isTimesheet:false}, (response) => {
      if (response && response.cancel === false) {
        const data = response.data as JobLookUpRow;
        const jobModel = new JobModel();
        jobModel.jobId = data.jobId;
        jobModel.jobStatus = data.jobStatus;
        jobModel.jobCode = data.description;
        jobModel.contactName = data.clientName;
        jobModel.statusList = data.statuses;
        return { cancel: response.cancel, data: jobModel };
      }

      return { cancel: true, data: null };
    }, (response) => {
      this.selectedJob = response.data as JobModel;
      this.jobDescription = this.displayJobWith(this.selectedJob);
      this.selectionService.onEntityChanged(this.selectedJob.jobId, entityType.Job);
    }, "job-lookup");
  }

  onUserChanged(event) {
    this.selectionService.onEntityChanged(parseInt(event.target.value, 10), this.GetEntityType());
  }

  onChangeFolder(event): void {
    if (this.selectionService.CurrentSelection.EntityId) {
      this.PopupInstance(this.resourceService.getText("dms.selectfolder"), FolderSelectionComponent, {
        EntityId: this.selectionService.CurrentSelection.EntityId,
        EntityType: this.selectionService.CurrentSelection.EntityType,
        CurrentFolderId: this.selectionService.CurrentSelection.FolderId ?? 0,
        CurrentFolderhierarchy: this.selectionService.CurrentSelection.Hierarchy
      },
      response => {
        if (response) {
          this.selectionService.onFolderChanged(response.FolderId, response.Hierarchy, response.FolderName);
        }
      },
      response => {
      }, "change-folder");
    }
  }

  onCopyDocuments(): void {
    this.onCopyMoveDocuments(eventType.Copy);
  }

  onMoveDocuments(): void {
    this.onCopyMoveDocuments(eventType.Move);
  }

  onCopyMoveDocuments(event: eventType): void{
    if ((this.selectionService.CurrentSelection.EntityId === null || this.selectionService.CurrentSelection.EntityId === undefined) && this.selectedEntityType === entityType.Job) {
      this.popupService.info(this.resourceService.getText("ifirm.common.error"), this.resourceService.getText("dms.fileuploaddialog.selectjoberror"));
      return;
    }

    if ((this.selectionService.CurrentSelection.EntityId === null || this.selectionService.CurrentSelection.EntityId === undefined) && this.selectedEntityType === entityType.Contact) {
      this.popupService.info(this.resourceService.getText("ifirm.common.error"), this.resourceService.getText("dms.fileuploaddialog.selectcontacterror"));
      return;
    }

    if (this.selectedEntityType === entityType.Contact && (this.selectionService.CurrentSelection.FolderId === null || this.selectionService.CurrentSelection.FolderId === undefined)) {
      this.popupService.info(this.resourceService.getText("ifirm.common.error"), this.resourceService.getText("dms.common.fallbackerrormessage"));
      return;
    }

    const destination: any = {
      Id: this.CurrentSelection.FolderId === null ? 0 : this.CurrentSelection.FolderId,
      Hierarchy: this.CurrentSelection.Hierarchy,
      EntityType: this.CurrentSelection.EntityType,
      EntityId: this.CurrentSelection.EntityId
    };

    const itemsList = this.selectedItems.map(x => ({
      Id: x.Id,
      Guid: x.FileGuid,
      Name: x.FileName,
      Hierarchy: x.Hierarchy,
      Kind: x.FileKind,
      EntityType: x.EntityType,
      EntityId: x.EntityId,
      Type: x.FileType,
      StoragePath: x.StoragePath,
      ParentFolderId: x.ParentId,
      EmailMetaDataId:x.EmailMetaDataId,
      LinkUrl : x.LinkUrl ?? null
    }));

    this.isLoading = true;
    const action = (documentList: any, destination: any) => event === eventType.Copy ? 
    this.fileCopyApiService.copyDocument(documentList, destination) : this.fileCopyApiService.moveDocument(documentList, destination);
    action(itemsList, destination).then(res => {
      if (res.success) {
        this.closePopup(true);
      }
      else {
        if (res.ValidationCode > 0) {
          if (res.maxallowedfilecount > 0 
            && res.maxallowedfoldercount > 0 
            && (res.userselectedfilecount > 0 || res.userselectedfoldercount > 0)) {
              this.popupService.info(this.resourceService.getText("dms.common.limitexceededheader"), 
              this.resourceService.getText(`dms.validationmessages.${res.ValidationCode}`, 
              [res.maxallowedfilecount, res.maxallowedfoldercount, res.userselectedfilecount, res.userselectedfoldercount]));
            }
          else {
            this.popupService.info(this.resourceService.getText("ifirm.common.alert"), 
            this.resourceService.getText(`dms.validationmessages.${res.ValidationCode}`));
          }

          this.closePopup(res.success);
        }
        else {
          this.popupService.info(this.resourceService.getText("ifirm.common.alert"), this.resourceService.getText("dms.common.fallbackerrormessage"));
        }
      }
    }).catch(x => {
      this.isLoading = false;
      this.popupService.info(this.resourceService.getText("ifirm.common.alert"), this.resourceService.getText("dms.common.fallbackerrormessage"));
    })
    .finally(() => {
      this.isLoading = false;
    });
  }

  closePopup(result: boolean): void {
    this.instance.close(result); 
  }

  private GetEntityType(): entityType {
    if (this.copyMoveDialogData.LocationDetails.EntityType === entityType.Firm && !this.isAllowInternaldocuments()) {
      return this.entityTypes.find(x => x.isAllowed).id;
    }

    return this.copyMoveDialogData.LocationDetails.EntityType;
  }

  private GetEntityId(): number {
    if (this.copyMoveDialogData.LocationDetails.EntityType === entityType.Firm && this.isAllowInternaldocuments()) {
      return this.selectionService.FirmEntityId;
    }

    if (this.copyMoveDialogData.LocationDetails.EntityType === entityType.Hr) {
      return this.copyMoveDialogData.LocationDetails.EntityId ?? this.copyMoveDialogData.UserRoles.userId;
    }

    return this.copyMoveDialogData.LocationDetails.EntityId;
  }

  private GetFolderId$()  {
    return of({data: this.copyMoveDialogData.LocationDetails.FolderId});
  }

  private GetFolderName(): string {
    if (this.copyMoveDialogData.LocationDetails.EntityType === entityType.Firm) {
      return this.resourceService.getText("dms.settings.internaldocuments")
    }

    return this.copyMoveDialogData.LocationDetails.FolderName;
  }

  private isAllowApmAccess(): boolean {
    return this.roles.allowApmAccess && this.roles.viewEditCopyMove;
  }

  private isCopyMoveAllowed(): boolean {
    const containsFolder = this.selectedItems.some(item => item.FileKind == fileKind.Folder);
    return containsFolder ? this.roles.viewEditCopyMove && this.roles.addCustomFolder : this.roles.viewEditCopyMove;
  }

  private hasContactViewRole(): boolean {
    return this.roles.viewEditCopyMove && this.roles.contactView;
  }

  private isAllowInternaldocuments(): boolean {
    return this.roles.internalDocumentsViewEdit && this.roles.firmDocuments;
  }

  private PopupInstance(title: string, component, configData, mapCallback, subscribeCallBack, cssClassName) {
    const config = new ModalPopupConfig();
    config.data = configData;
    const instance = this.popupService.open(title, component, config, cssClassName);
    const subscription = instance.afterClosed
      .pipe(
        map((response) => {
          return mapCallback(response);
        })).subscribe(response => {
          if (subscription) {
            subscription.unsubscribe();
          }
          if (response && response.cancel === false) {
            subscribeCallBack(response);
          }
        });
  }

  private getUsersList() {
    return this.dmsDialogApiService.getUsers(this.displaySystemUserAsSharedFolder);
  }

  private getItemsSelected$() {
    const request = this.selectedItems.map(x => ({
      Id: x.Id,
      Hierarchy: x.Hierarchy,
      Kind: x.FileKind
    }));
    const distict = this.eventTypeData !== eventType.Copy;
    return this.fileCopyApiService.getCountOfFiles$(request, false, distict);
  }

  private initializeItemsSelected(res) {
    const fileCount = res.FileCount;
    const fileText = res.FileCount === 1 ? this.resourceService.getText("dms.common.file") : this.resourceService.getText("dms.common.files");
    this.itemsSelectedMessage = this.resourceService.getText("dms.common.countitemsselected", [fileCount, fileText]);
  }
}

