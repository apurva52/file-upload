import {
    Injectable
} from '@angular/core';  
import { ClientModel } from 'projects/ifirm-common-components/src/lib/common-client-autocomplete/client-autocomplete/client-autocomplete/model/client.model';
import { ResourceService } from 'projects/ifirm-common-components/src/lib/localization/services/resource.service';
import {  Subject, concatMap, forkJoin, map, of, tap, throwError } from 'rxjs';
import { entityType } from '../../../constants/app-constants';
import { DmsDialogApiService } from '../../dms-dialog-api.service';
import { JobModel } from '../../file-save/model/job.model';
import { CopyMoveDocumentSelectionModel } from './../models/file-copy.mode';
import { CopyMoveSelectionApiService } from './file-copy-api.service';

@Injectable({
    providedIn: 'root'
})
export class CopyMoveSelectionService {
private _currentSelection: CopyMoveDocumentSelectionModel;
private _defaultFolderMap: Map<number, number>;
private _defaultFirmEntityId: number;
private _locationDetails: any;
private _roles: any;
private _previousSelection: Map<entityType, CopyMoveDocumentSelectionModel>;
public hierarchyChange: Subject<string>;

constructor(private dmsDialogApiService: DmsDialogApiService, private resourceService: ResourceService,private fileCopyApiService:CopyMoveSelectionApiService) {
    this._currentSelection = new CopyMoveDocumentSelectionModel(entityType.None);
    this._defaultFolderMap = new Map<number, number>();
    this._defaultFirmEntityId = 1;
    this.hierarchyChange = new Subject<string>();
}

init(data: any, roles: any, type: entityType, entityId: number, folderId: number, folderName: string) {
    this._currentSelection = new CopyMoveDocumentSelectionModel(type, entityId, "", folderId, data.Hierarchy, folderName);
    this._locationDetails = data;
    this._roles = roles;
    this._previousSelection = new Map<entityType, CopyMoveDocumentSelectionModel>();
    return this.setCurrentEntity$();
}

get CurrentSelection() : Readonly<CopyMoveDocumentSelectionModel> {
    return this._currentSelection as Readonly<CopyMoveDocumentSelectionModel>;
}

get FirmEntityId() {
  return this._defaultFirmEntityId;
}

onEntityTypeChanged(type: entityType) {
    this._previousSelection.set(this._currentSelection.EntityType, new CopyMoveDocumentSelectionModel(this._currentSelection.EntityType, this._currentSelection.EntityId));
    const enType = this._previousSelection.has(type) ? this._previousSelection.get(type).EntityType : type;
    const enId = this._previousSelection.has(type) ? this._previousSelection.get(type).EntityId : null;
    this._currentSelection = new CopyMoveDocumentSelectionModel(enType, enId);
    this._currentSelection.FolderName = this._currentSelection.DisplayHierarchy = this.getDefaultPath();
    this.hierarchyChange.next(this._currentSelection.DisplayHierarchy);
    if (type == entityType.Firm) {
      this._currentSelection.EntityId = this._defaultFirmEntityId;
      this.dmsDialogApiService.getInternalDocumentsFolderDetail(this._defaultFirmEntityId, entityType.Firm)
      .then((res) => {
        this._currentSelection.FolderId = res.data;
      });
    }
    else if(type === entityType.Hr && !this._locationDetails.EntityId) {
      this._currentSelection.EntityId = this._roles.userId;
    }
}

onEntityChanged(entityId: number, type: entityType) {
    this._previousSelection.set(this._currentSelection.EntityType, new CopyMoveDocumentSelectionModel(this._currentSelection.EntityType, this._currentSelection.EntityId));
    this._currentSelection =  new CopyMoveDocumentSelectionModel(type, entityId);
    if (entityId) {
      this.setCurrentEntity();
    }
}

onFolderChanged(folderId: number, hierarchy: string, folderName: string) {
    this._currentSelection = new CopyMoveDocumentSelectionModel(this._currentSelection.EntityType,
        this._currentSelection.EntityId,
        this._currentSelection.EntityName,
        folderId, hierarchy, folderName, "");
    this.setFolderPath();
}

private setCurrentEntity() {
  return this.dmsDialogApiService.getCurrentEntityForLookup(this._currentSelection.EntityId, this._currentSelection.EntityType)
     .then(res => {
      if(this._currentSelection.EntityType === entityType.Job) {
        this._currentSelection.EntityName = `${res.EntityId} ${(res.JobType || "")} ${res.PeriodEndedString || ""}`;
        this._currentSelection.SelectedEntity = new JobModel();
        this._currentSelection.SelectedEntity.jobId = this._currentSelection.EntityId;
        this._currentSelection.SelectedEntity.jobCode = this._currentSelection.EntityName;
        this._currentSelection.SelectedEntity.contactName = res.Name;
      }
      else if(this._currentSelection.EntityType === entityType.Contact) {
        this._currentSelection.EntityName = res.Name;
        this._currentSelection.SelectedEntity = new ClientModel();
        this._currentSelection.SelectedEntity.ClientCode = res.Code;
        this._currentSelection.SelectedEntity.ClientName = res.Name;
        this._currentSelection.SelectedEntity.ClientId = this._currentSelection.EntityId;
      }

      this.setFolderPath();
    });
}

private setCurrentEntity$() {
  return forkJoin([this.fileCopyApiService.getCurrentEntityForLookup$(this._currentSelection.EntityId, this._currentSelection.EntityType),
    this.setFolderPath$()])
    .pipe(
      tap(([res, path]) => {
        if(this._currentSelection.EntityType === entityType.Job) {
          this._currentSelection.EntityName = `${res.EntityId} ${(res.JobType || "")} ${res.PeriodEndedString || ""}`;
          this._currentSelection.SelectedEntity = new JobModel();
          this._currentSelection.SelectedEntity.jobId = this._currentSelection.EntityId;
          this._currentSelection.SelectedEntity.jobCode = this._currentSelection.EntityName;
          this._currentSelection.SelectedEntity.contactName = res.Name;
        }
        else if(this._currentSelection.EntityType === entityType.Contact) {
          this._currentSelection.EntityName = res.Name;
          this._currentSelection.SelectedEntity = new ClientModel();
          this._currentSelection.SelectedEntity.ClientCode = res.Code;
          this._currentSelection.SelectedEntity.ClientName = res.Name;
          this._currentSelection.SelectedEntity.ClientId = this._currentSelection.EntityId;
        }

        this.hierarchyChange.next(path);
      }
      )
    )
}

private setFolderPath() {
    if (this._currentSelection.FolderId && this._currentSelection.Hierarchy) {
      const hierarchy = `${this._currentSelection.Hierarchy}/${this._currentSelection.FolderId}`;
      this.dmsDialogApiService.getFolderHierarchy(hierarchy).then(res => {
        if (res && res.FolderHierarchies) {
          this._currentSelection.DisplayHierarchy = res.FolderHierarchies.map(x => x.FolderName).reduce((fullName, folderName) => 
          fullName ? `${fullName}/${folderName}` : folderName, "");
          this.hierarchyChange.next(this._currentSelection.DisplayHierarchy);
        }
      });
    } else if (this._currentSelection.FolderId) {
      this._currentSelection.Hierarchy = null;
      this._currentSelection.DisplayHierarchy = this._currentSelection.FolderName;
      this.hierarchyChange.next(this._currentSelection.DisplayHierarchy);
    } else {
      if (this._defaultFolderMap.has(this._currentSelection.EntityId)) {
        this._currentSelection.FolderId = this._defaultFolderMap.get(this._currentSelection.EntityId);
        this._currentSelection.Hierarchy = null;
      }
      else {
        this.dmsDialogApiService.createDefaultFolders(this._currentSelection.EntityId, this._currentSelection.EntityType).then((res) => {
          if (this._currentSelection.EntityType === entityType.Job) {
            this._currentSelection.FolderId = null;
            this._currentSelection.Hierarchy = null;
          }
          else {
          this._currentSelection.FolderId = res.data;
          this._currentSelection.Hierarchy = null;
          this._defaultFolderMap.set(this._currentSelection.EntityId, this._currentSelection.FolderId);
          }
        });
      }

      this._currentSelection.FolderName = this._currentSelection.DisplayHierarchy = this.getDefaultPath();
      this.hierarchyChange.next(this._currentSelection.DisplayHierarchy);
    }
}

private setFolderPath$() {
  if (this._currentSelection.FolderId && this._currentSelection.Hierarchy) {
    const hierarchy = `${this._currentSelection.Hierarchy}/${this._currentSelection.FolderId}`;
    return this.fileCopyApiService.getFolderHierarchy$(hierarchy)
    .pipe(
      map(res => {
        if (res && res.FolderHierarchies) {
          this._currentSelection.DisplayHierarchy = res.FolderHierarchies.map(x => x.FolderName).reduce((fullName, folderName) => 
          fullName ? `${fullName}/${folderName}` : folderName, "");
          return this._currentSelection.DisplayHierarchy;
        }
      })
    );
  }
  
  if (this._currentSelection.FolderId) {
    this._currentSelection.Hierarchy = null;
    this._currentSelection.DisplayHierarchy = this._currentSelection.FolderName;
    return of(this._currentSelection.DisplayHierarchy);
  } 

  this._currentSelection.FolderName = this._currentSelection.DisplayHierarchy = this.getDefaultPath();
  const defaultPath$ = of(this._currentSelection.DisplayHierarchy);
  if (this._defaultFolderMap.has(this._currentSelection.EntityId)) {
    this._currentSelection.FolderId = this._defaultFolderMap.get(this._currentSelection.EntityId);
    this._currentSelection.Hierarchy = null;
  }
  else {
    defaultPath$
    .pipe(
      concatMap(() => this.fileCopyApiService.createDefaultFolders$(this._currentSelection.EntityId, this._currentSelection.EntityType)),
      tap(res => {
        if (this._currentSelection.EntityType === entityType.Job) {
          this._currentSelection.FolderId = null;
          this._currentSelection.Hierarchy = null;
        }
        else {
        this._currentSelection.FolderId = res.data;
        this._currentSelection.Hierarchy = null;
        this._defaultFolderMap.set(this._currentSelection.EntityId, this._currentSelection.FolderId);
        }
      }
    ))     
  }

  return defaultPath$;
  ////this.hierarchyChange.next(this._currentSelection.DisplayHierarchy);
}

private getDefaultPath(): string {
  let path: string;
  switch(this._currentSelection.EntityType) {
    case entityType.Contact:
      path = this.resourceService.getText("dms.toassign");
      break;
    case entityType.Firm:
      path = this.resourceService.getText("dms.settings.internaldocuments");
      break;
    default:
      path = "<root>";
      break;
  }

  return path;
}
}