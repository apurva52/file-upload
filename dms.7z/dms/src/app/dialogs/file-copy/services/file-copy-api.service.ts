import {Injectable} from '@angular/core';  
import { ApiService } from '@ifirm';

@Injectable({
    providedIn: 'root'
})
export class CopyMoveSelectionApiService {
    constructor(private api: ApiService) { }
public getCountOfFiles(fileCountContract: any, isDeleted: boolean, distinct: boolean) {
    return this.api.post<any>('/dms/api/document/getcountoffiles', null, { fileCountContract, isDeleted, distinct}).toPromise();
  }

  public getCountOfFiles$(fileCountContract: any, isDeleted: boolean, distinct: boolean) {
    return this.api.post<any>('/dms/api/document/getcountoffiles', null, { fileCountContract, isDeleted, distinct});
  }

  public copyDocument(documentList: any, destination: any): Promise<any> {
    return this.api.post<any>('/dms/api/document/CopyDocument', null, { CopyDocumentList: documentList, Destination: destination}).toPromise();
  }

  public moveDocument(documentList: any, destination: any): Promise<any> {
    return this.api.post<any>('/dms/api/document/MoveDocument', null, { MoveDocumentList: documentList, Destination: destination}).toPromise();
  }

  
  public getInternalDocumentsFolderDetail$(entityId: number, entityType: any) {
    let data = { entityId, entityType }
    return this.api.post<any>('/dms/api/document/GetInternalDocumentsFolderDetail', null, data);
  }

  public createDefaultFolders$(entityId: number, entityType: any) {
    let dmsFile = { entityId, entityType }
    return this.api.post<any>('/dms/api/document/createdefaultfolders', null, dmsFile);
  }

  public getFolderHierarchy$(hierarchy: any) {
    return this.api.get<any>('/dms/api/document/getfolderhierarchy?hierarchy=' + hierarchy);
  }

  public getCurrentEntityForLookup$(entityId: number, entityType: any) {
    return this.api.get<any>('/dms/api/documentsearch/getcurrententityforlookup?entityId=' + entityId + '&entityType=' + entityType);
  }
}