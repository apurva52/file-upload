import { PropertyName } from '@ifirm';
import { entityType } from '../../../constants/app-constants';

export class ContactModel {

    @PropertyName('ContactName')
    ContactName: string;

    @PropertyName("EntityType")
    EntityType: entityType;

    @PropertyName("EntityId")
    EntityId: number;

    @PropertyName("Id")
    Id: number;

    @PropertyName("Hierarchy")
    Hierarchy: string;

    @PropertyName("FolderId")
    FolderId: number;

    @PropertyName("FileName")
    FileName: string;
}