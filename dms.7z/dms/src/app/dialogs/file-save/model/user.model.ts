import { PropertyName } from '@ifirm';
import { entityType } from '../../../constants/app-constants';

export class UserModel {

    @PropertyName("EntityType")
    EntityType: entityType;

    @PropertyName("EntityId")
    EntityId: number;

    @PropertyName("Hierarchy")
    Hierarchy: string;

    @PropertyName("FolderId")
    FolderId: number;

    @PropertyName("UserId")
    UserId: number;
}