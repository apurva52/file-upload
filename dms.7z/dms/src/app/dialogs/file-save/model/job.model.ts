import { PropertyName } from '@ifirm';
import { JobtItem } from 'projects/ifirm-common-components/src/lib/job-autocomplete/job-autocomplete/model/job-item.model';
import { entityType } from '../../../constants/app-constants';

export class JobModel {

    @PropertyName("EntityType")
    EntityType: entityType;

   @PropertyName("EntityId")
    EntityId: number;

    @PropertyName("FolderId")
    FolderId: number;
    
    @PropertyName("FileName")
    FileName: string;

    @PropertyName("Id")
    Id: number;

    @PropertyName("Hierarchy")
    Hierarchy: string;

    @PropertyName('JobId')
    jobId: number;

    @PropertyName('IsAllocated')
    isAllocated: boolean;

    @PropertyName('JobPriority')
    jobPriority: number;

    @PropertyName('JobComment')
    jobComment: string;

    @PropertyName('ContactCode')
    contactCode: string;

    @PropertyName('ContactName')
    contactName: string;

    @PropertyName('Code')
    jobCode: string;

    @PropertyName('StatusCssClass')
    statusCssClass: string;

    @PropertyName('StatusName')
    statusName: string;

    @PropertyName('JobType')
    jobType: string;

    @PropertyName('JobStatus')
    jobStatus: number;

    @PropertyName('StatusList')
    statusList: string;

    @PropertyName('ContactId')
    contactId: number;

    @PropertyName('Wip')
    wip: number;

    @PropertyName('Cost')
    cost: number;

    @PropertyName('IsClosed')
    isClosed: boolean;

    @PropertyName('IsPendingAllocation')
    isPendingAllocation: number;

    getJobModel(rec:JobtItem):JobModel{
        let jobModel = new JobModel();
        jobModel.jobId = rec.jobId;
        jobModel.jobStatus = rec.jobStatus;
        jobModel.jobCode = rec.jobTypeDescription;
        jobModel.contactName = rec.contactName;
        return jobModel;
    }
}

export class Jobs{

    constructor(){
        this.items = [];
    }

    @PropertyName('jobs', JobModel)
    items: JobModel[];
}