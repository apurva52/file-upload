import { Component, OnInit } from '@angular/core';
import { JobLookupComponent } from 'projects/ifirm-common-components/src/lib/job-lookup/job-lookup/job-lookup.component';
import { JobLookUpRow } from 'projects/ifirm-common-components/src/lib/job-lookup/job-lookup/model/job-lookup.model';
import { ResourceService } from 'projects/ifirm-common-components/src/lib/localization/services/resource.service';
import { ModalPopupConfig } from 'projects/ifirm-common-components/src/lib/modal-popup/models/modal-popup-config';
import { entityType } from '../../constants/app-constants';
import { JobModel } from './model/job.model';
import { map } from 'rxjs/operators';
import { ModalPopupInstance, ModalPopupService } from '@ifirm';
import { ClientLookupComponent } from 'projects/ifirm-common-components/src/lib/common-client-lookup/common-client-lookup/client-lookup.component';
import { FolderSelectionComponent } from '../folder-selection/folder-selection.component';
import { DmsDialogApiService } from '../dms-dialog-api.service';
import { DmsFile } from '../../pdf/models/dms-file.model';
import { ClientModel } from 'projects/ifirm-common-components/src/lib/common-client-autocomplete/client-autocomplete/client-autocomplete/model/client.model';
import { ContactModel } from '../../dialogs/file-save/model/contact.model';
import { UserModel } from '../../dialogs/file-save/model/user.model';
import { UserFolderModel } from '../../dialogs/file-save/model/user.folder.model';
import { toBoolean } from '../../common/function';

@Component({
  selector: 'app-file-save',
  templateUrl: './file-save.component.html',
  styleUrls: ['./file-save.component.scss']
})
export class FileSaveComponent implements OnInit {
  tabindex = 0;
  entityTypeSelected: entityType;
  showChangeFolder: boolean = false;
  selectedClient: ClientModel = new ClientModel();
  selectedJob: JobModel = new JobModel();
  contactModel: ContactModel = new ContactModel();
  userModel: UserModel = new UserModel();
  userFolderModel: UserFolderModel = new UserFolderModel();
  focusElement: number;
  contactName: string;
  entityTypes: any;
  selectedFolderHierarchy: string = "";
  rootFolderHierarchy: string = "<root>";
  changeFolderEnabled: boolean = true;
  dmsFile: DmsFile;
  entityTypeContact = entityType.Contact;
  entityTypeJob = entityType.Job;
  toAssignFolderId: number;
  initialEntityType: entityType;
  entityTypeHr = entityType.Hr;
  includeSystemFolder: boolean = true;
  users: any;
  isHrDocumentsLocations: boolean = false;
  isUserFolderLocations: boolean = false;
  hrEntityId: number;
  isHrVisible: boolean = false;
  isJobVisible: boolean = false;
  isContactVisible: boolean = false;

  constructor(private instance: ModalPopupInstance, private popupConfig: ModalPopupConfig<any>, private resourceService: ResourceService, private popupService: ModalPopupService, private dmsDialogApiService: DmsDialogApiService) {
    this.dmsFile = popupConfig.data;
  }

  ngOnInit(): void {
    this.getResources();
    this.entityTypeSelected = Number(this.dmsFile.EntityType);
    this.initialEntityType = Number(this.dmsFile.EntityType);
    this.setEntityId(this.dmsFile.EntityId);
    switch (this.entityTypeSelected) {
      case entityType.Firm:
        this.changeFolderEnabled = false;
        this.setInternalDocumentFolderId();
        this.isHrVisible = false;
        this.isJobVisible = false;
        this.isContactVisible = false;
        break;
      case entityType.Hr:
        this.setHrEntity();
        this.hrEntityId = this.dmsFile.EntityId;
        this.isJobVisible = false;
        this.isContactVisible = false;
        break;
      case entityType.User:
        this.changeFolderEnabled = false;
        this.isUserFolderLocation(this.entityTypeSelected);
        this.isHrVisible = false;
        this.isJobVisible = false;
        this.isContactVisible = false;
        break;
      case entityType.Contact:
        this.isHrVisible = false;
        this.isJobVisible = false;
        this.isContactVisible = true;
        break;
      case entityType.Job:
        this.isHrVisible = false;
        this.isJobVisible = true;
        this.isContactVisible = false;
        break;
    }

    if (toBoolean(this.dmsFile.IsSingleEntity)) {
      this.setHiearchyPath();
      this.setPreselectedEntity();
    }
    else if (this.dmsFile.Pdfsettings.HasContactViewRole) {
      this.entityTypeSelected = entityType.Contact;
      this.setDefaultPath(this.entityTypeSelected);
      this.isHrVisible = false;
      this.isJobVisible = false;
      this.isContactVisible = true;
    }
    else if (this.dmsFile.Pdfsettings.AllowApmAccess) {
      this.entityTypeSelected = entityType.Job;
      this.setDefaultPath(this.entityTypeSelected);
      this.isHrVisible = false;
      this.isJobVisible = true;
      this.isContactVisible = false;
    }
    else if (this.dmsFile.Pdfsettings.IsAllowInternaldocuments) {
      this.changeFolderEnabled = false;
      this.setInternalDocumentFolderId();
      this.isHrVisible = false;
      this.isJobVisible = false;
      this.isContactVisible = false;
    }
  }

  private setEntityId(entityId: number) {
    if (this.dmsFile.EntityType == entityType.Hr) {
      this.userModel.EntityId = entityId;
    }
    if (this.dmsFile.EntityType == entityType.User) {
      this.userFolderModel.EntityId = entityId;
    }
  }

  setHiearchyPath() {
    if (this.dmsFile.Hierarchy === undefined || this.dmsFile.Hierarchy === null || this.dmsFile.Hierarchy === "" || this.initialEntityType != this.entityTypeSelected) {
      this.setDefaultPath(this.entityTypeSelected);
    } else {
      // hierarchy = `${hierarchy}/${folderId}`;
      this.getFolderHierarchy(this.dmsFile.Hierarchy);
    }
  }

  private getResources() {
    this.entityTypes = [];
    if(this.dmsFile.Pdfsettings.AllowApmAccess && this.dmsFile.Pdfsettings.IsAllowDocumentsEdit){
      this.entityTypes.push({ name: this.resourceService.getText("ifirm.common.job"), id: entityType.Job });
    }
    if(this.dmsFile.Pdfsettings.HasContactViewRole && this.dmsFile.Pdfsettings.IsAllowDocumentsEdit){
      this.entityTypes.push({ name: this.resourceService.getText("ifirm.common.contact"), id: entityType.Contact });
    }
    if(this.dmsFile.Pdfsettings.IsAllowInternaldocuments && this.dmsFile.Pdfsettings.IsAllowFirmdocuments){
      this.entityTypes.push({ name: this.resourceService.getText("dms.settings.internaldocuments"), id: entityType.Firm });
    }

    if (this.dmsFile.EntityType == entityType.Hr) {
      this.entityTypes.push({ name: this.resourceService.getText("dms.settings.hrdocuments"), id: entityType.Hr });
    }
    if (this.dmsFile.EntityType == entityType.User) {
      this.entityTypes.push({ name: this.resourceService.getText("dms.fileuploaddialog.youruserfolder"), id: entityType.User });
      if(this.dmsFile.Pdfsettings.IsAllowHRManagerDocuments){
        this.entityTypes.push({ name: this.resourceService.getText("dms.fileuploaddialog.yourhrfolder"), id: entityType.Hr });
      }
      
    }
  }

  entityTypeChangeEvent() {
    this.dmsFile.EntityType = this.entityTypeSelected;
    if (this.initialEntityType != this.entityTypeSelected) {
      this.dmsFile.EntityId = null;
      this.dmsFile.FolderId = null;
      this.userModel.FolderId = null;
      this.userModel.Hierarchy = null;
    }

    if (this.initialEntityType != this.entityTypeSelected && (this.entityTypeSelected == entityType.Job || this.entityTypeSelected == entityType.Contact)) {
      this.dmsFile.Hierarchy = null;
      this.selectedJob.FolderId = null;
      this.selectedJob.Hierarchy = null;
    }

    switch (this.entityTypeSelected) {
      case entityType.Firm:
        this.dmsFile.EntityId = 1;
        this.changeFolderEnabled = false;
        if (this.dmsFile.FolderId == null || this.dmsFile.FolderId == undefined) {
          this.setInternalDocumentFolderId();
        }
        this.isHrVisible = false;
        this.isJobVisible = false;
        this.isContactVisible = false;
        break;
      case entityType.Hr:
        this.setHrEntity();
        this.isJobVisible = false;
        this.isContactVisible = false;
        break;
      case entityType.User:
        this.isUserFolderLocation(this.entityTypeSelected);
        this.isHrVisible = false;
        this.isJobVisible = false;
        this.isContactVisible = false;
        break;
      case entityType.Job:
        this.isHrVisible = false;
        this.isJobVisible = true;
        this.isContactVisible = false;
        break;
      case entityType.Contact:
        this.isHrVisible = false;
        this.isJobVisible = false;
        this.isContactVisible = true;
        break;
    }

    if (this.isUserFolderLocations) {
      this.dmsFile.Hierarchy = null;
      this.userModel.FolderId = null;
      this.userModel.Hierarchy = null;
      this.userModel.EntityId = this.userFolderModel.EntityId;
      this.userModel.EntityType = this.entityTypeSelected;
      //  this.setDefaultPath(this.entityTypeSelected);
    }

    if (toBoolean(this.dmsFile.IsSingleEntity)) {
      this.setHiearchyPath();
    }
    else {
      this.setDefaultPath(this.entityTypeSelected);
    }
    this.setFolderIdAndHierachy(this.dmsFile.Hierarchy, this.dmsFile.EntityType);
  }

  private setHrEntity() {
    if (this.isUserFolderLocations) {
      this.isHrVisible = false;
      this.dmsFile.Hierarchy = null;
      this.userModel.FolderId = null;
      this.userModel.Hierarchy = null;
      this.userModel.EntityId = this.userFolderModel.EntityId;
      this.userModel.EntityType = this.entityTypeSelected;
      // this.setDefaultPath(this.entityTypeSelected);
    }
    else {
      this.isHrVisible = true;
      if (this.users == null || this.users == undefined) {
        this.getUsers(this.includeSystemFolder);
      }
      else {
        this.setUserModel();
      }
    }
    if(!this.dmsFile.Pdfsettings.AllowApmAccess && !this.dmsFile.Pdfsettings.HasContactViewRole && !this.dmsFile.Pdfsettings.IsAllowInternaldocuments && !toBoolean(this.dmsFile.IsSingleEntity)){
      this.setDefaultPath(this.entityTypeSelected);
    }
    this.isHrDocumentsLocations = true;
    this.changeFolderEnabled = false;
  }

  private setUserModel() {
    if (!toBoolean(this.dmsFile.IsSingleEntity)) {
      this.userModel.EntityId = Number(this.users[0].UserId);
    }
    else {
      this.userModel.EntityId = Number(this.hrEntityId);
    }
    this.userModel.EntityType = this.entityTypeSelected;
  }

  private setInternalDocumentFolderId() {
    this.dmsDialogApiService.getInternalDocumentsFolderDetail(this.dmsFile.EntityId, this.dmsFile.EntityType).then(result => {
      if (result && result.success) {
        if (this.dmsFile.Hierarchy == undefined || this.dmsFile.Hierarchy == null || this.initialEntityType != this.entityTypeSelected) {
          this.dmsFile.FolderId = result.data;
          this.dmsFile.Hierarchy = null;
        }
      }
    })
  }

  private setPreselectedEntity() {
    if (this.dmsFile.EntityType === entityType.Job || this.dmsFile.EntityType === entityType.Contact) {
      this.getCurrentEntityForLookup(this.dmsFile.EntityId, this.dmsFile.EntityType);
      if (this.dmsFile.EntityType === entityType.Job) {
        this.getClientPortalAccessInfo(this.dmsFile.EntityId, this.dmsFile.EntityType);
      }
    }
    this.setFolderIdAndHierachy(this.dmsFile.Hierarchy, this.dmsFile.EntityType);
  }

  saveDocument() {
    if (this.entityTypeSelected == entityType.Job && this.selectedJob.EntityId == undefined) {
      this.popupService.info(this.resourceService.get('ifirm.common.error') as string, this.resourceService.get('dms.fileuploaddialog.selectjoberror') as string);
    } else if (this.entityTypeSelected == entityType.Contact && this.contactModel.ContactName == undefined) {
      this.popupService.info(this.resourceService.get('ifirm.common.error') as string, this.resourceService.get('dms.fileuploaddialog.selectcontacterror') as string);
    } else if (this.entityTypeSelected == entityType.Hr && this.userModel.EntityId == undefined) {
      this.popupService.info(this.resourceService.get('ifirm.common.error') as string, this.resourceService.get('dms.editpdf.usernotselected') as string);
    } else if (this.entityTypeSelected == entityType.Job) {
      this.selectedJob.FileName = this.dmsFile.Name;
      this.instance.close({ cancel: false, action: 'save', data: this.selectedJob });
    } else if (this.entityTypeSelected == entityType.Contact) {
      this.contactModel.FileName = this.dmsFile.Name;
      this.instance.close({ cancel: false, action: 'save', data: this.contactModel });
    } else if (this.entityTypeSelected == entityType.Firm) {
      this.instance.close({ cancel: false, action: 'save', data: this.dmsFile });
    } else if (this.entityTypeSelected == entityType.Hr) {
      this.instance.close({ cancel: false, action: 'save', data: this.userModel });
    } else if (this.entityTypeSelected == entityType.User) {
      this.instance.close({ cancel: false, action: 'save', data: this.userFolderModel });
    }


  }

  showChangeFolderDialog() {
    if (this.entityTypeSelected == entityType.Job && this.selectedJob.EntityId == undefined) {
      this.popupService.info(this.resourceService.get('ifirm.common.error') as string, this.resourceService.get('dms.fileuploaddialog.selectjoberror') as string);
    } else if (this.entityTypeSelected == entityType.Contact && this.contactModel.ContactName == undefined) {
      this.popupService.info(this.resourceService.get('ifirm.common.error') as string, this.resourceService.get('dms.fileuploaddialog.selectcontacterror') as string);
    } else if (this.entityTypeSelected == entityType.Hr && this.userModel.EntityId == undefined) {
      this.popupService.info(this.resourceService.get('ifirm.common.error') as string, this.resourceService.get('dms.editpdf.usernotselected') as string);
    } else {
      let title = this.resourceService.getText('dms.selectfolder');
      let data;
      const config: ModalPopupConfig<any> = new ModalPopupConfig<any>();
      if (this.entityTypeSelected == entityType.Contact) {
        data = { CurrentFolderId: this.contactModel.FolderId, CurrentFolderhierarchy: this.contactModel.Hierarchy, EntityId: this.contactModel.EntityId, EntityType: this.contactModel.EntityType };
      } else if (this.entityTypeSelected == entityType.Job) {
        data = { CurrentFolderId: this.selectedJob.FolderId == undefined || this.selectedJob.FolderId == null ? 0 : this.selectedJob.FolderId, CurrentFolderhierarchy: this.selectedJob.Hierarchy, EntityId: this.selectedJob.EntityId, EntityType: this.selectedJob.EntityType };
      } else if (this.entityTypeSelected == entityType.Firm) {
        data = { CurrentFolderId: this.dmsFile.FolderId, CurrentFolderhierarchy: this.dmsFile.Hierarchy, EntityId: this.dmsFile.EntityId, EntityType: this.dmsFile.EntityType };
      } else if (this.entityTypeSelected == entityType.User) {
        data = { CurrentFolderId: this.userFolderModel.FolderId == undefined || this.userFolderModel.FolderId == null ? 0 : this.userFolderModel.FolderId, CurrentFolderhierarchy: this.userFolderModel.Hierarchy, EntityId: this.userFolderModel.EntityId, EntityType: this.userFolderModel.EntityType };
      } else {
        data = { CurrentFolderId: this.userModel.FolderId == undefined || this.userModel.FolderId == null ? 0 : this.userModel.FolderId, CurrentFolderhierarchy: this.userModel.Hierarchy, EntityId: this.userModel.EntityId, EntityType: this.userModel.EntityType };
      }

      let configs = { data: data }
      let instance = this.popupService.open<FolderSelectionComponent>(title, FolderSelectionComponent, configs);
      const subscription = instance.afterClosed.subscribe(result => {
        if (subscription) {
          subscription.unsubscribe();
        }
        if (result) {
          if (result.Hierarchy) {
            this.getSelectedFolder(result.Hierarchy, result.FolderId)
          }
          else {
            this.getSelectedFolder(result.FolderId, result.FolderId)
          }
        }
      });
    }
  }

  jobSelectionChanged(event) {
    if (event.item) {
      let jobModel = new JobModel();
      jobModel = event.item;
      if (jobModel.jobId) {
        if (this.selectedJob.EntityId != jobModel.jobId) {
          this.dmsFile.Hierarchy = null;
          this.createDefaultFolders(jobModel.jobId, entityType.Job);
        }
        jobModel.jobCode = jobModel.jobCode;
        jobModel.contactCode = jobModel.contactCode;
        jobModel.contactName = jobModel.contactName;
        jobModel.EntityId = jobModel.jobId;
        jobModel.EntityType = entityType.Job;
        jobModel.FileName = this.dmsFile.Name;
        this.selectedJob = jobModel;
        this.selectedFolderHierarchy = this.rootFolderHierarchy;
      }
      if (this.selectedJob.EntityId != undefined) {
        this.changeFolderEnabled = false;
      }
    }
    else {
      this.selectedJob = new JobModel();
    }
  }

  clientSelectionChanged(event) {
    if (event.item) {
      let clientModel = event.item;
      if (clientModel.ClientId) {
        if (this.selectedClient.ClientId != event.item.ClientId) {
          this.dmsFile.Hierarchy = null;
          this.contactModel.Hierarchy = null;
          this.createDefaultFolders(Number(event.item.ClientId), entityType.Contact);
          this.setDefaultPath(this.entityTypeSelected);
        }
        this.selectedClient.ClientCode = clientModel.ClientCode;
        this.selectedClient.ClientId = this.contactModel.EntityId = Number(clientModel.ClientId);
        this.selectedClient.ClientName = this.contactModel.ContactName = clientModel.ClientName;
        this.contactModel.EntityType = entityType.Contact;
        if (this.contactModel.ContactName != undefined) {
          this.changeFolderEnabled = false;
        }
      }
    }
    else {
      this.selectedClient = new ClientModel();
      this.contactModel.ContactName = undefined;
    }
  }

  jobLookupPopup() {
    let title = this.resourceService.getText("ifirm.common.joblookup");
    this.PopupInstance(title, JobLookupComponent, {}, (response) => {
      if (response && response.cancel === false) {
        let data = response.data as JobLookUpRow;
        let jobModel = new JobModel();
        jobModel.jobCode = data.description;
        jobModel.contactCode = data.clientCode;
        jobModel.contactName = data.clientName;
        jobModel.EntityId = data.jobId;
        jobModel.EntityType = entityType.Job;
        jobModel.Id = this.dmsFile.Id;
        jobModel.FileName = this.dmsFile.Name;
        this.selectedJob = jobModel;
        this.selectedFolderHierarchy = this.rootFolderHierarchy;
        this.setDefaultPath(this.entityTypeSelected);
        this.changeFolderEnabled = false;
        return { cancel: response.cancel, data: jobModel };
      }

      return { cancel: true, data: null };
    }, (response) => {
    }, "job-lookup");
  }

  contactLookupPopup() {
    let title = this.resourceService.getText("ifirm.common.contactlookup");
    this.PopupInstance(title, ClientLookupComponent, {},
      response => {
        if (response && response.result) {
          if (response.data) {
            const result = response.data;
            if (result.id) {
              let clientModel = new ClientModel();
              clientModel.ClientCode = result.clientCode;
              clientModel.ClientName = this.contactModel.ContactName = result.clientName;
              clientModel.ClientId = this.contactModel.EntityId = Number(result.id);
              this.contactModel.EntityType = entityType.Contact;
              this.selectedClient = clientModel;
              this.dmsFile.Hierarchy = null;
              this.contactModel.Hierarchy = null;
              this.createDefaultFolders(this.contactModel.EntityId, this.contactModel.EntityType);
            }
            this.changeFolderEnabled = false;
            this.setDefaultPath(this.entityTypeSelected);
          }
        }
      },
      response => {
      }, "contact-lookup");
  }

  private PopupInstance(title: string, component, configData, mapCallback, subscribeCallBack, cssClassName) {
    const config = new ModalPopupConfig();
    config.data = configData;
    const instance = this.popupService.open(title, component, config, cssClassName);
    const subscription = instance.afterClosed
      .pipe(
        map((response) => {
          return mapCallback(response);
        })).subscribe(response => {
          if (subscription) {
            subscription.unsubscribe();
          }
          if (response && response.cancel === false) {
            subscribeCallBack(response);
          }
        });
  }

  private getFolderHierarchy(hierarchy: any) {
    this.selectedFolderHierarchy = "";
    let selectedFolderHierarchyName: any = [];
    this.dmsDialogApiService.getFolderHierarchy(hierarchy).then(res => {
      if (res && res.FolderHierarchies) {
        res.FolderHierarchies.forEach(function (value) {
          selectedFolderHierarchyName.push(value.FolderName)
        });
        if (selectedFolderHierarchyName.length > 1) {
          let hierarchyNamefilePathDelimeter: string = selectedFolderHierarchyName.join("\\");
          this.selectedFolderHierarchy = hierarchyNamefilePathDelimeter;
        } else {
          this.selectedFolderHierarchy = selectedFolderHierarchyName[0];
        }
      }
    });
  }

  private getSelectedFolder(hierarchy: any, folderId: number) {
    switch (this.entityTypeSelected) {
      case entityType.Contact:
        this.contactModel.FolderId = folderId;
        if (folderId != hierarchy) {
          this.contactModel.Hierarchy = hierarchy;
        }
        break;
      case entityType.Job:
        if (folderId == 0) {
          this.selectedJob.FolderId = null;
          this.selectedJob.Hierarchy = null;
        } else {
          this.selectedJob.FolderId = folderId;
          if (folderId != hierarchy) {
            this.selectedJob.Hierarchy = hierarchy;
          }
        }
        break;
      case entityType.Firm:
        this.dmsFile.FolderId = folderId;
        if (folderId != hierarchy) {
          this.dmsFile.Hierarchy = hierarchy;
        }
        break;
      case entityType.Hr:
        if (folderId == 0) {
          this.userModel.FolderId = null;
          this.userModel.Hierarchy = null;
        } else {
          this.userModel.FolderId = folderId;
          if (folderId != hierarchy) {
            this.userModel.Hierarchy = hierarchy;
          }
        }
        break;
      case entityType.User:
        if (folderId == 0) {
          this.userFolderModel.FolderId = null;
          this.userFolderModel.Hierarchy = null;
        } else {
          this.userFolderModel.FolderId = folderId;
          if (folderId != hierarchy) {
            this.userFolderModel.Hierarchy = hierarchy;
          }
        }
        break;
    }

    this.selectedFolderHierarchy = "";
    if ((folderId === undefined || folderId === null || folderId <= 0) && (hierarchy === undefined || hierarchy === null || hierarchy === "" || hierarchy <= 0)) {
      this.setDefaultPath(this.entityTypeSelected);
    } else {
      hierarchy = `${hierarchy}/${folderId}`;
      this.getFolderHierarchy(hierarchy);
    }

  }

  private setDefaultPath(entityTypes?: entityType) {
    if (entityTypes === entityType.Contact) {
      this.selectedFolderHierarchy = this.resourceService.getText("dms.toassign");
    }
    else if (entityTypes === entityType.Firm) {
      this.selectedFolderHierarchy = this.resourceService.getText('dms.settings.internaldocuments');
    }
    else {
      this.selectedFolderHierarchy = this.rootFolderHierarchy;
    }
  }

  private createDefaultFolders(entityId: number, entityTypes: entityType) {
    this.dmsDialogApiService.createDefaultFolders(entityId, entityTypes).then(res => {
      if (res && res.data != undefined) {
        this.toAssignFolderId = res.data;
        if (this.dmsFile.Hierarchy == undefined || this.dmsFile.Hierarchy == null) {
          this.contactModel.FolderId = this.toAssignFolderId;
        }
      }
    });
  }

  private setFolderIdAndHierachy(hierarchy: string, entityTypes: entityType) {
    if (hierarchy != undefined) {
      let folderIds = hierarchy.split('/');
      const clonefolderIds = Object.assign([], folderIds);
      let reCalculateHierachy;
      if (clonefolderIds.length > 1) {
        clonefolderIds.pop();
        reCalculateHierachy = clonefolderIds.join("/");
      }
      else {
        reCalculateHierachy = null;
      }

      if (entityTypes === entityType.Job) {
        this.selectedJob.Hierarchy = reCalculateHierachy;
        this.selectedJob.FolderId = Number(folderIds[folderIds.length - 1]);
      } else if (entityTypes === entityType.Contact) {
        this.contactModel.Hierarchy = reCalculateHierachy;
        this.contactModel.FolderId = Number(folderIds[folderIds.length - 1]);
      } else if (entityTypes === entityType.Firm) {
        this.dmsFile.Hierarchy = reCalculateHierachy;
        this.dmsFile.FolderId = Number(folderIds[folderIds.length - 1]);
      } else if (entityTypes === entityType.Hr) {
        this.userModel.Hierarchy = reCalculateHierachy;
        this.userModel.FolderId = Number(folderIds[folderIds.length - 1]);
      } else if (entityTypes === entityType.User) {
        this.userFolderModel.Hierarchy = reCalculateHierachy;
        this.userFolderModel.FolderId = Number(folderIds[folderIds.length - 1]);
      }
    }
    else {
      this.contactModel.FolderId = this.toAssignFolderId;
      this.contactModel.Hierarchy = null;
    }

  }

  private getCurrentEntityForLookup(entityId: number, entityTypes: entityType) {
    this.dmsDialogApiService.getCurrentEntityForLookup(entityId, entityTypes).then(res => {
      if (res) {
        if (entityTypes === entityType.Job) {
          this.selectedJob.jobCode = res.EntityId.toString();
          this.selectedJob.contactCode = res.JobType;
          this.selectedJob.contactName = res.Name;
          this.contactModel.ContactName = res.Name;
          this.selectedJob.EntityId = res.EntityId;
          this.selectedJob.EntityType = entityType.Job;
          this.selectedJob.Id = this.dmsFile.Id;
          this.createDefaultFolders(this.selectedJob.EntityId, this.selectedJob.EntityType);
        }
        if (entityTypes === entityType.Contact) {
          this.selectedClient.ClientId = this.contactModel.EntityId = res.EntityId;
          this.contactModel.EntityType = entityType.Contact;;
          this.selectedClient.ClientName = this.contactModel.ContactName = res.Name;
          this.contactModel.Id = this.dmsFile.Id;
          this.createDefaultFolders(this.contactModel.EntityId, this.contactModel.EntityType);

        }
        this.changeFolderEnabled = false;
      }
    });
  }

  private getClientPortalAccessInfo(entityId: number, entityTypes: entityType) {
    this.dmsDialogApiService.getClientPortalAccessInfo(entityId, entityTypes).then(res => {
      if (res) {
        this.contactModel.EntityId = res.ClientId;
        this.contactModel.EntityType = entityType.Contact;
      }
      this.createDefaultFolders(this.contactModel.EntityId, entityType.Contact);
      this.getCurrentEntityForLookup(this.contactModel.EntityId, entityType.Contact);
    });
  }

  private getUsers(includeSystemFolder) {
    this.dmsDialogApiService.getUsers(includeSystemFolder).then(res => {
      if (res) {
        this.users = res;
        this.setUserModel();
      }
    });
  }

  userChanged() {
    this.userModel.FolderId = null;
    this.userModel.Hierarchy = null;
    this.setDefaultPath(this.entityTypeSelected);
    this.changeFolderEnabled = false;
  }

  isHrDocumentsLocation(entityTypeSelected: entityType) {
    if (this.entityTypeSelected == entityType.Hr) {
      this.isHrDocumentsLocations = true;
      this.changeFolderEnabled = false;
    }
    if (this.dmsFile.Hierarchy != undefined) {
      this.getFolderHierarchy(this.dmsFile.Hierarchy);
    }
  }

  isUserFolderLocation(entityTypeSelected: entityType) {
    this.userFolderModel.EntityType = this.entityTypeSelected;
    this.userFolderModel.FolderId = this.dmsFile.FolderId;
    this.userFolderModel.Hierarchy = this.dmsFile.Hierarchy;
    if (this.dmsFile.EntityType == entityType.Firm) {
      this.userFolderModel.Hierarchy = null
      this.userFolderModel.FolderId = null;
    }
    if(!toBoolean(this.dmsFile.IsSingleEntity)){
      this.userFolderModel.Hierarchy = null;
      this.setDefaultPath(this.entityTypeSelected);
    }
    this.changeFolderEnabled = false;
    this.isUserFolderLocations = true;
  }

  closeThisDialog() {
    this.instance.close({ cancel: true, action: 'close' });
  }
}
