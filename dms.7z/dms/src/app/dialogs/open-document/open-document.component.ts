import { Component, OnInit, HostListener, ElementRef, ViewChild } from '@angular/core';
import { ResourceService, ModalPopupConfig, ModalPopupInstance, ModalPopupService, ConfirmationBoxComponent, ConfirmationBoxType, ToasterService } from '@ifirm';
import { DmsDialogApiService } from '../dms-dialog-api.service';
import {OnedriveAzureadappSettings} from '../models/onedrive-azureadapp-settings.model'
import {OneDriveDocumentUpload} from '../models/one-drive-document-upload.model'
import {OpenDocumentModel} from '../models/open-document.model'
import { OpenDocument, ApiValidationCode } from '../../constants/app-constants';
import { OnedriveOpenDocumentModel } from '../models/onedrive-open-document.model'
import { Observable, interval } from 'rxjs';

@Component({
  selector: 'app-open-document',
  templateUrl: './open-document.component.html',
  styleUrls: ['./open-document.component.scss']
})
export class OpenDocumentComponent implements OnInit {
  entityInfo: OnedriveOpenDocumentModel = null;
  siteName: string;
  isError: boolean;
  errorMessage: string;
  rData: boolean = false;
  oneDriveDocumentUpload: OneDriveDocumentUpload;
  isWebUrlAvailable: boolean;
  officeWordDocumentArray: Array<string>= ['DOCM','DOCX','DOTM','DOTX']
  officeExcelDocumentArray: Array<string> = ['XLSB','XLSX']
  officePowerPointDocumentArray: Array<string> = ['POT','POTM','POTX','PPS','PPSM','PPSX','PPTM','PPTX']
  selectOfficeProductText:string;
  selectOfficeProductDescText:string;
  buttonDesktopText:string;
  buttonOnlineText:string;
  oneDriveAzureAdAppSettings: OnedriveAzureadappSettings;
  alwaysHidden:boolean = true;
  closeOneDriveCallCount: number = -1;
  static filesOpened: Array<OpenedFile> = [];

  @ViewChild('onlineOfficeSelect', { read: ElementRef }) onlineOfficeSelect:ElementRef;
  @ViewChild('documentReady', { read: ElementRef }) documentReady:ElementRef;

  constructor(private config: ModalPopupConfig<any>, private instance: ModalPopupInstance, private dmsDialogApiService: DmsDialogApiService,
    private resourceService: ResourceService, private popupService: ModalPopupService, private toasterService: ToasterService) {
    this.entityInfo = config.data;
    this.siteName = window.location.protocol + "//" + window.location.host;
  }

  ngOnInit(): void {
    
      this.GetOneDriveAzureAdAppSettings();
      this.isWebUrlAvailable = false;
  }

  openDeskstopApp()
  {
    this.rData = true; 
    window.open(this.oneDriveAzureAdAppSettings.OpenEditPayload, '_self');
    this.closeInstance(); 
  }

  closeInstance()
  {
      setTimeout(() => 
      {
        this.rData = false;
        this.instance.close({ result: true });          
      },10);
  }

  async GetOneDriveAzureAdAppSettings()
  {
    this.displayTexts();
    this.rData = true;
    var res = await  this.dmsDialogApiService.GetOneDriveAzureAdAppSettings(this.entityInfo.FileId, this.entityInfo.IsReadOnly);
    this.rData = false;
      this.oneDriveAzureAdAppSettings= res.data;
      if(!res.success)
      {
        this.errorMessage = res.message;
        this.isError = true;
      }

      if(this.oneDriveAzureAdAppSettings)
      {
          if(this.entityInfo.ExtensionType && (this.officeWordDocumentArray.includes(this.entityInfo.ExtensionType.toUpperCase()) ||
    this.officeExcelDocumentArray.includes(this.entityInfo.ExtensionType.toUpperCase()) 
    || this.officePowerPointDocumentArray.includes(this.entityInfo.ExtensionType.toUpperCase())))
        {
          switch (this.oneDriveAzureAdAppSettings.DmsOfficeDocumentOpenWithApplication) {
            case OpenDocument.Deskstop:
            this.openDeskstopApp();
              break;
            case OpenDocument.Online:
              this.onlineOfficeSelect.nativeElement.querySelector('button').click();
              break;
          }
        }
        else{
          this.openDeskstopApp();
        }
      }
      else{
          this.popupService.info(this.resourceService.get('ifirm.common.error') as string, this.resourceService.get('dms.common.errormessage') as string);
      }
  }

  displayTexts()
  {
  if(this.officeWordDocumentArray.includes(this.entityInfo.ExtensionType.toUpperCase()))
  {
    this.selectOfficeProductText = this.resourceService.getText('dms.opendocumentinbrowser.selectword');
    this. buttonDesktopText='dms.opendocumentinbrowser.wordondesktop';
    this.buttonOnlineText='dms.opendocumentinbrowser.wordonline';
  }
  else if(this.officeExcelDocumentArray.includes(this.entityInfo.ExtensionType.toUpperCase())){
    this.selectOfficeProductText =this.resourceService.getText('dms.opendocumentinbrowser.selectexcel');
    this. buttonDesktopText='dms.opendocumentinbrowser.excelondeskstop';
    this.buttonOnlineText='dms.opendocumentinbrowser.excelonline';
  }
  else if(this.officePowerPointDocumentArray.includes(this.entityInfo.ExtensionType.toUpperCase())){
    this.selectOfficeProductText =this.resourceService.getText('dms.opendocumentinbrowser.selectpowerpoint');
    this. buttonDesktopText='dms.opendocumentinbrowser.powerpointondeskstop';
    this.buttonOnlineText='dms.opendocumentinbrowser.powerpointonline';
  }
  }

  //AutoFiling User Consent
  onlineOfficeClick(event) {
    if(this.isError)
    {
      this.popupService.info(this.resourceService.get('ifirm.common.error') as string, this.errorMessage as string);
      return;
    }

    if(!this.entityInfo.IsReadOnly)
    {
      this.entityInfo.IsReadOnly = this.oneDriveAzureAdAppSettings.IsReadOnly;
    }
    if(this.oneDriveAzureAdAppSettings.IsAzureAdSessionExist)
    {
      this.UploadOpenFileInBrowser(event);
    }
    else{
      this.getUserConsent(event);
    }
  } 

  getUserConsent(event)
  {
    this.rData = true;
    var windowUrl = this.oneDriveAzureAdAppSettings.ConsentUrl +
    "client_id=" + this.oneDriveAzureAdAppSettings.ClientId +
    "&response_type=" + this.oneDriveAzureAdAppSettings.ResponseType +
    "&redirect_uri=" + encodeURIComponent(this.siteName + this.oneDriveAzureAdAppSettings.RedirectUrl) +
    "&response_mode=query" +
    "&scope=" + this.oneDriveAzureAdAppSettings.Scope +
    "&state=" + this.oneDriveAzureAdAppSettings.ClientState;

    if (event && event.stopPropagation) {
      event.stopPropagation();
    }

    const newWindow = window.open(windowUrl, '_blank',);
    const limitedInterval = setInterval(() => {
      try{
            if(newWindow == null)
            {
              this.rData = false;
              clearInterval(limitedInterval);
            }
            else if(newWindow.closed)
            { 
              this.UploadOpenFileInBrowser(event);
              clearInterval(limitedInterval);
            }
        }
        catch(e)
        {
          console.log(e);
        }
      },  1000);
  }

  UploadOpenFileInBrowser(event)
  {
    this.rData = true;
    this.dmsDialogApiService.UploadOpenFileInBrowser(this.entityInfo).then((result: any) => {
      if (result != null && result != undefined && result.success) {
        if(result.data && result.data.IsFileExistInOneDrive)
          {
            if(this.isOnBrowserFileOpened(this.entityInfo.FileId, this.entityInfo.FileGuid))
            {
              this.popupService.info(this.resourceService.get('ifirm.common.error') as string, this.resourceService.get('dms.notifyerrorfileopened') as string);
              this.closeInstance();
            }
            else
            {
              let instance = this.popupService.confirm(this.resourceService.getText('dms.opendocumentinbrowser.opendocument') as string, this.resourceService.getText('dms.opendocumentinbrowser.messagereplacefile') as string, ConfirmationBoxType.YesNo);           
              const subscription = instance.afterClosed.subscribe(x => {
                if (subscription) {
                  subscription.unsubscribe();
                }
                if (x && x.result) {
                  this.entityInfo.IsDiscardOneDriveFile = true;
                  this.UploadOpenFileInBrowser(event);
                }
                else{
                  this.assigningOpenDocumentEvent(result);
                }
              });
           }
          }
          else{
            this.assigningOpenDocumentEvent(result);
          }
      }
      else {
        switch(result.errorcode)
        {
          case ApiValidationCode.FileForceUnlocked :
          case ApiValidationCode.FileNotFound :
          case ApiValidationCode.FileLockExist :
              this.popupService.info(this.resourceService.get('ifirm.common.error') as string, this.resourceService.get('dms.notifyerror_'+ result.errorcode) as string);
              break;
          default:
            this.popupService.info(this.resourceService.get('ifirm.common.error') as string, this.resourceService.get('dms.common.errormessage') as string);
           break;
        }
      this.closeInstance();
      }
    }).finally(()=> {
      this.rData = false;
    });
  }

  assigningOpenDocumentEvent(result)
  {
    this.isWebUrlAvailable= true;
    this.oneDriveDocumentUpload = result.data; 
    if(this.entityInfo.updateLockEvent && !this.entityInfo.IsReadOnly){
      if (this.entityInfo.IsOpenThroughUrl)        {
          this.entityInfo.updateLockEvent(this.oneDriveDocumentUpload);
        }
        else
        {
          this.entityInfo.updateLockEvent();
        }
    }

    if(this.entityInfo.IsReadOnly)
    {
      this.toasterService.success(this.resourceService.get('dms.notifyfileloadedreadonly') as string);
    }
    else if(!this.entityInfo.IsOpenThroughUrl){
      this.setOnBrowserFileOpen(this.entityInfo.FileId, this.entityInfo.FileGuid);
    }

    if(!this.entityInfo.IsOpenThroughUrl)
    {
      this.documentReady.nativeElement.querySelector('button').click();
    }
  }

  //AutoFiling User Consent
  openDocumentinBrowser(event) {
    if(this.oneDriveDocumentUpload && this.oneDriveDocumentUpload.WebUrl)
    {
     if (event && event.stopPropagation) {
       event.stopPropagation();
     }
     
     var theUrl = this.siteName + '/dms/api/OneDriveDocInBrowser/CloseFile?ItemId='+ this.oneDriveDocumentUpload.ItemId + '&UserId=' + this.oneDriveDocumentUpload.UserId + '&isReadOnly='+ this.entityInfo.IsReadOnly ;
     var theFourceCloseUrl = this.siteName + '/dms/api/OneDriveNotification/FourceCloseFile?ItemId='+ this.oneDriveDocumentUpload.ItemId + '&UserId=' + this.oneDriveDocumentUpload.UserId ;

     const newWindow = window.open(this.oneDriveDocumentUpload.WebUrl, '_blank',);
     const limitedInterval = setInterval(() => {
      if(newWindow != null && newWindow.closed)
       { 
        clearInterval(limitedInterval); 
        setTimeout(() => 
        {
          this.closeOneDriveDocument(theUrl);
        },10);

        setTimeout(() => 
        {
          this.dmsDialogApiService.CloseOneDriveDocument(theFourceCloseUrl).then((result: any) => {});
        },10000);
       }
       this.instance.close({ result: false });
      },  1000);

    }
    else{
      this.popupService.info(this.resourceService.get('ifirm.common.error') as string, this.resourceService.get('dms.common.errormessage') as string);
      this.instance.close({ result: false });
    }
   }

   closeOneDriveDocument(theUrl : string)
   {
    this.closeOneDriveCallCount++;
    this.dmsDialogApiService.CloseOneDriveDocument(theUrl).then((result: any) => {
      if(result != null && result != undefined && result.success)
      {
        switch(result.errorcode)
        {
          case 101 :
            if(this.closeOneDriveCallCount <= 20)
              {
                setTimeout(() => 
                {
                  this.closeOneDriveDocument(theUrl);
                },20000);
            }
            else{
              this.removeOnBrowserFileOpen(this.entityInfo.FileId, this.entityInfo.FileGuid);
            }
          break;
          case 1051:
            if (this.entityInfo.updateLockEvent) {
              this.entityInfo.updateUnlockEvent();
            }
            var fileName = this.entityInfo.FileName;
            var message =  this.resourceService.get('dms.notifyskipping1') as string + ' ' + fileName + ' ' + this.resourceService.get('dms.notifyskipping2') as string;
            this.toasterService.success(message);
            break;
          case 102 :
            break;
            default:
              if(this.entityInfo.updateLockEvent)
              {
                this.entityInfo.updateUnlockEvent();
              }
              if(!this.entityInfo.IsReadOnly)
              {
                var fileName = this.entityInfo.FileName;
                var message =  this.resourceService.get('dms.notifysaved1') as string + ' ' + fileName + ' ' + this.resourceService.get('dms.notifysaved2') as string;
                this.toasterService.success(message);
              }

          this.removeOnBrowserFileOpen(this.entityInfo.FileId, this.entityInfo.FileGuid);
          break;
        }
      }
      else{
        switch(result.errorcode)
          {
            case ApiValidationCode.FileForceUnlocked :
            case ApiValidationCode.FileNotFound :
            case ApiValidationCode.FileLockExist :
              this.popupService.info(this.resourceService.get('ifirm.common.error') as string, this.resourceService.get('dms.notifyerror_'+ result.errorcode) as string);
              break;
            default:
              this.popupService.info(this.resourceService.get('ifirm.common.error') as string, this.resourceService.get('dms.common.errormessage') as string);
            break;
          }
      }
    }).finally(()=> {
    });
   }

   setOnBrowserFileOpen(fileId : number,  fileGuid: string){
     if(!this.isOnBrowserFileOpened(fileId, fileGuid))
      {
        let file = new OpenedFile();
        file.fileId = fileId;
        file.fileGuid= fileGuid;
        OpenDocumentComponent.filesOpened.push(file);
      }
   }

   removeOnBrowserFileOpen(fileId : number,  fileGuid: string){
    if(this.isOnBrowserFileOpened(fileId, fileGuid))
     {
        let len =  OpenDocumentComponent.filesOpened.length;
        for (var i = 0; i < len; i++) {
          if (OpenDocumentComponent.filesOpened[i].fileId === fileId && OpenDocumentComponent.filesOpened[i].fileGuid === fileGuid ) {
            OpenDocumentComponent.filesOpened.splice(i, 1);
            break;
          }
        }
    }
  }


   isOnBrowserFileOpened(fileId : number, fileGuid: string): boolean{
    const result = OpenDocumentComponent.filesOpened.find((element : OpenedFile) => {
      return element.fileId == fileId && element.fileGuid == fileGuid;
    });

    return result && result != null;
   }
  }

  class OpenedFile {
    fileId: Number;
    fileGuid: string;
  }
