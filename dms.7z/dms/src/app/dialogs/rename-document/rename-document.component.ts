import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ResourceService, ModalPopupConfig, ModalPopupInstance } from '@ifirm';
import { DmsDialogApiService } from '../dms-dialog-api.service';
import { RenameDocumentModel } from '../models/rename-document.model';
import { ToasterService } from 'projects/ifirm-common-components/src/lib/toaster//toaster.service';
import { DocumentKind } from '../../constants/app-constants';
import {ValidatorService} from '../../validation/validator.service'

@Component({
  selector: 'app-rename-document',
  templateUrl: './rename-document.component.html',
  styleUrls: ['./rename-document.component.scss', '../dms-dialog-style.scss']
})
export class RenameDocumentComponent implements OnInit {
  rData: boolean;
  renameDocumentForm: FormGroup;
  data: RenameDocumentModel = null;
  extIndex: number;
  emailTimeStamp: string;
  emailName: string;
  extension: string;
  isFile: boolean;
  validationMessage: string;

  constructor(private config: ModalPopupConfig<any>, private instance: ModalPopupInstance, private dmsDialogApiService: DmsDialogApiService,
    private toasterService: ToasterService, private resourceService: ResourceService, private validatorService: ValidatorService) { 
    this.data = config.data as RenameDocumentModel;
    console.log('@data',  this.data);
    this.extIndex = this.data.OldName.lastIndexOf('.');
    this.isFile = this.data.Kind === DocumentKind.File;
  }

  ngOnInit(): void {
    let ctrlValue: string;
    this.validationMessage = this.resourceService.getText('dms.common.docnamerequiredmsg', [DocumentKind[this.data.Kind]]);
    if (this.data.Kind == DocumentKind.File && this.data.FileType.Extension) {
      ctrlValue = this.data.OldName.substring(0, this.extIndex);
      this.extension = this.data.OldName.substring(this.extIndex);
      if (this.data.FileType.Extension === "msg" && this.data.EmailMetaDataId > 0)
      {
        let timeStampIndex = this.data.OldName.lastIndexOf("_");
        if (timeStampIndex > 0)
        {
          this.emailTimeStamp = ctrlValue.substring(timeStampIndex);
          ctrlValue = this.data.OldName.substring(0, timeStampIndex);
        }
      }
    }
    else
    {
      ctrlValue = this.data.OldName;
    }

    this.renameDocumentForm = new FormGroup({
      name: new FormControl(ctrlValue, [Validators.required, this.validatorService.noWhitespaceValidator])
    });
  }

  get name() {
    return this.renameDocumentForm.get('name');
  }

  onSubmit() {
    if (this.renameDocumentForm.valid)
    {
      this.rData = true;
      let newName: string = this.name.value.trim();
      if (this.data.Kind == DocumentKind.File && this.data.FileType?.Extension)
      {
        newName = (this.data.FileType?.Extension === "msg" && this.data.EmailMetaDataId > 0) ? newName.concat(this.emailTimeStamp) : newName;
        newName = newName.concat(this.extension);
      }

      if (newName === this.data.OldName)
      {
        this.closePopup(false);
        return;
      }

      this.data.NewName = newName;
      let renameService = this.data.TemplateId ? this.dmsDialogApiService.RenameTemplateFolder(this.data) : this.dmsDialogApiService.RenameDocument(this.data); 
      renameService.then(result => {
        this.rData = false;
        if (result.success) {
          this.closePopup(true);
        }
        else {
          this.toasterService.error(this.resourceService.getText('dms.common.errormessage'));
        }
      }).catch(ex => {
        this.rData = false;
        this.toasterService.error(this.resourceService.getText('dms.common.errormessage'));
      });
    }
  }

  closePopup(result: boolean):void{
    this.instance.close(result); 
  }
}
