import { Component, OnInit, Input, Output, EventEmitter, ViewChild, ElementRef } from '@angular/core';
import { FileNotesModel } from '../../models/file-notes.model';
import { ResourceService, ModalPopupService, ConfirmationBoxType } from '@ifirm';
import { NoteStatus } from '../../../constants/app-constants';
import { DmsDialogApiService } from '../../dms-dialog-api.service';
import { ToasterService } from 'projects/ifirm-common-components/src/lib/toaster//toaster.service';

@Component({
  selector: 'app-file-note-item',
  templateUrl: './file-note-item.component.html',
  styleUrls: ['./file-note-item.component.scss']
})
export class FileNoteItemComponent implements OnInit {

  @Input() note: FileNotesModel;
  @Input() fileId: number;
  @Output() deleteNote: EventEmitter<{ noteId: Number }> = new EventEmitter<{ noteId: Number }>();
  @ViewChild('noteItemStatusDropdown', { static: true }) noteItemStatusDropdown: ElementRef;
  unassignedUser: string;
  isUpdatePreviousNoteStatus: boolean;
  previousNoteStatusDD: number;
  noteStatusText: string;

  constructor(private resourceService: ResourceService, private popupService: ModalPopupService, private dmsDialogApiService: DmsDialogApiService,
    private toasterService: ToasterService) {
  }

  ngOnInit(): void {
    this.unassignedUser = this.resourceService.getText('dms.unassigned');
    this.isUpdatePreviousNoteStatus = false;
    this.noteStatusText = this.getNoteStatus(this.note.Status);
  }

  get NoteStatus() {
    return NoteStatus;
  }

  showConfirmDeleteDialog(noteId: number, canDelete: boolean, createdOn: string): void {
    if (canDelete) {
      const instance = this.popupService.confirm(this.resourceService.getText('dms.notedeletetitle'), this.resourceService.getText('dms.notedeleteconfirmation') + ' ' + createdOn + ".", ConfirmationBoxType.YesNo);
      const subscription = instance.afterClosed.subscribe(a => {
        subscription.unsubscribe();
        if (a && a.result == true) {
          var deleteNote = new FileNotesModel();
          deleteNote.FileId = this.fileId;
          deleteNote.NoteId = noteId;
          this.dmsDialogApiService.DeleteNote(deleteNote).then(res => {
            this.deleteNote.emit({ noteId: noteId });
            var successMessage = this.resourceService.getText('dms.successdeletenote').replace('DATE', createdOn);
            this.toasterService.success(successMessage);
          }).catch(
            exception => {
              this.toasterService.error(this.resourceService.getText('dms.common.errormessage'));
            });
        }
      });
    }
  }

  enableNoteStatusDropDown(status: number) {
    this.previousNoteStatusDD = status;
    this.isUpdatePreviousNoteStatus = true;
    setTimeout(() => {
      this.noteItemStatusDropdown.nativeElement.focus();
    }, 100);
  }

  disableNoteStatusDropDown(id: number, createdBy: string, createdOn: string) {
    let previousStatus = this.note.Status;
    var updateNote = {
      NoteId: id,
      Status: this.previousNoteStatusDD,
      PrevStatus: previousStatus
    }
    this.dmsDialogApiService.UpdateNote(updateNote).then(res => {
      this.note.Status = parseInt(this.previousNoteStatusDD.toString());
      this.noteStatusText = this.getNoteStatus(this.note.Status);
      this.isUpdatePreviousNoteStatus = false;
      var successMessage = this.resourceService.getText('dms.successupdatenote').replace('DATE', createdOn).replace('USERNAME', createdBy).replace('X', this.getNoteStatus(previousStatus)).replace('Z', this.noteStatusText);
      this.toasterService.success(successMessage);
    }).catch(
      exception => {
        this.toasterService.error(this.resourceService.getText('dms.common.errormessage'));
      });
  }

  hideStatusDropDown() {
    this.isUpdatePreviousNoteStatus = false;
  }

  getNoteStatus(status: number) {
    var noteStatus: string;
    switch (status) {
      case NoteStatus.Open:
        noteStatus = this.resourceService.getText("dms.notestatusopen");
        break;
      case NoteStatus.Resolved:
        noteStatus = this.resourceService.getText("dms.notestatusresolved");
        break;
      case NoteStatus.Unassigned:
        noteStatus = this.resourceService.getText("dms.notestatusselect");
        break;
    }

    return noteStatus;
  }
}
