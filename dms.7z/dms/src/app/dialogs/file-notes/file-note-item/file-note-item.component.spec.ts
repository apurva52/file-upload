import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FileNoteItemComponent } from './file-note-item.component';

describe('FileNoteItemComponent', () => {
  let component: FileNoteItemComponent;
  let fixture: ComponentFixture<FileNoteItemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FileNoteItemComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FileNoteItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
