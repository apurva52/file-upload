import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ConfirmationBoxType, ResourceService, ModalPopupConfig, ModalPopupInstance, ModalPopupService } from '@ifirm';
import { ToasterService } from 'projects/ifirm-common-components/src/lib/toaster//toaster.service';
import { DmsDialogApiService } from '../dms-dialog-api.service';
import { FileNotesModel } from '../models/file-notes.model';
import { UserContractModel } from '../models/user-contract.model'
import { NoteStatus } from '../../constants/app-constants';
import { formatDate } from '@angular/common';

@Component({
  selector: 'app-file-notes',
  templateUrl: './file-notes.component.html',
  styleUrls: ['./file-notes.component.scss', '../dms-dialog-style.scss']
})
export class FileNotesComponent implements OnInit {

  fileNotesForm: FormGroup;
  rData: boolean = false;
  noteList: FileNotesModel[] = [];
  fileId: number;
  placeholder: string;
  noteDueDate: Date;
  dateFormat: any;
  filterUsers: UserContractModel[] = [];
  open: number;
  resolved: number;
  minDate: Date;
  isSaveNoteInProgress: boolean;

  constructor(private config: ModalPopupConfig<any>, private instance: ModalPopupInstance, private dmsDialogApiService: DmsDialogApiService,
    private toasterService: ToasterService, private resourceService: ResourceService, private popupService: ModalPopupService) {
    this.fileId = config.data.FileId as number;
    this.noteDueDate = new Date();
    this.minDate = new Date();
  }

  ngOnInit(): void {
    this.isSaveNoteInProgress = false;
    this.createForm();
    this.placeholder = this.resourceService.getText('dms.notetextareaplaceholder');
    this.dateFormat = "{dateformat: '" + "DD/MM/yyyy hh-mm-sss" + "', minDate: '" + this.getDateFormat() + "'}";
    this.getActiveUsers();
    this.getNoteList();
  }

  get NoteStatus() {
    return NoteStatus;
  }

  private createForm() {
    this.fileNotesForm = new FormGroup({
      noteUserId: new FormControl(""),
      notestatus: new FormControl(NoteStatus.Unassigned),
      noteText: new FormControl("", Validators.required)
    });
  }

  get noteUserId() {
    return this.fileNotesForm.get('noteUserId');
  }

  get notestatus() {
    return this.fileNotesForm.get('notestatus');
  }

  get noteText() {
    return this.fileNotesForm.get('noteText');
  }

  saveNote(): void {
    this.isSaveNoteInProgress = true;
    if (this.noteText.value.trim().length > 0) {
      var note = new FileNotesModel();
      note.FileId = this.fileId;
      note.IsDeleted = false;
      note.Description = this.noteText.value.trim();
      note.DueDate = new Date(this.formatDate(this.noteDueDate));
      note.AssignTo = this.noteUserId.value;
      note.Status = this.notestatus.value;
      this.dmsDialogApiService.AddNote(note).then(res => {
        if (this.noteList != null && this.noteList.length > 0) {
          this.noteList.unshift(res.NoteList[0]);
        }
        else {
          this.noteList = res.NoteList;
        }
        this.createForm();
        this.noteDueDate = null;
        var successMessage = this.resourceService.getText('dms.successaddnote').replace('DATE', res.NoteList[0].CreatedDateDisplay);
        this.toasterService.success(successMessage);
        this.isSaveNoteInProgress = false;
      }).catch(
        exception => {
          this.rData = false;
          this.toasterService.error(this.resourceService.getText('dms.common.errormessage'));
          this.isSaveNoteInProgress = false;
        });
    }
    else {
      this.noteText.setValue("");
      this.isSaveNoteInProgress = false;
    }
  }

  private formatDate(date: Date, format?: string): string {
    if (date) {
      format = format || 'yyyy-MM-dd';
      return formatDate(date, format, 'en-US')
    }
    return '';
  }

  getNoteList(): void {
    var request = new FileNotesModel();
    request.FileId = this.fileId;
    this.dmsDialogApiService.GetNoteList(request).then(res => {
      this.noteList = res.NoteList;
    }).catch(
      exception => {
        this.rData = false;
        this.toasterService.error(this.resourceService.getText('dms.common.errormessage'));
      });
  }

  private getDateFormat = function () {
    var d = new Date();
    var month = d.getMonth() + 1;
    var day = d.getDate();
    var output = d.getFullYear() + '-' +
      (month < 10 ? '0' : '') + month + '-' +
      (day < 10 ? '0' : '') + day;
    return output;
  }

  clearnotes() {
    this.noteText.setValue("");
  }

  getActiveUsers() {
    this.dmsDialogApiService.GetActiveUsers().then(users => {
      this.filterUsers = users;
    });
  }

  deleteNote(data) {
    var removeIndex = this.noteList.findIndex(i => i.NoteId === data.noteId);
    this.noteList.splice(removeIndex, 1);
  }

  closePopup(result: boolean): void {
    if (this.noteText.value.trim().length > 0) {
      const instance = this.popupService.confirm(this.resourceService.getText('dms.notediscard') as string, this.resourceService.getText('dms.notediscardconfirmation') as string, ConfirmationBoxType.YesNo);
      const subscription = instance.afterClosed.subscribe(a => {
        subscription.unsubscribe();
        if (a && a.result == true) {
          this.instance.close({ result: result });
        }
      });
    }
    else {
      this.instance.close({ result: result });
    }
  }
}
