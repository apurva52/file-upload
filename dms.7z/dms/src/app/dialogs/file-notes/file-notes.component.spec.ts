import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FileNotesComponent } from './file-notes.component';

describe('FileNotesComponent', () => {
  let component: FileNotesComponent;
  let fixture: ComponentFixture<FileNotesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FileNotesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FileNotesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
