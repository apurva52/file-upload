import { Component, OnDestroy, OnInit } from '@angular/core';
import { ModalPopupConfig, ModalPopupInstance, ResourceService, ToasterService } from '@ifirm';
import { DmsDialogApiService } from '../../dialogs/dms-dialog-api.service';
import { ApiStatus, PropertiesPayload, RetentionDateByTag, TagList } from './models/file-property.model';
import { FilePropertyService } from './services/file-property.service'
import { entityType, fileKind } from '../../constants/app-constants';
import { formatDate } from '@angular/common';
import { forkJoin, from, Observable, Subscription } from 'rxjs';

@Component({
  selector: 'app-file-property',
  templateUrl: './file-property.component.html',
  styleUrls: ['./file-property.component.scss']
})
export class FilePropertyComponent implements OnInit, OnDestroy {
  fileKindEnum = fileKind
  loader = false;
  name: string;
  type: string;
  originalRetentionDate: string;
  searchTag = this.resourceService.getText('dms.searchtag.search');
  source: string;
  activeRetentionDate: any;
  selectedTagList: TagList[] = [];
  initialSelectedTagList: TagList[] = [];
  minexpiryDate: Date = new Date();
  editRetention = false;
  expiryResetTitle = this.resourceService.getText('dms.propertiesdialog.reverticontooltip');
  propertiesPopupConfig = null;
  filePropertyData = null
  tags: TagList[] = [];
  disableUndoRetention = false;
  private subscriptions = new Subscription()
  constructor(private config: ModalPopupConfig<any>, private resourceService: ResourceService, private instance: ModalPopupInstance, private dmsDialogApiService: DmsDialogApiService, private toasterService: ToasterService, private filepropertyservice: FilePropertyService) {

    this.propertiesPopupConfig = config.data;
    this.getTagList();
    this.getFileProperty();
  }

  ngOnInit(): void {
    if (this.propertiesPopupConfig.file.kind == this.fileKindEnum.File) {
      this.editRetention = true;
      this.disableUndoRetention = this.propertiesPopupConfig.file.IsRecycleBin ? false:true;
    }
  }

  private getTagList(): void {
    const taglistobj = { EntityId: this.propertiesPopupConfig.file.EntityId, EntityType: this.propertiesPopupConfig.file.EntityType, FileId: this.propertiesPopupConfig.file.id, FileKind: this.propertiesPopupConfig.file.kind, FileSource: this.propertiesPopupConfig.file.Source } as any;

    this.dmsDialogApiService.GetTagList(taglistobj).then(res => {
      if (res.Status.toLowerCase() === ApiStatus.Success) {
        this.selectedTagList = res.SelectedTagList.map((val) => {
        return {
          id: val,
          name : res.TagList.find((res) => res.TagId == val).TagNameForDisplay
          }
        })
        
        this.initialSelectedTagList = [...this.selectedTagList]
        this.tags = res.TagList.map((value) => ({
          id: value.TagId,
          name: value.TagNameForDisplay
        }));
      }
      else {
        this.selectedTagList = []
        this.initialSelectedTagList = []
        this.tags = [];
      }
    }).catch(
      exception => {
        this.loader = false;
        this.toasterService.error(this.resourceService.getText('dms.common.errormessage'));
      });
  }

  getFileProperty(): void {
    const filepropobj = {} as PropertiesPayload;
    filepropobj.EntityId = this.propertiesPopupConfig.file.EntityId;
    filepropobj.EntityType = this.propertiesPopupConfig.file.EntityType;
    filepropobj.Hierarchy = this.propertiesPopupConfig.file.Hierarchy;
    filepropobj.Id = this.propertiesPopupConfig.file.id;
    filepropobj.IsDeleted = this.propertiesPopupConfig.isDeleted;
    filepropobj.Kind = this.propertiesPopupConfig.file.kind;
    this.loader = true;

    this.subscriptions.add(this.filepropertyservice.getFolderProperties(filepropobj).subscribe(res => {
      if (res) {
        this.loader = false;
        this.filePropertyData = res;
        this.originalRetentionDate = res.RetentionDate;
        this.filePropertyData.RetentionDate = !!res.RetentionDate ?  this.filePropertyData.RetentionDate : null;
        this.activeRetentionDate = res.RetentionDate;
        this.filePropertyData.Icon = this.fileIcon(this.propertiesPopupConfig.file);
        this.filePropertyData.SizeDisplay = this.resourceService.getText('dms.propertiesdialog.size', [res.SizeDisplay, res.TotalSizeDisplay]);
        this.filePropertyData.Contains = this.getFileConatinText(res.FileCount,res.FolderCount);
        this.propertiesPopupConfig.file.IsRecycleBin && this.tagChange();
      }
    }))
  }

  private getFileConatinText(filecount:number,foldercount:number): string {
   return  `${filecount}  ${this.resourceService.getText('dms.propertiesdialog.file')}
            ${filecount > 1 ? this.resourceService.getText('dms.propertiesdialog.pluralform') : ""} , 
            ${foldercount} ${this.resourceService.getText('dms.propertiesdialog.folder')}
           ${foldercount > 1 ?this.resourceService.getText('dms.propertiesdialog.pluralform') : ''}`;
  }

  fileIcon(file): string {
    return file.EmailMetaDataId > 0 ? 'email-logged' : 'dms-' + file.Icon;
  }

  removeRetention(): void {
    this.disableUndoRetention = true;
    this.editRetention = true;
    this.isDisabled();
    this.tagChange();
  }

  showEditRetention(): void {
    this.editRetention = false;
    this.disableUndoRetention = false;
    this.isDisabled();
    this.activeRetentionDate = new Date(this.filePropertyData.RetentionDate) > new Date() ? new Date(this.filePropertyData.RetentionDate) : new Date();
  }
  isDisabled(): boolean {
    if (this.filePropertyData && this.propertiesPopupConfig.file.kind === this.fileKindEnum.File) {
      if (!this.editRetention) {
        if (formatDate(this.activeRetentionDate, 'yyyy-MM-dd', 'en-US') !== this.originalRetentionDate || JSON.stringify(this.selectedTagList) !== JSON.stringify(this.initialSelectedTagList))
          return false
        else
          return true;
      }
      else {
        if (this.originalRetentionDate !== this.filePropertyData.RetentionDate || JSON.stringify(this.selectedTagList) !== JSON.stringify(this.initialSelectedTagList))
          return false
        else
          return true;
      }
    }

    if (this.filePropertyData && (this.propertiesPopupConfig.file.kind === this.fileKindEnum.Folder || this.propertiesPopupConfig.file.kind === this.fileKindEnum.Contact)) {
      if (JSON.stringify(this.selectedTagList) !== JSON.stringify(this.initialSelectedTagList) || (this.activeRetentionDate != null && !this.filePropertyData.IsFolderInPermanentLocation))
        return false;
      return true;
    }

  }

  IsEditRetention(): boolean {
    if (this.filePropertyData && this.propertiesPopupConfig.file.kind === this.fileKindEnum.File) {
      if (this.editRetention) {     
        return true;
      }
    }
    return false;
  }

  savePopup(): void {
    this.loader = true;
    this.subscriptions.add(forkJoin(this.getSaveApidata()).subscribe(res => {
      if (res) {
        this.loader = false;
        this.closePopup(true);
        this.toasterService.success(this.resourceService.getText('cp.settings.savedsuccessfully'));

      }
    },
      (error) => {
        this.loader = false;
        this.toasterService.error(this.resourceService.getText('dms.common.errormessage'));
      }
    ))
  }

  getSaveApidata(): Observable<any>[] {
    const apiCall: Observable<any>[] = [];
    if (formatDate(this.activeRetentionDate, 'yyyy-MM-dd', 'en-US') != this.originalRetentionDate && !this.filePropertyData.IsFolderInPermanentLocation ) {
      const postdata = {} as PropertiesPayload;
      postdata.EntityId = this.propertiesPopupConfig.file.EntityId;
      postdata.FileFolderId = this.propertiesPopupConfig.file.id;
      postdata.Hierarchy = this.propertiesPopupConfig.file.Hierarchy;
      postdata.Kind = this.propertiesPopupConfig.file.kind;
      postdata.EntityId = this.propertiesPopupConfig.file.EntityId;
      postdata.EntityType = this.propertiesPopupConfig.file.EntityType;
      postdata.IsRecycleBin = this.propertiesPopupConfig.file.IsRecycleBin;
      postdata.RetentionDate = this.activeRetentionDate ? formatDate(this.activeRetentionDate, true ? 'yyyy-MM-ddT00:00:00' : 'MMM d yyyy', 'en-US') : '';
      postdata.IsJobFolder = this.propertiesPopupConfig.file.IsSystemFolder && this.propertiesPopupConfig.EntityType === entityType.Job;
      apiCall.push(from(this.filepropertyservice.saveRetention(postdata)));
    }

    if (JSON.stringify(this.selectedTagList) !== JSON.stringify(this.initialSelectedTagList)) {
      const tagPayload = {} as PropertiesPayload;
      tagPayload.EntityType = this.propertiesPopupConfig.file.EntityType;
      tagPayload.FileId = this.propertiesPopupConfig.file.id;
      tagPayload.TagList = this.selectedTagList.map((res: TagList) => String(res.id));

      if(this.propertiesPopupConfig.file.kind !== fileKind.Folder && this.propertiesPopupConfig.file.kind !== fileKind.Contact)
      {
      tagPayload.FileSource = this.propertiesPopupConfig.file.Source;    
      apiCall.push(from(this.filepropertyservice.updateFileTaglist(tagPayload)));
      }

      else{     
      tagPayload.EntityId = this.propertiesPopupConfig.file.EntityId;
      tagPayload.EntityType = this.propertiesPopupConfig.file.EntityType;
      tagPayload.FolderId = this.propertiesPopupConfig.file.id;
      tagPayload.Hierarchy = this.propertiesPopupConfig.file.Hierarchy;
      tagPayload.IsRecycleBin = this.propertiesPopupConfig.file.IsRecycleBin;
      tagPayload.IsJobFolder = this.propertiesPopupConfig.file.isJobFolder;
      apiCall.push(from(this.filepropertyservice.updateFolderTaglist(tagPayload)));
      }

    }
    return apiCall;
  }

  closePopup(result: boolean): void {
    this.instance.close(result);
  }

   removeTag(event): void {
    if (event.value.id <= -1) {
      this.selectedTagList.unshift(event.value);
      this.selectedTagList = [...this.selectedTagList];
    }
   }

  tagChange(): void {
    const retntiondateobj = {} as RetentionDateByTag

    retntiondateobj.CreatedDate = this.filePropertyData.CreatedDate;
    retntiondateobj.DeletedDate = this.filePropertyData.DeletedDate;
    retntiondateobj.EntityId = this.propertiesPopupConfig.file.EntityId;
    retntiondateobj.EntityType = this.propertiesPopupConfig.file.EntityType;
    retntiondateobj.Id = this.propertiesPopupConfig.file.id;
    retntiondateobj.IsDeleted = this.propertiesPopupConfig.isDeleted;
    retntiondateobj.IsManuallyAssignedDate = this.filePropertyData.IsManuallyAssignedDate;
    retntiondateobj.RetentionDate = this.originalRetentionDate;
    retntiondateobj.SelectedTagList = this.selectedTagList.map((res: TagList) => String(res.id))
    this.subscriptions.add(this.filepropertyservice.getRetentionDatebyTag(retntiondateobj).subscribe(res => {
      if (res) {
        if (res.RetentionDate != "")
        {
          this.filePropertyData.RetentionDate = !!res.RetentionDate ? res.RetentionDate : null;
          this.activeRetentionDate = new Date(this.filePropertyData.RetentionDate);
        }
        this.filePropertyData.PurgeOnDate = res.PurgeOnDate;
      }
    }));
  }
  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

}
