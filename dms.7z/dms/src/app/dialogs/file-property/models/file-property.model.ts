import { entityType, fileKind, fileSource } from "../../../constants/app-constants";

export interface TagList {
    id: number;
    name: string;
}

export interface PropertiesPayload {
    EntityId?: number;
    EntityType?: entityType;
    Hierarchy?: any,
    Id?: any;
    IsDeleted?: boolean;
    Kind?: fileKind;
    FolderId?: number;
    FileId?: number;
    IsRecycleBin?: boolean;
    FileSource?: fileSource;
    RetentionDate?: string;
    IsJobFolder?: boolean;
    FileFolderId?: number;
    TagList?: string[];
}

export enum ApiStatus {
    Success = 'success'
}
export interface RetentionDateByTag {
    EntityId: number;
    EntityType: entityType;
    Id: any;
    IsDeleted: boolean;
    SelectedTagList: string[];
    CreatedDate: string
    DeletedDate: string;
    RetentionDate: string;
    IsManuallyAssignedDate: boolean;
}