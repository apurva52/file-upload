import { Injectable } from '@angular/core';
import { ApiService } from '@ifirm';
import {  map, Observable } from 'rxjs';
import {PropertiesPayload, RetentionDateByTag} from '../models/file-property.model';
@Injectable({
  providedIn: 'root'
})
export class FilePropertyService {
constructor(private api: ApiService){}
    getFolderProperties(propertiesPayload:PropertiesPayload): Observable<any> {
            const url = `dms/api/documentsearch/getfilefolderproperties`;
            return this.api.post<any>(url,null,propertiesPayload).pipe(map(res=> res.FileFolderProperties));
    }

    updateFolderTaglist(data:PropertiesPayload):Observable<any>{
            return this.api.post<any>('dms/api/tag/updatefoldertaglist',null,data);
    }

    updateFileTaglist(data:PropertiesPayload):Observable<any>{
      return this.api.post<any>('dms/api/tag/updatefiletaglist',null,data);
}

    saveRetention(savePostData:PropertiesPayload):Observable<any>{
      return this.api.post<any>('dms/api/retention/saveretention',null,savePostData);
    }
    
    getRetentionDatebyTag(datetag:RetentionDateByTag):Observable<any>{
      return this.api.post<any>('dms/api/documentsearch/getretentiondatebytag',null,datetag);
    }
  }