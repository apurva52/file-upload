import { Component, OnInit, SecurityContext } from '@angular/core';
import { ModalPopupService, ResourceService } from '@ifirm';
import { ModalPopupConfig } from 'projects/ifirm-common-components/src/lib/modal-popup/models/modal-popup-config';
import { ModalPopupInstance } from 'projects/ifirm-common-components/src/lib/modal-popup/models/modal-popup-instance';
import { DmsDialogApiService } from '../dms-dialog-api.service';
import { EmailPreviewModel } from '../models/email-preview.models';
import { DmsFileModel } from '../models/dms-fIle.model';
import { DomSanitizer } from '@angular/platform-browser';
import { DmsService } from '../../dms.service';

@Component({
  selector: 'app-email-preview',
  templateUrl: './email-preview.component.html',
  styleUrls: ['./email-preview.component.scss']
})

export class EmailPreviewComponent implements OnInit {
  isOpenDropdownShow: boolean = false;
  savedBy: string;
  file: any;
  dmsFileModel: DmsFileModel;
  emailPreviewDetails: EmailPreviewModel = new EmailPreviewModel();

  constructor(private popupConfig: ModalPopupConfig<any>, private popupInstance: ModalPopupInstance, private dmsDialogApiService: DmsDialogApiService,
    private resourceService: ResourceService, public domSanitizer: DomSanitizer, private popupService: ModalPopupService, private dmsService: DmsService) {
    this.file = popupConfig.data.file;
    this.dmsFileModel = popupConfig.data.file as DmsFileModel;
    this.dmsFileModel.FolderId = popupConfig.data.FolderId;
    this.dmsFileModel.FileGuid = popupConfig.data.file.Guid;
    this.dmsFileModel.FileType = popupConfig.data.file.Type;
    this.dmsFileModel.FileName = popupConfig.data.file.Name;
  }

  ngOnInit(): void {
    this.emailPreviewDetails.From = "";
    this.getEmailPreview(this.dmsFileModel.Id);
  }

  closeThisDialog(result: boolean): void {
    this.popupInstance.close({ result: result });
  }

  openInTrayApp() {
    this.dmsDialogApiService.getFilePayloadById(this.dmsFileModel.Id).then(result => {
      if (result != null) {
        window.open(result.data, '_self');
      }
    }).catch((err) => {
      this.popupService.info(this.resourceService.get('ifirm.common.error') as string, this.resourceService.get('dms.common.error') as string);
    });
  }

  ToggleMenu() {
    this.isOpenDropdownShow = !this.isOpenDropdownShow;
  }

  downloadFile() {
    this.checkIfFileExists(this.dmsFileModel);
  }

  getEmailPreview(fileID: number) {
    this.dmsDialogApiService.getPreviewDeatil(fileID).then(res => {
      if (res.success === true) {
        this.emailPreviewDetails = res.data;
        this.emailPreviewDetails.Message = this.setHtmlMessages();
        this.savedBy = this.resourceService.getText('dms.emailpreview.saved', [this.emailPreviewDetails.TaggedBy, this.emailPreviewDetails.TaggedDate]);
      } else {
        this.popupService.info(this.resourceService.get('ifirm.common.error') as string, this.resourceService.get('dms.emailpreview.error') as string);
        this.closeThisDialog(true);
      }
    }).catch((err) => {
      this.popupService.info(this.resourceService.get('ifirm.common.error') as string, this.resourceService.get('dms.emailpreview.error') as string);
      this.closeThisDialog(true);
    });
  }

  checkIfFileExists(dmsFileModel: DmsFileModel) {
    this.dmsDialogApiService.checkIfFileExists(dmsFileModel).then(res => {
      if (res.success === true) {
        this.dmsService.downloademailFile(dmsFileModel);
      } else {
        this.popupService.info(this.resourceService.get('ifirm.common.error') as string, this.resourceService.get('dms.common.error') as string);
      }
    }).catch((err) => {
      this.popupService.info(this.resourceService.get('ifirm.common.error') as string, this.resourceService.get('dms.common.error') as string);
    });
  }

  setHtmlMessages() {
    if (this.emailPreviewDetails.Message) {
      let iframe: any = document.getElementById('dmsEmailPreviewBodyiFrame');
      var iframedoc = iframe.contentWindow ? iframe.contentWindow.document : iframe.contentDocument;
      return iframedoc.body.innerHTML = this.domSanitizer.sanitize(SecurityContext.HTML, this.domSanitizer.bypassSecurityTrustHtml(this.emailPreviewDetails.Message));
    }
  }
}
