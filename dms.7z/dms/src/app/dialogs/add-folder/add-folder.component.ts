import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { FormGroup, FormControl, Validators, AbstractControl } from '@angular/forms';
import { ResourceService, ModalPopupConfig, ModalPopupInstance } from '@ifirm';
import { ToasterService } from 'projects/ifirm-common-components/src/lib/toaster//toaster.service';
import { AddFolderModel } from '../models/add-folder.model';
import { DmsDialogApiService } from '../dms-dialog-api.service';
import { DmsService } from '../../dms.service';
import {ValidatorService} from '../../validation/validator.service'

@Component({
  selector: 'app-add-folder',
  templateUrl: './add-folder.component.html',
  styleUrls: ['./add-folder.component.scss', '../dms-dialog-style.scss']
})
export class AddFolderComponent implements OnInit {

  addFolderForm: FormGroup;
  entityInfo: AddFolderModel = null;
  rData: boolean = false;
  @ViewChild('addFolderInput') addFolderInput: ElementRef;

  constructor(private config: ModalPopupConfig<any>, private instance: ModalPopupInstance, private dmsDialogApiService: DmsDialogApiService,
    private toasterService: ToasterService, private resourceService: ResourceService, private dmsService: DmsService, private validatorService: ValidatorService) {
    this.entityInfo = config.data as AddFolderModel;
  }

  ngOnInit(): void {
    this.createForm();
  }

  ngAfterViewInit(): void {
    this.addFolderInput.nativeElement.focus();
  }

  addFolder(): void {
    if (this.addFolderForm.status === 'VALID') {
      this.rData = true;
      this.entityInfo.FolderName = this.getFolderNameFormControl().value.trim();

      if (this.entityInfo.TemplateId && this.entityInfo.TemplateId > 0) {
        this.addTemplateFolder();
      }
      else {
        this.addRegularFolder();
      }
    }
  }

  closePopup(result: boolean): void {
    this.instance.close(result);
  }

  private createForm() {
    this.addFolderForm = new FormGroup({
      folderName: new FormControl("", [Validators.required, this.validatorService.noWhitespaceValidator])
    });
  }
  private getFolderNameFormControl(): AbstractControl { return this.addFolderForm.get('folderName'); }

  private addRegularFolder(): void {
    this.dmsDialogApiService.AddFolder(this.entityInfo).then(res => {
      this.rData = false;
      if (res.success == true) {
        this.closePopup(true);
      }
      else {
        this.toasterService.error(this.resourceService.getText('dms.common.errormessage'));
      }
    }).catch(
      exception => {
        this.rData = false;
        this.toasterService.error(this.resourceService.getText('dms.common.errormessage'));
        console.log(exception);
      });

  }

  private addTemplateFolder(): void {
    this.dmsDialogApiService.AddTemplateFolder(this.entityInfo).then(res => {
      this.rData = false;
      if (res.success == true) {
        this.closePopup(true);
      }
      else {
        this.toasterService.error(this.resourceService.getText('dms.common.errormessage'));
      }
    }).catch(
      exception => {
        this.rData = false;
        this.toasterService.error(this.resourceService.getText('dms.common.errormessage'));
        console.log(exception);
      });
  }
}
