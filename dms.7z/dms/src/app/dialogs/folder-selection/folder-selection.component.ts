import { ArrayDataSource } from '@angular/cdk/collections';
import { Component, OnInit } from '@angular/core';
import { NestedTreeControl } from '@angular/cdk/tree';
import { ResourceService, ModalPopupConfig, ModalPopupInstance } from '@ifirm';
import { DmsDialogApiService } from '../dms-dialog-api.service';
import { FolderTreeNodeModel } from '../models/folder-tree-node.model'
import { entityType } from '../../constants/app-constants';

@Component({
  selector: 'app-folder-selection',
  templateUrl: './folder-selection.component.html',
  styleUrls: ['./folder-selection.component.scss', '../dms-dialog-style.scss']
})
export class FolderSelectionComponent implements OnInit {
  treeNode: FolderTreeNodeModel[] = [];
  treeControl = new NestedTreeControl<FolderTreeNodeModel>(node => node.Childrens);
  dataSource = new ArrayDataSource(this.treeNode);
  data: any;
  resourceSelect: string;
  resourceEmpty: string;
  resourceCollapse: string;
  resourceExpand: string;
  selectedFolderId: number;
  selectedFolder: FolderTreeNodeModel;
  clientName: string;
  isPortalTreeNode: boolean;
  btnText: string;

  hasChild(_: number, node: FolderTreeNodeModel) {
    var response = (node.Childrens && node.Childrens.length > 0) || !node.Empty;
    return response;
  }

  constructor(private config: ModalPopupConfig<any> ,private instance: ModalPopupInstance, private dmsDialogApiService: DmsDialogApiService, private resourceService: ResourceService) {
    this.data = config.data;

    if (this.data.ClientId && this.data.ClientId > 0) {
      this.isPortalTreeNode = true;
      this.btnText = this.resourceService.getText('dms.send');
      this.clientName = this.data.ClientName;
      this.loadPortalTreeNode();
    }
    else {
      this.isPortalTreeNode = false;
      this.btnText = this.resourceService.getText('dms.selectfolder');
      this.selectedFolderId = this.data.CurrentFolderId;
      this.loadTreeNode();
    }
  }

  ngOnInit(): void {
    this.resourceSelect = this.resourceService.getText('dms.select');
    this.resourceEmpty = this.resourceService.getText('dms.empty');
    this.resourceCollapse = this.resourceService.getText('dms.collapse');
    this.resourceExpand = this.resourceService.getText('dms.expand');
  }

  toggleNode(node: FolderTreeNodeModel) {
    let nodeRef;
    if (!this.isPortalTreeNode) {
      nodeRef = this.GetNode(node.FolderId, node.Hierarchy);
    }
    else {
      nodeRef = this.GetPortalNode(node.Id, node.FullPath, node.Name)
    }
    if (nodeRef.Collapsed) {
      if (!this.isPortalTreeNode) {
        var getFolderTreeContract = {
          entityType: this.data.EntityType,
          entityId: this.data.EntityId,
          selectedFolderId: nodeRef.FolderId,
          hierarchy: nodeRef.Hierarchy,
          isImmediateFolder: true
        }

        this.dmsDialogApiService.GetFolderTree(getFolderTreeContract).then(res => {
          if (res && res.length > 0) {
            if (getFolderTreeContract.entityType === entityType.Job || getFolderTreeContract.entityType === entityType.Hr || getFolderTreeContract.entityType === entityType.User) {
              res = res[0].Childrens;
            }

            if (res.length > 0) {
              this.setChildren(nodeRef.FolderId, nodeRef.Hierarchy, res);
            } else {
              nodeRef.Empty = true;
            }
          }
          else {
            nodeRef.Empty = true;
          }
          this.refreshTree(this.treeNode, true);
        });
      }
      else {
        if (nodeRef.Childrens.length > 0) {
          nodeRef.Collapsed = false;
          nodeRef.Selected = 'selected';
        }
        else {
          nodeRef.Empty = true;
        }
        this.refreshTree(this.treeNode, true);
      }
    }
    else {
      nodeRef.Collapsed = true;
      this.collapseChildNode(nodeRef.Childrens);
      this.refreshTree(this.treeNode, true);
    }

  }

  collapseChildNode(nodeChildrens: FolderTreeNodeModel[]){
    if(nodeChildrens !== undefined && nodeChildrens !== null){
      nodeChildrens.forEach(childNode => {
        childNode.Collapsed = true;
        this.collapseChildNode(childNode.Childrens);
      });
    }
  }

  selectFolder(node: FolderTreeNodeModel) {
    this.selectedFolder = node;
    this.selectedFolderId = this.getNodeId(node);
  }

  selectedFolderClick() {
    this.closePopup(this.selectedFolder);
  }

  closePopup(result: FolderTreeNodeModel): void {
  this.instance.close(result);
  }

  getNodeId(node: FolderTreeNodeModel): number {
    return this.isPortalTreeNode ? node.Id : node.FolderId;
  }

  private loadTreeNode() {
    var getFolderTreeContract = {
      entityType: this.data.EntityType,
      entityId: this.data.EntityId,
      selectedFolderId: this.data.CurrentFolderId,
      hierarchy: this.data.CurrentFolderhierarchy,
      isImmediateFolder: false
    }
    this.dmsDialogApiService.GetFolderTree(getFolderTreeContract).then(res => {
      if (res) {
        this.refreshTree(res, false);
        if (this.data.CurrentFolderId > 0) {
          this.selectedFolder = this.treeNode.find(x => x.FolderId === this.data.CurrentFolderId);
        }
        else {
          if (getFolderTreeContract.entityType == entityType.Contact || getFolderTreeContract.entityType == entityType.Firm) {
            this.selectedFolder = this.getSelectedNode('selected');
          }
          else if (getFolderTreeContract.entityType == entityType.Job || getFolderTreeContract.entityType == entityType.Hr || getFolderTreeContract.entityType == entityType.User) {
            this.selectedFolder = this.getSelectedNode('root selected');
          }

          this.selectedFolderId = this.selectedFolder.FolderId;
        }
      }
    });
  }

  private loadPortalTreeNode() {
    this.dmsDialogApiService.getFoldersFromPortal(this.data.ClientId).then(res => {
      if (res) {
        this.refreshTree(res.Data, false);
        this.selectedFolder = this.getSelectedNode('root selected');
        this.selectedFolderId = this.selectedFolder.Id;
      }
    });
  }

  private GetNode(folderId: number, hierarchy: string): FolderTreeNodeModel {
    var treeStructure = (this.data.EntityType === entityType.Job || this.data.EntityType === entityType.Hr || this.data.EntityType === entityType.User) ? this.treeNode[0].Childrens : this.treeNode;
    if(folderId === 0){
      treeStructure = this.treeNode;
    }
    var node = treeStructure.find(x => x.FolderId == folderId);
    if (node === undefined || node === null) {
      var children;
      if (hierarchy !== undefined && hierarchy !== null) {
        var arrayFolderIds = hierarchy.split('/');
        arrayFolderIds.forEach(item => {
          if (children === undefined || children === null) {
            children = this.getNestedChildren(treeStructure, parseInt(item));
          }
          else {
            children = this.getNestedChildren(children, parseInt(item));
          }
        });
        node = children.find(x => x.FolderId == folderId);
      }
      else {
        node = this.treeNode[0].Childrens.find(x => x.FolderId == folderId);
      }
    }

    return node;
  }

  private GetPortalNode(Id: number, FullPath: string, Name: string): FolderTreeNodeModel {
    var treeStructure = (Name === '<root>') ? this.treeNode : this.treeNode[0].Childrens;
    var node = treeStructure.find(x => x.Id == Id);
    if (node === undefined || node === null) {
      var children;
      if (FullPath !== undefined && FullPath !== null) {
        var arrayFolderIds = FullPath.split('/');
        arrayFolderIds.splice(0, 2);
        arrayFolderIds.splice(arrayFolderIds.length-1,1);
        arrayFolderIds.forEach(item => {
          if (children === undefined || children === null) {
            children = treeStructure.find(x => x.Name == item).Childrens;
          }
          else {
            children = children.find(x => x.Name == item).Childrens;
          }
        });
        node = children.find(x => x.Id == Id);
      }
      else {
        node = treeStructure.find(x => x.Id == Id);
      }
    }

    return node;
  }


  private setChildren(folderId: number, hierarchy: string, result: FolderTreeNodeModel[]) {
    let node = this.GetNode(folderId, hierarchy);
    node.Childrens = result;
    node.Collapsed = false;
    node.Selected = 'selected';
  }

  private refreshTree(data: FolderTreeNodeModel[], clone: boolean) {
    this.treeNode = data;
    this.dataSource = clone ? new ArrayDataSource(structuredClone(data)) : new ArrayDataSource(data);
  }

  private getNestedChildren(folders: FolderTreeNodeModel[], folderId: number) {
    return folders.find(x => x.FolderId == folderId).Childrens;
  }

  private getSelectedNode(selectedValue: string) {
    return this.treeNode.find(x => x.Selected === selectedValue);
  }


}