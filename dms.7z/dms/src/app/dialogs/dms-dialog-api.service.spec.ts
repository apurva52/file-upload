import { TestBed } from '@angular/core/testing';

import { DmsDialogApiService } from './dms-dialog-api.service';

describe('DmsDialogApiService', () => {
  let service: DmsDialogApiService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DmsDialogApiService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
