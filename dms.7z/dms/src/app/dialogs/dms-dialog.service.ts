import { Injectable, NgZone } from '@angular/core';
import { ResourceService, ModalPopupConfig, ModalPopupService } from '@ifirm';
import { DmsService } from '../dms.service';
import { RenameDocumentComponent } from './rename-document/rename-document.component';
import { AddFolderComponent } from './add-folder/add-Folder.component';
import { FileVersionComponent } from './file-version/file-version.component';
import { FileNotesComponent } from './file-notes/file-notes.component';
import { EmailPreviewComponent } from './email-preview/email-preview.component';
import { OpenDocumentComponent } from './open-document/open-document.component';
import { FileversionspaceComponent } from './file-versionspace/file-versionspace.component';
import { FolderSelectionComponent } from './folder-selection/folder-selection.component';
import { InsertLinkComponent } from './insert-link/insert-link.component';
import { ClientLookupComponent } from 'projects/ifirm-common-components/src/lib/common-client-lookup/common-client-lookup/client-lookup.component';

@Injectable({
  providedIn: 'root'
})
export class DmsDialogService {

  constructor(private resourceService: ResourceService, private popupService: ModalPopupService, private dmsService: DmsService, private zone: NgZone) {
  }

  openDialog(name: string, data: any, closeFunction: any): void {
    const config = new ModalPopupConfig();
    config.data = data;

    let instance;

    switch (name) {
      case 'addfolder':
        instance = this.popupService.open<AddFolderComponent>(this.resourceService.getText('ifirm.common.addfolder'), AddFolderComponent, config);
        break;
      case 'renamedocument':
        instance = this.popupService.open<RenameDocumentComponent>(this.resourceService.getText('ifirm.common.rename'), RenameDocumentComponent, config);
        break;
      case 'filenotes':
        instance = this.popupService.open<FileNotesComponent>(this.resourceService.getText('dms.filenotes'), FileNotesComponent, config);
        break;
        case 'contactLookup':
          instance = this.popupService.open<ClientLookupComponent>(this.resourceService.getText('ifirm.common.contactlookup'), ClientLookupComponent, config);
          break;
      case 'emailPreview':
        this.zone.run(() => {
          instance = this.popupService.open<EmailPreviewComponent>(this.resourceService.getText('dms.emailpreview.title'), EmailPreviewComponent, config);
        });
        break;
      case 'fileversion':
        instance = this.popupService.open<FileVersionComponent>(this.resourceService.getText('dms.versionsdialog.versionhistory'), FileVersionComponent, config);
        break;
      case 'fileversionspace':
        instance = this.popupService.open<FileversionspaceComponent>(this.resourceService.getText('dms.versionsdialog.versionhistory'), FileversionspaceComponent, config);
        break;
      case 'opendocument':
        this.zone.run(() => {
          instance = this.popupService.open<OpenDocumentComponent>(this.resourceService.getText('dms.opendocumentinbrowser.opendocument'), OpenDocumentComponent, config);
        });
        break;
      case 'folderselection':
        this.zone.run(() => {
          instance = this.popupService.open<FolderSelectionComponent>(this.resourceService.getText('dms.selectfolder'), FolderSelectionComponent, config);
        });
        break;
      case 'insertlink':
        instance = this.popupService.open<InsertLinkComponent>(this.resourceService.getText('dms.common.link'), InsertLinkComponent, config);
        break;
    }

    this.closePopup(instance, closeFunction);
  }

  private closePopup(instance: any, closeFunction: any) {
    const subscription = instance.afterClosed.subscribe(x => {
      if (subscription) {
        subscription.unsubscribe();
      }

      if (closeFunction) {
        closeFunction(x);
      }
    });
  }
}
