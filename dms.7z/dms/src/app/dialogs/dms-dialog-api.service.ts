import { Injectable } from '@angular/core';
import { ApiService } from '@ifirm';
import { AddFolderModel } from "./models/add-folder.model";
import { RenameDocumentModel } from './models/rename-document.model';
import { FileNotesModel } from './models/file-notes.model';
import { DmsFileModel } from "./models/dms-fIle.model";
import { OnedriveAzureadappSettings } from './models/onedrive-azureadapp-settings.model'
import { FolderTreeNodeModel } from './models/folder-tree-node.model';
import { DmsFile } from '../pdf/models/dms-file.model';
import { InsertLinkModel } from './models/insert-link.model';

@Injectable({
  providedIn: 'root'
})
export class DmsDialogApiService {

  constructor(private api: ApiService) { }

  public AddFolder(data: AddFolderModel): Promise<any> {
    return this.api.post<any>('/dms/api/document/addfolder', null, data).toPromise();
  }

  public AddTemplateFolder(data: AddFolderModel): Promise<any> {
    return this.api.post<any>('/dms/api/foldertemplates/adddefaultfolder', null, data).toPromise();
  }

  public RenameDocument(data: RenameDocumentModel): Promise<any> {
    return this.api.post<any>('/dms/api/document/renamedocument', null, data).toPromise();
  }

  public RenameTemplateFolder(data: RenameDocumentModel): Promise<any> {
    return this.api.post<any>('/dms/api/foldertemplates/renamedefaultfolder', null, data).toPromise();
  }

  public GetActiveUsers(): Promise<any> {
    return this.api.get<any>('/dms/api/user/getactiveusers').toPromise();
  }

  public AddNote(data: FileNotesModel): Promise<any> {
    return this.api.post<any>('/dms/api/Notes/AddNote', null, data).toPromise();
  }

  public GetNoteList(data: FileNotesModel): Promise<any> {
    return this.api.post<any>('/dms/api/Notes/GetNotes', null, data).toPromise();
  }

  public DeleteNote(data: FileNotesModel): Promise<any> {
    return this.api.post<any>('/dms/api/Notes/DeleteNote', null, data).toPromise();
  }

  public UpdateNote(data: any): Promise<any> {
    return this.api.post<any>('/dms/api/Notes/UpdateNote', null, data).toPromise();
  }
  public getPreviewDeatil(fileid: number): Promise<any> {
    const url = '/dms/api/emailcontact/previewemail?fileId=' + fileid;
    return this.api.get<any>(url).toPromise();
  }

  public checkIfFileExists(deleteContract: DmsFileModel): Promise<any> {
    return this.api.post<any>('/dms/api/document/CheckIfFileExists', null, deleteContract).toPromise();
  }

  public GetFileVersions(fileId: number): Promise<any> {
    return this.api.get<any>('/dms/api/documentsearch/getfileversions?fileId=' + fileId).toPromise();
  }

  public CheckIfFileExists(data: any): Promise<any> {
    return this.api.post<any>('/dms/api/document/CheckIfFileExists', null, data).toPromise();
  }

  public DeleteDocumentspermanently(data: any): Promise<any> {
    return this.api.post<any>('/dms/api/recyclebin/deletequarantineddocumentspermanently', null, data).toPromise();
  }

  public RevertFileVersion(data: any): Promise<any> {
    return this.api.post<any>('/dms/api/fileversion/revertfileversion', null, data).toPromise();
  }

  public CopyFileVersion(data: any): Promise<any> {
    return this.api.post<any>('/dms/api/fileversion/copyfileversion', null, data).toPromise();
  }


  public GetOneDriveAzureAdAppSettings(fileId : number, isReadOnly : boolean): Promise<any> {
    return this.api.get<any>('/dms/api/OneDriveDocInBrowser/getazureadappsettings?fileId=' +  fileId +'&isReadOnly='+isReadOnly ).toPromise();
  }

  public UploadOpenFileInBrowser(entityInfo: any): Promise<any> {
    return this.api.post<any>('/dms/api/OneDriveDocInBrowser/UploadFileInStorage', null, entityInfo).toPromise();
  }

  public CloseOneDriveDocument(closeDocumentUrl: string): Promise<any> {
    return this.api.get<any>(closeDocumentUrl).toPromise();
  }

  public DeleteFileVersions(deleteContract: any): Promise<any> {
    return this.api.post<any>('/dms/api/document/deletefileversion', null, deleteContract).toPromise();
  }

  public GetFolderTree(getFolderTreeContract: any): Promise<FolderTreeNodeModel[]> {
    return this.api.post<any>('/dms/api/documentsearch/getfoldertree', null, getFolderTreeContract).toPromise();
  }

  public getFoldersFromPortal(clientId: number): Promise<any> {
    const url = '/crm/api/ClientPortal/GetClientPortalDirectoryForDMS?clientId=' + clientId;
    return this.api.get<any>(url).toPromise();
  }

  public getFolderHierarchy(hierarchy: any): Promise<any> {
    return this.api.get<any>('/dms/api/document/getfolderhierarchy?hierarchy=' + hierarchy).toPromise();
  }

  public createDefaultFolders(entityId: number, entityType: any): Promise<any> {
    let dmsFile = { entityId, entityType }
    return this.api.post<any>('/dms/api/document/createdefaultfolders', null, dmsFile).toPromise();
  }

  public getCurrentEntityForLookup(entityId: number, entityType: any): Promise<any> {
    return this.api.get<any>('/dms/api/documentsearch/getcurrententityforlookup?entityId=' + entityId + '&entityType=' + entityType).toPromise();
  }

  public getClientPortalAccessInfo(entityId: number, entityType: any): Promise<any> {
    return this.api.get<any>('/dms/api/clientportal/getclientportalaccessinfo?entityId=' + entityId + '&entityType=' + entityType).toPromise();
  }

  public getInternalDocumentsFolderDetail(entityId: number, entityType: any): Promise<any> {
    let data = { entityId, entityType }
    return this.api.post<any>('/dms/api/document/GetInternalDocumentsFolderDetail', null, data).toPromise();
  }

  public getUsers(includeSystemFolder: boolean): Promise<any> {
    return this.api.get<any>('/dms/api/user/getusers/?IncludeSystemFolder=' + includeSystemFolder).toPromise();
  }

  public getDocumentById(fileId: number): Promise<any> {
    return this.api.get<any>('/dms/api/document/GetDocumentById/?fileId=' + fileId).toPromise();
  }

  public getFilePayloadById(fileId: number): Promise<any> {
    return this.api.get<any>('/dms/api/document/OpenFilePayloadByFileId/?fileId=' + fileId).toPromise();
  }

  public insertLink(data: InsertLinkModel): Promise<any> {
    return this.api.post<any>('/dms/api/document/InsertLink', null, data).toPromise();
  }

  public GetTagList(insertLinkInfo: InsertLinkModel): Promise<any> {
    return this.api.get<any>('/dms/api/tag/getfileorfoldertaglist?entityId=' +insertLinkInfo.EntityId + 
    '&entityType=' +insertLinkInfo.EntityType + '&fileId=' +insertLinkInfo.FileId + '&kind=' +insertLinkInfo.FileKind + 
    '&source=' +insertLinkInfo.FileSource).toPromise();
  }

  public updateInsertLink(data: InsertLinkModel): Promise<any> {
    return this.api.post<any>('/dms/api/document/UpdateInsertLink', null, data).toPromise();
  }

  public validateFileDownload(data: any): Promise<any> {
    return this.api.post<any>('/dms/api/document/validatefiledownload/', null, data).toPromise();
  }

  public validateBulkFileDownload(data: any): Promise<any> {
    return this.api.post<any>('/dms/api/document/validatebulkfiledownload', null, data).toPromise();
  }

  public downloadFile(formParams):Promise<any> {
    return this.api.post('/dms/api/Export/DownloadFile/', null, formParams).toPromise();
  }

  public checkFolderEmpty(formParams):Promise<any> {
    return this.api.post('/dms/api/document/CheckFolderEmpty', null, formParams).toPromise();
  }

}