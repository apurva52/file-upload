import { Component, OnDestroy, OnInit } from '@angular/core';
import { ResourceService, ModalPopupConfig, ModalPopupInstance, ModalPopupService } from '@ifirm';
import { ToasterService } from 'projects/ifirm-common-components/src/lib/toaster//toaster.service';
import { DmsDialogApiService } from '../dms-dialog-api.service';
import { DmsService } from '../../dms.service';
import { FileVersion } from '../models/file-version.model'
import { antivirusScanStatus, AppConstants, entityType, eventType } from '../../constants/app-constants';

@Component({
  selector: 'app-file-version',
  templateUrl: './file-version.component.html',
  styleUrls: ['./file-version.component.scss']
})
export class FileVersionComponent implements OnInit {

  data: any;
  fileVersions: FileVersion[];
  loadError: boolean = false;
  showDownloadButton: boolean = false;
  showRevertButton: boolean = false;
  showCopyButton: boolean = false;
  fileLocked: string;
  totalDisplayed: number = 20;
  toolTipRestore: string;
  toolTipCopy: string;
  toolTipVersionPermanentDelete: string;
  fileIcon: string;

  constructor(private config: ModalPopupConfig<any>, private instance: ModalPopupInstance, private dmsDialogApiService: DmsDialogApiService,
    private toasterService: ToasterService, private resourceService: ResourceService, private dmsService: DmsService, private popupService: ModalPopupService) {
    this.data = config.data;
  }

  ngOnInit(): void {
    this.toolTipRestore = this.resourceService.getText('dms.versionsdialog.restoretooltip');
    this.toolTipCopy = this.resourceService.getText('dms.versionsdialog.copytooltip');
    this.toolTipVersionPermanentDelete = this.resourceService.getText('dms.delete.permanenttooltip');
    this.fileLocked = this.data.File.IsLocked ? "dms-isDisabled" : "";
    this.fileIcon = this.data.File.Icon;
    this.setUserRoles();
    this.dmsDialogApiService.GetFileVersions(this.data.File.Id).then(res => {
      if (res.Errors.length === 0) {
        this.fileVersions = res.FileVersions;
      }
      else {
        this.loadError = true;
      }
    })
  }

  private setUserRoles(): void {
    if (this.data.File.EntityType == entityType.Contact || this.data.File.EntityType == entityType.Job) {
      this.showDownloadButton = this.data.UserRoles.viewAny;
      this.showRevertButton = (this.data.UserRoles.viewEdit || this.data.UserRoles.viewEditCopyMove);
      this.showCopyButton = (this.data.UserRoles.viewEdit || this.data.UserRoles.viewEditCopyMove);
    }
    else if (this.data.UserRoles.firmDocuments && (this.data.File.EntityType == entityType.Firm || this.data.File.EntityType == entityType.User || this.data.File.EntityType == entityType.Hr)) {
      if (this.data.File.EntityType == entityType.Firm) {
        this.showDownloadButton = this.data.UserRoles.internalDocumentsView;
        this.showRevertButton = this.data.UserRoles.internalDocumentsViewEdit;
        this.showCopyButton = this.data.UserRoles.internalDocumentsViewEdit;
      }
      else if (this.data.File.EntityType == entityType.User) {
        this.showDownloadButton = true;
        this.showRevertButton = true;
        this.showCopyButton = true;
      }
      else if (this.data.File.EntityType == entityType.Hr) {
        this.showDownloadButton = this.data.UserRoles.hrManager;
        this.showRevertButton = this.data.UserRoles.hrManager;
        this.showCopyButton = this.data.UserRoles.hrManager;
      }
    }
  }

  downloadFileVersion(fileVersion: FileVersion) {
    this.closePopup(true);
    var fileContract = {
      StoragePath: fileVersion.StoragePath,
      FileGuid: fileVersion.VersionGuid,
      FileType: fileVersion.FileType
    }

    this.dmsDialogApiService.CheckIfFileExists(fileContract).then(res => {
      if (res.success === true) {
        if (fileVersion.AVScanStatus === antivirusScanStatus.Queued || fileVersion.AVScanStatus === antivirusScanStatus.NotStarted) {
          const confirmInstance = this.popupService.confirm(this.resourceService.getText('dms.downloadwarning'), this.resourceService.getText('dms.common.filenotscanned'));
          const subscription = confirmInstance.afterClosed.subscribe(a => {
            subscription.unsubscribe();
            if (a && a.result == true) {
              this.startDownloadingFileVersion(fileVersion);
            }
          });
        }
        else if (fileVersion.AVScanStatus === antivirusScanStatus.Fail || fileVersion.AVScanStatus === antivirusScanStatus.InvalidExtension) {
          var message = (fileVersion.AVScanStatus === antivirusScanStatus.Fail) ? this.resourceService.getText('dms.common.filequarantined') : this.resourceService.getText('dms.common.fileinvalidextention')
          var confirmInstance = this.popupService.confirm(this.resourceService.getText('dms.delete.permanenttitle'), message);
          const subscription = confirmInstance.afterClosed.subscribe(a => {
            subscription.unsubscribe();
            if (a && a.result == true) {
              var deleteContract = {
                FileGuid: fileVersion.VersionGuid,
                EntityType: fileVersion.EntityType,
                EntityId: fileVersion.EntityId
              };

              this.dmsDialogApiService.DeleteDocumentspermanently(deleteContract).then(res => {
                if (res.success === true) {
                  this.data.broadCastFunc(true);
                }
                else {
                  this.toasterService.error(this.resourceService.getText('dms.delete.errormessage'));
                }
              })
            }
          });
        }
        else {
          this.startDownloadingFileVersion(fileVersion);
        }
      }
      else {
        //// file not found
        this.toasterService.warning(this.resourceService.getText('dms.validationmessages.1002'));
      }
    });

    return false;
  }

  startDownloadingFileVersion(fileVersion: FileVersion) {
    var downloadContract = {
      VersionId: fileVersion.VersionId,
      FileId: fileVersion.FileId,
      VersionGuid: fileVersion.VersionGuid,
      UpdatedDateDisplay: fileVersion.UpdatedDateDisplay,
      EntityType: fileVersion.EntityType,
      EntityId: fileVersion.EntityId,
      Hierarchy: fileVersion.Hierarchy,
      FileName: fileVersion.FileName,
      FileType: fileVersion.FileType,
      StoragePath: fileVersion.StoragePath
    };

    var downloadContractBtoa = encodeURIComponent(btoa(unescape(encodeURIComponent(JSON.stringify(downloadContract)))));

    var target = "_self";
    var form = document.createElement("form");
    form.setAttribute("method", "POST");
    form.setAttribute("action", "/dms/api/export/DownloadFileVersion/");
    form.setAttribute("target", target);

    var inputdownloadContractBtoa = document.createElement('input');
    inputdownloadContractBtoa.type = "hidden";
    inputdownloadContractBtoa.name = "downloadContractBtoa";
    inputdownloadContractBtoa.value = downloadContractBtoa;
    form.appendChild(inputdownloadContractBtoa);

    document.body.appendChild(form);
    form.target = target;
    form.submit();
    document.body.removeChild(form);
  }

  revertFileVersion(fileVersion: FileVersion) {
    if (this.fileLocked === "") {
      this.fileLocked = "dms-isDisabled";
      this.dmsDialogApiService.RevertFileVersion(fileVersion).then(
        response => {
          if (response.success === true) {
            this.closePopup({ response: response.success, event: eventType.RevertVersion });
          }
          else {
            if (response.ValidationCode > 0) {
              this.toasterService.warning(this.resourceService.getText('dms.validationmessages.' + response.ValidationCode));
            }
            else {
              this.toasterService.error(this.resourceService.getText('dms.versionsdialog.reverterrormmessage'));
              this.fileLocked = "";
            }
          }
        }).catch(
          exception => {
            this.toasterService.error(this.resourceService.getText('dms.versionsdialog.reverterrormmessage'));
            this.fileLocked = "";
          });
    }

    return false;
  }

  copyFileVersion(fileVersion: FileVersion) {
    this.dmsDialogApiService.CopyFileVersion(fileVersion).then(
      res => {
        if (res.success === true) {
          this.closePopup({ response: res.success, event: eventType.CopyVersion });
        }
        else {
          this.toasterService.error(this.resourceService.getText('dms.versionsdialog.copyerrormmessage'))
        }
      })

    return false;
  }


  isCaseWareFileVersion(fileVersion: FileVersion) {
    return fileVersion.FileType && fileVersion.FileType.Extension === AppConstants.caseWareExtension;
  }

  isVersionRenamedOrReverted(file) {
    return (file.EventType === eventType.Rename || file.EventType === eventType.RevertVersion);
  }

  HeaderClick() {
    return false;
  }

  closePopup(result: any): void {
    this.instance.close({ result: result });
  }
}
