import { TestBed } from '@angular/core/testing';

import { DmsDialogService } from './dms-dialog.service';

describe('DmsDialogService', () => {
  let service: DmsDialogService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DmsDialogService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
