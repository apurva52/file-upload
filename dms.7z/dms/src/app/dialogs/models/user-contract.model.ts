import { PropertyName } from '@ifirm';

export class UserContractModel {
    @PropertyName('UserId')
    UserId: number;

    @PropertyName('FirstName')
    FirstName: string;

    @PropertyName('LastName')
    LastName: string;

    @PropertyName('UserName')
    UserName: string;

    @PropertyName('ProfilePhoto')
    ProfilePhoto: string;

    @PropertyName('Base64Photo')
    Base64Photo: string;

    @PropertyName('CanAddContact')
    CanAddContact: boolean;
    
    @PropertyName('CanEditContact')
    CanEditContact: boolean;
    
    @PropertyName('CanUploadDocument')
    CanUploadDocument: boolean;

    @PropertyName('FullName')
    FullName: string;
}
