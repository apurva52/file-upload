import { PropertyName } from '@ifirm';
import { FileTypeModel } from './file-type.model';
import { DocumentKind } from '../../constants/app-constants';

export class RenameDocumentModel {
    @PropertyName('Id')
    Id: number;

    @PropertyName('Guid')
    Guid: string;

    @PropertyName('EntityType')
    EntityType: number;

    @PropertyName('EntityId')
    EntityId: number;

    @PropertyName('ParentFolderId')
    ParentFolderId: number;

    @PropertyName('Hierarchy')
    Hierarchy: string;

    @PropertyName('OldName')
    OldName: string;

    @PropertyName('Name')
    NewName: string;

    @PropertyName('FileType')
    FileType: FileTypeModel;

    @PropertyName('EmailMetaDataId')
    EmailMetaDataId: Number;

    @PropertyName('Kind')
    Kind: DocumentKind;

    @PropertyName('DefaultFolderId')
    DefaultFolderId: Number;

    @PropertyName('TemplateId')
    TemplateId: Number;
}

export class RenameDocumentModelPayload{
  
    EntityId: number;
    EntityType: number;
    Id: number;
    Guid: string;
    ParentFolderId: number;
    Kind: number;
    FileType: FileType;
    OldName: string;
    Name: string;
    Hierarchy: string;
    EmailMetaDataId: number;
    NewName: string;
}

export interface FileType {
    Id: number;
    GroupName: string;
    Extension: string;
    FileExtensionId: number;
    ResourceKey: string;
  }

