import { PropertyName } from '@ifirm';

export class AddFolderModel {
    @PropertyName('EntityType')
    EntityType: number;

    @PropertyName('EntityId')
    EntityId: number;

    @PropertyName('ParentFolderId')
    ParentFolderId: number;

    @PropertyName('Hierarchy')
    Hierarchy: string;

    @PropertyName('FolderName')
    FolderName: string;

    @PropertyName('TemplateId')
    TemplateId:number;

    @PropertyName('DefaultFolderHierarchy')
    DefaultFolderHierarchy: string;
}
