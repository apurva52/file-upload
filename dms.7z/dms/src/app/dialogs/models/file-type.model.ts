import { PropertyName } from '@ifirm';

export class FileTypeModel {
    @PropertyName('Id')
    Id: number;

    @PropertyName('GroupName')
    GroupName: string;

    @PropertyName('Extension')
    Extension: string;

    @PropertyName('FileExtensionId')
    FileExtensionId: number;
}
