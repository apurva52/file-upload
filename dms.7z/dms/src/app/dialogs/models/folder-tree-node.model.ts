import { DmsFolderModel } from "./dms-folder.model";

export class FolderTreeNodeModel extends DmsFolderModel {
    Collapsed: boolean;
    Selected: string;
    Childrens: FolderTreeNodeModel[]
    Empty: boolean;
    Name: string;
    Id: number;
    FullPath: string;
}
