import { PropertyName } from "@ifirm";
import { entityType,documentType,fileSource,fileKind } from "../../constants/app-constants";
import { FileType } from "./dms-filetype.model";

export class DmsFileModel {
    @PropertyName("EntityType")
    EntityType: entityType;

    @PropertyName("EntityId")
    EntityId: number;

    @PropertyName("Id")
    Id: number;

    @PropertyName("JobTypeId")
    JobTypeId: number;

    @PropertyName("StoragePathId")
    StoragePathId: number;

    @PropertyName("ParentId")
    FolderId: number;

    @PropertyName("Guid")
    FileGuid: string;

    @PropertyName("Name")
    FileName: string;

    @PropertyName("Icon")
    Icon: string;

    @PropertyName("StoragePath")
    StoragePath: string;

    @PropertyName("Type")
    FileType: FileType;

    @PropertyName("Kind")
    FileKind: fileKind;

    @PropertyName("DocumentType")
    DocumentType: documentType;

    @PropertyName("FileSource")
    FileSource: fileSource;

    @PropertyName("Hierarchy")
    Hierarchy: string;

    @PropertyName("UpdatedBy")
    UpdatedBy: string;
    
    @PropertyName("UpdatedDate")
    UpdatedDate: string;

    @PropertyName("OpenEditPayload")
    OpenEditPayload: string;

    @PropertyName("EmailMetaDataId")
    EmailMetaDataId :number;
  
    @PropertyName("LinkUrl")
    LinkUrl :string;

    @PropertyName("ParentId")
    ParentId: number;
}