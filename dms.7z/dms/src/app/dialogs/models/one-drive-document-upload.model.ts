import { PropertyName } from '@ifirm';

export class OneDriveDocumentUpload {
    @PropertyName('WebUrl')
    WebUrl: string;

    @PropertyName('IteamId')
    ItemId: string;

    @PropertyName('UserId')
    UserId: string;
}
