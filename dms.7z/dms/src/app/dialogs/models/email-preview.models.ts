import { PropertyName } from "@ifirm";

export class EmailPreviewModel {
    @PropertyName("EmailMetadataId")
    EmailMetadataId: number;

    @PropertyName("FileId")
    FileId: number;

    @PropertyName("ParentInternetMessageId")
    ParentInternetMessageId: string;

    @PropertyName("ConversationId")
    ConversationId: number;

    @PropertyName("From")
    From: string;

    @PropertyName("To")
    To: string;

    @PropertyName("Cc")
    Cc: string;

    @PropertyName("Subject")
    Subject: string;

    @PropertyName("Message")
    Message: string;

    @PropertyName("ReceivedDate")
    ReceivedDate: string;

    @PropertyName("Attachments")
    Attachments: string;

    @PropertyName("TaggedBy")
    TaggedBy: string;

    @PropertyName("TaggedDate")
    TaggedDate: string;

    @PropertyName("IsCurrentWeek")
    IsCurrentWeek: number;

    @PropertyName("IsCurrentMonth")
    IsCurrentMonth: number;

    @PropertyName("IsCurrentYear")
    IsCurrentYear: number;

    @PropertyName("FirstName")
    FirstName: string;

    @PropertyName("LastName")
    LastName: string;

    @PropertyName("Selected")
    Selected: number;

    @PropertyName("FromInitial")
    FromInitial: string;

}