import { PropertyName } from '@ifirm';
import { OpenDocument } from '../../constants/app-constants';

export class OnedriveAzureadappSettings {
    @PropertyName('ClientId')
    ClientId: string;

    @PropertyName('Scope')
    Scope: string;

    @PropertyName('ClientState')
    ClientState: string;

    @PropertyName('ConsentUrl')
    ConsentUrl: string;

    @PropertyName('RedirectUrl')
    RedirectUrl: string;

    @PropertyName('ResponseType')
    ResponseType: string;

    @PropertyName('IsAzureAdSessionExist')
    IsAzureAdSessionExist: boolean;

    @PropertyName('DmsOfficeDocumentOpenWithApplication')
    DmsOfficeDocumentOpenWithApplication: OpenDocument;

    @PropertyName('IsReadOnly')
    IsReadOnly : boolean;

    @PropertyName('OpenEditPayload')
    OpenEditPayload: string
}
