import { PropertyName } from '@ifirm';
import { fileKind, fileSource } from '../../constants/app-constants';

export class InsertLinkModel {
    @PropertyName('DisplayText')
    DisplayText: string;

    @PropertyName('LinkUrl')
    LinkUrl: string;

    @PropertyName('EntityType')
    EntityType: number;

    @PropertyName('EntityId')
    EntityId: number;

    @PropertyName('FolderId')
    FolderId: number;

    @PropertyName('Hierarchy')
    Hierarchy: string;

    @PropertyName('TagList')
    TagList: number[];

    @PropertyName("Kind")
    FileKind: fileKind;

    @PropertyName("FileSource")
    FileSource: fileSource;

    @PropertyName('FileId')
    FileId: number;
}
