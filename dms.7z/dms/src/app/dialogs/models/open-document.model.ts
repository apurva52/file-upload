import { entityType,documentType,fileSource,fileKind } from "../../constants/app-constants";
import { FileType } from "./dms-filetype.model";

export class OpenDocumentModel {
    FileId: number;
    EntityType: entityType;
    EntityId: number;
    Hierarchy: string;
    FileName: string;
    FileGuid: string;
    ExtensionType: string;
    IsReadOnly: boolean;
    updateLockEvent: any;
    updateUnlockEvent: any;
    IsDiscardOneDriveFile: boolean;
}
