import { PropertyName } from '@ifirm';
import { eventType } from '../../constants/app-constants';
import { DmsFileModel } from './dms-fIle.model';

export class CopyMoveDocumentModel {
    @PropertyName('EventType')
    EventType: eventType;

    @PropertyName("UserRoles")
    UserRoles: any;

    @PropertyName("SelectedItems")
    SelectedItems: DmsFileModel[];

    @PropertyName("LocationDetails")
    LocationDetails: any;
}