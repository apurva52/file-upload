import { PropertyName } from '@ifirm';

export class FileNotesModel {
    @PropertyName('NoteId')
    NoteId: number;

    @PropertyName('Description')
    Description: string;

    @PropertyName('FileId')
    FileId: number;

    @PropertyName('Status')
    Status: number;

    @PropertyName('IsDeleted')
    IsDeleted: boolean;

    @PropertyName('CreatedBy')
    CreatedBy: string;

    @PropertyName('CreatedById')
    CreatedById: number;
    
    @PropertyName('UpdatedBy')
    UpdatedBy: number;
        
    @PropertyName('CreatedDate')
    CreatedDate: Date;
        
    @PropertyName('UpdatedDate')
    UpdatedDate: Date;
        
    @PropertyName('DueDate')
    DueDate: Date;
        
    @PropertyName('CreatedDateDisplay')
    CreatedDateDisplay: string;
        
    @PropertyName('UpdatedDateDisplay')
    UpdatedDateDisplay: string;
        
    @PropertyName('DueDateDisplay')
    DueDateDisplay: string;
        
    @PropertyName('AssignTo')
    AssignTo: string;
        
    @PropertyName('AssignToId')
    AssignToId: number;
        
    @PropertyName('CanDelete')
    CanDelete: boolean;
        
    @PropertyName('CanUpdateStatus')
    CanUpdateStatus: boolean;

    @PropertyName('PrevStatus')
    PrevStatus: number;
}
