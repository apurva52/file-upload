import { PropertyName } from '@ifirm';
import { entityType, fileKind } from '../../constants/app-constants';

export class FileVersion {
    @PropertyName('VersionId')
    VersionId: number;

    @PropertyName('FileId')
    FileId: number;

    @PropertyName('FileName')
    FileName: string;

    @PropertyName('Hierarchy')
    Hierarchy:string;

    @PropertyName('UpdatedDateDisplay')
    UpdatedDateDisplay: string;

    @PropertyName('UpdatedByFirstName')
    UpdatedByFirstName: string;

    @PropertyName('UpdatedByLastName')
    UpdatedByLastName: string;

    @PropertyName('SizeDisplay')
    SizeDisplay: string;

    @PropertyName('IsBaseFile')
    IsBaseFile: boolean;

    @PropertyName('StoragePath')
    StoragePath: string;

    @PropertyName('VersionGuid')
    VersionGuid: string;

    @PropertyName('FileType')
    FileType: any;

    @PropertyName('AVScanStatus')
    AVScanStatus: number;

    @PropertyName('EntityType')
    EntityType: entityType;

    @PropertyName('EntityId')
    EntityId: Number;

    @PropertyName("Kind")
    FileKind: fileKind;

    @PropertyName('Size')
    Size: string;

}
