export class DmsFolderModel {
    FolderId: number;
    StoragePathId:number;
    EntityType: number;
    EntityId: number;
    ParentFolderId: number;
    Hierarchy: string;
    FolderGuid: string;
    FolderName: string;
    CreatedBy: number;
    CreatedDateTime: Date;
    UpdatedBy: number;
    UpdatedDateTime: Date;
    DefaultFolderId: number;
    FolderKey: string;
    SortOrder: number;
    IsDeleted: boolean;
    ParentDefaultFolderId: number;
}
