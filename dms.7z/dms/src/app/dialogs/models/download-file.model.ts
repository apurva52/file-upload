export class DownloadFileModel{
  
    StoragePath: string;
    FileGuid: string;
    FileId: number;
    FileType: FileType;
}

export interface FileType {
    Id: number;
    GroupName: string;
    Extension: string;
    FileExtensionId: number;
    ResourceKey: string;
  }
