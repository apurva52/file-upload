import { PropertyName } from '@ifirm';
import { FileType } from "./dms-filetype.model";
import { entityType,documentType,fileSource,fileKind } from "../../constants/app-constants";

export class OnedriveOpenDocumentModel {
    @PropertyName("FileId")
    FileId: number;

    @PropertyName("EntityType")
    EntityType: entityType;

    @PropertyName("EntityId")
    EntityId: number;

    @PropertyName("Hierarchy")
    Hierarchy: string;

    @PropertyName("FileType")
    FileType: FileType;

    @PropertyName("FileName")
    FileName: string;

    @PropertyName("FileGuid")
    FileGuid: string;

    @PropertyName("OpenEditPayload")
    OpenEditPayload: string;

    @PropertyName("ExtensionType")
    ExtensionType: string;

    @PropertyName("IsReadOnly")
    IsReadOnly: boolean;

    @PropertyName("updateLockEvent")
    updateLockEvent: any;

    @PropertyName("updateUnlockEvent")
    updateUnlockEvent: any;

    @PropertyName("IsOpenThroughUrl")
    IsOpenThroughUrl: boolean;

    IsDiscardOneDriveFile: boolean
}
