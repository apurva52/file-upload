import { PropertyName } from "@ifirm";

export class FileType{
    @PropertyName("Id")
    Id: number;

    @PropertyName("GroupName")
    GroupName: string;

    @PropertyName("Extension")
    Extension: string;

    @PropertyName("FileExtensionId")
    FileExtensionId: number;

    @PropertyName("ResourceKey")
    ResourceKey: string;

    @PropertyName("Count")
    Count: number;
}