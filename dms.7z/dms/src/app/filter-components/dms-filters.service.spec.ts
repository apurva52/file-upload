import { TestBed } from '@angular/core/testing';

import { DmsFiltersService } from './dms-filters.service';

describe('DmsFiltersService', () => {
  let service: DmsFiltersService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DmsFiltersService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
