import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { ContactGroupPayload, ContactGroupResponse, ContactListPayload, ContactListResponse, FilterAcceptanceCriteria, myRecentActivityAction, UserInfoResponse, UserListPayload, UserListResponse } from '../shared/filters/model/user.model';

@Injectable({
  providedIn: 'root'
})
export class DmsFiltersService {


  contactGroupPayload: ContactGroupPayload = {
    PageNumber: 0,
    PageSize: 200,
    SearchText: ''
  }
  contactListPayload = {
    ContactGroupId: null,
    IsArchivedContact: true,
    PageNumber: 0,
    PageSize: 200,
    SearchText: ''
  }
  userFullName = null;
  
  defaultFilter: FilterAcceptanceCriteria = {
    ContactGroupId:"",
    ContactList: [],
    ContactsTagList: [],
    DateFrom: "",
    DateTo:"",
    FileTypes:[],
    FirmSystemTag: "",
    IsArchivedContacts: true,
    IsFilterPortalTag: false,
    IsInActiveUser: false,
    IsJobClosed:"0",
    JobTypeTagList: [],
    MyRecentFiles: false,
    NoteAssignTo: "",
    NoteCreatedBy: "",
    NoteDueDate: "",
    NoteStatus: "",
    ShowArchivedContactsCheckBox:false,
    ShowInActiveUserCheckBox: false,
    TagList: [],
    UserFolders: 1,
    UserId: ""}
  tempDefaultFilter: FilterAcceptanceCriteria = {
    ContactGroupId:"",
    ContactList: [],
    ContactsTagList: [],
    DateFrom: "",
    DateTo:"",
    FileTypes:[],
    FirmSystemTag: "",
    IsArchivedContacts: true,
    IsFilterPortalTag: false,
    IsInActiveUser: false,
    IsJobClosed:"0",
    JobTypeTagList: [],
    MyRecentFiles: false,
    NoteAssignTo: "",
    NoteCreatedBy: "",
    NoteDueDate: "",
    NoteStatus: "",
    ShowArchivedContactsCheckBox:false,
    ShowInActiveUserCheckBox: false,
    TagList: [],
    UserFolders: 1,
    UserId: ""}

  public updateDateSection = new Subject();

  constructor(private api: HttpClient) { }

  getUserList(payload: UserListPayload): Observable<UserListResponse[]> {
    let params = new HttpParams();
    params = params.append('IncludeSystemUser', payload.IncludeSystemUser);
    params = params.append('IsInactiveUser', payload.IsInactiveUser);
    params = params.append('PageNumber', payload.PageNumber);
    params = params.append('PageSize', payload.PageSize);
    params = params.append('SearchText', payload.SearchText);
    const url = 'dms/api/user/getuserlist';
    return this.api.get<UserListResponse[]>(url,{params: params});
  }
  getContactGroupList(payload: ContactGroupPayload): Observable<ContactGroupResponse[]> {
    let params = new HttpParams();
    params = params.append('PageNumber', payload.PageNumber);
    params = params.append('PageSize', payload.PageSize);
    params = params.append('SearchText', payload.SearchText);
    const url = 'dms/api/documentsearch/getcontactgrouplist'
    return this.api.get<ContactGroupResponse[]>(url,{params: params});
  }
  getContactList(payload: ContactListPayload): Observable<ContactListResponse[]> {
    let params = new HttpParams();
    params = params.append('ContactGroupId', payload.ContactGroupId);
    params = params.append('IsArchivedContact', payload.IsArchivedContact);
    params = params.append('PageNumber', payload.PageNumber);
    params = params.append('PageSize', payload.PageSize);
    params = params.append('SearchText', payload.SearchText);
    const url = 'dms/api/documentsearch/getcontactlist';
    return this.api.get<ContactListResponse[]>(url,{params: params});
  }
  getUserInfo(): Observable<UserInfoResponse> {
    const url = 'dms/api/user/getuserinfo';
    return this.api.get<UserInfoResponse>(url);
  }

  getEmailAddresses(emailAddressType,entityId,entityType): Observable<any>{
    const obj = { emailAddressType: emailAddressType, entityId: entityId, entityType: entityType };
    return this.api.post<any>('/dms/api/emailcontact/getemailaddresslist', obj);
  }
  shareMyRecentActivity(data: myRecentActivityAction) {
    this.updateDateSection.next(data);
  }
}
