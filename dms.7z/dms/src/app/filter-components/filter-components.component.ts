import { CommonModule, DatePipe } from '@angular/common';
import { Component, CUSTOM_ELEMENTS_SCHEMA, ElementRef, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { IFirmButtonModule, LocalizationModule, ModalPopupService, ResourceService, ToasterService } from '@ifirm';
import { ErrorBoxComponent } from 'projects/ifirm-common-components/src/lib/modal-popup/error-box/error-box.component';
import { ContactsComponent } from '../shared/filters/contacts/contacts.component';
import { DatesComponent } from '../shared/filters/dates/dates.component';
import { NotesComponent } from '../shared/filters/notes/notes.component';
import { TagsComponent } from '../shared/filters/tags/tags.component';
import { TypesComponent } from '../shared/filters/types/types.component';
import { UsersComponent } from '../shared/filters/users/users.component';
import { ContactGroupResponse, ContactListResponse, FileTypeResponse, payLoadCommonModel, TagsListResponse, TagsResponse, UserInfoResponse, UserListPayload, UserListResponse } from '../shared/filters/model/user.model';
import { GridServiceService } from '../shared/tools/service/grid-service.service';
import { DmsFiltersService } from './dms-filters.service';
import { formatDate } from '@angular/common';
import { JobStatusComponent } from '../shared/filters/job-status/job-status.component';
import { Subscription } from 'rxjs';
import { RecycleBinService } from '../module/recyclebin/recyclebin/recyclebin.service';
import { DmsService } from '../dms.service';
import { FirmDocumentsService } from '../module/firm/firm-documents/services/firm-documents.service';
import { DMSFirmDocument, entityType } from '../constants/app-constants';
import { ConversationsService } from '../module/conversations/conversations/services/conversations.service';

@Component({
  selector: 'app-filter-components',
  templateUrl: './filter-components.component.html',
  styleUrls: ['./filter-components.component.scss'],
  standalone: true,
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  imports: [CommonModule, ReactiveFormsModule, FormsModule, LocalizationModule, UsersComponent, JobStatusComponent,
    NotesComponent, DatesComponent, TagsComponent, ContactsComponent, TypesComponent,IFirmButtonModule],
    providers: [DatePipe]
})
export class FilterComponentsComponent implements OnInit, OnDestroy {

  userList: UserListResponse[] = [];
  assignToUserList: UserListResponse[] = [];
  createdByUser: UserListResponse[] = [];
  @Input()selectedIndex;
  @Input() crmEntityId :number;
  @Input() crmEntityType :entityType;
  userInfo = new UserInfoResponse();
  previousPayload = new payLoadCommonModel()
  fileExcollection: FileTypeResponse[] = [];
  filtersTags: TagsResponse[] = [];
  groupContactList: ContactGroupResponse[] = [];
  contactList:ContactListResponse[] = [];
  disableApplyFilter: boolean = true;
  isClearFilter: boolean = false
  callClearFilter: boolean = false;
  callApplyFilter: boolean = false;
  userListPayload: UserListPayload = {
    IncludeSystemUser: false,
    IsInactiveUser: false,
    PageNumber: 0,
    PageSize: 200,
    SearchText: ''
  }
  isEmptyEvent: boolean = false;
  dmsCommonPayload = new payLoadCommonModel();
  conversationsPayload :any;
  fileTypeSubscription: Subscription;
  fileTagSubscription: Subscription;
  filterTypeSubscription: Subscription;
  dmsCommonPayloadSubscription: Subscription;
  clientDocCommonPayloadSub: Subscription;
  isContactFilterRequired: boolean = true;
  isJobStatusFilterRequired: boolean = false;
  isEnabledUserFolder: boolean = false;
  sentByEmailAddresses :[] = [];
  @Output() callParentComponent = new EventEmitter<boolean>();

  constructor(private dmsFilterService: DmsFiltersService, private popupService: ModalPopupService, private resourceService: ResourceService,
    private toasterService: ToasterService, private datepipe: DatePipe, private gridService: GridServiceService,private conversationsService:ConversationsService,
    private recycleBinService: RecycleBinService, private dmsService: DmsService, private dmsFirmDocService: FirmDocumentsService) {}

  ngOnDestroy(): void {
    this.fileTypeSubscription?.unsubscribe();
    this.fileTagSubscription?.unsubscribe();
    this.filterTypeSubscription?.unsubscribe();
    this.dmsCommonPayloadSubscription?.unsubscribe();
    this.clientDocCommonPayloadSub?.unsubscribe();
    const copyFilter = JSON.stringify(this.dmsFilterService.defaultFilter)
    this.dmsFilterService.tempDefaultFilter = JSON.parse(copyFilter);
  }
  ngOnInit(): void {
   const payload: any = this.conversationsService.getPayload$();
   this.clearCrmFilter();
    this.conversationsPayload = payload.source.value;
    this.fileTypeSubscription = this.gridService.filterFileTypeSubject.subscribe((response: FileTypeResponse[])=>{
      this.fetchFileDataType(response);
    });
    this.fileTagSubscription = this.gridService.filterTagListSubject.subscribe((response: TagsListResponse)=>{
      if (response !== null){
        this.fetchFiltersTags(response);
        if (this.isClearFilter){
          this.isClearFilter = false;
          this.callClearFilter = true;
          const copyFilter = JSON.stringify(this.dmsFilterService.defaultFilter)
        this.dmsFilterService.tempDefaultFilter = JSON.parse(copyFilter);
        }
      }
    });
    this.fileTagSubscription = this.dmsFirmDocService.getFilterTags().subscribe((response: TagsListResponse)=>{
      if (response !== null){
        this.fetchFiltersTags(response);
        if (this.isClearFilter){
          this.isClearFilter = false;
          this.callClearFilter = true;
          const copyFilter = JSON.stringify(this.dmsFilterService.defaultFilter)
        this.dmsFilterService.tempDefaultFilter = JSON.parse(copyFilter);
        }
      }
    });
    this.fileTypeSubscription = this.recycleBinService.getRecycleBinFilterTypesSubject().subscribe(response =>{
      this.fetchFileDataType(response);
      if (this.isClearFilter){
        this.dmsCommonPayload.IsFiltering = false;
        this.dmsCommonPayload.IsContentSearch = false;
        this.dmsCommonPayload.IsFileSearch = false;
        this.dmsCommonPayload.SearchMore = true;
        this.dmsCommonPayload.Page = 0;
        this.isClearFilter = false;
        this.callClearFilter = true;
        const copyFilter = JSON.stringify(this.dmsFilterService.defaultFilter)
        this.dmsFilterService.tempDefaultFilter = JSON.parse(copyFilter);
      }
    })
    this.fileTypeSubscription = this.dmsFirmDocService.getFilterFilesType().subscribe(response =>{
      this.fetchFileDataType(response);
      if (this.isClearFilter){
        this.isClearFilter = false;
        this.callClearFilter = true;
        const copyFilter = JSON.stringify(this.dmsFilterService.defaultFilter)
        this.dmsFilterService.tempDefaultFilter = JSON.parse(copyFilter);
      }
    })
    this.filterTypeSubscription = this.gridService.getFilterFields().subscribe((response: any) =>{
      if (response){
        if (response.FolderId === 0 && response.FolderHierarchyList.length === 0){
          this.isContactFilterRequired = true;
          this.isJobStatusFilterRequired = false;
        }else if (response.FolderId === 0 && response.FolderHierarchyList.length > 0){
          this.isContactFilterRequired = false;
          this.isJobStatusFilterRequired = true;
        }else {
          this.isContactFilterRequired = false;
          this.isJobStatusFilterRequired = false;
        }
      }
    })
    this.clientDocCommonPayloadSub = this.gridService.getCommonPayload().subscribe((response: payLoadCommonModel) =>{
      if (response){
        const tempData = JSON.stringify(response);
        this.dmsCommonPayload = JSON.parse(tempData);
        this.previousPayload = JSON.parse(tempData);
      }
    })
    this.dmsCommonPayloadSubscription = this.recycleBinService.getPayloadSubject().subscribe(response=>{
      this.dmsCommonPayload = response
    })
    this.dmsCommonPayloadSubscription = this.dmsFirmDocService.getPayloadForFilter().subscribe(response=>{
      const tempData = JSON.stringify(response);
      this.dmsCommonPayload = JSON.parse(tempData);
      if (!this.dmsFirmDocService.isFilterSearchArea){
        this.previousPayload = JSON.parse(tempData);
        switch (this.dmsCommonPayload?.EntityType) {
          case DMSFirmDocument.InternalDocuments:
            switch (true){
              case this.dmsCommonPayload.FolderId === null: case this.dmsCommonPayload.FolderId === 0: case this.dmsCommonPayload.FolderId === -1:
                this.isEnabledUserFolder = true;
                break
              default:
                this.isEnabledUserFolder = false;
            }  
          break;
          case DMSFirmDocument.HRDocuments:
            switch (true){
              case this.dmsCommonPayload.EntityId === null: case this.dmsCommonPayload.EntityId === 0:
                this.isEnabledUserFolder = true;
                break
              default:
                this.isEnabledUserFolder = false;
            }  
          break
          case DMSFirmDocument.User:
            this.isEnabledUserFolder = false;
            break
          default:
            this.isEnabledUserFolder = true;
            break;
        }
      }
    })
    if (this.selectedIndex === 'clientDocument'){
      this.fetchUserInfo();
    }
    if (this.selectedIndex === 'recycleBin'){
      this.dmsFilterService.defaultFilter.IsArchivedContacts = false;
      this.dmsFilterService.tempDefaultFilter.IsArchivedContacts = false;
    }
    if(this.selectedIndex === 'crm')
    {
      this.fetchUserData('userByApiCall');
      this.fetchEmailAddress()
    }
  }
  fetchFileDataType(response: FileTypeResponse[]){
    this.fileExcollection = [];
    setTimeout(() => {
      this.fileExcollection = response;
    }, 100);
  }
  fetchFiltersTags(response: TagsListResponse){
    this.filtersTags = response.TagList
  }
  fetchGroupContactList(){
    this.dmsFilterService.getContactGroupList(this.dmsFilterService.contactGroupPayload).subscribe({
      next: (res) => this.contactGroupSuccess(res),
      error: (e) => {this.toasterService.error(this.resourceService.getText('ifirm.common.error'))},
    })
  }
  contactGroupSuccess(res: ContactGroupResponse[]){
    this.groupContactList = res; 
  }
  fetchContactList(){
    this.dmsFilterService.getContactList(this.dmsFilterService.contactListPayload).subscribe({
      next: (res) => this.contactListSuccess(res),
      error: (e) => {this.toasterService.error(this.resourceService.getText('ifirm.common.error'))},
    })
  }
  contactListSuccess(res: ContactListResponse[]){
    this.contactList = res; 
  }
  dataFromExtensionFilter(event: string[]){
    this.dmsCommonPayload.Filters.FileTypes = event;
    this.isSameActionTakenOnFilter();
  }
  fetchUserData(type: string){
    this.dmsFilterService.getUserList(this.userListPayload).subscribe({
      next: (response) => this.userBySuccess(response,type),
      error: (e) => {this.toasterService.error(this.resourceService.getText('ifirm.common.error'))},
    })
  }

  fetchEmailAddress() :void
  {
    this.dmsFilterService.getEmailAddresses(1,this.crmEntityId,this.crmEntityType).subscribe({
      next: (response) =>{this.sentByEmailAddresses = response},
      error: (e) => {this.toasterService.error(this.resourceService.getText('ifirm.common.error'))},
    })
  }
  userBySuccess(response: UserListResponse[],type: string){
    if (type === 'userByApiCall'){
      this.userList = response;
    }else if (type === 'contactAssignToApi'){
      this.assignToUserList = response;
    }else if (type === 'contactCreatedByApi'){
      this.createdByUser = response;
    }
  }
  fetchUserInfo(){
    this.dmsFilterService.getUserInfo().subscribe({
      next: (response) => this.updateUserInfo(response),
      error: (e) => {this.toasterService.error(this.resourceService.getText('ifirm.common.error'))},
    })
  }
  updateUserInfo(response: UserInfoResponse){
    this.userInfo.UserId = response.UserId;
    this.userInfo.UserFullName = response.UserFullName;
  }
  dataFromLastSection(event){
    if(this.selectedIndex == 'crm')
    {
      this.disableApplyFilter = false;
      this.conversationsPayload.IsFiltering = true;
      this.conversationsPayload.Filters.SavedBy = event.data.userId;  
      this.conversationsPayload.Filters.SavedDateFrom =  this.formatDate(event.data.savedstartDate);
      this.conversationsPayload.Filters.SavedDateTo =  this.formatDate(event.data.savedendDate);
      this.conversationsPayload.Page = 0;
      return;
    }

    if (event.eventfrom === 'activeUser'){
      this.userListPayload.IsInactiveUser = event.data.activeUser === null ? false : event.data.activeUser;
      this.fetchUserData('userByApiCall');
    }
    this.dmsCommonPayload.Filters.DateFrom = this.formatDate(event.data.startDate);
    this.dmsCommonPayload.Filters.DateTo = this.formatDate(event.data.DateTo);
    this.dmsCommonPayload.Filters.IsInActiveUser = event.data.activeUser === null ? false : event.data.activeUser;
    this.dmsCommonPayload.Filters.ShowInActiveUserCheckBox = event.data.activeUser === null ? false : event.data.activeUser;
    if (event.eventfrom === "ByUser"){
      this.dmsCommonPayload.Filters.UserId = event.data.selectedUser=== null ? "": event.data.selectedUser;
    }
    this.isSameActionTakenOnFilter();
  }

  dataUpperSection(event)
  {
    this.disableApplyFilter = false;
    this.conversationsPayload.IsFiltering = true;
    this.conversationsPayload.Filters.SentBy = event.data.emailid;
    this.conversationsPayload.Filters.ReceivedDateFrom =  this.formatDate(event.data.startDate);  
    this.conversationsPayload.Filters.ReceivedDateTo =  this.formatDate(event.data.DateTo);
    this.conversationsPayload.Filters.WithAttachment =  this.formatDate(event.data.savedstartDate);  event.data.attachment === null ? false : event.data.attachment;
  }
  formatDate(date: Date, format?: string): string {
    if (date) {
        format = format || 'yyyy-MM-dd';
        return formatDate(date, format, 'en-US')
    }
    return '';
  }
  dataFromNotesFilter(event){
    this.dmsCommonPayload.Filters.NoteDueDate = this.formatDate(event.dueDate);
    this.dmsCommonPayload.Filters.NoteCreatedBy = event.createdBy;
    this.dmsCommonPayload.Filters.NoteAssignTo = event.assignTo;
    this.dmsCommonPayload.Filters.NoteStatus = event.noteStatus;
    this.isSameActionTakenOnFilter();
  }
  dataFromTagsFilter(event: string[]){
    this.dmsCommonPayload.Filters.TagList = event;
    this.isSameActionTakenOnFilter();
  }
  dataFromContact(event){
    if (event.from === 'groupList'){
      const selectedGroup = event?.data?.selectedContactGroup?.length > 0 ? event?.data?.selectedContactGroup[0] : '';
      this.dmsFilterService.contactListPayload.ContactGroupId = selectedGroup;
      this.dmsCommonPayload.Filters.ContactGroupId = selectedGroup;
      this.dmsCommonPayload.Filters.ContactList= [];
      this.isSameActionTakenOnFilter();
      this.fetchContactList();
    }else if (event.from === 'myrecentFiles'){
      if (event?.data?.myrecentFiles){
        let fromDate = new Date();
        const updatedDate = fromDate.setMonth(fromDate.getMonth() + -6);
        this.dmsCommonPayload.Filters.UserId = this.userInfo.UserId;
        this.dmsCommonPayload.Filters.DateFrom = this.datepipe.transform(new Date(updatedDate), 'yyyy-MM-dd');
        this.dmsCommonPayload.Filters.DateTo = this.datepipe.transform(new Date(), 'yyyy-MM-dd');
        this.dmsFilterService.userFullName = this.userInfo.UserFullName;
        this.dmsCommonPayload.Filters.MyRecentFiles = event?.data?.myrecentFiles;
        this.dmsFilterService.shareMyRecentActivity({event: true, data: this.dmsCommonPayload});
        this.isSameActionTakenOnFilter();
      }else {
        this.dmsCommonPayload.Filters.UserId = '';
        this.dmsCommonPayload.Filters.DateFrom = '';
        this.dmsCommonPayload.Filters.DateTo = '';
        this.dmsFilterService.userFullName = null;
        this.dmsCommonPayload.Filters.MyRecentFiles = event?.data?.myrecentFiles;
        this.dmsFilterService.shareMyRecentActivity({event: false, data: this.dmsCommonPayload});
        this.isSameActionTakenOnFilter();
      }
    }
    else {
      this.dmsFilterService.contactListPayload.IsArchivedContact = event?.data?.archivedContacts;
      this.dmsCommonPayload.Filters.IsArchivedContacts = event?.data?.archivedContacts === null ? true : !event?.data?.archivedContacts;
      this.dmsCommonPayload.Filters.ShowArchivedContactsCheckBox = event?.data?.archivedContacts === null ? false : event?.data?.archivedContacts;
      this.dmsCommonPayload.Filters.ContactList = event?.data?.selectedContactList;
      this.dmsCommonPayload.Filters.MyRecentFiles = event?.data?.myrecentFiles === null ? false : event?.data?.myrecentFiles;
      this.isSameActionTakenOnFilter();
    }
  }
  dataFromSearchContact(event){
    if (event?.type === 'contactListApiCall'){
      this.dmsFilterService.contactListPayload.SearchText = event.data.SearchText;
      this.dmsFilterService.contactListPayload.PageSize = event.data.PageSize;
      this.dmsFilterService.contactListPayload.PageNumber = event.data.PageNumber;
      this.fetchContactList();
    }else if (event?.type === 'contactGroupApiCall'){
      this.dmsFilterService.contactGroupPayload.SearchText = event.data.SearchText;
      this.dmsFilterService.contactGroupPayload.PageSize = event.data.PageSize;
      this.dmsFilterService.contactGroupPayload.PageNumber = event.data.PageNumber;
      this.fetchGroupContactList();
    }else 
    if (event?.type === 'userByApiCall' || event?.type === 'contactAssignToApi' || event?.type === 'contactCreatedByApi'){
      this.userListPayload.SearchText = event.data.SearchText;
      this.userListPayload.PageNumber = event.data.PageNumber;
      this.userListPayload.PageSize = event.data.PageSize;
      this.fetchUserData(event?.type);
    }
  }
  fetchUserfolderdata(event: string){
    this.dmsCommonPayload.Filters.UserFolders = parseInt(event);
    this.isSameActionTakenOnFilter();
  }
  applyFilter(){
    this.callClearFilter = false;
    const fromDate = new Date(this.dmsCommonPayload.Filters.DateFrom);
    const toDate = new Date(this.dmsCommonPayload.Filters.DateTo);
    if (fromDate?.getTime() > toDate?.getTime()){
      this.popupService.open<ErrorBoxComponent>(this.resourceService.getText('ifirm.common.error'),
    ErrorBoxComponent, { data: this.resourceService.get('dms.filters.errordate') });
    }else {
      const tempVariable = JSON.stringify(this.dmsCommonPayload.Filters)
      this.dmsFilterService.tempDefaultFilter = JSON.parse(tempVariable);
      this.callApplyFilter = true;
      if (this.selectedIndex === 'clientDocument'){
        const updateOnlyContactsApplied = this.compareOnlyContactUpdated();
        const payload = {
          payload: this.dmsCommonPayload,
          isOnlyContactSelected: this.isContactFilterRequired ? updateOnlyContactsApplied: false,
          isEmptyEvent: this.isEmptyEvent
        }
        this.gridService.filterEvent.next(payload);
      }
      
      else if (this.selectedIndex == 'crm')
      {
        this.conversationsService.showGridList = false;
        this.conversationsService.setPayload$(this.conversationsPayload);    
        this.conversationsService.loadEmailConversations(this.conversationsPayload);
      }
      else {
        this.recycleBinService.setPayloadSubject(this.dmsCommonPayload);
        if (this.dmsCommonPayload.IsFileSearch === true || this.dmsCommonPayload?.SearchTags?.Tags?.length > 0){
          this.dmsFirmDocService.setPayload$(this.dmsCommonPayload);
        }else {
          this.dmsFirmDocService.setPayload$(this.previousPayload);
        }
        
        this.recycleBinService.scrollTop();
        this.callParentComponent.emit(true);
      } 
      this.validateClearButton();
    }
    this.disableApplyFilter = true;
  }
  validateClearButton(){
    const originalData = this.dmsFilterService.defaultFilter;
    const updatedData = this.dmsFilterService.tempDefaultFilter;
    if (this.selectedIndex === 'firmDocument'){
        originalData.IsArchivedContacts = false;
    }
    const result = JSON.stringify(originalData) === JSON.stringify(updatedData);
    if (result){
      this.isClearFilter = false;
    }else {
      this.isClearFilter = true;
    }
  }
  clearFilterFun(){
    const tempVariable = JSON.stringify(this.dmsFilterService.defaultFilter)
    this.dmsFilterService.tempDefaultFilter = JSON.parse(tempVariable);
    this.isClearFilter = false;
    this.userListPayload.IsInactiveUser = false;
    const tempVariableOne = JSON.stringify(this.dmsFilterService.defaultFilter)
    this.dmsCommonPayload.Filters = JSON.parse(tempVariableOne);;
    this.dmsCommonPayload.IsFiltering = false;
    this.dmsCommonPayload.IsContentSearch = false;
    this.dmsCommonPayload.IsFileSearch = false;
    this.dmsCommonPayload.SearchMore = true;
    this.dmsCommonPayload.Page = 0;
    if (this.selectedIndex === 'clientDocument'){
      const payload = {
        payload: this.previousPayload,
        isOnlyContactSelected: false,
        isEmptyEvent: true
      }
      this.dmsService.clearSearchFilter.next(payload)
    }
    else if(this.selectedIndex === 'crm')
    {
     this.clearCrmFilter()
    }
    else {
      this.dmsCommonPayload.Filters.IsArchivedContacts = false;
      this.dmsCommonPayload.Filters.ShowArchivedContactsCheckBox = false;
      this.dmsCommonPayload.IsPurgeDate = false;
      this.recycleBinService.setPayloadSubject(this.dmsCommonPayload);
      // console.log("previous payload", this.previousPayload)
      if (this.dmsCommonPayload?.SearchTags?.Tags?.length === 0){
        this.dmsFirmDocService.setPayload$(this.previousPayload);
      }else {
        this.dmsFirmDocService.setPayload$(this.dmsCommonPayload);
      }
      
      this.callParentComponent.emit(true);
      this.recycleBinService.scrollTop();
    } 
    this.callClearFilter = true;
  }
  dataFromJobStatus(event: string){
    if (event == '2'){
      delete this.dmsCommonPayload.Filters.IsJobClosed
    }else {
      this.dmsCommonPayload.Filters.IsJobClosed = event;
    }
    this.isSameActionTakenOnFilter();
  }

  clearCrmFilter()
  {
    let crmObj = this.conversationsService.conversationsPayload();
    crmObj.EntityId = this.crmEntityId;
    crmObj.EntityType = this.crmEntityType;
    crmObj.IsFiltering = false;
      this.conversationsService.showGridList = false;
    this.conversationsService.setPayload$(crmObj);
    this.conversationsService.loadEmailConversations(crmObj);
  }
  isSameActionTakenOnFilter(){
    const original = JSON.stringify(this.dmsFilterService.tempDefaultFilter);
    const originalData = JSON.parse(original);
    const updated = JSON.stringify(this.dmsCommonPayload.Filters);
    const updatedData = JSON.parse(updated);
    if (this.selectedIndex === 'firmDocument'){
      originalData.IsArchivedContacts = false;
    }
    const result = JSON.stringify(originalData) === JSON.stringify(updatedData);
    if (!result){
      this.disableApplyFilter = false;
    }else {
      this.disableApplyFilter = true;
    }
    const tempDefaultData = JSON.stringify(this.dmsFilterService.defaultFilter);
    const defaultData = JSON.parse(tempDefaultData);
    if (this.selectedIndex === 'firmDocument'){
        defaultData.IsArchivedContacts = false;
    }
    const secondResult = JSON.stringify(defaultData) === JSON.stringify(updatedData)
    if (secondResult){
      this.dmsCommonPayload.IsFiltering = false;
      this.dmsCommonPayload.IsContentSearch = false;
      this.dmsCommonPayload.IsFileSearch = false;
      this.dmsCommonPayload.IsPurgeDate = false;
      this.dmsCommonPayload.SearchMore = true;
      this.isEmptyEvent = true;
    }else {
      this.isEmptyEvent = false;
      if (this.selectedIndex !== 'recycleBin'){
          this.userListPayload.IsInactiveUser = false;
      }
      this.dmsCommonPayload.IsFiltering = true;
      this.dmsCommonPayload.IsContentSearch = false;
      this.dmsCommonPayload.IsFileSearch = true;
      this.dmsCommonPayload.IsPurgeDate = false;
      this.dmsCommonPayload.SearchMore = false;
      this.dmsCommonPayload.Page = 0;
    }
  }
  compareOnlyContactUpdated(){
    const tempDefaultFilter = JSON.stringify(this.dmsFilterService.defaultFilter)
    const defaultFilter = JSON.parse(tempDefaultFilter);
    const tempNewFilters = JSON.stringify(this.dmsCommonPayload.Filters)
    const newFilters = JSON.parse(tempNewFilters);
    const deleteArray = ['ContactGroupId', 'ContactList', 'ShowArchivedContactsCheckBox', 'ShowInActiveUserCheckBox', 'IsInActiveUser', 'IsArchivedContacts'];
    deleteArray.forEach(element => {
      delete defaultFilter?.[element];
      delete newFilters?.[element];
    });
    const result = JSON.stringify(defaultFilter) === JSON.stringify(newFilters);
    return result;
  }
}
